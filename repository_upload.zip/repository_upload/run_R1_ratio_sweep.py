"""
run_R1_ratio_sweep.py - oil:PS ratio sweep for the co-hydropyrolysis route (paper Scenario 2; model Sc1).
Li et al. measured only oil:PS = 2.5; other ratios rescale Li's per-feed yields linearly (assumption, see
compounds.sc1_composition_for_ratio). Runs the BioSTEAM model for each ratio and H2 route and reports
MFSP (TEA) and well-to-wake GWP (same LCA settings as the paper base case).

Run from the Module_R1 folder (BioSTEAM environment):   python run_R1_ratio_sweep.py
Outputs: R1_outputs/Li25/R1_ratio_sweep.csv, R1_ratio_sweep_full.csv, R1_fig_ratio_sweep.png,
         R1_response/figs_word/FigS3_ratio_sweep.png
"""
import os, sys, traceback
ROOT = os.path.dirname(os.path.abspath(__file__))
SCRIPTS = os.path.join(ROOT, "tea_20260605_1634", "scripts")
sys.path.insert(0, ROOT); sys.path.insert(0, SCRIPTS)
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import run_R1_analysis as RA

RATIOS = (2.5, 2.75, 3.0, 3.25, 3.5, 3.75)
H2S = ("SMR", "SOEC", "Photocatalysis")
SHORT = {"SMR": "SMR", "SOEC": "SOEC", "Photocatalysis": "Photo"}
JET = 88.9


def main():
    import tea_model as tm
    import pyrolyzer as pz
    try:
        import make_lca as L
        factors = L.load_all_impacts()
    except Exception:
        traceback.print_exc(); L = None; factors = None
        print("!! LCA module not available - GWP columns will be empty")
    parity = 3.10 / tm.to_gge(1.0, 1)
    keep = dict(r=tm.OIL_TO_PS_RATIO, y=dict(tm.SCENARIO1_PYRO_YIELDS), liq=tm.SCENARIO1_LIQUID_FRACTION,
                pz=(pz.SCENARIO1_LIQUID_FRACTION, pz.SCENARIO1_CHAR_FRACTION, pz.SCENARIO1_GAS_FRACTION))
    rows = []
    try:
        for r in RATIOS:
            d = RA._apply_sc1_ratio(tm, r)
            for h2 in H2S:
                cfg = tm.simulate_config(1, h2)
                t = tm.run_tea(cfg)
                row = dict(scenario=f"S2 co-hydropyrolysis + {SHORT[h2]}", h2_source=h2, oil_to_PS_ratio=r,
                           status="measured (Li et al.)" if r == 2.5 else "extrapolated",
                           PS_mass_fraction=1 / (1 + r), liquid_yield_wt_pct=d["liq"] * 100,
                           oil_kg_hr=cfg["streams"]["oil_kg_hr"], oil_t_per_day=cfg["streams"]["oil_kg_hr"] * 0.024,
                           product_kg_hr=cfg["saf_kg_hr"], H2_kg_hr=cfg.get("H2_demand"),
                           aromatics_wt_pct=d["aromatics_wt"] * 100, aromatics_vol_pct=d["aromatics_vol"] * 100,
                           TCI_MM=t.get("TCI", float("nan")) / 1e6, MFSP_usd_per_kg=t["mfsp_per_kg"],
                           MFSP_usd_per_GJ=t["mfsp_per_kg"] / tm.SAF_LHV_MJ_KG * 1000,
                           vs_parity_pct=(t["mfsp_per_kg"] / parity - 1) * 100,
                           feedstock=t.get("feedstock_contr"), capital=t.get("capital_contr"))
                if L is not None:
                    try:
                        inv = L.compute_inventory(cfg)
                        res, _ = L.compute_impacts_per_kg(inv, factors)
                        g = res["Global warming"] / inv["lhv"] * 1e3
                        row.update(GWP_g_per_MJ=g, GWP_reduction_vs_JetA_pct=100 * (1 - g / JET),
                                   fossil_carbon_share=inv.get("fossil_share"))
                    except Exception:
                        traceback.print_exc()
                rows.append(row)
                print(f"oil:PS {r:4.2f}  {h2:15s}  MFSP {t['mfsp_per_kg']:.3f} $/kg"
                      + (f"  GWP {row['GWP_g_per_MJ']:.1f} g/MJ" if "GWP_g_per_MJ" in row else ""))
    finally:
        tm.OIL_TO_PS_RATIO = keep["r"]
        tm.SCENARIO1_PYRO_YIELDS.clear(); tm.SCENARIO1_PYRO_YIELDS.update(keep["y"])
        tm.SCENARIO1_LIQUID_FRACTION = keep["liq"]
        pz.SCENARIO1_LIQUID_FRACTION, pz.SCENARIO1_CHAR_FRACTION, pz.SCENARIO1_GAS_FRACTION = keep["pz"]

    df = pd.DataFrame(rows)
    out = os.path.join(ROOT, "R1_outputs", "Li25"); os.makedirs(out, exist_ok=True)
    df.to_csv(os.path.join(out, "R1_ratio_sweep_full.csv"), index=False)
    df.to_csv(os.path.join(out, "R1_ratio_sweep.csv"), index=False)

    # figure (Word-sized, 6.5 in wide)
    plt.rcParams.update({"font.family": ["Arial", "Liberation Sans", "DejaVu Sans"], "font.size": 9.5,
                         "axes.spines.top": False, "axes.spines.right": False})
    col = {"SMR": "#1f4e79", "SOEC": "#4a90c2", "Photocatalysis": "#e0a030"}
    has_gwp = "GWP_g_per_MJ" in df
    fig, axs = plt.subplots(1, 2 if has_gwp else 1, figsize=(6.5, 3.4), squeeze=False)
    a = axs[0][0]
    for h2 in H2S:
        g = df[df.h2_source == h2]
        a.plot(g.oil_to_PS_ratio, g.MFSP_usd_per_kg, marker="o", ms=4, color=col[h2], label=SHORT[h2])
    a.axhline(parity, color="crimson", ls="--", lw=1, label=f"parity ${parity:.2f}/kg")
    a.set_xlabel("Waste oil : PS mass ratio"); a.set_ylabel("MFSP ($/kg)"); a.set_title("(a) MFSP", fontsize=10)
    if has_gwp:
        b = axs[0][1]
        for h2 in H2S:
            g = df[df.h2_source == h2]
            b.plot(g.oil_to_PS_ratio, g.GWP_g_per_MJ, marker="o", ms=4, color=col[h2], label=SHORT[h2])
        b.set_xlabel("Waste oil : PS mass ratio"); b.set_ylabel("GWP (g CO$_2$e/MJ, well-to-wake)"); b.set_title("(b) GWP", fontsize=10)
    for ax in axs[0]:
        ax.axvspan(2.52, RATIOS[-1] + 0.05, color="#efefef", zorder=0)
        ax.text(2.5, ax.get_ylim()[1], " measured", fontsize=8, va="top")
    h, l = a.get_legend_handles_labels()
    fig.legend(h, l, ncol=4, fontsize=8.5, frameon=False, loc="lower center", bbox_to_anchor=(0.5, -0.04))
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    fig.savefig(os.path.join(out, "R1_fig_ratio_sweep.png"), dpi=300)
    fw = os.path.join(ROOT, "R1_response", "figs_word"); os.makedirs(fw, exist_ok=True)
    fig.savefig(os.path.join(fw, "FigS3_ratio_sweep.png"), dpi=300); plt.close(fig)
    pd.set_option("display.width", 200)
    print(df.round(3).to_string())
    print("\nSaved:", os.path.join(out, "R1_ratio_sweep.csv"))


if __name__ == "__main__":
    main()
