"""run_R1_cases.py - run the R1 analysis for BOTH Scenario-1 cases and write a side-by-side comparison.

  Li25     : Li et al. 2025 AS MEASURED (waste oil : PS = 2.5)            -> R1_outputs/Li25/
  Extrap34 : EXTRAPOLATION beyond Li's tested ratio (oil : PS = 3.4,
             aromatics 23-25 vol%)                                         -> R1_outputs/Extrap34/
Usage (from Module_R1):  python run_R1_cases.py        (each case takes as long as one run_R1_analysis.py)
"""
import os, subprocess, sys
import pandas as pd

ROOT = os.path.dirname(os.path.abspath(__file__))
frames = {}
for case in ("Li25", "Extrap34"):
    env = dict(os.environ, SC1_CASE=case)
    print(f"\n===== case {case} =====", flush=True)
    subprocess.run([sys.executable, os.path.join(ROOT, "run_R1_analysis.py")], cwd=ROOT, env=env, check=True)
    d = os.path.join(ROOT, "R1_outputs", case)
    eq = pd.read_csv(os.path.join(d, "R1_equal_basis.csv"))
    mc = pd.read_csv(os.path.join(d, "R1_mc_summary.csv"))
    f = eq[eq.basis.str.startswith("equal PS feed")][["scenario", "product_kg_hr", "MFSP_usd_per_kg", "vs_parity_pct"]]
    f = f.merge(mc[["scenario", "P5", "P50", "P95", "prob_below_parity"]], on="scenario")
    frames[case] = f.set_index("scenario")
cmp = pd.concat(frames, axis=1)
out = os.path.join(ROOT, "R1_outputs", "R1_case_comparison.csv")
cmp.to_csv(out)
print("\nSide-by-side (Li25 = as measured, Extrap34 = extrapolation):")
print(cmp.round(3).to_string())
print("\nWritten:", out)
