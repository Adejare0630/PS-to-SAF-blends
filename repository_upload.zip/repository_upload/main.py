#%%
# SAF-from-PS simulation: 3 scenarios × 3 H2 sources → TEA, PFDs, plots
# Basis: 250 metric tons/day polystyrene feedstock
#%%
import os
import sys
import warnings
warnings.filterwarnings('ignore')

# Ensure graphviz binaries are on PATH (installed at default Windows location)
_gv_bin = r"C:\Program Files\Graphviz\bin"
if os.path.isdir(_gv_bin) and _gv_bin not in os.environ.get("PATH", ""):
    os.environ["PATH"] = _gv_bin + os.pathsep + os.environ.get("PATH", "")
#%%
import numpy as np
import sys as _s, os as _o
_s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
import scenario_relabel  # R1.14: display swap Sc1<->Sc2 (set SCENARIO_RELABEL=0 to disable)
import matplotlib
# Pick the display mode explicitly rather than relying on whatever the
# frontend may or may not have already configured:
#   - Inside a Jupyter/IPython kernel (VS Code Interactive Window, #%% cells)
#     -- force the `inline` backend via the %matplotlib magic. This is what
#     actually makes plt.show() render a figure below the cell; without it
#     the kernel's default backend is not guaranteed to be inline, and a
#     manually-selected GUI backend (e.g. TkAgg) can't take over figures
#     created under a different backend mid-session -- doing so leaves stale
#     figure managers in Gcf's registry and plt.show() crashes with
#     "FigureManagerBase has no attribute '_owns_mainloop'".
#   - Plain script (`python main.py` from a terminal) -- use TkAgg so
#     plt.show() opens real windows.
try:
    _ip = get_ipython()
except NameError:
    _ip = None
if _ip is not None:
    _ip.run_line_magic('matplotlib', 'inline')
else:
    matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import matplotlib.patches as mpatches

import biosteam as bst
import thermosteam as tmo
#%%
# ── local modules ──────────────────────────────────────────────────────────────
# Make compounds.py, pyrolyzer.py, ... importable however this file is run (python main.py, or the
# VS Code Interactive Window, which may start the kernel in another folder and define no __file__).
# Kept in this cell so it also works when this cell is run on its own.
import os, sys
_HERE = next(d for d in (os.path.dirname(os.path.abspath(p)) for p in
                         (globals().get("__vsc_ipynb_file__"), globals().get("__file__"),
                          r"c:\Users\adesi\Module\Module_R1\main.py") if p)
             if os.path.isfile(os.path.join(d, "compounds.py")))
__file__ = os.path.join(_HERE, "main.py")          # used later for output paths
if _HERE in sys.path:
    sys.path.remove(_HERE)
sys.path.insert(0, _HERE)                           # first, so this folder's modules win
os.chdir(_HERE)
# Drop any copies of this folder's modules the kernel already holds, so edits to compounds.py etc.
# take effect without restarting the kernel (otherwise stale copies raise "cannot import name ...").
# Only these named modules: never __main__ or tea_bridge, which re-runs this file while it is importing.
for _m in ("compounds", "pretreatment", "pyrolyzer", "hydrogen_production", "hydrogenation", "tea"):
    _mod = sys.modules.get(_m)
    if _mod is not None and os.path.dirname(os.path.abspath(getattr(_mod, "__file__", None) or "")) == _HERE:
        del sys.modules[_m]
from compounds import (define_chemicals,
                       SCENARIO1_LIQUID_FRACTION, SCENARIO2_LIQUID_FRACTION,
                       SCENARIO1_PYRO_YIELDS, HYDROGENATION_CONVERSION, OIL_HDO_H2_KG_PER_KG_OIL, SC1_OIL_TO_PS_RATIO,
                       SCENARIO2_PYRO_YIELDS, SELECTIVE_H2_STOICH,
                       SC2_EXTENDED_HYDRO_CONVERSION, SC2_EXTENDED_H2_STOICH, sc2_h2_demand_kg_hr, SC2_DISTILL16, SC2_ENDS_LHV_MJ_KG, SC2_CASE,
                       PRETREAT_MOISTURE_FRAC, PRETREAT_CONTAM_FRAC, PRETREAT_PS_LOSS_FRAC)
from pretreatment import PSPretreatmentUnit
from pyrolyzer import Pyrolyzer
from hydrogen_production import SMR_H2Unit, Photocatalysis_H2Unit, SOEC_H2Unit
from hydrogenation import HydrogenationUnit, SelectiveHydrogenationUnit, SPKBlendingUnit
from tea import SAF_TEA_Parameters
#%%
# ── constants ──────────────────────────────────────────────────────────────────
PS_FEED_KG_HR = 250_000 / 24   # 250 MT/day polystyrene → ~10,416.67 kg/hr
import os as _os_r1
SC2_FEED_SCALE = float(_os_r1.environ.get("SC2_FEED_SCALE", 1.0))   # R1.4 equal-product basis (1.0 = as submitted)

H2_CONFIGS = {
    'SMR':            {'label': 'SMR',           'color': '#e74c3c', 'marker': 'o'},
    'Photocatalysis': {'label': 'Photocatalysis', 'color': '#2ecc71', 'marker': 's'},
    'SOEC':           {'label': 'SOEC (NGCC)',    'color': '#3498db', 'marker': '^'},
}

SCENARIO_LABELS = {
    1: 'Scenario 1\n(Co-hydropyrolysis, Pd/SBA-15)',
    2: 'Scenario 2\n(EB-rich oil + SPK 1:1 blend)',
}
#%%
# ══════════════════════════════════════════════════════════════════════════════
# 1.  Chemistry setup
# ══════════════════════════════════════════════════════════════════════════════
def setup_chemicals():
    chems = define_chemicals()
    print("Chemicals registered with thermosteam.")
    return chems

#%%
# ══════════════════════════════════════════════════════════════════════════════
# 2.  Build a single scenario + H2-source flowsheet
# ══════════════════════════════════════════════════════════════════════════════
def build_flowsheet(scenario: int, h2_source: str,
                    params: SAF_TEA_Parameters,
                    electricity_price: float = None,
                    ch4_price: float = None) -> dict:
    """
    Instantiate and simulate one process configuration.
    Feedstock basis: PS_FEED_KG_HR kg/hr polystyrene (250 MT/day, fixed).

    Scenario 1: Co-hydropyrolysis (waste oil : PS = 2.5, Li et al. 2025), Pd/SBA-15, full ring saturation.
    Scenario 2: PS-only → selective vinyl hydrogenation → ethylbenzene + SPK blend (50:50).

    electricity_price / ch4_price: optional overrides (USD/kWh, USD/GJ) passed
    through to the H2 unit; when omitted, each unit keeps its own built-in default.

    Returns a dict with unit objects, TEA inputs, and CO2 intensity.
    """
    # ── fixed raw PS feed (plant-gate intake, before pretreatment) ────────────
    raw_ps_kg_hr = PS_FEED_KG_HR * (SC2_FEED_SCALE if scenario == 2 else 1.0)   # 250 MT/day (x scale for equal-product basis)

    # Pretreatment (shred/wash/dry) recovers clean PS from the raw bale stream.
    # Computed analytically here too (deterministic fraction-based mass
    # balance, matches PSPretreatmentUnit._run() exactly) so downstream sizing
    # (oil co-feed ratio, H2 demand) can proceed before the unit object below
    # is instantiated -- the same pattern already used for H2_demand.
    _ps_in_kg_hr = raw_ps_kg_hr * (1 - PRETREAT_MOISTURE_FRAC - PRETREAT_CONTAM_FRAC)
    ps_kg_hr     = _ps_in_kg_hr * (1 - PRETREAT_PS_LOSS_FRAC)   # clean PS reaching the pyrolyzer

    if scenario == 1:
        oil_kg_hr    = ps_kg_hr * float(_os_r1.environ.get("OIL_TO_PS_RATIO", SC1_OIL_TO_PS_RATIO))   # R2.1: set by SC1_CASE (Li25 = 2.5 as measured; Extrap34 = 3.4)
        total_feed   = ps_kg_hr + oil_kg_hr
        liq_frac     = SCENARIO1_LIQUID_FRACTION      # case-dependent (compounds.py: Li25 0.84 / Extrap34 0.828)
        catalyst     = 'Pd/SBA-15'
        pyro_sc      = 1
    else:   # scenario 2 — PS-only pyrolysis → selective hydro → EB + SPK blend
        oil_kg_hr    = 0.0
        total_feed   = ps_kg_hr
        liq_frac     = SCENARIO2_LIQUID_FRACTION      
        catalyst     = 'Pd/C' if SC2_DISTILL16 else 'Pd/Al2O3'
        pyro_sc      = 2   # PS-only pyrolysis yields

    liq_kg_hr = total_feed * liq_frac

    # ── H2 demand ─────────────────────────────────────────────────────────────
    if scenario == 2:
        # R1: single-source Sc2 H2 demand (compounds.sc2_h2_demand_kg_hr): vinyl-only + oligomer H2
        H2_demand = sc2_h2_demand_kg_hr(liq_kg_hr)
    else:
        # R1: vinyl-selective hydrogenation (ring preserved, Li et al.) — per-species stoichiometric H2 demand,
        # matching HydrogenationUnit's own HYDROGENATION_CONVERSION / H2_CONSUMPTION_RATIO
        # chemistry (previously a flat 0.06 kg H2/kg liquid heuristic overestimated
        # demand ~1.8x relative to the reactor's actual per-species consumption).
        H2_demand = 0.0
        for _sp, (_, _conv) in HYDROGENATION_CONVERSION.items():
            _sp_kg_hr = liq_kg_hr * SCENARIO1_PYRO_YIELDS.get(_sp, 0.0)
            H2_demand += _sp_kg_hr * _conv * HydrogenationUnit.H2_CONSUMPTION_RATIO.get(_sp, 0.06)
        H2_demand += oil_kg_hr * OIL_HDO_H2_KG_PER_KG_OIL   # R1: oxygen removal from waste oil (assumption)

    # ── stream creation ───────────────────────────────────────────────────────
    # Raw PS bales -> pretreatment (shred/wash/dry) -> clean PS to pyrolyzer.
    s_ps_raw     = bst.Stream('s_ps_raw', Polystyrene=raw_ps_kg_hr, units='kg/hr', phase='s')
    s_wash_water = bst.Stream('s_wash_water')   # flow set internally by PSPretreatmentUnit
    pretreat_kwargs = {} if electricity_price is None else {'electricity_price': electricity_price}
    pretreat = PSPretreatmentUnit(
        'Pretreat', ins=[s_ps_raw, s_wash_water],
        outs=[bst.Stream('s_ps'), bst.Stream('pretreat_reject')],
        **pretreat_kwargs,
    )
    pretreat.simulate()

    s_ps  = pretreat.outs[0]
    s_oil = bst.Stream('s_oil', WasteCookingOil=oil_kg_hr, units='kg/hr', phase='l')

    if h2_source == 'SMR':
        s_ch4   = bst.Stream('s_ch4',   Methane=1.0, units='kg/hr')
        s_steam = bst.Stream('s_steam', Water=1.0,   units='kg/hr')
        smr_kwargs = {} if ch4_price is None else {'CH4_price': ch4_price}
        h2_unit = SMR_H2Unit(
            'H2_SMR', ins=[s_ch4, s_steam],
            outs=[bst.Stream('h2_out'), bst.Stream('flue')],
            H2_demand=H2_demand, **smr_kwargs,
        )
    elif h2_source == 'Photocatalysis':
        s_water = bst.Stream('s_water_pc', Water=1.0, units='kg/hr')
        pc_kwargs = {} if electricity_price is None else {'electricity_price': electricity_price}
        h2_unit = Photocatalysis_H2Unit(
            'H2_PC', ins=[s_water],
            outs=[bst.Stream('h2_out'), bst.Stream('o2_pc')],
            H2_demand=H2_demand, **pc_kwargs,
        )
    else:   # SOEC
        s_water_se = bst.Stream('s_water_se', Water=1.0, units='kg/hr')
        s_elec     = bst.Stream('s_elec')
        soec_kwargs = {} if electricity_price is None else {'electricity_price': electricity_price}
        h2_unit = SOEC_H2Unit(
            'H2_SOEC', ins=[s_water_se, s_elec],
            outs=[bst.Stream('h2_out'), bst.Stream('o2_soec')],
            H2_demand=H2_demand, **soec_kwargs,
        )
    h2_co2_factor = h2_unit.CO2_emissions_kg_per_kgH2

    # ── unit operations ───────────────────────────────────────────────────────
    pyrolyzer = Pyrolyzer(
        'Pyrolyzer', ins=[s_ps, s_oil],
        outs=[bst.Stream('pyro_oil'), bst.Stream('char'), bst.Stream('gas')],
        scenario=pyro_sc,
    )
    pyrolyzer.simulate()
    h2_unit.simulate()

    if scenario == 1:
        hydro = HydrogenationUnit(
            'Hydrogenation',
            ins=[pyrolyzer.outs[0], h2_unit.outs[0]],
            outs=[bst.Stream('saf'), bst.Stream('offgas')],
            scenario=1, catalyst=catalyst,
        )
    else:   # scenario 2
        hydro = SelectiveHydrogenationUnit(
            'SelHydro',
            ins=[pyrolyzer.outs[0], h2_unit.outs[0]],
            outs=[bst.Stream('eb_oil'), bst.Stream('offgas')],
        )
    hydro.simulate()

    # ── Scenario 2: EB extraction + SPK blending (50:50 by mass) ─────────────
    # SPKBlendingUnit sets spk_feed flow internally so that SPK == EB (50:50).
    # The EB recovery from distillation is 95 %; bottoms go to fuel/recycle.
    if scenario == 2:
        s_spk   = bst.Stream('s_spk', SPK=1.0, units='kg/hr', phase='l')
        blender = SPKBlendingUnit(
            'SPKBlender',
            ins=[hydro.outs[0], s_spk],
            outs=[bst.Stream('eb_spk_blend'), bst.Stream('dist_bottoms')],
        )
        blender.simulate()

        eb_kg_hr              = blender.eb_kg_hr
        spk_kg_hr             = blender.spk_kg_hr   # additive*(1-w)/w
        blend_kg_hr           = blender.blend_kg_hr
        product_kg_hr         = blend_kg_hr
        spk_feedstock_cost_hr = spk_kg_hr * params.SPK_price

        print(f"\n    [Sc2 SPK blend]  EB-rich oil = {eb_kg_hr:,.1f} kg/hr  |  "
              f"SPK = {spk_kg_hr:,.1f} kg/hr  |  "
              f"Blend = {blend_kg_hr:,.1f} kg/hr  [{SC2_CASE}; other ends = {blender.ends_kg_hr:,.1f} kg/hr]", end='')
    else:   # scenario 1
        blender               = None
        eb_kg_hr              = 0.0
        spk_kg_hr             = 0.0
        blend_kg_hr           = 0.0
        product_kg_hr         = hydro.outs[0].F_mass
        spk_feedstock_cost_hr = 0.0

    # ── purchase costs ────────────────────────────────────────────────────────
    total_purchase_cost = (
        sum(pretreat.purchase_costs.values())
        + sum(pyrolyzer.purchase_costs.values())
        + sum(h2_unit.purchase_costs.values())
        + sum(hydro.purchase_costs.values())
        + (sum(blender.purchase_costs.values()) if blender else 0.0)
    )

    # ── utility costs (USD/hr) ────────────────────────────────────────────────
    utility_cost_hr = (
        pretreat.utility_cost + pretreat._utility_cost_hr
        + pyrolyzer.utility_cost
        + h2_unit._utility_cost_hr
        + hydro.utility_cost
        + (blender.utility_cost if blender else 0.0)
    )

    # ── feedstock costs (USD/hr) ──────────────────────────────────────────────
    # Priced on the RAW PS intake (what the plant actually purchases/collects),
    # not the clean PS reaching the pyrolyzer after pretreatment losses.
    feedstock_cost_hr = (
        raw_ps_kg_hr  * params.PS_price
        + oil_kg_hr * params.waste_oil_price
        + spk_feedstock_cost_hr   # non-zero for Sc2 only
    )

    # ── byproduct revenues (USD/hr) ───────────────────────────────────────────
    char_kg_hr = pyrolyzer.outs[1].F_mass
    byproduct_revenue_hr = char_kg_hr * params.char_price
    if blender is not None and getattr(blender, 'ends_kg_hr', 0.0) > 0:   # R1: Prajapati16 other-ends credited at fuel (heat) value only
        byproduct_revenue_hr += blender.ends_kg_hr * SC2_ENDS_LHV_MJ_KG / 1000.0 * 6.50   # 6.50 USD/GJ = tea_model HEAT_PRICE_GJ

    # ── CO2 intensity ─────────────────────────────────────────────────────────
    co2_kg_per_kgSAF = (h2_co2_factor * H2_demand) / max(product_kg_hr, 1e-6)

    return {
        'scenario':             scenario,
        'h2_source':            h2_source,
        'pretreat':             pretreat,
        'pyrolyzer':            pyrolyzer,
        'h2_unit':              h2_unit,
        'hydro':                hydro,
        'blender':              blender,          # SPKBlendingUnit (Sc2) or None
        'total_purchase_cost':  total_purchase_cost,
        'utility_cost_hr':      utility_cost_hr,
        'feedstock_cost_hr':    feedstock_cost_hr,
        'byproduct_revenue_hr': byproduct_revenue_hr,
        'saf_out_kg_hr':        product_kg_hr,    # = blend_kg_hr for Sc2
        'co2_kg_per_kgSAF':     co2_kg_per_kgSAF,
        'H2_demand':            H2_demand,
        'ps_kg_hr':             ps_kg_hr,          # clean PS reaching the pyrolyzer (post-pretreatment)
        'raw_ps_kg_hr':         raw_ps_kg_hr,      # raw PS purchased/collected (250 MT/day, pricing basis)
        'pretreat_reject_kg_hr': pretreat.outs[1].F_mass,
        # SPK blending detail (Sc2 only; zero for Sc1)
        'eb_kg_hr':             eb_kg_hr,
        'spk_kg_hr':            spk_kg_hr,
        'ends_kg_hr':           (blender.ends_kg_hr if blender is not None else 0.0),
        'blend_kg_hr':          blend_kg_hr,
    }
#%%
# ══════════════════════════════════════════════════════════════════════════════
# 2b.  tea_bridge / tea_model access (lazy import — avoids a circular import,
#      since tea_bridge.py loads a fresh copy of this file to grab build_flowsheet)
# ══════════════════════════════════════════════════════════════════════════════
def _load_tea_bridge():
    scripts_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               'tea_20260605_1634', 'scripts')
    if scripts_dir not in sys.path:
        sys.path.insert(0, scripts_dir)
    import tea_bridge as tb
    import tea_model as tm
    return tb, tm


MARKET_PRICE_USD_KG = 1.09   # R1: fossil-jet parity ($/kg); the premium-SAF $1.80/$1.94 case was removed


def _irr_from_cashflows(annual_cf):
    """Newton-Raphson equity IRR from an annual cash-flow array (same style as
    the original tea.py compute_NPV, applied to tea_model's DCFROR cash flows,
    which don't themselves depend on the discount rate)."""
    rate = 0.10
    for _ in range(200):
        f  = sum(cf / (1 + rate) ** t for t, cf in enumerate(annual_cf))
        df = sum(-t * cf / (1 + rate) ** (t + 1) for t, cf in enumerate(annual_cf))
        if abs(df) < 1e-12:
            break
        rate -= f / df
        rate  = max(-0.99, min(rate, 5.0))
    return rate


# ══════════════════════════════════════════════════════════════════════════════
# 3.  Run all 6 configurations — priced with the corrected NREL/Humbird 2011
#     DCFROR engine (tea_model.py) via tea_bridge.py, the same engine used for
#     tea_report.md / tea_report.pptx.
# ══════════════════════════════════════════════════════════════════════════════
def run_all_configurations():
    tb, tm = _load_tea_bridge()
    RES = tb.simulate_all()

    results = {}
    for key, res in RES.items():
        sc, h2_src = key
        FCI = res['FCI']
        WC  = res['WC']
        VOC_annual = (res['utility_cost_hr'] + res['feedstock_cost_hr']) * tm.OPERATING_HR
        FOC_annual = tm.fixed_operating_cost(FCI)
        byproduct_annual = res['byproduct_revenue_hr'] * tm.OPERATING_HR
        product_kg_yr     = res['saf_kg_hr'] * tm.OPERATING_HR

        npv_usd = tm.npv_at_price(FCI, WC, VOC_annual, FOC_annual, product_kg_yr,
                                   byproduct_annual, MARKET_PRICE_USD_KG)
        year_labels, annual_cf, cum_undiscounted, _ = tm.compute_cashflows(
            FCI, WC, VOC_annual, FOC_annual, product_kg_yr, byproduct_annual,
            MARKET_PRICE_USD_KG)
        irr     = _irr_from_cashflows(annual_cf)
        payback = next((yr for yr, c in zip(year_labels, cum_undiscounted) if c >= 0), None)

        results[key] = {
            **res,
            # backward-compatible summary fields for the dashboard/plot functions below
            'MSP (USD/kg SAF)':     res['mfsp_per_kg'],
            'NPV (MM USD)':         npv_usd / 1e6,
            'IRR (%)':              irr * 100,
            'TCI (MM USD)':         res['TCI'] / 1e6,
            'Payback period (yr)':  payback if payback is not None else '>30',
            'Feedstock cost (MM USD/yr)': res['feedstock_cost_hr'] * tm.OPERATING_HR / 1e6,
            'Utility cost (MM USD/yr)':   res['utility_cost_hr']   * tm.OPERATING_HR / 1e6,
            'Maintenance (MM USD/yr)':    FCI * tm.MAINTENANCE_FRAC   / 1e6,
            'Labor (MM USD/yr)':          tm.labor_cost(FCI) / 1e6,
            'Insurance (MM USD/yr)':      FCI * tm.INSURANCE_TAX_FRAC / 1e6,
            'Overhead (MM USD/yr)':       0.0,
            '_FCI': FCI, '_WC': WC, '_VOC_annual': VOC_annual, '_FOC_annual': FOC_annual,
            '_byproduct_annual': byproduct_annual, '_product_kg_yr': product_kg_yr,
        }
        prod_label = 'blend' if sc == 2 else 'SAF'
        print(f"  Simulating Scenario {sc} + {h2_src} ... "
              f"MSP = ${res['mfsp_per_kg']:.2f}/kg {prod_label}  |  "
              f"NPV = ${npv_usd/1e6:.1f} MM  |  "
              f"CO2 = {res['co2_kg_per_kgSAF']:.3f} kg/kg {prod_label}")

    return results

#%%
# ══════════════════════════════════════════════════════════════════════════════
# 4.  PFD generation (schematic block diagram, 9 panels)
# ══════════════════════════════════════════════════════════════════════════════
def draw_pfd(ax, scenario, h2_source, result):
    """Draw a schematic PFD for one configuration onto ax."""
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 6)
    ax.axis('off')

    cfg   = H2_CONFIGS[h2_source]
    color = cfg['color']

    def box(x, y, w, h, label, bg='#ecf0f1', fontsize=7):
        rect = FancyBboxPatch((x, y), w, h,
                              boxstyle='round,pad=0.1',
                              facecolor=bg, edgecolor='#2c3e50', linewidth=1.2)
        ax.add_patch(rect)
        ax.text(x + w / 2, y + h / 2, label, ha='center', va='center',
                fontsize=fontsize, fontweight='bold', wrap=True,
                multialignment='center')

    def arrow(x1, y1, x2, y2, label='', col='#7f8c8d'):
        ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                    arrowprops=dict(arrowstyle='->', color=col, lw=1.4))
        if label:
            mx, my = (x1 + x2) / 2, (y1 + y2) / 2
            ax.text(mx, my + 0.15, label, ha='center', va='bottom',
                    fontsize=6, color='#555')

    h2_labels = {
        'SMR':            'SMR Unit\n(CH₄+H₂O→H₂)',
        'Photocatalysis': 'Photocatalytic\nSplitting\n(Solar, 5% STH)',
        'SOEC':           'SOEC Unit\n(H₂O→H₂, NGCC)',
    }

    if scenario == 1:
        # ── feedstock ────────────────────────────────────────────────────────
        box(0.2, 4.0, 1.5, 0.8, 'Waste\nPS Feed', bg='#ffeaa7')
        box(0.2, 2.8, 1.5, 0.8, 'Waste\nCooking Oil', bg='#ffeaa7')

        # ── pyrolyzer ────────────────────────────────────────────────────────
        box(2.2, 3.2, 2.0, 1.2, 'Co-Hydropyrolysis\nReactor\n480 °C, 0.15 MPa H₂', bg='#fab1a0')
        arrow(1.7, 4.4, 2.2, 3.9, 'PS')
        arrow(1.7, 3.2, 2.2, 3.6, 'Oil')
        ax.text(4.25, 2.5, '← Char',    fontsize=6, color='#636e72')
        ax.annotate('', xy=(4.2, 2.8), xytext=(3.2, 3.2),
                    arrowprops=dict(arrowstyle='->', color='#636e72', lw=1))
        ax.text(4.25, 4.7, '← Off-gas', fontsize=6, color='#636e72')
        ax.annotate('', xy=(4.2, 4.6), xytext=(3.2, 4.4),
                    arrowprops=dict(arrowstyle='->', color='#636e72', lw=1))

        # ── H2 unit ──────────────────────────────────────────────────────────
        box(2.2, 1.0, 2.0, 1.0, h2_labels[h2_source], bg='#a29bfe')
        arrow(3.4, 1.0, 5.5, 2.5, 'H₂')

        # ── hydrogenation ────────────────────────────────────────────────────
        box(5.5, 2.8, 2.0, 1.2, 'Pd/SBA-15\nHydrogenation\n350 °C', bg='#81ecec')
        arrow(4.2, 3.8, 5.5, 3.8, 'Pyro-oil')

        # ── separation + product ─────────────────────────────────────────────
        box(8.0, 3.0, 1.7, 1.0, 'Distillation\n& Separation', bg='#dfe6e9')
        arrow(7.5, 3.8, 8.0, 3.5, '')
        box(8.0, 4.5, 1.7, 0.8, 'SAF Product\n(C8–C16)', bg='#55efc4')
        ax.annotate('', xy=(8.85, 4.5), xytext=(8.85, 4.0),
                    arrowprops=dict(arrowstyle='->', color='#00b894', lw=1.5))

        sc_title = 'Sc1: Co-Hydropyrolysis'

    else:   # scenario == 2
        # ── feedstock ────────────────────────────────────────────────────────
        box(0.2, 4.0, 1.5, 0.8, 'Waste\nPS Feed', bg='#ffeaa7')

        # ── pyrolyzer ────────────────────────────────────────────────────────
        box(2.2, 3.2, 2.0, 1.2, 'PS Pyrolysis\nReactor\n550 °C, atm', bg='#fab1a0')
        arrow(1.7, 4.4, 2.2, 3.9, 'PS')
        ax.text(4.25, 2.5, '← Char',    fontsize=6, color='#636e72')
        ax.annotate('', xy=(4.2, 2.8), xytext=(3.2, 3.2),
                    arrowprops=dict(arrowstyle='->', color='#636e72', lw=1))
        ax.text(4.25, 4.7, '← Gas',     fontsize=6, color='#636e72')
        ax.annotate('', xy=(4.2, 4.6), xytext=(3.2, 4.4),
                    arrowprops=dict(arrowstyle='->', color='#636e72', lw=1))

        # ── H2 unit (small — selective hydro only) ───────────────────────────
        box(2.2, 1.0, 2.0, 1.0, h2_labels[h2_source], bg='#a29bfe')
        arrow(3.4, 1.0, 5.5, 2.5, 'H₂')

        # ── selective hydrogenation ──────────────────────────────────────────
        box(5.5, 2.8, 2.0, 1.2,
            'Extended\nHydrogenation\n200 °C, Pd/Al₂O₃', bg='#81ecec')
        arrow(4.2, 3.8, 5.5, 3.8, 'Pyro-oil')

        # ── SPK purchased + blending ─────────────────────────────────────────
        box(8.0, 1.5, 1.7, 0.8, 'SPK\n(purchased)', bg='#ffeaa7')
        box(8.0, 3.0, 1.7, 1.0, 'Blending\n(50 : 50)', bg='#dfe6e9')
        arrow(7.5, 3.4, 8.0, 3.5, 'EB')
        ax.annotate('', xy=(8.85, 3.0), xytext=(8.85, 2.3),
                    arrowprops=dict(arrowstyle='->', color='#7f8c8d', lw=1.2))

        # ── EB-SPK blend product ─────────────────────────────────────────────
        box(8.0, 4.5, 1.7, 0.8, 'EB-SPK Blend\n(50:50 SAF)', bg='#55efc4')
        ax.annotate('', xy=(8.85, 4.5), xytext=(8.85, 4.0),
                    arrowprops=dict(arrowstyle='->', color='#00b894', lw=1.5))

        sc_title = 'Sc2: EB + SPK Blend'

    # ── title ─────────────────────────────────────────────────────────────────
    ax.set_title(f'{sc_title} + {cfg["label"]}', fontsize=8,
                 fontweight='bold', color=color, pad=4)

    # ── key metrics box ───────────────────────────────────────────────────────
    if result:
        msp = result.get('MSP (USD/kg SAF)', float('nan'))
        npv = result.get('NPV (MM USD)',      float('nan'))
        co2 = result.get('co2_kg_per_kgSAF', float('nan'))
        prod_lbl = 'blend' if scenario == 2 else 'SAF'
        info = f"MSP=${msp:.2f}/kg {prod_lbl}  NPV=${npv:.0f}MM  CO₂={co2:.3f}kg/kg"
        ax.text(5.0, 0.3, info, ha='center', va='center', fontsize=6,
                color='#2d3436',
                bbox=dict(boxstyle='round,pad=0.3', facecolor='#f9f9f9',
                          edgecolor='#b2bec3'))

#%%
def generate_pfd(results):
    fig, axes = plt.subplots(2, 3, figsize=(21, 10))
    fig.suptitle(
        'SAF from Waste Polystyrene — Process Flow Diagrams\n'
        '(2 Scenarios × 3 H₂ Sources | Basis: 250 MT/day PS)',
        fontsize=13, fontweight='bold', y=0.98
    )
    for col, h2_src in enumerate(H2_CONFIGS):
        for row, sc in enumerate([1, 2]):
            ax  = axes[row][col]
            res = results.get((sc, h2_src))
            draw_pfd(ax, sc, h2_src, res)

    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.savefig('PFD_SAF_from_PS.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("PFD_SAF_from_PS.png saved.")

#%%
# ══════════════════════════════════════════════════════════════════════════════
# 5.  TEA dashboard (6-panel)
# ══════════════════════════════════════════════════════════════════════════════
def generate_tea_dashboard(results):
    fig = plt.figure(figsize=(18, 14))
    fig.suptitle(
        'TEA Dashboard — SAF from Waste Polystyrene  |  Basis: 250 MT/day PS\n'
        'Sc1: Co-hydropyrolysis (Pd/SBA-15)   Sc2: EB + SPK Blend (50:50)',
        fontsize=13, fontweight='bold'
    )
    gs = gridspec.GridSpec(3, 2, figure=fig, hspace=0.50, wspace=0.35)

    sc_labels = ['Sc1 SMR', 'Sc1 PC', 'Sc1 SOEC',
                 'Sc2 SMR', 'Sc2 PC', 'Sc2 SOEC']
    bar_colors = (
        [H2_CONFIGS['SMR']['color'], H2_CONFIGS['Photocatalysis']['color'],
         H2_CONFIGS['SOEC']['color']] * 2
    )

    def _vals(metric, default=0.0):
        out = []
        for sc in [1, 2]:
            for h2 in H2_CONFIGS:
                r = results.get((sc, h2))
                out.append(r.get(metric, default) if r else default)
        return out

    # ── MSP ──────────────────────────────────────────────────────────────────
    ax1 = fig.add_subplot(gs[0, 0])
    msps = _vals('MSP (USD/kg SAF)')
    bars = ax1.bar(sc_labels, msps, color=bar_colors, edgecolor='k', linewidth=0.6)
    ax1.axhline(MARKET_PRICE_USD_KG, color='navy', linestyle='--', linewidth=1.2, label='Fossil-jet parity $1.09/kg')
    ax1.set_title('Minimum Selling Price (MSP)', fontweight='bold')
    ax1.set_ylabel('USD / kg SAF')
    ax1.legend(fontsize=8)
    ax1.tick_params(axis='x', labelrotation=30, labelsize=8)
    for bar, val in zip(bars, msps):
        ax1.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.02,
                 f'${val:.2f}', ha='center', va='bottom', fontsize=7)

    # ── NPV ──────────────────────────────────────────────────────────────────
    ax2 = fig.add_subplot(gs[0, 1])
    npvs = _vals('NPV (MM USD)')
    bars = ax2.bar(sc_labels, npvs, color=bar_colors, edgecolor='k', linewidth=0.6)
    ax2.axhline(0, color='black', linewidth=0.8)
    ax2.set_title('Net Present Value (NPV)', fontweight='bold')
    ax2.set_ylabel('MM USD')
    ax2.tick_params(axis='x', labelrotation=30, labelsize=8)
    for bar, val in zip(bars, npvs):
        ypos = bar.get_height() + (1 if val >= 0 else -4)
        ax2.text(bar.get_x() + bar.get_width() / 2, ypos,
                 f'${val:.0f}M', ha='center', va='bottom', fontsize=7)

    # ── IRR ──────────────────────────────────────────────────────────────────
    ax3 = fig.add_subplot(gs[1, 0])
    irrs = _vals('IRR (%)')
    bars = ax3.bar(sc_labels, irrs, color=bar_colors, edgecolor='k', linewidth=0.6)
    ax3.axhline(10.0, color='crimson', linestyle='--', linewidth=1.2, label='Hurdle rate 10%')
    ax3.set_title('Internal Rate of Return (IRR)', fontweight='bold')
    ax3.set_ylabel('IRR (%)')
    ax3.legend(fontsize=8)
    ax3.tick_params(axis='x', labelrotation=30, labelsize=8)
    for bar, val in zip(bars, irrs):
        ax3.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.3,
                 f'{val:.1f}%', ha='center', va='bottom', fontsize=7)

    # ── TCI ──────────────────────────────────────────────────────────────────
    ax4 = fig.add_subplot(gs[1, 1])
    tcis = _vals('TCI (MM USD)')
    bars = ax4.bar(sc_labels, tcis, color=bar_colors, edgecolor='k', linewidth=0.6)
    ax4.set_title('Total Capital Investment (TCI)', fontweight='bold')
    ax4.set_ylabel('MM USD')
    ax4.tick_params(axis='x', labelrotation=30, labelsize=8)
    for bar, val in zip(bars, tcis):
        ax4.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.5,
                 f'${val:.1f}M', ha='center', va='bottom', fontsize=7)

    # ── AOC breakdown (stacked bar) ───────────────────────────────────────────
    ax5 = fig.add_subplot(gs[2, 0])
    feed_costs = _vals('Feedstock cost (MM USD/yr)')
    util_costs = _vals('Utility cost (MM USD/yr)')
    n_cfg = len(sc_labels)
    fix_costs = [sum(_vals(k)[i] for k in ('Maintenance (MM USD/yr)',
                                            'Labor (MM USD/yr)',
                                            'Insurance (MM USD/yr)',
                                            'Overhead (MM USD/yr)'))
                 for i in range(n_cfg)]
    x = np.arange(n_cfg)
    w = 0.55
    ax5.bar(x, feed_costs, w, label='Feedstock',   color='#fdcb6e', edgecolor='k', lw=0.6)
    ax5.bar(x, util_costs, w, bottom=feed_costs,   label='Utilities',   color='#e17055', edgecolor='k', lw=0.6)
    ax5.bar(x, fix_costs,  w,
            bottom=[f + u for f, u in zip(feed_costs, util_costs)],
            label='Fixed costs', color='#74b9ff', edgecolor='k', lw=0.6)
    ax5.set_title('Annual Operating Cost (AOC) Breakdown', fontweight='bold')
    ax5.set_ylabel('MM USD / yr')
    ax5.set_xticks(x)
    ax5.set_xticklabels(sc_labels, rotation=30, fontsize=7)
    ax5.legend(fontsize=8, loc='upper right')

    # ── CO2 intensity ─────────────────────────────────────────────────────────
    ax6 = fig.add_subplot(gs[2, 1])
    co2s = _vals('co2_kg_per_kgSAF')
    bars = ax6.bar(sc_labels, co2s, color=bar_colors, edgecolor='k', linewidth=0.6)
    ax6.axhline(2.5, color='green', linestyle='--', linewidth=1.2,
                label='Jet fuel baseline ~2.5 kg CO₂/kg')
    ax6.set_title('CO₂ Intensity (H₂ production scope)', fontweight='bold')
    ax6.set_ylabel('kg CO₂ / kg product')
    ax6.legend(fontsize=8)
    ax6.tick_params(axis='x', labelrotation=30, labelsize=7)
    for bar, val in zip(bars, co2s):
        ax6.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                 f'{val:.3f}', ha='center', va='bottom', fontsize=6)

    # ── shared legend for H2 source ───────────────────────────────────────────
    legend_patches = [mpatches.Patch(color=v['color'], label=v['label'])
                      for v in H2_CONFIGS.values()]
    legend_patches += [mpatches.Patch(color='white', edgecolor='k',
                                      label='Left group = Sc1  |  Right group = Sc2')]
    fig.legend(handles=legend_patches, loc='lower center', ncol=4,
               fontsize=9, bbox_to_anchor=(0.5, 0.01))

    plt.savefig('TEA_SAF_from_PS.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("TEA_SAF_from_PS.png saved.")


# ══════════════════════════════════════════════════════════════════════════════
# 6.  Sensitivity: NPV vs SAF selling price
# ══════════════════════════════════════════════════════════════════════════════
def generate_sensitivity_plot(results):
    _, tm = _load_tea_bridge()

    sell_prices = np.linspace(0.80, 3.50, 50)
    fig, axes   = plt.subplots(1, 3, figsize=(20, 5), sharey=True)
    fig.suptitle('NPV Sensitivity to Product Selling Price\n'
                 '(Sc1: SAF price  |  Sc2: EB-SPK blend price)',
                 fontsize=13, fontweight='bold')

    for col, sc in enumerate([1, 2]):
        ax = axes[col]
        for h2_src, cfg in H2_CONFIGS.items():
            res = results.get((sc, h2_src))
            if res is None:
                continue
            FCI, WC = res['_FCI'], res['_WC']
            VOC_annual, FOC_annual = res['_VOC_annual'], res['_FOC_annual']
            product_kg_yr, byproduct_annual = res['_product_kg_yr'], res['_byproduct_annual']

            npv_curve = [
                tm.npv_at_price(FCI, WC, VOC_annual, FOC_annual,
                                product_kg_yr, byproduct_annual, sp) / 1e6
                for sp in sell_prices
            ]
            ax.plot(sell_prices, npv_curve,
                    color=cfg['color'], marker=cfg['marker'],
                    markevery=10, linewidth=2.0, label=cfg['label'])

        ax.axhline(0, color='black', linewidth=0.8, linestyle='--')
        ax.axvline(MARKET_PRICE_USD_KG, color='navy', linewidth=1.0, linestyle=':', label='Fossil-jet parity $1.09/kg')
        ax.set_xlabel('Selling Price (USD/kg)', fontsize=11)
        ax.set_ylabel('NPV (MM USD)' if col == 0 else '', fontsize=11)
        prod_lbl = 'EB-SPK Blend' if sc == 2 else 'SAF'
        ax.set_title(f'Scenario {sc} — {prod_lbl}', fontsize=11, fontweight='bold')
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig('Sensitivity_NPV_vs_SAFprice.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("Sensitivity_NPV_vs_SAFprice.png saved.")


# ══════════════════════════════════════════════════════════════════════════════
# 7.  Pareto: MSP vs CO2 intensity
# ══════════════════════════════════════════════════════════════════════════════
def generate_pareto_plot(results):
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.set_title('Pareto Front: MSP vs CO₂ Intensity by H₂ Source',
                 fontsize=12, fontweight='bold')

    scenario_markers = {1: 'o', 2: '^'}
    scenario_sizes   = {1: 120, 2: 140}

    for (sc, h2_src), res in results.items():
        if res is None:
            continue
        msp = res.get('MSP (USD/kg SAF)', float('nan'))
        co2 = res.get('co2_kg_per_kgSAF', float('nan'))
        cfg = H2_CONFIGS[h2_src]
        ax.scatter(co2, msp,
                   color=cfg['color'],
                   marker=scenario_markers[sc],
                   s=scenario_sizes[sc],
                   edgecolors='k', linewidths=0.8, zorder=5,
                   label=f'Sc{sc}-{cfg["label"]}')
        ax.annotate(f'Sc{sc}\n{cfg["label"]}',
                    (co2, msp), textcoords='offset points',
                    xytext=(6, 4), fontsize=7)

    ax.axhline(MARKET_PRICE_USD_KG, color='navy',  linestyle='--', linewidth=1, label='Fossil-jet parity $1.09/kg')
    ax.axvline(2.50, color='green', linestyle=':',  linewidth=1, label='Fossil jet CO₂ baseline')
    ax.set_xlabel('CO₂ Intensity (kg CO₂ / kg SAF)', fontsize=11)
    ax.set_ylabel('MSP (USD / kg SAF)', fontsize=11)
    ax.legend(fontsize=8, loc='upper left')
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig('H2_MSP_vs_CO2.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("H2_MSP_vs_CO2.png saved.")


# ══════════════════════════════════════════════════════════════════════════════
# 8.  BioSTEAM process diagrams (graphviz-rendered)
# ══════════════════════════════════════════════════════════════════════════════
def generate_biosteam_diagrams(results):
    """
    Save a BioSTEAM system diagram for each of the 6 configurations.
    Requires graphviz to be installed on the system PATH.
    Outputs: BioSTEAM_PFD_Sc{N}_{H2source}.png
    """
    saved = []
    for (sc, h2_src), res in results.items():
        if res is None:
            continue
        cfg_id = f'Sc{sc}_{h2_src.replace("/", "_")}'
        units  = [u for u in [res['pyrolyzer'], res['h2_unit'], res['hydro'],
                               res.get('blender')] if u is not None]
        fname  = f'BioSTEAM_PFD_{cfg_id}'
        try:
            # Use a unique system ID per configuration to avoid registry conflicts
            sys_id = f'SAF_{cfg_id}'
            # Close any pre-existing system with this ID before recreating
            try:
                existing = bst.System.registry.search(sys_id)
                if existing is not None:
                    existing.close()
            except AttributeError:
                pass   # older BioSTEAM versions have no registry.search
            system = bst.System(sys_id, path=units)
            system.diagram(
                kind='thorough',
                file=fname,
                format='png',
                display=False,
            )
            saved.append(fname + '.png')
            print(f"  [ok] {fname}.png")
        except Exception as e:
            print(f"  [fail] {cfg_id}: {e}")

    return saved


# ══════════════════════════════════════════════════════════════════════════════
# 8b. Material stream tables
# ══════════════════════════════════════════════════════════════════════════════
def save_material_streams(results):
    """
    Export stream flow tables for all 6 configurations to an Excel workbook.
    One worksheet per configuration; one row per stream.
    Outputs: Material_Streams_All_Scenarios.xlsx
    """
    try:
        import pandas as pd
    except ImportError:
        print("  [fail] pandas not found — skipping material stream export.")
        return

    STREAM_LABELS = {
        # feed streams created inside build_flowsheet
        's_ps':        'PS Feed',
        's_oil':       'Waste Cooking Oil Feed',
        's_ch4':       'Methane Feed (SMR)',
        's_steam':     'Steam Feed (SMR)',
        's_water_pc':  'Water Feed (PC)',
        's_water_se':  'Water Feed (SOEC)',
        's_elec':      'Electricity (placeholder)',
        # unit outlets
        'pyro_oil':    'Pyrolysis Oil',
        'char':        'Char',
        'gas':         'Pyrolysis Gas',
        'h2_out':      'Hydrogen Product',
        'flue':        'Flue Gas (SMR)',
        'o2_pc':       'Oxygen (PC)',
        'o2_soec':     'Oxygen (SOEC)',
        'saf':          'SAF Product (Sc1)',
        'eb_oil':       'EB-rich Oil (Sc2 hydro outlet)',
        'offgas':       'Off-gas / H2 excess',
        's_spk':        'Purchased SPK Feed (Sc2)',
        'eb_spk_blend': 'EB additive + SPK blend product (Sc2)',
        'dist_bottoms': 'Distillation Bottoms (Sc2)',
    }

    from datetime import datetime
    fname = 'Material_Streams_All_Scenarios.xlsx'
    try:
        open(fname, 'ab').close()   # probe for lock
    except PermissionError:
        fname = f"Material_Streams_{datetime.now().strftime('%H%M%S')}.xlsx"
        print(f"  (default file locked — writing to {fname})")
    with pd.ExcelWriter(fname, engine='openpyxl') as writer:
        for (sc, h2_src), res in sorted(results.items()):
            if res is None:
                continue

            sheet = f'Sc{sc}_{h2_src}'[:31]   # Excel max 31 chars
            units = [u for u in [res['pyrolyzer'], res['h2_unit'], res['hydro'],
                                  res.get('blender')] if u is not None]

            # Collect unique streams preserving order: ins then outs of each unit
            seen, ordered_streams = set(), []
            for unit in units:
                for s in list(unit.ins) + list(unit.outs):
                    if s.ID not in seen:
                        seen.add(s.ID)
                        ordered_streams.append(s)

            rows = []
            for s in ordered_streams:
                if s.F_mass < 1e-9:       # skip truly empty placeholder streams
                    continue
                row = {
                    'Stream ID':          s.ID,
                    'Description':        STREAM_LABELS.get(s.ID, ''),
                    'Phase':              s.phase,
                    'T (°C)':             round(s.T - 273.15, 2),
                    'P (bar)':            round(s.P / 1e5,    4),
                    'Total flow (kg/hr)': round(s.F_mass,     4),
                }
                # Component mass flows — only non-zero entries
                for chem in s.chemicals:
                    try:
                        kg_hr = s.get_flow('kg/hr', chem.ID)
                    except Exception:
                        kg_hr = 0.0
                    if kg_hr > 1e-9:
                        row[f'{chem.ID} (kg/hr)'] = round(kg_hr, 4)

                # Mass fractions for components that appear
                total = s.F_mass or 1.0
                for chem in s.chemicals:
                    try:
                        kg_hr = s.get_flow('kg/hr', chem.ID)
                    except Exception:
                        kg_hr = 0.0
                    if kg_hr > 1e-9:
                        row[f'{chem.ID} (wt fr)'] = round(kg_hr / total, 5)

                rows.append(row)

            df = pd.DataFrame(rows)
            df.to_excel(writer, sheet_name=sheet, index=False)

            # Auto-fit column widths
            ws = writer.sheets[sheet]
            for col in ws.columns:
                max_len = max((len(str(cell.value or '')) for cell in col), default=10)
                ws.column_dimensions[col[0].column_letter].width = min(max_len + 2, 40)

    print(f"{fname} saved.")


# ══════════════════════════════════════════════════════════════════════════════
# 9.  Tornado chart — MSP sensitivity to key economic parameters
# ══════════════════════════════════════════════════════════════════════════════
def generate_tornado_chart(results):
    tb, tm = _load_tea_bridge()

    fig, axes = plt.subplots(2, 3, figsize=(20, 12))
    fig.suptitle(
        'Tornado Chart — MFSP Sensitivity Analysis (NREL/Humbird 2011 DCFROR)\n'
        'Bars show ΔMFSP (USD/kg product) for ±20% one-at-a-time parameter changes',
        fontsize=13, fontweight='bold'
    )

    for row, sc in enumerate([1, 2]):
        for col, h2_src in enumerate(list(H2_CONFIGS.keys())):
            ax  = axes[row][col]
            key = (sc, h2_src)
            res = results.get(key)
            cfg = H2_CONFIGS[h2_src]

            if res is None:
                ax.text(0.5, 0.5, 'No data', ha='center', va='center',
                        transform=ax.transAxes, fontsize=10)
                ax.axis('off')
                continue

            base_msp = res['mfsp_per_kg']
            df   = tb.sensitivity_for(key, results)
            rows = list(zip(df['parameter'], df['delta_low'], df['delta_high']))

            n    = len(rows)
            ypos = list(range(n))

            for i, (_, d_lo, d_hi) in enumerate(rows):
                left  = min(d_lo, d_hi)
                right = max(d_lo, d_hi)
                # Negative wing (parameter reduces MSP) in blue, positive in red
                if left < 0:
                    ax.barh(i, abs(left), left=left, height=0.55,
                            color='#3498db', alpha=0.80, edgecolor='k', linewidth=0.4)
                if right > 0:
                    ax.barh(i, right, left=0, height=0.55,
                            color='#e74c3c', alpha=0.80, edgecolor='k', linewidth=0.4)
                # Endpoint value labels
                ax.text(left - 0.002, i, f'${base_msp + left:.2f}',
                        ha='right', va='center', fontsize=6.5, color='#2c3e50')
                ax.text(right + 0.002, i, f'${base_msp + right:.2f}',
                        ha='left',  va='center', fontsize=6.5, color='#2c3e50')

            ax.axvline(0, color='black', linewidth=1.2, zorder=5)
            ax.set_yticks(ypos)
            ax.set_yticklabels([r[0] for r in rows], fontsize=7.5)
            prod_lbl = 'blend' if sc == 2 else 'SAF'
            ax.set_xlabel(f'ΔMSP from base (USD/kg {prod_lbl})', fontsize=8)
            ax.set_title(
                f'Sc{sc} + {cfg["label"]}   [Base MSP = ${base_msp:.2f}/kg {prod_lbl}]',
                fontsize=8, fontweight='bold', color=cfg['color'], pad=5
            )
            ax.invert_yaxis()
            ax.grid(axis='x', alpha=0.25, linestyle='--')

            # Legend only on first subplot
            if row == 0 and col == 0:
                ax.barh([], [], color='#3498db', alpha=0.80, label='Low value → lower MSP')
                ax.barh([], [], color='#e74c3c', alpha=0.80, label='High value → higher MSP')
                ax.legend(fontsize=7, loc='lower right')

    plt.tight_layout(rect=[0, 0, 1, 0.95])
    plt.savefig('Tornado_MSP_Sensitivity.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("Tornado_MSP_Sensitivity.png saved.")


# ══════════════════════════════════════════════════════════════════════════════
# 10.  Monte Carlo uncertainty analysis (2 000 samples, all 6 configurations)
# ══════════════════════════════════════════════════════════════════════════════
def generate_uncertainty_analysis(results):
    """
    Monte Carlo uncertainty analysis via tea_model.py's run_uncertainty()
    (Latin-hypercube sampling, triangular ±20% distributions on 7 NREL/Humbird
    DCFROR parameters) — the same engine used for tea_report.md's uncertainty
    section. Produces MFSP distributions for all 6 configurations.
    """
    tb, tm = _load_tea_bridge()
    N = 1_000

    fig, axes = plt.subplots(2, 3, figsize=(20, 12))
    fig.suptitle(
        f'Monte Carlo Uncertainty Analysis — MFSP Distribution  (N = {N:,} samples, NREL/Humbird 2011 DCFROR)\n'
        'Latin-hypercube sampling, triangular ±20% distributions on 7 parameters',
        fontsize=13, fontweight='bold'
    )

    for row, sc in enumerate([1, 2]):
        for col, h2_src in enumerate(list(H2_CONFIGS.keys())):
            ax  = axes[row][col]
            key = (sc, h2_src)
            res = results.get(key)
            cfg = H2_CONFIGS[h2_src]

            if res is None:
                ax.text(0.5, 0.5, 'No data', ha='center', va='center',
                        transform=ax.transAxes, fontsize=10)
                ax.axis('off')
                continue

            base_msp = res['mfsp_per_kg']
            samples_df, summary_df, _ = tb.uncertainty_for(key, results, n=N)
            msp_samples = samples_df['mfsp'].to_numpy()
            p5, p50, p95 = (summary_df['P5'].iloc[0], summary_df['P50'].iloc[0],
                            summary_df['P95'].iloc[0])

            ax.hist(msp_samples, bins=60, color=cfg['color'], alpha=0.72,
                    edgecolor='k', linewidth=0.35)
            ax.axvline(p5,     color='#0984e3', linestyle='--', lw=1.8,
                       label=f'P5  = ${p5:.2f}/kg')
            ax.axvline(p50,    color='black',   linestyle='-',  lw=2.2,
                       label=f'P50 = ${p50:.2f}/kg')
            ax.axvline(p95,    color='#d63031', linestyle='--', lw=1.8,
                       label=f'P95 = ${p95:.2f}/kg')
            ax.axvline(base_msp, color='#00b894', linestyle=':',  lw=1.5,
                       label=f'Base= ${base_msp:.2f}/kg')
            ax.axvline(MARKET_PRICE_USD_KG, color='navy', linestyle='-.', lw=1.2,
                       label=f'Parity ${MARKET_PRICE_USD_KG:.2f}/kg')

            prod_lbl = 'blend' if sc == 2 else 'SAF'
            ax.set_xlabel(f'MFSP (USD/kg {prod_lbl})', fontsize=9)
            ax.set_ylabel('Sample count', fontsize=9)
            ax.set_title(f'Sc{sc} + {cfg["label"]}',
                         fontsize=9, fontweight='bold', color=cfg['color'])
            ax.legend(fontsize=7.5, loc='upper right')
            ax.grid(True, alpha=0.25, linestyle='--')

            # Annotation: P90 range
            ax.text(0.03, 0.97,
                    f'P5–P95 range: ${p5:.2f}–${p95:.2f}/kg',
                    transform=ax.transAxes, fontsize=7,
                    va='top', color='#2d3436',
                    bbox=dict(boxstyle='round,pad=0.25',
                              facecolor='#f9f9f9', edgecolor='#b2bec3'))

    plt.tight_layout(rect=[0, 0, 1, 0.92])
    plt.savefig('Uncertainty_MSP_MonteCarlo.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("Uncertainty_MSP_MonteCarlo.png saved.")


# ══════════════════════════════════════════════════════════════════════════════
# 11.  Summary table to console
# ══════════════════════════════════════════════════════════════════════════════
def print_summary_table(results):
    hdr = (f"{'Configuration':<25} {'MSP':>8} {'NPV (MM)':>10} "
           f"{'IRR (%)':>8} {'TCI (MM)':>10} {'CO2 (kg/kg)':>12} "
           f"{'Payback':>8}")
    print('\n' + '=' * len(hdr))
    print('SIMULATION RESULTS SUMMARY')
    print('=' * len(hdr))
    print(hdr)
    print('-' * len(hdr))
    for sc in [1, 2]:
        for h2_src in H2_CONFIGS:
            res = results.get((sc, h2_src))
            if res is None:
                print(f"  Sc{sc} + {h2_src:<15}  ERROR")
                continue
            name    = f"Sc{sc} + {h2_src}"
            msp     = res.get('MSP (USD/kg SAF)', float('nan'))
            npv     = res.get('NPV (MM USD)',      float('nan'))
            irr     = res.get('IRR (%)',            float('nan'))
            tci     = res.get('TCI (MM USD)',       float('nan'))
            co2     = res.get('co2_kg_per_kgSAF',  float('nan'))
            payback = res.get('Payback period (yr)', '?')
            print(f"  {name:<23} {msp:>8.2f} {npv:>10.1f} "
                  f"{irr:>8.1f} {tci:>10.1f} {co2:>12.4f} {str(payback):>8}")
    print('=' * len(hdr))


# ══════════════════════════════════════════════════════════════════════════════
# 11b.  Full TEA report plot set (tea_20260605_1634/scripts/make_*.py)
# ══════════════════════════════════════════════════════════════════════════════
def run_report_plots():
    """
    Generate every remaining tea_20260605_1634/plots/*.pdf figure that
    tea_report.md / tea_report.pptx are built from, by running the standalone
    make_*.py scripts. Each script computes its own results via
    tea_bridge.simulate_all() rather than reusing run_all_configurations()'s
    results above, so this reproduces the full figure set display_all_plots()
    knows how to show, not just main.py's own 6 PNGs.
    """
    import importlib.util

    scripts_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "tea_20260605_1634", "scripts",
    )
    # Each script does `import tea_bridge`/`import tea_model` as if it were
    # run standalone from this directory -- put it on sys.path so that
    # resolves even when run_report_plots() is called on its own.
    if scripts_dir not in sys.path:
        sys.path.insert(0, scripts_dir)

    def _load(name):
        spec = importlib.util.spec_from_file_location(
            name, os.path.join(scripts_dir, f"{name}.py"))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod

    # These run their plotting calls unconditionally at module level.
    for name in ("make_npv", "make_cashflow", "make_tpec",
                 "make_contour", "make_contour_process", "make_material_balance"):
        try:
            print(f"  Running {name}.py ...")
            _load(name)
        except Exception as e:
            print(f"  [ERROR] {name}.py: {e}")

    # make_plots.py gates its plot calls behind `if __name__ == "__main__":`,
    # so they must be invoked explicitly after loading.
    try:
        print("  Running make_plots.py ...")
        mp = _load("make_plots")
        mp.plot_mfsp_stacked_bar()
        mp.plot_capex_stacked()
        mp.plot_opex_stacked()
        mp.plot_sensitivity_tornado()
        mp.plot_sensitivity_tornado_all()
        mp.plot_uncertainty_cdf()
        mp.plot_uncertainty_histogram()
        mp.plot_literature_comparison()
        mp.plot_mfsp_grouped()
    except Exception as e:
        print(f"  [ERROR] make_plots.py: {e}")


# ══════════════════════════════════════════════════════════════════════════════
# 12.  Cradle-to-gate LCA (TRACI 2.1, 1 MJ SAF functional unit)
# ══════════════════════════════════════════════════════════════════════════════
def run_lca_analysis():
    """
    Run the full cradle-to-gate LCA for all 6 SAF configurations using
    OpenLCA ecoinvent background data and the NREL DCFROR TEA model inventory.

    Delegates to make_lca.py (tea_20260605_1634/scripts/) which contains:
      - read_impacts()       : parse OpenLCA Excel exports (TRACI 2.1)
      - compute_inventory()  : derive per-kg-SAF material/energy flows
      - compute_impacts_per_kg() : multiply inventory by impact factors (per kg SAF, mass basis)
      - run_lca()            : loop all 6 configs, return results dicts
      - save_csvs()          : write lca_results.csv + lca_contributions.csv
      - plot_*()             : 7 PDF figures saved to TEA_Outputs_20260608/
    """
    LCA_SCRIPT_DIR = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "tea_20260605_1634", "scripts",
    )
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        "make_lca", os.path.join(LCA_SCRIPT_DIR, "make_lca.py")
    )
    lca = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(lca)

    print("  Loading OpenLCA impact factors ...")
    all_results, all_contribs, _, summary_rows, _ = lca.run_lca()

    print("  Saving LCA CSVs ...")
    lca.save_csvs(summary_rows, all_contribs)

    print("  Generating LCA plots ...")
    out = lca.OUT_DIR
    plot_calls = [
        ("lca_ghg.pdf",           lambda: lca.plot_ghg_bar(all_results,
                                      os.path.join(out, "lca_ghg.pdf"))),
        ("lca_ghg_stack.pdf",     lambda: lca.plot_ghg_stack(all_contribs,
                                      os.path.join(out, "lca_ghg_stack.pdf"))),
        ("lca_traci_heatmap.pdf", lambda: lca.plot_traci_heatmap(all_results,
                                      os.path.join(out, "lca_traci_heatmap.pdf"))),
        ("lca_radar.pdf",         lambda: lca.plot_radar(all_results,
                                      os.path.join(out, "lca_radar.pdf"))),
        ("lca_h2_comparison.pdf", lambda: lca.plot_h2_comparison(all_results, all_contribs,
                                      os.path.join(out, "lca_h2_comparison.pdf"))),
        ("lca_traci_bars.pdf",    lambda: lca.plot_traci_bars(all_results,
                                      os.path.join(out, "lca_traci_bars.pdf"))),
        ("lca_percent_stack.pdf", lambda: lca.plot_percent_stack(all_contribs,
                                      os.path.join(out, "lca_percent_stack.pdf"))),
        ("lca_normalized_stack.pdf", lambda: lca.plot_normalized_stack(all_results, all_contribs,
                                      os.path.join(out, "lca_normalized_stack.pdf"))),
    ]
    for name, fn in plot_calls:
        try:
            fn()
        except Exception as e:
            print(f"  [ERROR] {name}: {e}")

    # make_lca (R1) reports GWP per MJ (LHV): row["Global warming"] is g CO2 eq/MJ, and the
    # fossil Jet-A reference is FOSSIL_JET_G_PER_MJ (well-to-wake). kg/kg is kept for reference.
    print("\n  LCA Summary (GWP, well-to-wake):")
    print(f"  {'Scenario':<15} {'g CO2e/MJ':>10} {'kg CO2e/kg':>11} {'vs Fossil':>10}")
    print("  " + "-" * 50)
    fossil_g = lca.FOSSIL_JET_G_PER_MJ
    for row in summary_rows:
        print(f"  {row['scenario']:<15} {row['GWP_g_per_MJ']:>10.1f} {row['GWP_kg_per_kg']:>11.3f} "
              f"{row['GWP_reduction_vs_fossil_pct']:>9.1f}%")
    print(f"  {'Fossil Jet-A':<15} {fossil_g:>10.1f} {'':>11} {'---':>10}")


# ══════════════════════════════════════════════════════════════════════════════
# 13.  LCA + TEA sensitivity tornado plots (±20% one-at-a-time)
# ══════════════════════════════════════════════════════════════════════════════
def run_tornado_analysis():
    """
    Generate three sensitivity tornado PDFs via make_tornado.py:
      lca_tornado_tea.pdf      — 2×3 panel, MFSP by scenario
      lca_tornado_lca.pdf      — 2×3 panel, GHG intensity by scenario
      lca_tornado_combined.pdf — 4×3 panel (TEA rows 0-1, LCA rows 2-3)

    Parameters perturbed ±20% one-at-a-time:
      TEA : 8 parameters read from data/sensitivity.csv
      LCA : smr_gwp, soec_elec, photo_elec, liq_yield, process_heat,
            wco_credit, char_credit, spk_impact
    """
    import importlib.util
    tornado_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "tea_20260605_1634", "scripts", "make_tornado.py",
    )
    spec = importlib.util.spec_from_file_location("make_tornado", tornado_path)
    tor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(tor)

    print("  Computing LCA sensitivity ...")
    sens_lca = tor.run_lca_sensitivity()

    out = tor.OUT_DIR
    tor.plot_tea_tornado(os.path.join(out, "lca_tornado_tea.pdf"))
    tor.plot_lca_tornado(sens_lca, os.path.join(out, "lca_tornado_lca.pdf"))
    tor.plot_combined(sens_lca, os.path.join(out, "lca_tornado_combined.pdf"))


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════
if __name__ == '__main__':
    print("\n" + "=" * 60)
    print("  SAF FROM WASTE POLYSTYRENE — BioSTEAM SIMULATION")
    print("  Iowa State University | Adejare Adesiyan | 2026")
    print("=" * 60)

    # 1. Chemicals
    chems  = setup_chemicals()

    # 2. Run all 6 configurations (2 scenarios × 3 H2 sources), priced with the
    #    corrected NREL/Humbird 2011 DCFROR engine via tea_bridge/tea_model —
    #    the same engine used for tea_report.md / tea_report.pptx.
    print("\n[1/7] Running process simulations ...")
    results = run_all_configurations()

    # 3. PFDs
    print("\n[2/7] Generating Process Flow Diagrams ...")
    generate_pfd(results)

    # 4. TEA dashboard
    print("\n[3/7] Generating TEA dashboard ...")
    generate_tea_dashboard(results)

    # 5. BioSTEAM process diagrams
    print("\n[4/7] Generating BioSTEAM process diagrams ...")
    generate_biosteam_diagrams(results)

    # 5b. Material stream tables
    print("\n[4b/7] Saving material stream tables ...")
    save_material_streams(results)

    # 6. Sensitivity + Pareto + Tornado
    print("\n[5/7] Generating sensitivity and Pareto plots ...")
    generate_sensitivity_plot(results)
    generate_pareto_plot(results)

    print("\n[6/7] Generating tornado sensitivity chart ...")
    generate_tornado_chart(results)

    print("\n[7/10] Running Monte Carlo uncertainty analysis ...")
    generate_uncertainty_analysis(results)

    # 8. Full TEA report plot set (make_npv, make_cashflow, make_tpec,
    #    make_contour, make_contour_process, make_material_balance, make_plots)
    print("\n[8/10] Generating full TEA report plot set ...")
    run_report_plots()

    # 9. LCA
    print("\n[9/10] Running cradle-to-gate LCA (TRACI 2.1) ...")
    run_lca_analysis()

    # 10. LCA + TEA sensitivity tornados
    print("\n[10/10] Generating sensitivity tornado plots (TEA + LCA) ...")
    run_tornado_analysis()

    # Console summary
    print_summary_table(results)

    print("\nAll outputs written to the current directory.")
    print("  BioSTEAM_PFD_Sc{N}_{H2source}.png       (6 files — requires graphviz)")
    print("  Material_Streams_All_Scenarios.xlsx       (stream tables, 6 sheets)")
    print("  PFD_SAF_from_PS.png                       (2 × 3 schematic)")
    print("  TEA_SAF_from_PS.png")
    print("  Sensitivity_NPV_vs_SAFprice.png")
    print("  H2_MSP_vs_CO2.png")
    print("  Tornado_MSP_Sensitivity.png")
    print("  Uncertainty_MSP_MonteCarlo.png            (Monte Carlo, all 6 configs)")
    print("  pfd_threejs.html                          (interactive Three.js PFDs)\n")

# %%
# ══════════════════════════════════════════════════════════════════════════════
# 14.  Display all generated plots inline (Jupyter / Spyder)
# ══════════════════════════════════════════════════════════════════════════════
#%%
def display_all_plots():
    """Load and display every PNG/PDF saved by the pipeline."""
    import sys, subprocess
    import matplotlib.pyplot as plt
    from pathlib import Path

    # ── ensure PyMuPDF is installed in the active interpreter ────────────────
    try:
        import fitz as _fitz
    except ImportError:
        print("  [auto-install] pymupdf not found — installing into active interpreter ...")
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', '--quiet', 'pymupdf'])
        import fitz as _fitz
    print(f"  [ok] PyMuPDF {_fitz.__version__} ready ({sys.executable})")

    # ── TEA PDF plots (tea_20260605_1634/plots/) ─────────────────────────────
    tea_plots_dir = Path(__file__).parent / 'tea_20260605_1634' / 'plots'

    # grouped so related plots render together
    tea_pdf_groups = [
        ('MFSP', [
            ('mfsp_stacked_bar.pdf',  'MFSP — Stacked Bar',          (12, 7)),
            ('mfsp_grouped_bar.pdf',  'MFSP — Grouped Bar',          (12, 7)),
        ]),
        ('Capital & Operating Cost', [
            ('capex_stacked.pdf',     'CapEx — Stacked by Area',     (12, 7)),
            ('opex_stacked.pdf',      'OpEx — Stacked by Category',  (12, 7)),
            ('tpec_by_area.pdf',      'TPEC by Process Area',        (12, 7)),
            ('tpec_subequipment.pdf', 'TPEC — Sub-equipment Detail', (12, 7)),
        ]),
        ('NPV & Cash Flow', [
            ('npv_curves.pdf',        'NPV Curves',                  (14, 7)),
            ('npv_bar.pdf',           'NPV Bar Chart',               (12, 7)),
            ('npv_summary.pdf',       'NPV Summary',                 (12, 7)),
            ('cashflow_grid.pdf',     'Cash Flow Grid (6 configs)',  (18, 12)),
            ('cashflow_overlay.pdf',  'Cash Flow Overlay',           (14, 7)),
            ('payback_summary.pdf',   'Payback Period Summary',      (12, 7)),
        ]),
        ('Sensitivity & Uncertainty', [
            ('sensitivity_tornado_all.pdf', 'Sensitivity Tornado — All',    (14, 9)),
            ('uncertainty_histogram.pdf',   'Uncertainty — MSP Histogram',  (14, 9)),
            ('uncertainty_cdf.pdf',         'Uncertainty — CDF',            (14, 9)),
        ]),
        ('Literature & Contour', [
            ('contour_yield_vs_onstream.pdf',      'Contour: Yield vs On-stream hrs',   (10, 8)),
            ('contour_yield_vs_capital.pdf',       'Contour: Yield vs Capital Cost',    (10, 8)),
            ('contour_T_vs_tau.pdf',               'Contour: T vs Residence Time',      (10, 8)),
            ('contour_sc1_copyo_ratio_vs_T.pdf',   'Contour Sc1: Co-pyro Ratio vs T',  (10, 8)),
            ('contour_sc2_spk_vs_yield.pdf',       'Contour Sc2: SPK vs Yield',         (10, 8)),
            ('contour_sc2_spk_blend_vs_T.pdf',     'Contour Sc2: SPK Blend vs T',       (10, 8)),
        ]),
    ]

    def _render_pdf(pdf_path, title, figsize, fitz_mod):
        if fitz_mod is None:
            print(f"  [info] pymupdf not installed — cannot render {pdf_path.name}.")
            return
        doc = fitz_mod.open(str(pdf_path))
        for i, page in enumerate(doc):
            mat = fitz_mod.Matrix(2.0, 2.0)
            pix = page.get_pixmap(matrix=mat, alpha=False)
            img = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.h, pix.w, 3)
            _, ax = plt.subplots(figsize=figsize)
            ax.imshow(img)
            ax.axis('off')
            lbl = title if len(doc) == 1 else f'{title}  (page {i+1})'
            ax.set_title(lbl, fontsize=10, fontweight='bold', pad=6)
            plt.tight_layout()
            plt.show()
        doc.close()

    for group_name, plots in tea_pdf_groups:
        found = [(n, t, fs) for n, t, fs in plots if (tea_plots_dir / n).exists()]
        if not found:
            print(f"  [skip] TEA group '{group_name}' — no files found.")
            continue
        print(f"\n  -- TEA: {group_name} --")
        for pdf_name, title, figsize in found:
            _render_pdf(tea_plots_dir / pdf_name, title, figsize, _fitz)

    # ── LCA PDF plots (displayed as images if pdf2image is available) ─────────
    lca_out_dir = Path(__file__).parent / 'TEA_Outputs_20260608'
    lca_pdfs = [
        'lca_ghg.pdf',
        'lca_ghg_stack.pdf',
        'lca_h2_comparison.pdf',
        'lca_traci_bars.pdf',
        'lca_percent_stack.pdf',
        'lca_normalized_stack.pdf',
        'lca_tornado_lca.pdf',
    ]
    for pdf_name in lca_pdfs:
        pdf_path = lca_out_dir / pdf_name
        if not pdf_path.exists():
            print(f"  [skip] {pdf_name} not found.")
            continue
        doc = _fitz.open(str(pdf_path))
        for i, page in enumerate(doc):
            mat = _fitz.Matrix(2.0, 2.0)   # 2× zoom → ~144 dpi
            pix = page.get_pixmap(matrix=mat, alpha=False)
            img = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.h, pix.w, 3)
            _, ax = plt.subplots(figsize=(12, 8))
            ax.imshow(img)
            ax.axis('off')
            label = pdf_name if len(doc) == 1 else f'{pdf_name}  (page {i+1})'
            ax.set_title(label, fontsize=10, fontweight='bold', pad=6)
            plt.tight_layout()
            plt.show()
        doc.close()

if __name__ == '__main__':
    display_all_plots()

# %%
