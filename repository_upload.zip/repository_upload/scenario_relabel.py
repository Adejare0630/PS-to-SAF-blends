"""R1.14 display relabelling: swap Sc1 <-> Sc2 (and 'Scenario 1' <-> 'Scenario 2') in every
matplotlib text object (display only), so figures show:  Sc1 = PS-only pyrolysis (reference),
                                          Sc2 = co-hydropyrolysis with waste cooking oil (proposed).
Internal model IDs, CSV keys and code stay unchanged (physical scenario 1 = co-hydropyrolysis).
Import this module BEFORE any plotting. Disable with env var SCENARIO_RELABEL=0.
Also provides disp() for strings written to CSV/Excel by new R1 scripts.
"""
import os, re

ENABLED = os.environ.get("SCENARIO_RELABEL", "1") != "0"
_PAT = re.compile(r"(?<![A-Za-z])(Sc|Scenario ?)([12])(?!\d)")


def disp(text):
    """Swap scenario numbers in a string (idempotency is NOT guaranteed: apply once)."""
    if not ENABLED or not isinstance(text, str):
        return text
    return _PAT.sub(lambda m: m.group(1) + ("2" if m.group(2) == "1" else "1"), text)


def _install():
    """Patch Text.get_text (read-only view): stored text is never modified, so the swap is applied
    exactly once whenever the text is read for drawing/layout (idempotent, no double swapping)."""
    if not ENABLED:
        return
    import matplotlib.text as mtext
    if getattr(mtext.Text, "_r1_relabel", False):
        return
    _orig = mtext.Text.get_text

    def get_text(self):
        return disp(_orig(self))

    mtext.Text.get_text = get_text
    mtext.Text._r1_relabel = True


_install()
