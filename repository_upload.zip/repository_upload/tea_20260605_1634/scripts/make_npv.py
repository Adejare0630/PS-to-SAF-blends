"""
make_npv.py — NPV plots for all 6 SAF configurations.
Process engineering sourced from main.py's BioSTEAM simulation; all financial
math (Peters/Timmerhaus/West capital, 60/40 debt/equity, MACRS7, 35% tax, 3-yr
construction, 6-month startup) comes from tea_model.py's NREL/Humbird 2011
DCFROR engine via tea_bridge.py.

Figure 1: Equity NPV vs. selling price — curves for all 6 configs, two panels.
Figure 2: NPV bar chart at two reference prices.
Figure 3: Combined summary figure.

Primary unit: $/kg SAF (mass basis) throughout.
"""

import os, warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import sys as _s, os as _o
_s.path.insert(0, _o.path.dirname(_o.path.dirname(_o.path.dirname(_o.path.abspath(__file__)))))
import scenario_relabel  # R1.14: display swap Sc1<->Sc2 (set SCENARIO_RELABEL=0 to disable)
import matplotlib
# Standalone run: force Agg (fast, headless). Loaded by main.py inside an
# IPython/Jupyter session: leave the backend main.py already configured
# (inline / TkAgg) alone so plt.show() calls below actually render.
try:
    get_ipython()
except NameError:
    matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib as mpl
import matplotlib.ticker as mticker

import tea_bridge as tb
import tea_model as tm

DATA_DIR  = tb.DATA_DIR
PLOTS_DIR = tb.PLOTS_DIR

# ── style ─────────────────────────────────────────────────────────────────────
mpl.rcParams.update({
    "font.family":      "serif",
    "font.serif":       ["DejaVu Serif", "Times New Roman", "serif"],
    "axes.labelsize":   11,
    "axes.titlesize":   11,
    "xtick.labelsize":  9,
    "ytick.labelsize":  9,
    "figure.dpi":       150,
    "savefig.dpi":      300,
    "savefig.bbox":     "tight",
})

META = {
    "Sc1_SMR":            {"label": "Sc1 + SMR",            "color": "#0072B2", "ls": "-"},
    "Sc1_SOEC":           {"label": "Sc1 + SOEC",           "color": "#56B4E9", "ls": "-"},
    "Sc1_Photocatalysis": {"label": "Sc1 + Photocatalysis", "color": "#009E73", "ls": "-"},
    "Sc2_SMR":            {"label": "Sc2 + SMR",            "color": "#D55E00", "ls": "--"},
    "Sc2_SOEC":           {"label": "Sc2 + SOEC",           "color": "#CC79A7", "ls": "--"},
    "Sc2_Photocatalysis": {"label": "Sc2 + Photocatalysis", "color": "#E69F00", "ls": "--"},
}
LABEL_ORDER = list(META.keys())
KEY_MAP     = {lbl: tb.SCENARIO_KEYS[i] for i, lbl in enumerate(tb.LABEL_ORDER)}

# $/kg SAF reference prices, converted from their usual $/GGE quotes on a
# Sc1 SAF LHV basis (fossil jet ~$3.10/GGE, Parity +20% ~$5.50/GGE)
FOSSIL_JET_KG = 3.10 / tm.to_gge(1.0, 1)
SAF_MARKET_KG = 1.20 * FOSSIL_JET_KG   # R1: premium-SAF ($5.50/GGE) case removed; now parity +20%

PANEL_CONFIGS = {
    0: ["Sc1_SMR", "Sc1_SOEC", "Sc1_Photocatalysis"],
    1: ["Sc2_SMR", "Sc2_SOEC", "Sc2_Photocatalysis"],
}
PANEL_TITLES = {
    0: "Scenario 1 — Co-hydropyrolysis (Pd/SBA-15)",
    1: "Scenario 2 — PS-only pyrolysis + SPK blend (Pd/Al₂O₃)",
}


def npv_at_kg_price(res: dict, price_kg: float) -> float:
    """Equity NPV (USD) at a given selling price in $/kg SAF, via tea_model's DCFROR."""
    return tm.npv_at_price(
        res['FCI'], res['WC'],
        res['VOC_annual_MM'] * 1e6, res['FOC_annual_MM'] * 1e6,
        res['product_kg_yr'], res['byproduct_annual_MM'] * 1e6,
        price_kg,
    )


# ════════════════════════════════════════════════════════════════════════════
# Simulate all 6 base cases (main.py process + tea_model.py Humbird 2011 DCFROR)
# ════════════════════════════════════════════════════════════════════════════
print("=" * 65)
print("Simulating 6 configurations (main.py process + Humbird 2011 DCFROR) ...")
print("=" * 65)
RESULTS = tb.simulate_all()


# ════════════════════════════════════════════════════════════════════════════
# Compute NPV curves ($/kg SAF price sweep)
# ════════════════════════════════════════════════════════════════════════════
print("\nComputing NPV curves (200 price points x 6 configs) ...")

PRICE_KG = np.linspace(0.10, 3.00, 200)

rows_curves = []
npv_data    = {}

for lbl in LABEL_ORDER:
    k   = KEY_MAP[lbl]
    res = RESULTS.get(k)
    if res is None:
        continue

    npv_arr = np.array([npv_at_kg_price(res, p) / 1e6 for p in PRICE_KG])
    npv_data[lbl] = (PRICE_KG, npv_arr)

    for p, n in zip(PRICE_KG, npv_arr):
        rows_curves.append({"config": lbl, "price_kg": round(p, 4),
                            "npv_million": round(n, 4)})

    mfsp  = res['mfsp_per_kg']
    npv_f = npv_at_kg_price(res, FOSSIL_JET_KG) / 1e6
    print(f"  {lbl}: NPV at ${FOSSIL_JET_KG:.2f}/kg = ${npv_f:.0f}M  |  breakeven MFSP = ${mfsp:.2f}/kg")

df_curves = pd.DataFrame(rows_curves)
df_curves.to_csv(os.path.join(DATA_DIR, "npv_curves.csv"), index=False)
print(f"  -> Saved npv_curves.csv ({len(df_curves)} rows)")


# ── NPV at reference prices ───────────────────────────────────────────────────
rows_market = []
for lbl in LABEL_ORDER:
    k   = KEY_MAP[lbl]
    res = RESULTS.get(k)
    if res is None:
        continue
    for ref_kg, ref_label in [(FOSSIL_JET_KG, "fossil_parity"),
                               (SAF_MARKET_KG, "saf_market")]:
        n = npv_at_kg_price(res, ref_kg)
        rows_market.append({
            "config":          lbl,
            "reference":       ref_label,
            "price_kg":        round(ref_kg, 3),
            "npv_million_usd": round(n / 1e6, 2),
            "mfsp_kg":         round(res['mfsp_per_kg'], 3),
        })

df_market = pd.DataFrame(rows_market)
df_market.to_csv(os.path.join(DATA_DIR, "npv_at_market.csv"), index=False)
print(f"  -> Saved npv_at_market.csv ({len(df_market)} rows)")


# ════════════════════════════════════════════════════════════════════════════
# Figure 1: NPV vs. selling price curves — two-panel
# ════════════════════════════════════════════════════════════════════════════
print("\n[Figure 1] NPV vs. selling price curves ...")

fig1, axes1 = plt.subplots(1, 2, figsize=(14, 6), sharey=False)
fig1.suptitle(
    "Equity NPV vs. Product Selling Price — All 6 Configurations\n"
    "NREL/Humbird 2011 DCFROR: 30-yr plant, 10% IRR, 60/40 debt/equity, "
    "MACRS7, 35% tax  (2023 USD, CEPCI 797.9)",
    fontsize=12, fontweight="bold"
)

for pi, ax in enumerate(axes1):
    ax.axhline(0, color="black", linewidth=1.2, zorder=3)
    ax.axvline(FOSSIL_JET_KG, color="navy", linewidth=1.2, linestyle=":",
               zorder=2, label=f"Fossil jet ${FOSSIL_JET_KG:.2f}/kg")
    ax.axvline(SAF_MARKET_KG, color="firebrick", linewidth=1.2, linestyle=":",
               zorder=2, label=f"Parity +20% ${SAF_MARKET_KG:.2f}/kg")

    for lbl in PANEL_CONFIGS[pi]:
        if lbl not in npv_data:
            continue
        m = META[lbl]
        prices, npvs = npv_data[lbl]
        mfsp_kg = RESULTS[KEY_MAP[lbl]]['mfsp_per_kg']
        ax.plot(prices, npvs, color=m["color"], linewidth=2.2, linestyle=m["ls"],
                label=f"{m['label']}  (MFSP=${mfsp_kg:.2f}/kg)")

    ylim = ax.get_ylim()
    ax.fill_between([0.10, 3.00], 0, max(ylim[1], 200),
                    color="#d4edda", alpha=0.20, zorder=0)
    ax.fill_between([0.10, 3.00], min(ylim[0], -200), 0,
                    color="#f8d7da", alpha=0.20, zorder=0)

    ax.set_xlabel("Selling Price ($/kg SAF)", fontsize=10)
    ax.set_ylabel("Equity NPV (M$)", fontsize=10)
    ax.set_title(PANEL_TITLES[pi], fontsize=10, fontweight="bold")
    ax.set_xlim(0.10, 3.00)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x:,.0f}M"))
    ax.legend(fontsize=8.5, loc="lower right" if pi == 0 else "upper left",
              framealpha=0.90, edgecolor="gray")
    for sp in ax.spines.values():
        sp.set_linewidth(0.8)
    ax.grid(axis="y", linewidth=0.4, alpha=0.5, linestyle="--")

fig1.tight_layout(rect=[0, 0, 1, 0.93])
out1 = os.path.join(PLOTS_DIR, "npv_curves.pdf")
fig1.savefig(out1)
plt.show()
plt.close(fig1)
print(f"  -> Saved: {out1}")


# ════════════════════════════════════════════════════════════════════════════
# Figure 2: NPV bar chart at reference prices
# ════════════════════════════════════════════════════════════════════════════
print("[Figure 2] NPV bar chart at reference prices ...")

fig2, axes2 = plt.subplots(1, 2, figsize=(14, 6), sharey=False)
fig2.suptitle(
    "Equity NPV at Reference Selling Prices — All 6 Configurations\n"
    "NREL/Humbird 2011 DCFROR  (2023 USD, CEPCI 797.9)",
    fontsize=12, fontweight="bold"
)

REFS = [("fossil_parity", f"Fossil-Jet Parity  (${FOSSIL_JET_KG:.2f}/kg)", axes2[0]),
        ("saf_market",    f"Parity +20%   (${SAF_MARKET_KG:.2f}/kg)", axes2[1])]

x         = np.arange(len(LABEL_ORDER))
bar_width = 0.60

for ref_key, ref_title, ax in REFS:
    subset     = df_market[df_market["reference"] == ref_key].set_index("config")
    bar_colors = [META[lbl]["color"] for lbl in LABEL_ORDER]
    bar_vals   = [subset.loc[lbl, "npv_million_usd"] if lbl in subset.index else 0.0
                  for lbl in LABEL_ORDER]

    ax.bar(x, bar_vals, width=bar_width, color=bar_colors,
           edgecolor="white", linewidth=0.6, zorder=3)
    ax.axhline(0, color="black", linewidth=1.2, zorder=4)

    for xi, val in zip(x, bar_vals):
        va, off = ("bottom", 5) if val >= 0 else ("top", -5)
        ax.annotate(f"${val:,.0f}M", xy=(xi, val), xytext=(0, off),
                    textcoords="offset points",
                    ha="center", va=va, fontsize=7.5, fontweight="bold")

    ylims = ax.get_ylim()
    ax.fill_between([-0.5, len(LABEL_ORDER) - 0.5], 0, max(ylims[1] * 1.1, 10),
                    color="#d4edda", alpha=0.18, zorder=0)
    ax.fill_between([-0.5, len(LABEL_ORDER) - 0.5], min(ylims[0] * 1.1, -10), 0,
                    color="#f8d7da", alpha=0.18, zorder=0)

    bar_labels = [META[lbl]["label"] for lbl in LABEL_ORDER]
    ax.set_xticks(x)
    ax.set_xticklabels(bar_labels, rotation=30, ha="right", fontsize=9)
    ax.set_ylabel("Equity NPV (M$)", fontsize=10)
    ax.set_title(ref_title, fontsize=10, fontweight="bold")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"${v:,.0f}M"))
    ax.grid(axis="y", linewidth=0.4, alpha=0.5, linestyle="--", zorder=1)
    for sp in ax.spines.values():
        sp.set_linewidth(0.8)

    for xi, lbl in enumerate(LABEL_ORDER):
        mfsp = subset.loc[lbl, "mfsp_kg"] if lbl in subset.index else 0.0
        ax.text(xi, ax.get_ylim()[1] * 0.97, f"MFSP\n${mfsp:.2f}/kg",
                ha="center", va="top", fontsize=6.5, color="#444444", style="italic")

fig2.tight_layout(rect=[0, 0, 1, 0.93])
out2 = os.path.join(PLOTS_DIR, "npv_bar.pdf")
fig2.savefig(out2)
plt.show()
plt.close(fig2)
print(f"  -> Saved: {out2}")


# ════════════════════════════════════════════════════════════════════════════
# Figure 3: Combined summary (curves top, bars bottom)
# ════════════════════════════════════════════════════════════════════════════
print("[Figure 3] Combined NPV summary figure ...")

fig3 = plt.figure(figsize=(16, 13))
gs   = fig3.add_gridspec(2, 2, hspace=0.35, wspace=0.30, height_ratios=[1.1, 1])
ax_c1 = fig3.add_subplot(gs[0, 0])
ax_c2 = fig3.add_subplot(gs[0, 1])
ax_b1 = fig3.add_subplot(gs[1, 0])
ax_b2 = fig3.add_subplot(gs[1, 1])

fig3.suptitle(
    "Net Present Value Analysis — All 6 SAF Configurations\n"
    "NREL/Humbird 2011 DCFROR: 30-yr plant, 10% IRR, 60/40 debt/equity, "
    "MACRS7, 35% tax  (2023 USD, CEPCI 797.9)",
    fontsize=13, fontweight="bold", y=0.995
)

for pi, (ax, ptitle) in enumerate([
    (ax_c1, PANEL_TITLES[0]),
    (ax_c2, PANEL_TITLES[1]),
]):
    ax.axhline(0, color="black", linewidth=1.2, zorder=3)
    ax.axvline(FOSSIL_JET_KG, color="navy", linewidth=1.1, linestyle=":",
               zorder=2, label=f"Fossil parity ${FOSSIL_JET_KG:.2f}/kg")
    ax.axvline(SAF_MARKET_KG, color="firebrick", linewidth=1.1, linestyle=":",
               zorder=2, label=f"Parity +20% ${SAF_MARKET_KG:.2f}/kg")

    for lbl in PANEL_CONFIGS[pi]:
        if lbl not in npv_data:
            continue
        m = META[lbl]
        prices, npvs = npv_data[lbl]
        mfsp_kg = RESULTS[KEY_MAP[lbl]]['mfsp_per_kg']
        ax.plot(prices, npvs, color=m["color"], linewidth=2.0, linestyle=m["ls"],
                label=f"{m['label']}  (MFSP=${mfsp_kg:.2f}/kg)")

    ylim = ax.get_ylim()
    ax.fill_between([0.10, 3.00], 0, max(ylim[1], 200),
                    color="#d4edda", alpha=0.18, zorder=0)
    ax.fill_between([0.10, 3.00], min(ylim[0], -200), 0,
                    color="#f8d7da", alpha=0.18, zorder=0)

    ax.set_xlabel("Selling Price ($/kg SAF)", fontsize=10)
    ax.set_ylabel("Equity NPV (M$)", fontsize=10)
    ax.set_title(ptitle, fontsize=9.5, fontweight="bold")
    ax.set_xlim(0.10, 3.00)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"${v:,.0f}M"))
    ax.legend(fontsize=8, loc="lower right" if pi == 0 else "upper left",
              framealpha=0.90, edgecolor="gray")
    ax.grid(axis="y", linewidth=0.35, alpha=0.45, linestyle="--")
    for sp in ax.spines.values():
        sp.set_linewidth(0.7)

for ref_key, ref_title, ax in [
    ("fossil_parity", f"At Fossil-Jet Parity  (${FOSSIL_JET_KG:.2f}/kg)", ax_b1),
    ("saf_market",    f"At Parity +20%   (${SAF_MARKET_KG:.2f}/kg)", ax_b2),
]:
    subset    = df_market[df_market["reference"] == ref_key].set_index("config")
    bar_vals  = [subset.loc[lbl, "npv_million_usd"] if lbl in subset.index else 0.0
                 for lbl in LABEL_ORDER]
    bar_colors = [META[lbl]["color"] for lbl in LABEL_ORDER]
    ax.bar(x, bar_vals, width=bar_width, color=bar_colors,
           edgecolor="white", linewidth=0.6, zorder=3)
    ax.axhline(0, color="black", linewidth=1.2, zorder=4)
    for xi, val in zip(x, bar_vals):
        va, off = ("bottom", 4) if val >= 0 else ("top", -4)
        ax.annotate(f"${val:,.0f}M", xy=(xi, val), xytext=(0, off),
                    textcoords="offset points", ha="center", va=va, fontsize=7)

    short_labels = [lbl.replace("Sc1_", "Sc1\n").replace("Sc2_", "Sc2\n")
                    .replace("Photocatalysis", "Photo") for lbl in LABEL_ORDER]
    ax.set_xticks(x)
    ax.set_xticklabels(short_labels, fontsize=8.5)
    ax.set_ylabel("Equity NPV (M$)", fontsize=10)
    ax.set_title(ref_title, fontsize=9.5, fontweight="bold")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"${v:,.0f}M"))
    ax.grid(axis="y", linewidth=0.35, alpha=0.45, linestyle="--", zorder=1)
    for sp in ax.spines.values():
        sp.set_linewidth(0.7)

out3 = os.path.join(PLOTS_DIR, "npv_summary.pdf")
fig3.savefig(out3)
plt.show()
plt.close(fig3)
print(f"  -> Saved: {out3}")

print("\nAll NPV plots complete.")
