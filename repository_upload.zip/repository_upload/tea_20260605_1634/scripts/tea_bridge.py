"""
tea_bridge.py — adapter between main.py's BioSTEAM process simulation and
tea_model.py's NREL/Humbird 2011 DCFROR financial engine.

Process engineering (unit operations, purchase costs, utility/feedstock
duties) is sourced from main.py's build_flowsheet() — the process model is
not duplicated here. All financial math (Peters/Timmerhaus/West capital factors,
60/40 debt/equity, MACRS7 depreciation, 35% tax, 3-yr construction schedule,
6-month startup, ±20% sensitivity, LHS Monte Carlo) comes from tea_model.py.

This keeps a single source of truth for the physical process (main.py) and
a single source of truth for TEA assumptions (tea_model.py), so every plot
built on top of this bridge reflects the same NREL/Humbird 2011 DCFROR
method as data/*.csv.
"""

from __future__ import annotations

import os
import sys
import importlib.util as _ilu

# ── resolve paths ─────────────────────────────────────────────────────────────
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
RUN_DIR    = os.path.dirname(SCRIPT_DIR)           # tea_20260605_1634/
MODULE_DIR = os.path.dirname(RUN_DIR)              # Module/ (source code)
DATA_DIR   = os.path.join(RUN_DIR, "data")
PLOTS_DIR  = os.path.join(RUN_DIR, "plots")
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(PLOTS_DIR, exist_ok=True)

sys.path.insert(0, MODULE_DIR)
sys.path.insert(0, SCRIPT_DIR)

# ── import main.py's process simulation (engineering layer) ──────────────────
_spec = _ilu.spec_from_file_location("_main_sim", os.path.join(MODULE_DIR, "main.py"))
_main = _ilu.module_from_spec(_spec)
_spec.loader.exec_module(_main)

setup_chemicals = _main.setup_chemicals
build_flowsheet = _main.build_flowsheet
H2_CONFIGS      = _main.H2_CONFIGS

from tea import SAF_TEA_Parameters   # kept as the params container build_flowsheet expects

import tea_model as tm               # NREL/Humbird 2011 DCFROR engine — source of truth for TEA assumptions

SCENARIO_KEYS = [(1, 'SMR'), (1, 'Photocatalysis'), (1, 'SOEC'),
                 (2, 'SMR'), (2, 'Photocatalysis'), (2, 'SOEC')]
LABEL_ORDER   = ["Sc1_SMR", "Sc1_Photocatalysis", "Sc1_SOEC",
                 "Sc2_SMR", "Sc2_Photocatalysis", "Sc2_SOEC"]


def key_to_label(k: tuple) -> str:
    sc, h2 = k
    return f"Sc{sc}_{h2}"


def get_params() -> SAF_TEA_Parameters:
    """
    SAF_TEA_Parameters container for build_flowsheet(), with feedstock/
    byproduct prices aligned to tea_model.py's NREL/Humbird-consistent values
    (tea.py's own defaults price waste PS as a purchased commodity at
    $0.60/kg; tea_model.py correctly treats it as a low-cost waste feedstock
    at $0.05/kg — this must match exactly, since the sensitivity/uncertainty
    routines below decompose feedstock cost using tea_model's PS_PRICE_KG).
    """
    p = SAF_TEA_Parameters()
    p.PS_price        = tm.PS_PRICE_KG
    p.waste_oil_price = tm.OIL_PRICE_KG
    p.char_price      = tm.CHAR_PRICE_KG
    p.oxygen_price    = tm.OXYGEN_PRICE_KG
    p.SPK_price       = tm.SPK_PRICE_KG
    return p


def _heat_cost_hr(unit) -> float:
    """Heat utility cost at tea_model.py's Humbird-consistent HEAT_PRICE_GJ —
    NOT BioSTEAM's own default utility-agent pricing (bst.Unit.utility_cost),
    which main.py's build_flowsheet uses internally and which does not match
    the NREL/Humbird 2011 assumptions this project is priced against."""
    return sum(hu.duty for hu in unit.heat_utilities) / 3600 * tm.HEAT_PRICE_GJ / 277.778


def _cfg_from_result(res: dict) -> dict:
    """
    Adapt main.py's build_flowsheet() output into tea_model.py's cfg schema.

    Recomputes utility_cost_hr and feedstock_cost_hr from the underlying unit
    objects using tea_model.py's own pricing methodology (Humbird HEAT_PRICE_GJ
    for heat, stoichiometric CH4 mass flow x CH4_PRICE_GJ costed as feedstock
    for SMR, escalated ELEC_PRICE_KWH for PC/SOEC) instead of main.py's own
    res['utility_cost_hr']/res['feedstock_cost_hr'], which mix BioSTEAM's
    default utility-agent prices with main.py's own NG-as-utility convention.
    This keeps pricing identical between tea_model.py's own CSV/report run and
    every config priced through this bridge for the plots.
    """
    pretreat, pyrolyzer, hydro, h2_unit = res['pretreat'], res['pyrolyzer'], res['hydro'], res['h2_unit']
    blender  = res.get('blender')
    h2_source = res['h2_source']

    pretreat_heat_hr = _heat_cost_hr(pretreat)
    pretreat_util_hr = getattr(pretreat, "_utility_cost_hr", 0.0)   # shredder electricity + wash water
    pyro_heat_hr  = _heat_cost_hr(pyrolyzer)
    hydro_heat_hr = _heat_cost_hr(hydro)
    blend_heat_hr = _heat_cost_hr(blender) if blender else 0.0
    # SMR's own _utility_cost_hr is a heuristic NG-intensity estimate that
    # would duplicate the stoichiometric CH4 feedstock cost below — excluded,
    # same fix as tea_model.py's simulate_config().
    h2_util_hr = 0.0 if h2_source == "SMR" else getattr(h2_unit, "_utility_cost_hr", 0.0)
    utility_cost_hr = (pretreat_heat_hr + pretreat_util_hr
                        + pyro_heat_hr + hydro_heat_hr + blend_heat_hr + h2_util_hr)
    catalyst_cost_hr = tm.catalyst_inventory_usd([hydro, blender]) * tm.CATALYST_ANNUAL_FRAC / tm.OPERATING_HR
    utility_cost_hr += catalyst_cost_hr   # R1 update 15 (same as tea_model.simulate_config)

    oil_kg_hr = pyrolyzer.ins[1].F_mass
    # Priced on the RAW PS intake (what's purchased/collected), not the clean
    # PS reaching the pyrolyzer after pretreatment losses.
    feedstock_cost_hr = res['raw_ps_kg_hr'] * tm.PS_PRICE_KG + oil_kg_hr * tm.OIL_PRICE_KG
    if h2_source == "SMR":
        ch4_kg_hr = h2_unit.ins[0].get_flow("kg/hr", "Methane")
        feedstock_cost_hr += ch4_kg_hr * tm.CH4_HHV_GJ_KG * tm.CH4_PRICE_GJ
    spk_kg_hr = res.get('spk_kg_hr', 0.0)
    if res['scenario'] == 2:
        feedstock_cost_hr += spk_kg_hr * tm.SPK_PRICE_KG

    # main.py's build_flowsheet only credits char byproduct revenue — it never
    # adds the O2 credit for Photocatalysis/SOEC, or the pyrolysis off-gas heat
    # credit, that tea_model.py includes. Recomputed here so both paths give
    # the same byproduct revenue.
    char_kg_hr = pyrolyzer.outs[1].F_mass
    byproduct_revenue_hr = char_kg_hr * tm.CHAR_PRICE_KG
    ends_kg_hr = blender.ends_kg_hr if blender else 0.0
    byproduct_revenue_hr += ends_kg_hr * tm.SC2_ENDS_LHV_MJ_KG / 1000.0 * tm.HEAT_PRICE_GJ   # R1 other-ends fuel-value credit
    if h2_source in ("Photocatalysis", "SOEC"):
        o2_kg_hr = h2_unit.outs[1].F_mass
        byproduct_revenue_hr += o2_kg_hr * tm.OXYGEN_PRICE_KG

    # Pyrolysis off-gas heat credit: burn the CH4/H2-bearing gas on-site for
    # process heat instead of venting it, capped at the actual purchased-heat
    # spend (same convention as tea_model.py's simulate_config()).
    gas = pyrolyzer.outs[2]
    gas_ch4_kg_hr = gas.get_flow("kg/hr", "Methane")
    gas_h2_kg_hr  = gas.get_flow("kg/hr", "Hydrogen")
    gas_fuel_value_hr = (gas_ch4_kg_hr * tm.CH4_HHV_GJ_KG
                          + gas_h2_kg_hr * tm.H2_HHV_GJ_KG) * tm.HEAT_PRICE_GJ
    purchased_heat_hr = pretreat_heat_hr + pyro_heat_hr + hydro_heat_hr + blend_heat_hr
    byproduct_revenue_hr += min(gas_fuel_value_hr, purchased_heat_hr)

    return dict(
        scenario=res['scenario'], h2_source=h2_source,
        tpec=res['total_purchase_cost'],
        utility_cost_hr=utility_cost_hr,
        feedstock_cost_hr=feedstock_cost_hr,
        byproduct_revenue_hr=byproduct_revenue_hr,
        saf_kg_hr=res['saf_out_kg_hr'],
        spk_kg_hr=spk_kg_hr,
        additive_kg_hr=(blender.additive_kg_hr if blender else 0.0), ends_kg_hr=ends_kg_hr,
        streams=dict(
            ps_kg_hr=res['raw_ps_kg_hr'],           # raw PS purchased (pricing basis)
            clean_ps_kg_hr=pyrolyzer.ins[0].F_mass,  # clean PS reaching the pyrolyzer
            pretreat_reject_kg_hr=pretreat.outs[1].F_mass,
            h2_kg_hr=res.get('H2_demand', 0.0),
            gas_ch4_kg_hr=gas_ch4_kg_hr,
            gas_h2_kg_hr=gas_h2_kg_hr,
        ),
        catalyst_cost_hr=catalyst_cost_hr,
    )


def simulate_all(params: SAF_TEA_Parameters | None = None):
    """
    Run all 6 configurations through main.py's process simulation, then
    price them with tea_model.py's Humbird 2011 DCFROR method.

    Returns
    -------
    RES : {(scenario, h2_source): merged dict of engineering + cfg + DCFROR results}
          Includes main.py's raw fields (pyrolyzer, h2_unit, hydro, blender,
          co2_kg_per_kgSAF, ...) plus tea_model's DCFROR fields (FCI, TCI,
          mfsp_gge, mfsp_per_kg, feedstock_contr, capital_contr, ...).
    """
    if params is None:
        params = get_params()
    setup_chemicals()

    RES = {}
    for sc, h2_src in SCENARIO_KEYS:
        res = build_flowsheet(
            sc, h2_src, params,
            electricity_price=tm.ELEC_PRICE_KWH,
            ch4_price=tm.CH4_PRICE_GJ,
        )
        cfg = _cfg_from_result(res)
        tea = tm.run_tea(cfg)
        RES[(sc, h2_src)] = {**res, **cfg, **tea}
        print(f"  {key_to_label((sc, h2_src)):<20} "
              f"MFSP = ${tea['mfsp_gge']:.2f}/GGE  |  FCI = ${tea['FCI']/1e6:.1f} MM")
    return RES


def sensitivity_for(k: tuple, RES: dict):
    """tea_model.py ±20% sensitivity table for one configuration."""
    sc, h2_src = k
    res = RES[k]
    cfg = _cfg_from_result(res)
    return tm.run_sensitivity(sc, h2_src, cfg, res)


def uncertainty_for(k: tuple, RES: dict, n: int = 1000):
    """tea_model.py LHS Monte Carlo uncertainty for one configuration. Returns (samples_df, summary_df, spearman_df)."""
    sc, h2_src = k
    res = RES[k]
    cfg = _cfg_from_result(res)
    return tm.run_uncertainty(sc, h2_src, cfg, res, n=n)
