"""
make_tornado.py — Sensitivity tornado plots for TEA (MFSP) and LCA (GHG).

TEA tornado : reads sensitivity.csv (±20% one-at-a-time, 8 parameters)
LCA tornado : perturbs key LCA parameters ±20% and recomputes GHG intensity
              (g CO₂ eq / MJ SAF, well-to-gate, TRACI 2.1)

Outputs
-------
  lca_tornado_tea.pdf     2×3 panel — MFSP sensitivity by scenario
  lca_tornado_lca.pdf     2×3 panel — GHG sensitivity by scenario
  lca_tornado_combined.pdf  stacked 2-row figure (TEA top, LCA bottom)
"""

from __future__ import annotations
import os, sys, warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import sys as _s, os as _o
_s.path.insert(0, _o.path.dirname(_o.path.dirname(_o.path.dirname(_o.path.abspath(__file__)))))
import scenario_relabel  # R1.14: display swap Sc1<->Sc2 (set SCENARIO_RELABEL=0 to disable)
import matplotlib
# Standalone run: force Agg (fast, headless). Loaded by main.py inside an
# IPython/Jupyter session: leave the backend main.py already configured
# (inline / TkAgg) alone so plt.show() calls below actually render.
try:
    get_ipython()
except NameError:
    matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
RUN_DIR    = os.path.dirname(SCRIPT_DIR)
MODULE_DIR = os.path.dirname(RUN_DIR)
DATA_DIR   = os.path.join(RUN_DIR, "data")
sys.path.insert(0, SCRIPT_DIR)
sys.path.insert(0, MODULE_DIR)

# ── import main.py simulation engine ─────────────────────────────────────────
import importlib.util as _ilu
_spec = _ilu.spec_from_file_location("_main_sim", os.path.join(MODULE_DIR, "main.py"))
_main = _ilu.module_from_spec(_spec)
_spec.loader.exec_module(_main)

setup_chemicals        = _main.setup_chemicals
run_all_configurations = _main.run_all_configurations

import tea_bridge as _tb   # same NREL/Humbird 2011 DCFROR engine as tea_report.md

print("[make_tornado] Simulating 6 configurations ...")
setup_chemicals()
_RESULTS = run_all_configurations()
print("[make_tornado] Simulation complete.")

_KEY_MAP = {
    "Sc1+SMR":   (1, "SMR"),
    "Sc1+SOEC":  (1, "SOEC"),
    "Sc1+Photo": (1, "Photocatalysis"),
    "Sc2+SMR":   (2, "SMR"),
    "Sc2+SOEC":  (2, "SOEC"),
    "Sc2+Photo": (2, "Photocatalysis"),
}


def _tea_sensitivity_rows(lbl):
    """Return (rows, base_msp) for tornado; rows = [(param, delta_lo, delta_hi)].
    Sourced from tea_model.py's own ±20% sensitivity engine via tea_bridge.py --
    the same 7-8 parameter set (Pyrolysis liquid yield, PS feedstock cost,
    On-stream factor, Total installed capital, Plant capacity, IRR, H2/energy
    cost, +SPK feedstock price for Sc2) used in tea_report.md's §6."""
    key = _KEY_MAP.get(lbl)
    res = _RESULTS.get(key) if key else None
    if res is None:
        return [], 0.0
    base = res['mfsp_per_kg']
    df = _tb.sensitivity_for(key, _RESULTS)
    rows = list(zip(df['parameter'], df['delta_low'], df['delta_high']))
    return rows, base


from make_lca import (
    CATEGORIES, FOSSIL_JET_GWP_PER_MJ,
    LABEL_ORDER, SC_COLORS,
    OLCA_FILES, OLCA_DIR,
    SMR_GWP_PER_KG_H2, SOEC_KWH_PER_KG_H2, PHOTO_AUX_KWH_PER_KG_H2,
    PYRO_HEAT_MJ_PER_KG_FEED, NG_HEAT_GWP_PER_MJ, WATER_KG_PER_KG_H2,
    CHAR_CREDIT_GWP, CHAR_LHV_MJ_PER_KG, COAL_GWP_PER_MJ,
    WCO_CREDIT_MODE, INCLUDE_CHAR_CREDIT, INCLUDE_COMBUSTION,
    C_FRAC_PS, C_FRAC_WCO, C_FRAC_EB, C_FRAC_SC1_PRODUCT, CO2_PER_C,
    load_all_impacts, compute_inventory,
    spk_gwp_per_kg, fossil_carbon_share, char_credit_gwp_per_kg, offgas_terms,
    run_lca,
    simulate_config, SAF_LHV_MJ_KG, BLEND_LHV_MJ_KG, SC2_ENDS_LHV_MJ_KG,
)

OUT_DIR = os.path.join(MODULE_DIR, "TEA_Outputs_20260608")
os.makedirs(OUT_DIR, exist_ok=True)

plt.rcParams.update({
    "font.family": "serif",
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.linewidth": 0.8,
    "figure.dpi": 150,
})

# ── scenario label translation ────────────────────────────────────────────────
SC_CSV_TO_LABEL = {
    "Sc1_SMR":          "Sc1+SMR",
    "Sc1_SOEC":         "Sc1+SOEC",
    "Sc1_Photocatalysis":"Sc1+Photo",
    "Sc2_SMR":          "Sc2+SMR",
    "Sc2_SOEC":         "Sc2+SOEC",
    "Sc2_Photocatalysis":"Sc2+Photo",
}

SC_TO_SIM = {
    "Sc1+SMR":   (1, "SMR"),
    "Sc1+SOEC":  (1, "SOEC"),
    "Sc1+Photo": (1, "Photocatalysis"),
    "Sc2+SMR":   (2, "SMR"),
    "Sc2+SOEC":  (2, "SOEC"),
    "Sc2+Photo": (2, "Photocatalysis"),
}

PARAM_DISPLAY = {
    "Pyrolysis liquid yield": "Pyrolysis liquid yield",
    "On-stream factor":       "On-stream factor",
    "Total installed capital":"Total installed capital",
    "Plant capacity":         "Plant capacity",
    "IRR":                    "Internal rate of return",
    "H2 / energy cost":       "H2 / energy cost",
    "PS feedstock cost":      "PS feedstock cost",
    "SPK feedstock price":    "SPK feedstock price",
}

# ══════════════════════════════════════════════════════════════════════════════
# 1. TEA Tornado
# ══════════════════════════════════════════════════════════════════════════════
def _draw_tornado(ax, rows, base_val, xlabel, title, color_lo="#1976D2",
                  color_hi="#D32F2F", base_color="#212121"):
    """
    Draw a horizontal tornado bar chart.
    rows : list of (param_label, delta_lo, delta_hi)  — sorted by total swing
    """
    n = len(rows)
    y = np.arange(n)

    for i, (lbl, dlo, dhi) in enumerate(rows):
        # bar toward lower value (delta < 0 = beneficial)
        if dlo < 0:
            ax.barh(i, dlo, color=color_lo, alpha=0.85, height=0.55,
                    align="center", linewidth=0)
        else:
            ax.barh(i, dlo, color=color_hi, alpha=0.85, height=0.55,
                    align="center", linewidth=0)
        # bar toward higher value
        if dhi > 0:
            ax.barh(i, dhi, color=color_hi, alpha=0.85, height=0.55,
                    align="center", linewidth=0)
        else:
            ax.barh(i, dhi, color=color_lo, alpha=0.85, height=0.55,
                    align="center", linewidth=0)

    ax.axvline(0, color=base_color, lw=1.2, zorder=4)
    ax.set_yticks(y)
    ax.set_yticklabels([r[0] for r in rows], fontsize=8.5)
    ax.set_xlabel(xlabel, fontsize=8.5)
    ax.set_title(title, fontsize=9.5, fontweight="bold", pad=5,
                 color=SC_COLORS.get(title, "#222222"))
    ax.xaxis.grid(True, ls=":", lw=0.5, alpha=0.6)
    ax.set_axisbelow(True)
    ax.tick_params(axis="x", labelsize=8)

    # annotation: base value
    ax.text(0.02, -0.14, f"Base: {base_val:.2f}",
            transform=ax.transAxes, fontsize=7.5, color="#555")


def plot_tea_tornado(out_path):
    fig, axes = plt.subplots(2, 3, figsize=(16, 9))
    axes_flat = axes.flatten()

    for ax, lbl in zip(axes_flat, LABEL_ORDER):
        rows, base = _tea_sensitivity_rows(lbl)
        _draw_tornado(ax, rows, base_val=base,
                      xlabel="Delta MFSP ($/kg SAF)",
                      title=lbl)

    legend_elements = [
        mpatches.Patch(fc="#D32F2F", alpha=0.85, label="Increases MFSP"),
        mpatches.Patch(fc="#1976D2", alpha=0.85, label="Decreases MFSP"),
    ]
    fig.legend(handles=legend_elements, loc="lower center", ncol=2,
               fontsize=9, bbox_to_anchor=(0.5, -0.01), framealpha=0.9)

    fig.suptitle("TEA Sensitivity Analysis -- MFSP Tornado (+-20% one-at-a-time)\n"
                 "All 6 SAF Configurations | 2023 USD | main.py BioSTEAM simulation",
                 fontsize=11.5, y=1.01)
    fig.tight_layout(rect=[0, 0.04, 1, 1])
    fig.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved -> {out_path}")


# ══════════════════════════════════════════════════════════════════════════════
# 2. LCA GHG Tornado — perturb LCA parameters ±20%
# ══════════════════════════════════════════════════════════════════════════════
LCA_PARAMS = [
    # (param_key, display_name, applies_to_h2, applies_to_sc)
    # applies_to_h2: None = all, or list of h2 source labels
    # applies_to_sc: None = all, or list of sc numbers
    ("smr_gwp",       "SMR H2 GHG factor",        ["SMR"],                    None),
    ("soec_elec",     "SOEC electricity demand",   ["SOEC"],                   None),
    ("photo_elec",    "Photo auxiliary electricity",["Photocatalysis"],         None),
    ("liq_yield",     "Pyrolysis liquid yield",    None,                       None),
    ("process_heat",  "Process heat (NG)",         None,                       None),
    ("wco_credit",    "WCO treatment credit",      None,                       [1]),
    ("char_credit",   "Char co-product credit",    None,                       None),
    ("spk_impact",    "Purchased SPK impact",      None,                       [2]),
]


def ghg_base(cfg, factors, **overrides):
    """Compute GHG intensity (g CO₂/MJ SAF) with optional LCA parameter overrides."""
    import copy

    # Build modified inventory
    saf      = cfg["saf_kg_hr"]
    streams  = cfg["streams"]
    h2_src   = cfg["h2_source"]
    sc       = cfg["scenario"]
    lhv      = SAF_LHV_MJ_KG if sc == 1 else BLEND_LHV_MJ_KG

    h2_per_saf   = cfg["H2_demand"] / saf
    oil_per_saf  = streams["oil_kg_hr"] / saf
    char_per_saf = streams["char_kg_hr"] / saf
    spk_per_saf  = cfg["spk_kg_hr"] / saf
    water_per_saf = WATER_KG_PER_KG_H2 * h2_per_saf
    # clean PS reaching the pyrolyzer (not the raw pretreatment intake) --
    # pyrolysis heat scales with what's actually fed to the reactor
    total_feed_hr = streams["clean_ps_kg_hr"] + streams["oil_kg_hr"]
    pyro_heat_mj_per_kg = overrides.get("process_heat", PYRO_HEAT_MJ_PER_KG_FEED)
    process_heat_per_saf = pyro_heat_mj_per_kg * total_feed_hr / saf
    _fs = fossil_carbon_share(cfg)
    _disp, offgas_co2 = offgas_terms(cfg, process_heat_per_saf, _fs)   # R1 update 15: same as make_lca
    process_heat_per_saf -= _disp

    # Pyrolysis liquid yield override: more SAF per unit feed → scale per-saf ratios
    liq_mult = overrides.get("liq_yield", 1.0)
    if liq_mult != 1.0:
        h2_per_saf   /= liq_mult
        oil_per_saf  /= liq_mult
        char_per_saf /= liq_mult
        spk_per_saf  /= liq_mult
        water_per_saf /= liq_mult
        process_heat_per_saf /= liq_mult

    # H₂ electricity demand overrides
    smr_gwp_use  = overrides.get("smr_gwp", SMR_GWP_PER_KG_H2)
    soec_kwh_use = overrides.get("soec_elec", SOEC_KWH_PER_KG_H2)
    photo_kwh_use= overrides.get("photo_elec", PHOTO_AUX_KWH_PER_KG_H2)

    smr_gwp_apme = factors["smr_h2"].get("Global warming", 1.697)
    smr_scale    = smr_gwp_use / smr_gwp_apme

    if h2_src == "SOEC":
        elec_kwh_per_saf = soec_kwh_use * h2_per_saf
    elif h2_src == "Photocatalysis":
        elec_kwh_per_saf = photo_kwh_use * h2_per_saf
    else:
        elec_kwh_per_saf = 0.0

    # WCO / char credit scale
    wco_scale  = overrides.get("wco_credit",  1.0)
    char_scale = overrides.get("char_credit", 1.0)
    spk_scale  = overrides.get("spk_impact",  1.0)

    cat = "Global warming"

    # H₂ impact
    if h2_src == "SMR":
        h2_val = h2_per_saf * smr_gwp_use
    elif h2_src == "SOEC":
        # R1 FIX: SOEC runs on NGCC grid power (as in make_lca.py). This replica previously used
        # PV factors and no water, which made SOEC look like photocatalysis (cause of the
        # Fig. 14 vs Table S9 SOEC mismatch).
        h2_val = (water_per_saf * factors["water"].get(cat, 0.0)
                  + elec_kwh_per_saf * factors["ng_elec"].get(cat, 0.0))
    else:
        h2_val = (water_per_saf * factors["water"].get(cat, 0.0)
                  + elec_kwh_per_saf * factors["pv_elec"].get(cat, 0.0))

    # Process heat
    ht_val = process_heat_per_saf * NG_HEAT_GWP_PER_MJ + offgas_co2 / liq_mult

    # SPK
    spk_val = spk_per_saf * spk_gwp_per_kg(factors) * spk_scale

    # WCO credit
    oil_credit = (-oil_per_saf * factors["waste_oil"].get(cat, 0.0) * wco_scale
                  if WCO_CREDIT_MODE == "incineration" else 0.0)

    # Char credit
    char_credit_gwp = char_credit_gwp_per_kg(_fs) * char_scale
    char_credit = -char_per_saf * char_credit_gwp if INCLUDE_CHAR_CREDIT else 0.0

    # Fossil-carbon combustion (well-to-wake), same rule as make_lca.compute_inventory
    comb_val = 0.0
    if INCLUDE_COMBUSTION:
        if sc == 1:
            c_ps  = streams["clean_ps_kg_hr"] * C_FRAC_PS
            c_oil = streams["oil_kg_hr"] * C_FRAC_WCO
            comb_val = c_ps / (c_ps + c_oil) * C_FRAC_SC1_PRODUCT * CO2_PER_C
        else:
            comb_val = (1.0 - cfg["spk_kg_hr"] / saf) * C_FRAC_EB * CO2_PER_C
            _ends = cfg.get("ends_kg_hr", 0.0) / saf / liq_mult      # R1: other-ends net burden (see make_lca.compute_inventory)
            comb_val += _ends * (C_FRAC_EB * CO2_PER_C - SC2_ENDS_LHV_MJ_KG * NG_HEAT_GWP_PER_MJ)

    total_per_kg = h2_val + ht_val + spk_val + oil_credit + char_credit + comb_val
    return total_per_kg / lhv * 1e3  # g CO₂/MJ


def run_lca_sensitivity():
    """
    For each scenario, perturb each applicable LCA parameter ±20%
    and record delta GHG (g CO₂/MJ SAF).
    Returns dict {label: list of (param_display, delta_lo, delta_hi, base)}
    """
    factors = load_all_impacts()
    results = {}

    for lbl in LABEL_ORDER:
        sc, h2 = SC_TO_SIM[lbl]
        cfg  = simulate_config(sc, h2)
        base = ghg_base(cfg, factors)

        rows = []
        for pkey, pname, h2_filter, sc_filter in LCA_PARAMS:
            # Skip if not applicable to this H₂ source or scenario
            if h2_filter and h2 not in h2_filter:
                continue
            if sc_filter and sc not in sc_filter:
                continue

            lo_kw = {pkey: 0.8}
            hi_kw = {pkey: 1.2}

            # For absolute parameters, ±20% multiplier:
            # smr_gwp, soec_elec, photo_elec, process_heat:
            #   lo = base × 0.8, hi = base × 1.2
            if pkey == "smr_gwp":
                lo_kw = {"smr_gwp": SMR_GWP_PER_KG_H2 * 0.8}
                hi_kw = {"smr_gwp": SMR_GWP_PER_KG_H2 * 1.2}
            elif pkey == "soec_elec":
                lo_kw = {"soec_elec": SOEC_KWH_PER_KG_H2 * 0.8}
                hi_kw = {"soec_elec": SOEC_KWH_PER_KG_H2 * 1.2}
            elif pkey == "photo_elec":
                lo_kw = {"photo_elec": PHOTO_AUX_KWH_PER_KG_H2 * 0.8}
                hi_kw = {"photo_elec": PHOTO_AUX_KWH_PER_KG_H2 * 1.2}
            elif pkey == "process_heat":
                lo_kw = {"process_heat": PYRO_HEAT_MJ_PER_KG_FEED * 0.8}
                hi_kw = {"process_heat": PYRO_HEAT_MJ_PER_KG_FEED * 1.2}
            # liq_yield, wco_credit, char_credit, spk_impact: scale factor
            # lo_kw / hi_kw already set as 0.8 / 1.2

            ghg_lo = ghg_base(cfg, factors, **lo_kw)
            ghg_hi = ghg_base(cfg, factors, **hi_kw)

            rows.append((pname, ghg_lo - base, ghg_hi - base))

        # Sort by total swing (descending → top of tornado)
        rows.sort(key=lambda r: abs(r[1]) + abs(r[2]), reverse=False)
        results[lbl] = (rows, base)

    return results


def plot_lca_tornado(sens_results, out_path):
    fig, axes = plt.subplots(2, 3, figsize=(16, 9))
    axes_flat = axes.flatten()

    for ax, lbl in zip(axes_flat, LABEL_ORDER):
        rows, base = sens_results[lbl]
        _draw_tornado(ax, rows, base_val=base,
                      xlabel="Delta GHG (g CO2 eq / MJ SAF)",
                      title=lbl,
                      color_lo="#2196A6",   # teal = decreases GHG (beneficial)
                      color_hi="#E53935")   # red  = increases GHG

        # Fossil jet reference annotation
        ax.text(0.98, 0.02, f"Fossil Jet: 88.9 g/MJ",
                transform=ax.transAxes, fontsize=7, color="#B71C1C",
                ha="right", va="bottom")

    legend_elements = [
        mpatches.Patch(fc="#E53935", alpha=0.85, label="Increases GHG intensity"),
        mpatches.Patch(fc="#2196A6", alpha=0.85, label="Decreases GHG intensity"),
    ]
    fig.legend(handles=legend_elements, loc="lower center", ncol=2,
               fontsize=9, bbox_to_anchor=(0.5, -0.01), framealpha=0.9)

    fig.suptitle("LCA Sensitivity Analysis -- GHG Tornado (+-20% one-at-a-time)\n"
                 "All 6 Configurations | Well-to-Wake | TRACI 2.1 GWP (g CO2-eq/MJ)",
                 fontsize=11.5, y=1.01)
    fig.tight_layout(rect=[0, 0.04, 1, 1])
    fig.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.show()
    plt.close(fig)
    print(f"  Saved -> {out_path}")


# ══════════════════════════════════════════════════════════════════════════════
# 3. Combined 2-row figure (TEA top, LCA bottom)
# ══════════════════════════════════════════════════════════════════════════════
def plot_combined(sens_lca, out_path):
    """
    4-row × 3-col figure:
      Top 2 rows  = TEA MFSP tornado (one row per Sc tier)
      Bot 2 rows  = LCA GHG tornado
    """
    fig, axes = plt.subplots(4, 3, figsize=(17, 19))

    # ── TEA rows 0-1 ─────────────────────────────────────────────────────────
    sc1_lbls = [l for l in LABEL_ORDER if "Sc1" in l]
    sc2_lbls = [l for l in LABEL_ORDER if "Sc2" in l]

    for col, lbl in enumerate(sc1_lbls):
        ax = axes[0][col]
        rows_tea, base = _tea_sensitivity_rows(lbl)
        _draw_tornado(ax, rows_tea, base_val=base,
                      xlabel="Delta MFSP ($/kg SAF)", title=lbl)
        if col == 0:
            ax.set_ylabel("TEA parameter", fontsize=9, labelpad=8)

    for col, lbl in enumerate(sc2_lbls):
        ax = axes[1][col]
        rows_tea, base = _tea_sensitivity_rows(lbl)
        _draw_tornado(ax, rows_tea, base_val=base,
                      xlabel="Delta MFSP ($/kg SAF)", title=lbl)
        if col == 0:
            ax.set_ylabel("TEA parameter", fontsize=9, labelpad=8)

    # ── LCA rows 2-3 ─────────────────────────────────────────────────────────
    for col, lbl in enumerate(sc1_lbls):
        ax = axes[2][col]
        rows_lca, base = sens_lca[lbl]
        _draw_tornado(ax, rows_lca, base_val=base,
                      xlabel="Delta GHG (g CO2 eq/MJ)",
                      title=lbl, color_lo="#2196A6", color_hi="#E53935")
        if col == 0:
            ax.set_ylabel("LCA parameter", fontsize=9, labelpad=8)

    for col, lbl in enumerate(sc2_lbls):
        ax = axes[3][col]
        rows_lca, base = sens_lca[lbl]
        _draw_tornado(ax, rows_lca, base_val=base,
                      xlabel="Delta GHG (g CO2 eq/MJ)",
                      title=lbl, color_lo="#2196A6", color_hi="#E53935")
        if col == 0:
            ax.set_ylabel("LCA parameter", fontsize=9, labelpad=8)

    # ── divider label ─────────────────────────────────────────────────────────
    tea_patch = mpatches.Patch(fc="#D32F2F", alpha=0.85, label="Increases MFSP / GHG")
    blue_patch = mpatches.Patch(fc="#1976D2", alpha=0.85, label="Decreases MFSP (TEA)")
    teal_patch = mpatches.Patch(fc="#2196A6", alpha=0.85, label="Decreases GHG (LCA)")
    fig.legend(handles=[tea_patch, blue_patch, teal_patch],
               loc="lower center", ncol=3, fontsize=9,
               bbox_to_anchor=(0.5, -0.01), framealpha=0.9)

    # Row section labels
    for row_y, label in [
        (0.76, "TEA Sensitivity -- MFSP (Scenario 1)"),
        (0.54, "TEA Sensitivity -- MFSP (Scenario 2)"),
        (0.31, "LCA Sensitivity -- GHG Intensity (Scenario 1)"),
        (0.09, "LCA Sensitivity -- GHG Intensity (Scenario 2)"),
    ]:
        fig.text(0.01, row_y, label, fontsize=10, fontweight="bold",
                 color="#333", rotation=90, va="center")

    fig.suptitle(
        "Sensitivity Tornado -- TEA (MFSP) and LCA (GHG) | +-20% One-at-a-Time\n"
        "SAF from Waste Polystyrene | 6 Configurations",
        fontsize=12, y=1.005,
    )
    fig.tight_layout(rect=[0.03, 0.03, 1, 1])
    fig.savefig(out_path, dpi=180, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved -> {out_path}")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("=" * 60)
    print("  Sensitivity Tornado Plots — TEA + LCA")
    print("=" * 60)

    print("\nComputing LCA sensitivity …")
    sens_lca = run_lca_sensitivity()

    print("\nGenerating plots …")
    plot_tea_tornado(os.path.join(OUT_DIR, "lca_tornado_tea.pdf"))
    plot_lca_tornado(sens_lca, os.path.join(OUT_DIR, "lca_tornado_lca.pdf"))
    plot_combined(sens_lca, os.path.join(OUT_DIR, "lca_tornado_combined.pdf"))

    print("\nDone. Files saved to:", OUT_DIR)
