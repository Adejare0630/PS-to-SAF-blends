"""
make_plots.py — TEA publication-quality PDF plots.
Process engineering sourced from main.py's BioSTEAM simulation; all financial
math (Peters/Timmerhaus/West capital, 60/40 debt/equity, MACRS7, 35% tax, 3-yr
construction, 6-month startup, +-20% sensitivity, LHS Monte Carlo) comes from
tea_model.py's NREL/Humbird 2011 DCFROR engine via tea_bridge.py.
No static CSVs except literature.csv, which is external benchmark data that
cannot be derived from simulation.
"""
#%%
import os, warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import sys as _s, os as _o
_s.path.insert(0, _o.path.dirname(_o.path.dirname(_o.path.dirname(_o.path.abspath(__file__)))))
import scenario_relabel  # R1.14: display swap Sc1<->Sc2 (set SCENARIO_RELABEL=0 to disable)
import matplotlib
# Standalone run: force Agg (fast, headless). Loaded by main.py inside an
# IPython/Jupyter session: leave the backend main.py already configured
# (inline / TkAgg) alone so plt.show() calls below actually render.
try:
    get_ipython()
except NameError:
    matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.lines as mlines
from matplotlib.ticker import MaxNLocator
import matplotlib as mpl

import tea_bridge as tb
import tea_model as tm

DATA_DIR  = tb.DATA_DIR
PLOTS_DIR = tb.PLOTS_DIR

# ── matplotlib global style ────────────────────────────────────────────────────
mpl.rcParams.update({
    "font.family":          "serif",
    "font.serif":           ["DejaVu Serif", "Times New Roman", "Times", "serif"],
    "axes.labelsize":       12,
    "axes.titlesize":       12,
    "xtick.labelsize":      10,
    "ytick.labelsize":      10,
    "legend.fontsize":      9,
    "figure.dpi":           150,
    "savefig.dpi":          300,
    "savefig.bbox":         "tight",
    "axes.spines.top":      True,
    "axes.spines.right":    True,
})

# ── Okabe-Ito colorblind-safe palette ─────────────────────────────────────────
PALETTE = [
    "#0072B2",   # [0] blue           — Feedstock / Sc1
    "#E69F00",   # [1] orange         — Capital depreciation
    "#009E73",   # [2] bluish green   — Fixed operating
    "#D55E00",   # [3] vermillion     — Utilities / Sc2
    "#CC79A7",   # [4] reddish purple — Other / WC
    "#F0E442",   # [5] yellow
    "#56B4E9",   # [6] sky blue       — Co-product credit
    "#666666",   # [7] dark gray      — Net MFSP marker
]

# ── scenario ordering & display labels ────────────────────────────────────────
SCENARIO_KEYS = tb.SCENARIO_KEYS
XLABELS = {
    (1, 'SMR'):            "Sc1\nSMR",
    (1, 'Photocatalysis'): "Sc1\nPhoto",
    (1, 'SOEC'):           "Sc1\nSOEC",
    (2, 'SMR'):            "Sc2\nSMR",
    (2, 'Photocatalysis'): "Sc2\nPhoto",
    (2, 'SOEC'):           "Sc2\nSOEC",
}

CATEGORIES = ['Feedstock', 'Capital depreciation',
              'Fixed operating', 'Utilities', 'Co-product credit']
CAT_COLORS = {
    'Feedstock':            PALETTE[0],
    'Capital depreciation': PALETTE[1],
    'Fixed operating':      PALETTE[2],
    'Utilities':            PALETTE[3],
    'Co-product credit':    PALETTE[6],
}

# ═══════════════════════════════════════════════════════════════════════════════
# Run simulation (once at module load): main.py process + Humbird 2011 DCFROR
# ═══════════════════════════════════════════════════════════════════════════════
print("[make_plots] Simulating 6 configurations (main.py process + Humbird 2011 DCFROR) ...")
RESULTS = tb.simulate_all()
print("[make_plots] Simulation complete.\n")


# ── helper: per-kg-SAF MFSP contribution breakdown (already computed by tea_model) ─
def _contributions(res):
    return {
        'Feedstock':            res['feedstock_contr'],
        'Capital depreciation': res['capital_contr'],
        'Fixed operating':      res['foc_contr'],
        'Utilities':            res['utility_contr'],
        'Co-product credit':    res['byproduct_credit'],
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Plot 1: MFSP stacked bar — cost contributions per scenario
# ═══════════════════════════════════════════════════════════════════════════════
def plot_mfsp_stacked_bar():
    n     = len(SCENARIO_KEYS)
    x     = np.arange(n)
    width = 0.55

    fig, ax = plt.subplots(figsize=(9, 5.5))
    bottoms_pos = np.zeros(n)
    bottoms_neg = np.zeros(n)
    patches = []

    for cat in CATEGORIES:
        vals = np.array([
            _contributions(RESULTS[k])[cat] if RESULTS.get(k) else 0.0
            for k in SCENARIO_KEYS
        ])
        color = CAT_COLORS[cat]
        if cat == 'Co-product credit':
            ax.bar(x, vals, width=width, bottom=bottoms_neg,
                   color=color, edgecolor="white", linewidth=0.5)
            bottoms_neg += vals
        else:
            ax.bar(x, vals, width=width, bottom=bottoms_pos,
                   color=color, edgecolor="white", linewidth=0.5)
            bottoms_pos += vals
        patches.append(mpatches.Patch(facecolor=color, label=cat))

    # Net MFSP diamond marker
    for i, k in enumerate(SCENARIO_KEYS):
        if RESULTS.get(k):
            net = RESULTS[k]['mfsp_per_kg']
            ax.plot(i, net, "D", color=PALETTE[7], markersize=7, zorder=5, clip_on=False)
            ax.hlines(net, i - width/2, i + width/2,
                      colors=PALETTE[7], linewidths=1.5, linestyles="--", zorder=4)

    net_marker = mlines.Line2D([], [], marker="D", color=PALETTE[7],
                               linestyle="--", linewidth=1.5, markersize=6,
                               label="Net MFSP")
    patches.append(net_marker)

    ax.set_xticks(x)
    ax.set_xticklabels([XLABELS[k] for k in SCENARIO_KEYS], fontsize=9.5)
    ax.set_ylabel("MFSP ($/kg SAF)", fontsize=12)
    ax.set_xlabel("Scenario / H$_2$ source", fontsize=12)
    for sp in ax.spines.values():
        sp.set_linewidth(0.8)
    ax.yaxis.set_major_locator(MaxNLocator(8, integer=False))
    ax.grid(axis="y", linestyle=":", linewidth=0.5, alpha=0.6)
    ax.legend(handles=patches, loc="upper right",
              frameon=True, framealpha=0.9, edgecolor="gray", fontsize=8.5)
    fig.tight_layout()
    out = os.path.join(PLOTS_DIR, "mfsp_stacked_bar.pdf")
    fig.savefig(out)
    plt.show()
    plt.close(fig)
    print(f"  Saved: {out}")


# ═══════════════════════════════════════════════════════════════════════════════
# Plot 2: Sensitivity tornado — Sc1 + SMR base case
# ═══════════════════════════════════════════════════════════════════════════════
def plot_sensitivity_tornado():
    key  = (1, 'SMR')
    res  = RESULTS[key]
    base = res['mfsp_per_kg']

    sens = tb.sensitivity_for(key, RESULTS)
    rows = [(row.parameter, row.delta_low, row.delta_high)
            for row in sens.itertuples()]
    rows.sort(key=lambda r: abs(r[2] - r[1]), reverse=True)

    n = len(rows)
    y = np.arange(n)

    fig, ax = plt.subplots(figsize=(8, 0.8 * n + 1.5))
    bar_h = 0.4
    for i, (_, lo, hi) in enumerate(rows):
        ax.barh(i, lo, height=bar_h, color=PALETTE[0], edgecolor="white", linewidth=0.4)
        ax.barh(i, hi, height=bar_h, color=PALETTE[3], edgecolor="white", linewidth=0.4)

    ax.axvline(0, color="black", linewidth=0.9)
    ax.set_yticks(y)
    ax.set_yticklabels([r[0] for r in rows], fontsize=9.5)
    ax.set_xlabel("$\\Delta$MFSP from base case ($/kg SAF)", fontsize=11)
    ax.set_title(f"Sensitivity Analysis — Base MFSP = ${base:.2f}/kg SAF  (Sc1 + SMR)",
                 fontsize=11)
    for sp in ax.spines.values():
        sp.set_linewidth(0.8)
    ax.grid(axis="x", linestyle=":", linewidth=0.5, alpha=0.6)
    ax.legend(handles=[
        mpatches.Patch(facecolor=PALETTE[0], label="−20%"),
        mpatches.Patch(facecolor=PALETTE[3], label="+20%"),
    ], loc="lower right", frameon=True, framealpha=0.9, edgecolor="gray", fontsize=9)
    fig.tight_layout()
    out = os.path.join(PLOTS_DIR, "sensitivity_tornado.pdf")
    fig.savefig(out)
    plt.close(fig)
    print(f"  Saved: {out}")


# ═══════════════════════════════════════════════════════════════════════════════
# Plot 3: Uncertainty CDF (all 6 configs overlaid)
# ═══════════════════════════════════════════════════════════════════════════════
def plot_uncertainty_cdf():
    fig, ax = plt.subplots(figsize=(9, 5.5))

    configs_style = [
        ((1, 'SMR'),            PALETTE[0], "-",  "Sc1 + SMR"),
        ((1, 'SOEC'),           PALETTE[0], "--", "Sc1 + SOEC"),
        ((1, 'Photocatalysis'), PALETTE[0], ":",  "Sc1 + Photo"),
        ((2, 'SMR'),            PALETTE[3], "-",  "Sc2 + SMR"),
        ((2, 'SOEC'),           PALETTE[3], "--", "Sc2 + SOEC"),
        ((2, 'Photocatalysis'), PALETTE[3], ":",  "Sc2 + Photo"),
    ]

    print("  [uncertainty CDF] Running LHS Monte Carlo N=1000 x6 ...")
    mc_cache = {}
    for k, color, ls, name in configs_style:
        res = RESULTS.get(k)
        if res is None:
            continue
        samples_df, _, _ = tb.uncertainty_for(k, RESULTS, n=1000)
        mc_cache[k] = samples_df
        vals = np.sort(samples_df['mfsp'].values)
        cdf  = np.arange(1, len(vals) + 1) / len(vals)
        ax.plot(vals, cdf, color=color, linestyle=ls, linewidth=2, label=name)

    for yp in (0.05, 0.50, 0.95):
        ax.axhline(yp, color="gray", linestyle="--", linewidth=0.6)

    # Annotate P5/P50/P95 for Sc1+SMR
    if (1, 'SMR') in mc_cache:
        s1 = np.sort(mc_cache[(1, 'SMR')]['mfsp'].values)
        for pct, lbl_txt, yoff in [(5, "P5", 0.01), (50, "P50", 0.46), (95, "P95", 0.91)]:
            v = np.percentile(s1, pct)
            ax.text(v + 0.01, yoff, f"{lbl_txt}=${v:.2f}",
                    color=PALETTE[0], fontsize=7.5)

    ax.set_xlabel("MFSP ($/kg SAF)", fontsize=12)
    ax.set_ylabel("Cumulative probability", fontsize=12)
    ax.set_ylim(0, 1.02)
    ax.set_xlim(left=0)
    for sp in ax.spines.values():
        sp.set_linewidth(0.8)
    ax.grid(linestyle=":", linewidth=0.4, alpha=0.5)
    ax.legend(loc="lower right", frameon=True, framealpha=0.9,
              edgecolor="gray", fontsize=8.5, ncol=2)
    fig.tight_layout()
    out = os.path.join(PLOTS_DIR, "uncertainty_cdf.pdf")
    fig.savefig(out)
    plt.show()
    plt.close(fig)
    print(f"  Saved: {out}")


# ═══════════════════════════════════════════════════════════════════════════════
# Plot 3b: Uncertainty histogram — 2x3 panel grid
# ═══════════════════════════════════════════════════════════════════════════════
def plot_uncertainty_histogram():
    panel_cfg = [
        ((1, 'SMR'),            PALETTE[0], "Sc1 + SMR"),
        ((1, 'SOEC'),           "#56B4E9",  "Sc1 + SOEC"),
        ((1, 'Photocatalysis'), "#009E73",  "Sc1 + Photo"),
        ((2, 'SMR'),            PALETTE[3], "Sc2 + SMR"),
        ((2, 'SOEC'),           "#CC79A7",  "Sc2 + SOEC"),
        ((2, 'Photocatalysis'), "#F0E442",  "Sc2 + Photo"),
    ]

    print("  [uncertainty histogram] Running LHS Monte Carlo N=1000 x6 ...")
    fig, axes = plt.subplots(2, 3, figsize=(13, 7))
    fig.suptitle(
        "MFSP Uncertainty Distributions — All 6 Configurations (N=1000)  [$/kg SAF]",
        fontsize=12, fontweight="bold"
    )

    for ax, (k, color, title) in zip(axes.flat, panel_cfg):
        res = RESULTS.get(k)
        if res is None:
            ax.text(0.5, 0.5, "No data", ha="center", va="center",
                    transform=ax.transAxes, fontsize=10)
            ax.set_title(title, fontsize=10); continue

        samples_df, _, _ = tb.uncertainty_for(k, RESULTS, n=1000)
        samples = samples_df['mfsp'].values
        ax.hist(samples, bins=40, color=color, edgecolor="white",
                linewidth=0.3, density=True, alpha=0.85)

        p5, p50, p95 = np.percentile(samples, [5, 50, 95])
        ax.axvline(p5,  color="navy",    linestyle="--", linewidth=1.2,
                   label=f"P5=${p5:.2f}")
        ax.axvline(p50, color="black",   linestyle="-",  linewidth=1.5,
                   label=f"P50=${p50:.2f}")
        ax.axvline(p95, color="crimson", linestyle="--", linewidth=1.2,
                   label=f"P95=${p95:.2f}")
        ax.legend(fontsize=7, loc="upper right")
        ax.set_xlabel("MFSP ($/kg SAF)", fontsize=9)
        ax.set_ylabel("Probability density", fontsize=9)
        ax.set_title(title, fontsize=10, fontweight="bold")
        for sp in ax.spines.values():
            sp.set_linewidth(0.8)
        ax.grid(axis="y", linestyle=":", linewidth=0.4, alpha=0.5)

    fig.tight_layout(rect=[0, 0, 1, 0.96])
    out = os.path.join(PLOTS_DIR, "uncertainty_histogram.pdf")
    fig.savefig(out)
    plt.show()
    plt.close(fig)
    print(f"  Saved: {out}")


# ═══════════════════════════════════════════════════════════════════════════════
# Plot 4: Literature comparison (reads literature.csv — external benchmark data)
# ═══════════════════════════════════════════════════════════════════════════════
def plot_literature_comparison():
    lit_path = os.path.join(DATA_DIR, "literature.csv")
    if not os.path.exists(lit_path):
        print(f"  [skip] literature.csv not found at {lit_path}")
        return

    df = pd.read_csv(lit_path).sort_values("normalized_mfsp_2023")
    keys   = df["citation_key"].tolist()
    values = df["normalized_mfsp_2023"].values   # already 2023 $/GGE
    is_this_study = ["this_study" in str(k).lower() for k in keys]

    colors     = [PALETTE[3] if f else PALETTE[0] for f in is_this_study]
    edgecolors = ["black"    if f else "none"      for f in is_this_study]

    fig, ax = plt.subplots(figsize=(9, 0.6 * len(keys) + 2))
    y = np.arange(len(keys))
    ax.barh(y, values, height=0.5, color=colors, edgecolor=edgecolors, linewidth=1.0)
    for i, v in enumerate(values):
        ax.text(v + max(values) * 0.01, i, f"${v:.2f}", va="center", fontsize=9)

    ax.set_yticks(y)
    ax.set_yticklabels(keys, fontsize=9)
    ax.set_xlabel("MFSP normalized to 2023 USD ($/GGE)", fontsize=11)
    ax.set_xlim(0, max(values) * 1.18)
    for sp in ax.spines.values():
        sp.set_linewidth(0.8)
    ax.grid(axis="x", linestyle=":", linewidth=0.5, alpha=0.6)
    ax.legend(handles=[
        mpatches.Patch(facecolor=PALETTE[0], label="Prior literature"),
        mpatches.Patch(facecolor=PALETTE[3], edgecolor="black",
                       linewidth=1.0, label="This study"),
    ], loc="lower right", frameon=True, framealpha=0.9, edgecolor="gray", fontsize=9)
    fig.tight_layout()
    out = os.path.join(PLOTS_DIR, "literature_comparison.pdf")
    fig.savefig(out)
    plt.close(fig)
    print(f"  Saved: {out}")


# ═══════════════════════════════════════════════════════════════════════════════
# Plot 5: MFSP grouped bar — net MFSP per config
# ═══════════════════════════════════════════════════════════════════════════════
def plot_mfsp_grouped():
    vals   = [RESULTS[k]['mfsp_per_kg'] if RESULTS.get(k) else 0.0
              for k in SCENARIO_KEYS]
    colors = [PALETTE[0]] * 3 + [PALETTE[3]] * 3
    alphas = [1.0, 0.75, 0.50, 1.0, 0.75, 0.50]

    fig, ax = plt.subplots(figsize=(8, 4.5))
    x    = np.arange(len(SCENARIO_KEYS))
    bars = ax.bar(x, vals, width=0.6, color=colors, edgecolor="white", linewidth=0.6)
    for bar, alpha in zip(bars, alphas):
        bar.set_alpha(alpha)
    for xi, vi in zip(x, vals):
        ax.text(xi, vi + max(vals) * 0.02, f"${vi:.2f}",
                ha="center", va="bottom", fontsize=9)

    fossil_kg = 3.10 / tm.to_gge(1.0, 1)   # fossil jet ~$3.10/GGE, on Sc1 SAF LHV basis
    ax.axhline(fossil_kg, color="black", linestyle="--", linewidth=1.0)
    ax.text(len(SCENARIO_KEYS) - 0.5, fossil_kg + max(vals) * 0.01,
            f"Fossil jet fuel ~${fossil_kg:.2f}/kg",
            ha="right", fontsize=8, color="black")

    ax.set_xticks(x)
    ax.set_xticklabels([XLABELS[k] for k in SCENARIO_KEYS], fontsize=9.5)
    ax.set_ylabel("Net MFSP ($/kg SAF)", fontsize=12)
    ax.set_ylim(0, max(vals) * 1.20)
    for sp in ax.spines.values():
        sp.set_linewidth(0.8)
    ax.grid(axis="y", linestyle=":", linewidth=0.4, alpha=0.6)
    ax.legend(handles=[
        mpatches.Patch(facecolor=PALETTE[0], label="Scenario 1 (co-hydropyrolysis)"),
        mpatches.Patch(facecolor=PALETTE[3], label="Scenario 2 (PS-only + SPK blend)"),
    ], loc="upper right", frameon=True, framealpha=0.9, edgecolor="gray", fontsize=9)
    fig.tight_layout()
    out = os.path.join(PLOTS_DIR, "mfsp_grouped_bar.pdf")
    fig.savefig(out)
    plt.show()
    plt.close(fig)
    print(f"  Saved: {out}")


# ═══════════════════════════════════════════════════════════════════════════════
# Plot 6: CapEx stacked bar — Peters, Timmerhaus & West capital breakdown
# ═══════════════════════════════════════════════════════════════════════════════
def plot_capex_stacked():
    n     = len(SCENARIO_KEYS)
    x     = np.arange(n)
    width = 0.55

    def _z(k, field):
        return RESULTS[k].get(field, 0.0) / 1e6 if RESULTS.get(k) else 0.0

    components = [
        ("Delivered equipment\n(PEC + 10% delivery)",
         [_z(k, 'DEC') for k in SCENARIO_KEYS],
         PALETTE[0]),
        ("Direct installed costs\n(install., instr., piping, elec., bldgs., yard, services)",
         [_z(k, 'DirectInstalled') for k in SCENARIO_KEYS],
         PALETTE[1]),
        ("Indirects\n(eng., constr., legal, contractor, contingency)",
         [_z(k, 'Indirect') for k in SCENARIO_KEYS],
         PALETTE[2]),
        ("Working capital\n(75% of delivered equip.)",
         [_z(k, 'WC') for k in SCENARIO_KEYS],
         PALETTE[4]),
    ]

    fig, ax = plt.subplots(figsize=(9, 5.5))
    bottoms = np.zeros(n)
    patches = []
    for label, vals, color in components:
        vals = np.array(vals)
        ax.bar(x, vals, width=width, bottom=bottoms,
               color=color, edgecolor="white", linewidth=0.5)
        bottoms += vals
        patches.append(mpatches.Patch(facecolor=color, label=label))

    for i, k in enumerate(SCENARIO_KEYS):
        tci = _z(k, 'TCI')
        ax.text(i, tci + max(bottoms) * 0.01, f"${tci:.0f}M",
                ha="center", va="bottom", fontsize=8, fontweight="bold")

    ax.set_xticks(x)
    ax.set_xticklabels([XLABELS[k] for k in SCENARIO_KEYS], fontsize=9.5)
    ax.set_ylabel("Capital Investment (MM 2023 USD)", fontsize=12)
    ax.set_xlabel("Scenario / H$_2$ source", fontsize=12)
    ax.yaxis.set_major_locator(MaxNLocator(8, integer=False))
    ax.grid(axis="y", linestyle=":", linewidth=0.5, alpha=0.6)
    for sp in ax.spines.values():
        sp.set_linewidth(0.8)
    ax.legend(handles=patches, loc="upper right",
              frameon=True, framealpha=0.9, edgecolor="gray", fontsize=8)
    fig.tight_layout()
    out = os.path.join(PLOTS_DIR, "capex_stacked.pdf")
    fig.savefig(out)
    plt.show()
    plt.close(fig)
    print(f"  Saved: {out}")

#%%
# ═══════════════════════════════════════════════════════════════════════════════
# Plot 7: OpEx stacked bar — annual operating cost breakdown (Humbird fractions)
# ═══════════════════════════════════════════════════════════════════════════════
def plot_opex_stacked():
    n     = len(SCENARIO_KEYS)
    x     = np.arange(n)
    width = 0.55

    def feedstock_M(k):
        r = RESULTS[k]; return r['feedstock_cost_hr'] * tm.OPERATING_HR / 1e6

    def utility_M(k):
        r = RESULTS[k]; return r['utility_cost_hr'] * tm.OPERATING_HR / 1e6

    def maintenance_M(k):
        return RESULTS[k]['FCI'] * tm.MAINTENANCE_FRAC / 1e6

    def insurance_M(k):
        return RESULTS[k]['FCI'] * tm.INSURANCE_TAX_FRAC / 1e6

    def labor_M(k):
        return tm.labor_cost(RESULTS[k]['FCI']) / 1e6

    item_map = [
        (feedstock_M,   'Feedstock',          PALETTE[0]),
        (utility_M,     'Utilities',          PALETTE[3]),
        (maintenance_M, 'Maintenance (3% FCI)', PALETTE[2]),
        (insurance_M,   'Insurance & taxes (0.7% FCI)', PALETTE[4]),
        (labor_M,       'Labor & burden (5% FCI)', PALETTE[1]),
    ]
    credit_vals = np.array([
        -(RESULTS[k]['byproduct_revenue_hr'] * tm.OPERATING_HR / 1e6) if RESULTS.get(k) else 0.0
        for k in SCENARIO_KEYS
    ])

    fig, ax = plt.subplots(figsize=(9, 5.5))
    bottoms_pos = np.zeros(n)
    bottoms_neg = np.zeros(n)
    patches = []

    for fn, display, color in item_map:
        vals = np.array([fn(k) if RESULTS.get(k) else 0.0 for k in SCENARIO_KEYS])
        ax.bar(x, vals, width=width, bottom=bottoms_pos,
               color=color, edgecolor="white", linewidth=0.5)
        bottoms_pos += vals
        patches.append(mpatches.Patch(facecolor=color, label=display))

    ax.bar(x, credit_vals, width=width, bottom=bottoms_neg,
           color=PALETTE[6], edgecolor="white", linewidth=0.5)
    bottoms_neg += credit_vals
    patches.append(mpatches.Patch(facecolor=PALETTE[6], label="Co-product credit"))

    for i in range(n):
        net = bottoms_pos[i] + bottoms_neg[i]
        ax.text(i, bottoms_pos[i] + max(bottoms_pos) * 0.015,
                f"${net:.1f}M", ha="center", va="bottom",
                fontsize=7.5, fontweight="bold")

    ax.axhline(0, color="black", linewidth=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels([XLABELS[k] for k in SCENARIO_KEYS], fontsize=9.5)
    ax.set_ylabel("Annual Operating Cost (MM 2023 USD/yr)", fontsize=12)
    ax.set_xlabel("Scenario / H$_2$ source", fontsize=12)
    ax.yaxis.set_major_locator(MaxNLocator(8, integer=False))
    ax.grid(axis="y", linestyle=":", linewidth=0.5, alpha=0.6)
    for sp in ax.spines.values():
        sp.set_linewidth(0.8)
    ax.legend(handles=patches, 
              loc="lower center", ncol=3,
              bbox_to_anchor=(0.5, -0.25),
              #frameon=True, 
              framealpha=0.9, edgecolor="gray", fontsize=8)
    fig.tight_layout()
    out = os.path.join(PLOTS_DIR, "opex_stacked.pdf")
    fig.savefig(out)
    plt.show()
    plt.close(fig)
    print(f"  Saved: {out}")

#%%
# ═══════════════════════════════════════════════════════════════════════════════
# Plot 8: Sensitivity tornado — all 6 configurations (2x3 grid)
# ═══════════════════════════════════════════════════════════════════════════════
def plot_sensitivity_tornado_all():
    PANEL_COLORS = {
        (1, 'SMR'):            PALETTE[0],
        (1, 'Photocatalysis'): "#009E73",
        (1, 'SOEC'):           "#56B4E9",
        (2, 'SMR'):            PALETTE[3],
        (2, 'Photocatalysis'): "#E69F00",
        (2, 'SOEC'):           "#CC79A7",
    }
    PANEL_TITLES = {
        (1, 'SMR'):            "Sc1 + SMR",
        (1, 'Photocatalysis'): "Sc1 + Photocatalysis",
        (1, 'SOEC'):           "Sc1 + SOEC",
        (2, 'SMR'):            "Sc2 + SMR",
        (2, 'Photocatalysis'): "Sc2 + Photocatalysis",
        (2, 'SOEC'):           "Sc2 + SOEC",
    }

    fig, axes = plt.subplots(2, 3, figsize=(16, 10))
    fig.suptitle(
        "Sensitivity Tornado — All 6 Configurations (±20% one-at-a-time)\n"
        "Bars show ΔMFSP ($/kg SAF) from base case  |  NREL/Humbird 2011 DCFROR",
        fontsize=13, fontweight="bold"
    )

    for ax, k in zip(axes.flat, SCENARIO_KEYS):
        res = RESULTS.get(k)
        if res is None:
            ax.text(0.5, 0.5, "No data", ha="center", va="center",
                    transform=ax.transAxes)
            ax.set_title(PANEL_TITLES[k]); continue

        base = res['mfsp_per_kg']
        sens = tb.sensitivity_for(k, RESULTS)
        rows = [(row.parameter, row.delta_low, row.delta_high)
                for row in sens.itertuples()]
        rows.sort(key=lambda r: abs(r[2] - r[1]), reverse=False)

        y     = np.arange(len(rows))
        bar_h = 0.45
        color = PANEL_COLORS[k]
        for i, (_, lo, hi) in enumerate(rows):
            pad = (abs(lo) + abs(hi)) * 0.02 + 0.005
            ax.barh(i, lo, height=bar_h, color=PALETTE[0],
                    edgecolor="white", linewidth=0.4, alpha=0.85)
            ax.barh(i, hi, height=bar_h, color=PALETTE[3],
                    edgecolor="white", linewidth=0.4, alpha=0.85)
            ax.text(lo - pad, i, f"${base + lo:.2f}",
                    ha="right", va="center", fontsize=6.5, color="#2c3e50")
            ax.text(hi + pad, i, f"${base + hi:.2f}",
                    ha="left",  va="center", fontsize=6.5, color="#2c3e50")

        ax.axvline(0, color="black", linewidth=1.0, zorder=5)
        ax.set_yticks(y)
        ax.set_yticklabels([r[0] for r in rows], fontsize=8)
        ax.set_xlabel("ΔMFSP ($/kg SAF)", fontsize=9)
        ax.set_title(f"{PANEL_TITLES[k]}  [Base = ${base:.2f}/kg]",
                     fontsize=9.5, fontweight="bold", color=color, pad=4)
        for sp in ax.spines.values():
            sp.set_linewidth(0.7)
        ax.grid(axis="x", linestyle=":", linewidth=0.4, alpha=0.5)

        if k == (1, 'SMR'):
            ax.legend(handles=[
                mpatches.Patch(facecolor=PALETTE[0], alpha=0.85, label="−20% perturbation"),
                mpatches.Patch(facecolor=PALETTE[3], alpha=0.85, label="+20% perturbation"),
            ], fontsize=7, loc="lower right")

    fig.tight_layout(rect=[0, 0, 1, 0.95])
    out = os.path.join(PLOTS_DIR, "sensitivity_tornado_all.pdf")
    fig.savefig(out)
    plt.show()
    plt.close(fig)
    print(f"  Saved: {out}")


# ═══════════════════════════════════════════════════════════════════════════════
# main
# ═══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("[Phase 8] Generating TEA plots (Humbird 2011 DCFROR via tea_bridge) ...")
    plot_mfsp_stacked_bar()
    plot_capex_stacked()
    plot_opex_stacked()
    plot_sensitivity_tornado()
    plot_sensitivity_tornado_all()
    plot_uncertainty_cdf()
    plot_uncertainty_histogram()
    plot_literature_comparison()
    plot_mfsp_grouped()
    print(f"\nAll plots written to {PLOTS_DIR}")

# %%
