"""
make_cashflow.py — Cash flow diagrams for all 6 SAF configurations.
Process engineering sourced from main.py's BioSTEAM simulation; all financial
math (Peters/Timmerhaus/West capital, 60/40 debt/equity, MACRS7, 35% tax, 3-yr
construction schedule 8/60/32%, 6-month startup) comes from tea_model.py's engine via tea_bridge.py.

Figure 1: 2x3 panel grid — annual CF bars + cumulative lines at SAF market price.
Figure 2: Overlay — cumulative discounted NPV curves at two reference prices.
Figure 3: Payback period summary — horizontal bar chart.

Year axis includes the 3-yr construction period (years -3..-1) followed by
30 operating years (years 1..30),(see tea_model.compute_cashflows). Primary unit: $/kg SAF.
"""

import os, warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import sys as _s, os as _o
_s.path.insert(0, _o.path.dirname(_o.path.dirname(_o.path.dirname(_o.path.abspath(__file__)))))
import scenario_relabel  # R1.14: display swap Sc1<->Sc2 (set SCENARIO_RELABEL=0 to disable)
import matplotlib
# Standalone run: force Agg (fast, headless). Loaded by main.py inside an
# IPython/Jupyter session: leave the backend main.py already configured
# (inline / TkAgg) alone so plt.show() calls below actually render.
try:
    get_ipython()
except NameError:
    matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib as mpl
import matplotlib.ticker as mticker
import matplotlib.patches as mpatches

import tea_bridge as tb
import tea_model as tm

DATA_DIR  = tb.DATA_DIR
PLOTS_DIR = tb.PLOTS_DIR

# ── style ─────────────────────────────────────────────────────────────────────
mpl.rcParams.update({
    "font.family":    "serif",
    "font.serif":     ["DejaVu Serif", "Times New Roman", "serif"],
    "axes.labelsize": 10,
    "axes.titlesize": 10,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "figure.dpi":     150,
    "savefig.dpi":    300,
    "savefig.bbox":   "tight",
})

META = {
    "Sc1_SMR":            {"label": "Sc1 + SMR",            "color": "#0072B2", "ls": "-"},
    "Sc1_SOEC":           {"label": "Sc1 + SOEC",           "color": "#56B4E9", "ls": "-"},
    "Sc1_Photocatalysis": {"label": "Sc1 + Photocatalysis", "color": "#009E73", "ls": "-"},
    "Sc2_SMR":            {"label": "Sc2 + SMR",            "color": "#D55E00", "ls": "--"},
    "Sc2_SOEC":           {"label": "Sc2 + SOEC",           "color": "#CC79A7", "ls": "--"},
    "Sc2_Photocatalysis": {"label": "Sc2 + Photocatalysis", "color": "#E69F00", "ls": "--"},
}
LABEL_ORDER = list(META.keys())
KEY_MAP     = {lbl: tb.SCENARIO_KEYS[i] for i, lbl in enumerate(tb.LABEL_ORDER)}

# $/kg SAF reference prices, converted from their usual $/GGE quotes on a
# Sc1 SAF LHV basis (fossil jet ~$3.10/GGE, SAF market ~$5.50/GGE)
FOSSIL_JET_KG = 3.10 / tm.to_gge(1.0, 1)
SAF_MARKET_KG = 1.20 * FOSSIL_JET_KG   # R1: premium-SAF ($5.50/GGE) case removed; now parity +20%

PLANT_LIFE = tm.PLANT_LIFE   # 30 years (Humbird 2011)


def cashflows_at_kg_price(res: dict, price_kg: float):
    """Full DCFROR cash flow stream at a given selling price ($/kg SAF)."""
    return tm.compute_cashflows(
        res['FCI'], res['WC'],
        res['VOC_annual_MM'] * 1e6, res['FOC_annual_MM'] * 1e6,
        res['product_kg_yr'], res['byproduct_annual_MM'] * 1e6,
        price_kg,
    )


def find_payback_year(year_labels, cumulative):
    """Fractional year where cumulative first crosses zero; None if never."""
    for i in range(1, len(cumulative)):
        if cumulative[i - 1] < 0 <= cumulative[i]:
            frac = -cumulative[i - 1] / (cumulative[i] - cumulative[i - 1])
            return year_labels[i - 1] + frac
    return None


# ════════════════════════════════════════════════════════════════════════════
# Simulate all 6 base cases (main.py process + tea_model.py financials)
# ════════════════════════════════════════════════════════════════════════════
print("=" * 65)
print("Simulating 6 configurations (main.py process + financials) ...")
print("=" * 65)
RESULTS = tb.simulate_all()


# ════════════════════════════════════════════════════════════════════════════
# Compute cash flows at reference prices
# ════════════════════════════════════════════════════════════════════════════
print("\nComputing cash flow streams ...")

cf_data = {}   # (lbl, price_kg) -> (years, ann_M, cum_u_M, cum_d_M)
rows_cf = []
rows_pb = []

MFSP_REF_PRICES = {}   # store MFSP $/kg per label

for lbl in LABEL_ORDER:
    k   = KEY_MAP[lbl]
    res = RESULTS.get(k)
    if res is None:
        continue
    mfsp = res['mfsp_per_kg']
    MFSP_REF_PRICES[lbl] = mfsp

    for ref_kg, ref_label in [(FOSSIL_JET_KG, "fossil_parity"),
                              (SAF_MARKET_KG, "saf_market"),
                              (mfsp,          "mfsp")]:
        yrs, ann, cum_u, cum_d = cashflows_at_kg_price(res, ref_kg)
        yrs    = list(yrs)
        ann_M  = ann / 1e6
        cum_uM = cum_u / 1e6
        cum_dM = cum_d / 1e6
        key_cf = (lbl, round(ref_kg, 4))
        cf_data[key_cf] = (yrs, ann_M, cum_uM, cum_dM)

        pb_simple     = find_payback_year(yrs, list(cum_uM))
        pb_discounted = find_payback_year(yrs, list(cum_dM))

        rows_pb.append({
            "config":            lbl,
            "ref_price_kg":      round(ref_kg, 4),
            "ref_label":         ref_label,
            "mfsp_kg":           round(mfsp, 3),
            "final_npv_million": round(float(cum_dM[-1]), 1),
            "simple_payback_yr": round(pb_simple, 1) if pb_simple is not None else "N/A",
            "disc_payback_yr":   round(pb_discounted, 1) if pb_discounted is not None else "N/A",
        })

        for yr, a, cu, cd in zip(yrs, ann_M, cum_uM, cum_dM):
            rows_cf.append({
                "config":             lbl,
                "ref_price_kg":       round(ref_kg, 4),
                "year":               int(yr),
                "annual_cf_million":  round(float(a), 3),
                "cum_undiscounted_M": round(float(cu), 3),
                "cum_discounted_M":   round(float(cd), 3),
            })

        tag  = f"${ref_kg:.2f}/kg"
        pb_s = f"{pb_simple:.1f}" if pb_simple is not None else "N/A"
        pb_d = f"{pb_discounted:.1f}" if pb_discounted is not None else "N/A"
        print(f"  {lbl} @ {tag}: SPB={pb_s} yr,  DPB={pb_d} yr,  "
              f"final NPV=${float(cum_dM[-1]):.0f}M")

df_cf = pd.DataFrame(rows_cf)
df_pb = pd.DataFrame(rows_pb)
df_cf.to_csv(os.path.join(DATA_DIR, "cashflow.csv"),  index=False)
df_pb.to_csv(os.path.join(DATA_DIR, "payback.csv"),   index=False)
print(f"\n  -> Saved cashflow.csv, payback.csv")


# ════════════════════════════════════════════════════════════════════════════
# Figure 1: 2x3 panel cash flow grid at SAF market price (twin axes)
# ════════════════════════════════════════════════════════════════════════════
print("\n[Figure 1] 2x3 cash flow grid at SAF market price ...")

fig1, axes1 = plt.subplots(2, 3, figsize=(18, 11))
fig1.suptitle(
    f"Annual & Cumulative Equity Cash Flows — All 6 SAF Configurations\n"
    f"Reference selling price (parity +20%): ${SAF_MARKET_KG:.2f}/kg SAF  |  "
    f"30-yr plant (+3-yr construction), 10% IRR, "
    f"60/40 debt/equity, 35% tax (2023 USD, CEPCI 797.9)",
    fontsize=11.5, fontweight="bold"
)


def _add_cf_panel(ax_l, lbl):
    m    = META[lbl]
    mfsp = MFSP_REF_PRICES.get(lbl, 0.0)
    yrs, ann, cum_u, cum_d = cf_data[(lbl, round(SAF_MARKET_KG, 4))]
    yrs = np.array(yrs)

    ax_r = ax_l.twinx()

    bar_abs  = max(abs(ann.min()), abs(ann.max()), 1.0)
    left_neg = bar_abs * 1.6
    left_pos = bar_abs * 3.8
    ax_l.set_ylim(-left_neg, left_pos)
    frac_below = left_neg / (left_neg + left_pos)

    cum_peak   = max(float(cum_u.max()), float(cum_d.max())) * 1.08
    right_min  = -cum_peak * frac_below / (1 - frac_below)
    right_min  = min(right_min, float(min(cum_u.min(), cum_d.min())) * 1.1)
    ax_r.set_ylim(right_min, cum_peak)

    bar_pos_color = "#a8d8a8"
    bar_neg_color = "#f4a6a6"
    bar_colors = [bar_pos_color if v >= 0 else bar_neg_color for v in ann]
    bar_edges  = ["#2e7d32"    if v >= 0 else "#c62828"    for v in ann]
    ax_l.bar(yrs, ann, width=0.80, color=bar_colors, edgecolor=bar_edges,
             linewidth=0.55, zorder=3, label="Annual CF (left axis)")
    ax_l.axhline(0, color="black", linewidth=0.7, zorder=4)
    ax_l.axvline(0, color="#888888", linewidth=0.8, linestyle=":", zorder=2)
    ax_l.set_ylabel("Annual Cash Flow (M$)", fontsize=8.5, color="#444444")
    ax_l.tick_params(axis="y", labelcolor="#444444", labelsize=7.5)
    ax_l.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"${v:,.0f}M"))

    ax_r.plot(yrs, cum_u, color="black", linewidth=1.8, linestyle="-",
              zorder=5, label="Cumulative (undiscounted)")
    ax_r.plot(yrs, cum_d, color=m["color"], linewidth=2.3, linestyle="--",
              zorder=5, label="Cumulative NPV (10% IRR)")
    ax_r.axhline(0, color="black", linewidth=0.6, zorder=4, alpha=0.5)
    ax_r.set_ylabel("Cumulative Cash Flow (M$)", fontsize=8.5, color=m["color"])
    ax_r.tick_params(axis="y", labelcolor=m["color"], labelsize=7.5)
    ax_r.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"${v:,.0f}M"))

    pb_s = find_payback_year(list(yrs), list(cum_u))
    pb_d = find_payback_year(list(yrs), list(cum_d))

    if pb_s is not None:
        ax_r.plot(pb_s, 0, "v", color="black", markersize=9,
                  zorder=10, markeredgewidth=0.5, markeredgecolor="white")
        ax_r.annotate(f"SPB\n{pb_s:.1f} yr",
                      xy=(pb_s, 0), xytext=(8, cum_peak * 0.08),
                      textcoords=("offset points", "data"),
                      fontsize=7.5, color="black", fontweight="bold", ha="left",
                      arrowprops=dict(arrowstyle="-", color="black", lw=0.7),
                      bbox=dict(boxstyle="round,pad=0.18", fc="white",
                                ec="black", alpha=0.88, linewidth=0.6))

    if pb_d is not None:
        ax_r.plot(pb_d, 0, "v", color=m["color"], markersize=9,
                  zorder=10, markeredgewidth=0.5, markeredgecolor="white")
        ax_r.annotate(f"DPB\n{pb_d:.1f} yr",
                      xy=(pb_d, 0), xytext=(8, -cum_peak * 0.10),
                      textcoords=("offset points", "data"),
                      fontsize=7.5, color=m["color"], fontweight="bold", ha="left",
                      arrowprops=dict(arrowstyle="-", color=m["color"], lw=0.7),
                      bbox=dict(boxstyle="round,pad=0.18", fc="white",
                                ec=m["color"], alpha=0.88, linewidth=0.6))

    npv_final = float(cum_d[-1])
    color_npv = "#1b5e20" if npv_final >= 0 else "#b71c1c"
    ax_r.annotate(f"Final NPV\n${npv_final:,.0f}M",
                  xy=(PLANT_LIFE, npv_final),
                  xytext=(-45, -18 if npv_final >= 0 else 18),
                  textcoords="offset points",
                  fontsize=8, color=color_npv, fontweight="bold",
                  arrowprops=dict(arrowstyle="->", color=color_npv,
                                  lw=0.9, connectionstyle="arc3,rad=-0.25"),
                  bbox=dict(boxstyle="round,pad=0.22", fc="white",
                            ec=color_npv, alpha=0.92, linewidth=0.7))

    ax_l.grid(axis="y", linewidth=0.30, alpha=0.35, linestyle="--", zorder=1)
    ax_l.set_xlabel("Project Year (neg. = construction)", fontsize=8.5)
    ax_l.set_title(f"{m['label']}   |   MFSP = ${mfsp:.2f}/kg SAF",
                   fontsize=9.5, fontweight="bold", color=m["color"])
    ax_l.set_xlim(yrs.min() - 1, PLANT_LIFE + 1)
    for sp in ax_l.spines.values():
        sp.set_linewidth(0.7)

    h1, l1 = ax_l.get_legend_handles_labels()
    h2, l2 = ax_r.get_legend_handles_labels()
    pb_s_h = mpatches.Patch(color="black",    label="▼ Simple payback (SPB)")
    pb_d_h = mpatches.Patch(color=m["color"], label="▼ Discounted payback (DPB)")
    ax_l.legend(h1 + h2 + [pb_s_h, pb_d_h], l1 + l2 + [pb_s_h.get_label(),
                pb_d_h.get_label()], fontsize=6.5, loc="upper left",
                framealpha=0.88, edgecolor="gray", ncol=1)


for ax, lbl in zip(axes1.flat, LABEL_ORDER):
    k = KEY_MAP[lbl]
    if RESULTS.get(k) and (lbl, round(SAF_MARKET_KG, 4)) in cf_data:
        _add_cf_panel(ax, lbl)

fig1.tight_layout(rect=[0, 0, 1, 0.93])
out1 = os.path.join(PLOTS_DIR, "cashflow_grid.pdf")
fig1.savefig(out1)
plt.show()
plt.close(fig1)
print(f"  -> Saved: {out1}")


# ════════════════════════════════════════════════════════════════════════════
# Figure 2: Overlay — cumulative NPV curves for all 6 at both ref prices
# ════════════════════════════════════════════════════════════════════════════
print("[Figure 2] Overlay cumulative NPV curves ...")

fig2, axes2 = plt.subplots(1, 2, figsize=(16, 7))
fig2.suptitle(
    "Cumulative Discounted NPV Over Project Life — All 6 SAF Configurations\n"
    "30-yr plant, 10% IRR, 35% tax (2023 USD, CEPCI 797.9)",
    fontsize=12, fontweight="bold"
)

TITLES = {
    round(FOSSIL_JET_KG, 4): f"At Fossil-Jet Parity  (${FOSSIL_JET_KG:.2f}/kg)",
    round(SAF_MARKET_KG, 4): f"At Parity +20%   (${SAF_MARKET_KG:.2f}/kg)",
}
MIN_SEP = 28.0

for ax, ref_kg in zip(axes2, [FOSSIL_JET_KG, SAF_MARKET_KG]):
    rk = round(ref_kg, 4)
    ax.axhline(0, color="black", linewidth=1.2, zorder=4)

    final_npvs = {}
    for lbl in LABEL_ORDER:
        key_cf = (lbl, rk)
        if key_cf not in cf_data:
            continue
        m     = META[lbl]
        yrs, _, _, cum_d = cf_data[key_cf]
        mfsp  = MFSP_REF_PRICES.get(lbl, 0.0)
        pb_d  = find_payback_year(list(yrs), list(cum_d))
        npv_f = float(cum_d[-1])
        final_npvs[lbl] = npv_f

        ax.plot(yrs, cum_d, color=m["color"], linewidth=2.0, linestyle=m["ls"],
                label=f"{m['label']}  (MFSP=${mfsp:.2f}/kg)")

        if pb_d is not None:
            ax.axvline(pb_d, color=m["color"], linewidth=0.9,
                       linestyle=":", alpha=0.75, zorder=3)
            ax.plot(pb_d, 0, "o", color=m["color"], markersize=6,
                    zorder=5, markeredgecolor="white", markeredgewidth=0.6)

    # Stagger right-edge NPV labels
    sorted_lbls = sorted(final_npvs, key=lambda l: final_npvs[l])
    stag_y = {lbl: final_npvs[lbl] for lbl in sorted_lbls}
    for i in range(1, len(sorted_lbls)):
        lo, hi = sorted_lbls[i - 1], sorted_lbls[i]
        if stag_y[hi] - stag_y[lo] < MIN_SEP:
            stag_y[hi] = stag_y[lo] + MIN_SEP
    for i in range(len(sorted_lbls) - 2, -1, -1):
        lo, hi = sorted_lbls[i], sorted_lbls[i + 1]
        if stag_y[hi] - stag_y[lo] < MIN_SEP:
            stag_y[lo] = stag_y[hi] - MIN_SEP

    LABEL_X = PLANT_LIFE + 1.5
    for lbl in LABEL_ORDER:
        if lbl not in final_npvs:
            continue
        npv_f = final_npvs[lbl]
        y_txt = stag_y[lbl]
        ax.text(LABEL_X, y_txt, f"${npv_f:,.0f}M",
                fontsize=7.5, color=META[lbl]["color"], va="center", ha="left", zorder=8)
        if abs(y_txt - npv_f) > 6:
            ax.plot([float(PLANT_LIFE), LABEL_X - 0.1], [npv_f, y_txt],
                    color=META[lbl]["color"], linewidth=0.55, alpha=0.55, zorder=7)

    ylim = ax.get_ylim()
    ax.fill_between([-3, PLANT_LIFE], 0, max(ylim[1], 100),
                    color="#d4edda", alpha=0.12, zorder=0)
    ax.fill_between([-3, PLANT_LIFE], min(ylim[0], -100), 0,
                    color="#f8d7da", alpha=0.12, zorder=0)

    ax.set_xlabel("Project Year (neg. = construction)", fontsize=10)
    ax.set_ylabel("Cumulative NPV (M$)", fontsize=10)
    ax.set_title(TITLES[rk], fontsize=10, fontweight="bold")
    ax.set_xlim(-4, PLANT_LIFE + 8)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"${v:,.0f}M"))
    ax.plot([], [], "o:", color="gray", markersize=5,
            label="• = discounted payback year")
    ax.legend(fontsize=8, loc="upper left", framealpha=0.90, edgecolor="gray")
    ax.grid(axis="y", linewidth=0.35, alpha=0.45, linestyle="--", zorder=1)
    for sp in ax.spines.values():
        sp.set_linewidth(0.7)

fig2.tight_layout(rect=[0, 0, 1, 0.93])
out2 = os.path.join(PLOTS_DIR, "cashflow_overlay.pdf")
fig2.savefig(out2)
plt.show()
plt.close(fig2)
print(f"  -> Saved: {out2}")


# ════════════════════════════════════════════════════════════════════════════
# Figure 3: Payback summary horizontal bar chart
# ════════════════════════════════════════════════════════════════════════════
print("[Figure 3] Payback summary ...")

fig3, axes3 = plt.subplots(1, 2, figsize=(14, 6))
fig3.suptitle(
    "Payback Period Summary — All 6 SAF Configurations\n"
    "Simple (undiscounted) vs. Discounted (10% IRR), from start of operation",
    fontsize=12, fontweight="bold"
)

df_pb_filt = df_pb[df_pb["ref_label"].isin(["fossil_parity", "saf_market"])]

for ax, ref_label_key, ax_title in [
    (axes3[0], "fossil_parity",
     f"At Fossil-Jet Parity  (${FOSSIL_JET_KG:.2f}/kg)"),
    (axes3[1], "saf_market",
     f"At Parity +20%   (${SAF_MARKET_KG:.2f}/kg)"),
]:
    subset = df_pb_filt[df_pb_filt["ref_label"] == ref_label_key].set_index("config")

    y_pos  = np.arange(len(LABEL_ORDER))
    labels = [META[lbl]["label"] for lbl in LABEL_ORDER]
    colors = [META[lbl]["color"] for lbl in LABEL_ORDER]

    pb_s_vals, pb_d_vals = [], []
    for lbl in LABEL_ORDER:
        if lbl in subset.index:
            row   = subset.loc[lbl]
            pb_s  = row["simple_payback_yr"]
            pb_d  = row["disc_payback_yr"]
            pb_s_vals.append(float(pb_s) if pb_s != "N/A" else PLANT_LIFE + 2)
            pb_d_vals.append(float(pb_d) if pb_d != "N/A" else PLANT_LIFE + 2)
        else:
            pb_s_vals.append(PLANT_LIFE + 2)
            pb_d_vals.append(PLANT_LIFE + 2)

    bar_h = 0.35
    ax.barh(y_pos + bar_h/2, pb_s_vals, bar_h,
            color=colors, alpha=0.55, edgecolor="gray",
            linewidth=0.6, label="Simple (undiscounted)")
    ax.barh(y_pos - bar_h/2, pb_d_vals, bar_h,
            color=colors, alpha=0.90, edgecolor="gray",
            linewidth=0.6, label="Discounted (10% IRR)")

    for i, (ps, pd_) in enumerate(zip(pb_s_vals, pb_d_vals)):
        ps_txt = f"{ps:.1f} yr" if ps <= PLANT_LIFE else "N/A"
        pd_txt = f"{pd_:.1f} yr" if pd_ <= PLANT_LIFE else "N/A"
        ax.text(min(ps, PLANT_LIFE + 1) + 0.3, i + bar_h/2,
                ps_txt, va="center", fontsize=8, color=colors[i])
        ax.text(min(pd_, PLANT_LIFE + 1) + 0.3, i - bar_h/2,
                pd_txt, va="center", fontsize=8, color=colors[i], fontweight="bold")

    ax.axvline(PLANT_LIFE, color="red", linewidth=1.4, linestyle="--",
               zorder=5, label=f"Plant life ({PLANT_LIFE} yr)")
    ax.set_yticks(y_pos)
    ax.set_yticklabels(labels, fontsize=9)
    ax.set_xlabel("Payback Period (years since start-up)", fontsize=9)
    ax.set_title(ax_title, fontsize=9.5, fontweight="bold")
    ax.set_xlim(0, PLANT_LIFE + 8)
    ax.invert_yaxis()
    ax.legend(fontsize=8.5, loc="lower right", framealpha=0.90, edgecolor="gray")
    ax.grid(axis="x", linewidth=0.35, alpha=0.45, linestyle="--", zorder=1)
    for sp in ax.spines.values():
        sp.set_linewidth(0.7)

fig3.tight_layout(rect=[0, 0, 1, 0.93])
out3 = os.path.join(PLOTS_DIR, "payback_summary.pdf")
fig3.savefig(out3)
plt.show()
plt.close(fig3)
print(f"  -> Saved: {out3}")

print("\nAll cash flow plots complete.")
