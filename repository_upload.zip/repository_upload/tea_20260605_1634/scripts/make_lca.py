"""
make_lca.py — Cradle-to-gate LCA for all 6 SAF configurations.

System boundary : well-to-wake (R1 revision): raw-material extraction -> fuel gate -> combustion
                  CO2 of FOSSIL carbon (PS-derived). Biogenic (waste-oil / HEFA) carbon = 0 at stack.
Functional unit : 1 kg of SAF product (mass basis)
Impact method   : TRACI 2.1 (10 categories)
Background data : ecoinvent Cutoff (OpenLCA exports at C:/Users/adesi/Module/OpenLCA/)

H₂ production modeling
  SMR       – 9.0 kg CO₂ eq/kg H₂ (literature GREET 2022); non-GWP categories scaled
              from hydrogen_cracking_APME OpenLCA file (refinery H₂ proxy, Cutoff).
  SOEC      – NGCC electricity × 46.4 kWh/kg H₂ (SOEC_EFFICIENCY = 0.85 HHV) +
              stoichiometric water input (9 kg H₂O/kg H₂) — matches hydrogen_production.py's
              SOEC_H2Unit, which is explicitly NGCC-grid-powered (NGCC_CO2_FACTOR = 0.49
              kg CO2/kWh), not solar PV. Fixed 2026-07-31 (was incorrectly priced with PV
              electricity factors and omitted its water consumption — see report §0).
  Photo     – stoichiometric water input (9 kg H₂O/kg H₂) + 5 kWh/kg H₂ auxiliary PV electricity

Waste feedstocks (PS, WCO): zero upstream burden (cutoff at waste gate).
WCO treatment credit       : avoided hazardous waste incineration (OpenLCA data). R1: OFF in base case
                             (WCO_CREDIT_MODE = "none"); see credit-treatment table.
Char co-product credit     : avoided coal combustion (GWP only).
Purchased SPK (Sc2)        : GWP = CORSIA default UCO-HEFA 13.9 g/MJ; other TRACI categories = OpenLCA proxy.
"""

from __future__ import annotations
import os, sys, warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import sys as _s, os as _o
_s.path.insert(0, _o.path.dirname(_o.path.dirname(_o.path.dirname(_o.path.abspath(__file__)))))
import scenario_relabel  # R1.14: display swap Sc1<->Sc2 (set SCENARIO_RELABEL=0 to disable)
import matplotlib
# Standalone run: force Agg (fast, headless). Loaded by main.py inside an
# IPython/Jupyter session: leave the backend main.py already configured
# (inline / TkAgg) alone so plt.show() calls below actually render.
try:
    get_ipython()
except NameError:
    matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.gridspec import GridSpec
from matplotlib.lines import Line2D

# ── resolve paths ─────────────────────────────────────────────────────────────
SCRIPT_DIR   = os.path.dirname(os.path.abspath(__file__))
RUN_DIR      = os.path.dirname(SCRIPT_DIR)
PROJECT_ROOT = os.path.dirname(RUN_DIR)
DATA_DIR     = os.path.join(RUN_DIR, "data")
sys.path.insert(0, SCRIPT_DIR)

from tea_model import (
    SC2_ENDS_LHV_MJ_KG,
    CONFIGS, simulate_config,
    SAF_LHV_MJ_KG, BLEND_LHV_MJ_KG,
    OPERATING_HR,
)

OLCA_DIR = os.path.join(PROJECT_ROOT, "OpenLCA")
OUT_DIR  = os.path.join(PROJECT_ROOT, "TEA_Outputs_20260608")
os.makedirs(OUT_DIR, exist_ok=True)

# ─── PHYSICAL / LCA CONSTANTS ─────────────────────────────────────────────────
SOEC_EFFICIENCY         = 0.85          # HHV basis (from SOEC_H2Unit)
H2_HHV_KJ_PER_KG       = 142_000       # kJ/kg
SOEC_KWH_PER_KG_H2     = (H2_HHV_KJ_PER_KG / 3600) / SOEC_EFFICIENCY  # ≈ 46.4 kWh/kg H₂

PHOTO_AUX_KWH_PER_KG_H2 = 5.0          # auxiliary electricity (from Photocatalysis_H2Unit _cost)
WATER_KG_PER_KG_H2      = 18.015 / 2.016  # ≈ 8.93 kg H₂O / kg H₂ (stoichiometric)

# SMR GHG (dedicated SMR, literature GREET 2022 / NREL H2A)
SMR_GWP_PER_KG_H2      = 9.0           # kg CO₂ eq / kg H₂

# Process heat from natural gas combustion (pyrolysis + hydrogenation)
PYRO_HEAT_MJ_PER_KG_FEED = 2.5         # MJ NG heat / kg plastic feed (literature)
NG_HEAT_GWP_PER_MJ       = 0.0554      # kg CO₂ eq / MJ NG combustion (incl. upstream)

# Char co-product credit: char displaces coal combustion
# Coal LHV ≈ 26 MJ/kg, GHG ≈ 0.105 kg CO₂/MJ → credit ≈ 2.7 kg CO₂/kg char
CHAR_LHV_MJ_PER_KG   = 26.0
COAL_GWP_PER_MJ       = 0.105          # kg CO₂ eq / MJ coal
CHAR_CREDIT_GWP       = CHAR_LHV_MJ_PER_KG * COAL_GWP_PER_MJ  # kg CO₂ credit / kg char

# Fossil jet fuel reference (well-to-gate, IPCC AR6 / ICAO)
FOSSIL_JET_GWP_PER_MJ  = 0.0889        # kg CO₂ eq / MJ Jet-A WELL-TO-WAKE (ICAO/CORSIA baseline ~89 g/MJ); now matches the well-to-wake boundary above
FOSSIL_JET_G_PER_MJ    = FOSSIL_JET_GWP_PER_MJ * 1000.0   # 88.9 g CO₂ eq / MJ Jet-A (well-to-wake). GWP is reported in g CO₂ eq/MJ (LHV) throughout.

# ─── R1 REVISION SWITCHES (reviewer comments R1.6, R1.15, R2.3) ───────────────
# Credit treatment: "none" = cut-off, no credit (recommended base case);
#                   "incineration" = original avoided-incineration credit (sensitivity only)
WCO_CREDIT_MODE      = "none"
INCLUDE_CHAR_CREDIT  = True          # set False for the "no char credit" case
INCLUDE_COMBUSTION   = True          # add fossil-carbon combustion CO2 (well-to-wake)
# Carbon mass fractions (assumptions; replace with values from the BioSTEAM stream composition)
C_FRAC_PS, C_FRAC_WCO, C_FRAC_EB, C_FRAC_SC1_PRODUCT = 0.923, 0.77, 0.905, 0.865   # EB C8H10 = 0.905 (was 0.88); Sc1 product = 33.5 wt% EB + n-alkanes (~0.85)
CO2_PER_C = 44.0 / 12.0

# ─── R1 update 15: consistency fixes ─────────────────────────────────────────
# (a) Purchased HEFA-SPK. The OpenLCA proxy (Jet-A surrogate from poplar bioconversion, cradle-to-gate) carries a
#     NEGATIVE GWP (biogenic uptake credited) while SPK combustion CO2 is treated as biogenic (zero) -> the biogenic
#     credit was counted twice, and poplar bioconversion is not HEFA. Default now uses the ICAO CORSIA default core LCA
#     value for UCO-HEFA (13.9 g CO2e/MJ, well-to-wake, biogenic combustion CO2 excluded) for GWP. Non-GWP TRACI
#     categories still use the OpenLCA proxy (stated as a limitation). SPK_GWP_MODE="openlca" reproduces the previous run.
SPK_GWP_MODE          = os.environ.get("SPK_GWP_MODE", "corsia_uco")
SPK_CORSIA_G_PER_MJ   = float(os.environ.get("SPK_CORSIA_G_PER_MJ", 13.9))   # tallow 22.5; soybean ~40 (CORSIA defaults)
SPK_LHV_MJ_PER_KG     = 44.1
# (b) Char co-product. PS-derived char is fossil carbon: if it displaces coal, its own combustion CO2 must be counted.
#     "net" (default) = displaced coal GWP minus fossil CO2 of burning the char; "gross" = submitted coal-only credit.
CHAR_CREDIT_MODE      = os.environ.get("CHAR_CREDIT_MODE", "net")
C_FRAC_CHAR           = 0.85          # ASSUMPTION: carbon mass fraction of pyrolysis char
# (c) Pyrolysis off-gas. The TEA burns the off-gas on site for process heat (capped at the heat demand). The LCA now
#     does the same: the off-gas LHV displaces purchased NG heat (up to the process-heat demand) and the CO2 from
#     burning its fossil (PS-derived) methane carbon is charged. Previously the LCA bought all heat as NG and ignored
#     the off-gas.
OFFGAS_IN_LCA         = os.environ.get("OFFGAS_IN_LCA", "1") == "1"
CH4_LHV_MJ_PER_KG, H2_LHV_MJ_PER_KG = 50.0, 120.0


def spk_gwp_per_kg(factors):
    """kg CO2e per kg purchased HEFA-SPK (well-to-wake GWP basis consistent with biogenic combustion = 0)."""
    if SPK_GWP_MODE == "openlca":
        return factors["aviation"].get("Global warming", 0.0)
    return SPK_CORSIA_G_PER_MJ * SPK_LHV_MJ_PER_KG / 1000.0


def fossil_carbon_share(cfg):
    """Share of feed carbon that is fossil (PS-derived). Waste-oil carbon is biogenic."""
    st = cfg["streams"]
    c_ps, c_oil = st["clean_ps_kg_hr"] * C_FRAC_PS, st.get("oil_kg_hr", 0.0) * C_FRAC_WCO
    return c_ps / max(c_ps + c_oil, 1e-12)


def char_credit_gwp_per_kg(fossil_share):
    """Net GWP credit (positive = credit) per kg char used as coal substitute."""
    if CHAR_CREDIT_MODE == "gross":
        return CHAR_CREDIT_GWP
    return CHAR_CREDIT_GWP - C_FRAC_CHAR * CO2_PER_C * fossil_share


def offgas_terms(cfg, process_heat_per_saf, fossil_share):
    """Return (displaced NG heat MJ/kg fuel, fossil CO2 from burning the off-gas kg/kg fuel)."""
    if not OFFGAS_IN_LCA:
        return 0.0, 0.0
    st, saf = cfg["streams"], cfg["saf_kg_hr"]
    ch4, h2 = st.get("gas_ch4_kg_hr", 0.0), st.get("gas_h2_kg_hr", 0.0)
    heat = (ch4 * CH4_LHV_MJ_PER_KG + h2 * H2_LHV_MJ_PER_KG) / saf
    co2 = ch4 * (44.0 / 16.0) * fossil_share / saf      # all off-gas assumed burned (excess flared)
    return min(heat, process_heat_per_saf), co2

# ─── OpenLCA FILE KEYS ────────────────────────────────────────────────────────
OLCA_FILES = {
    "smr_h2":    "hydrogen_cracking__APME___hydrogen__liquid___Cutoff__U___RoW.xlsx",
    "pv_elec":   ("electricity_production__photovoltaic__3kWp_flat_roof_installation"
                  "__multi_Si___electricity__low_voltage___Cutoff__U___RoW.xlsx"),
    "ng_elec":   ("electricity_production__natural_gas__10MW___electricity__high_voltage"
                  "___Cutoff__U___RoW.xlsx"),
    "water":     ("water_production__deionised__from_tap_water__at_user___water__deionised"
                  "__from_tap_water__at_user___Cutoff__U___RoW.xlsx"),
    "waste_oil": ("treatment_of_waste_mineral_oil__hazardous_waste_incineration___waste"
                  "_mineral_oil___Cutoff__U___RoW.xlsx"),
    "aviation":  ("aviation_fuel__Jet_A_fuel_surrogate__bioconversion_of_poplar_biomass"
                  "__at_biorefinery__45_5_MJ_kg___US.xlsx"),
    "ps_prod":   ("polystyrene_production__high_impact___polystyrene__high_impact"
                  "___Cutoff__U___RoW.xlsx"),
}

# ─── TRACI 2.1 CATEGORIES (display order) ────────────────────────────────────
CATEGORIES = [
    "Global warming",
    "Fossil fuel depletion",
    "Acidification",
    "Eutrophication",
    "Respiratory effects",
    "Smog",
    "Ecotoxicity",
    "Carcinogenics",
    "Non carcinogenics",
    "Ozone depletion",
]

CAT_UNITS = {
    "Global warming":     "g CO₂ eq/MJ",
    "Fossil fuel depletion": "MJ surplus/kg fuel",
    "Acidification":      "kg SO₂ eq/kg fuel",
    "Eutrophication":     "kg N eq/kg fuel",
    "Respiratory effects":"kg PM₂.₅ eq/kg fuel",
    "Smog":               "kg O₃ eq/kg fuel",
    "Ecotoxicity":        "CTUe/kg fuel",
    "Carcinogenics":      "CTUh/kg fuel",
    "Non carcinogenics":  "CTUh/kg fuel",
    "Ozone depletion":    "kg CFC-11 eq/kg fuel",
}

CAT_SHORT = {
    "Global warming":        "GWP",
    "Fossil fuel depletion": "FossFuel",
    "Acidification":         "Acid.",
    "Eutrophication":        "Eutro.",
    "Respiratory effects":   "Resp.",
    "Smog":                  "Smog",
    "Ecotoxicity":           "Ecotox.",
    "Carcinogenics":         "Carc.",
    "Non carcinogenics":     "Non-carc.",
    "Ozone depletion":       "ODP",
}

# ─── STYLE ───────────────────────────────────────────────────────────────────
SC_COLORS = {
    "Sc1+SMR":   "#8B4513",   # brown
    "Sc1+SOEC":  "#2196A6",   # teal
    "Sc1+Photo": "#2D7D32",   # dark green
    "Sc2+SMR":   "#C2522B",   # rust
    "Sc2+SOEC":  "#5BA0C8",   # light teal/blue
    "Sc2+Photo": "#81C784",   # light green
}
LABEL_ORDER = ["Sc1+SMR", "Sc1+SOEC", "Sc1+Photo", "Sc2+SMR", "Sc2+SOEC", "Sc2+Photo"]

CONTRIB_COLORS = {
    "H₂ production":       "#E57373",
    "Process heat (NG)":   "#FF8A65",
    "Purchased SPK":       "#FFB74D",
    "WCO treatment credit":"#81C784",
    "Char credit":         "#4DB6AC",
    "Fossil C combustion": "#6D4C41",
}

plt.rcParams.update({
    "font.family": "serif",
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.linewidth": 0.8,
    "figure.dpi": 150,
})


# ══════════════════════════════════════════════════════════════════════════════
# 1. Read OpenLCA Impact Factors
# ══════════════════════════════════════════════════════════════════════════════
def read_impacts(key: str) -> dict[str, float]:
    """
    Read TRACI 2.1 impact results per functional unit from an OpenLCA Excel export.
    Returns {impact_category_name: value}.
    """
    path = os.path.join(OLCA_DIR, OLCA_FILES[key])
    df = pd.read_excel(path, sheet_name="Impacts", header=1, usecols="B:E",
                       engine="openpyxl")
    df.columns = ["UUID", "category", "unit", "value"]
    df = df.dropna(subset=["category", "value"])
    df["category"] = df["category"].str.strip()
    return dict(zip(df["category"], df["value"].astype(float)))


def load_all_impacts() -> dict[str, dict[str, float]]:
    """Load all OpenLCA impact files into nested dict {key: {category: value}}."""
    return {k: read_impacts(k) for k in OLCA_FILES}


# ══════════════════════════════════════════════════════════════════════════════
# 2. Build per-kg-SAF Inventory and Compute TRACI Impacts
# ══════════════════════════════════════════════════════════════════════════════
def compute_inventory(cfg: dict) -> dict:
    """
    Derive physical inventory (per kg SAF) from simulate_config() output.
    Returns inventory dict with all flow rates per kg SAF.
    """
    saf      = cfg["saf_kg_hr"]
    streams  = cfg["streams"]
    h2_src   = cfg["h2_source"]
    sc       = cfg["scenario"]

    inv = {}
    inv["h2_per_saf"]   = cfg["H2_demand"] / saf              # kg H₂ / kg SAF
    inv["oil_per_saf"]  = streams["oil_kg_hr"] / saf          # kg WCO / kg SAF
    inv["char_per_saf"] = streams["char_kg_hr"] / saf         # kg char / kg SAF
    inv["spk_per_saf"]  = cfg["spk_kg_hr"] / saf              # kg SPK / kg SAF
    inv["water_per_saf"]= WATER_KG_PER_KG_H2 * inv["h2_per_saf"]  # kg H₂O / kg SAF

    # Total feed for process heat estimate (clean PS reaching the pyrolyzer,
    # not the raw pretreatment intake — pyrolysis heat scales with what's
    # actually fed to the reactor)
    total_feed_hr = streams["clean_ps_kg_hr"] + streams["oil_kg_hr"]
    inv["process_heat_per_saf"] = PYRO_HEAT_MJ_PER_KG_FEED * total_feed_hr / saf  # MJ/kg SAF (gross demand)
    _fs = fossil_carbon_share(cfg)
    _disp, _gas_co2 = offgas_terms(cfg, inv["process_heat_per_saf"], _fs)
    inv["process_heat_per_saf"] -= _disp                     # purchased NG heat net of off-gas firing (R1 update 15)
    inv["offgas_co2_per_saf"]   = _gas_co2
    inv["char_credit_gwp_per_kg"] = char_credit_gwp_per_kg(_fs)
    inv["fossil_share"] = _fs

    # Electricity per kg SAF (H₂ production)
    if h2_src == "SOEC":
        inv["elec_kwh_per_saf"] = SOEC_KWH_PER_KG_H2 * inv["h2_per_saf"]
        inv["h2_source_key"]    = "soec_ngcc"
    elif h2_src == "Photocatalysis":
        inv["elec_kwh_per_saf"] = PHOTO_AUX_KWH_PER_KG_H2 * inv["h2_per_saf"]
        inv["h2_source_key"]    = "photo"
    else:  # SMR
        inv["elec_kwh_per_saf"] = 0.0
        inv["h2_source_key"]    = "smr"

    # Fossil-carbon combustion CO2 (kg CO2 / kg fuel). Sc1: share of product carbon that came from PS
    # (waste-oil carbon is biogenic). Sc2: the EB half of the 50:50 blend is PS-derived; HEFA half biogenic.
    if sc == 1:
        c_ps  = streams["clean_ps_kg_hr"] * C_FRAC_PS
        c_oil = streams["oil_kg_hr"] * C_FRAC_WCO
        inv["fossil_comb_per_saf"] = c_ps / (c_ps + c_oil) * C_FRAC_SC1_PRODUCT * CO2_PER_C
    else:
        inv["fossil_comb_per_saf"] = (1.0 - inv["spk_per_saf"]) * C_FRAC_EB * CO2_PER_C
        # R1 (Prajapati16): the distillation 'other ends' are PS-derived fossil carbon burned as process fuel.
        # Net burden = their CO2 minus the NG heat they displace. Folded into 'Fossil C combustion' (GWP only).
        _ends = cfg.get("ends_kg_hr", 0.0) / saf
        inv["fossil_comb_per_saf"] += _ends * (C_FRAC_EB * CO2_PER_C - SC2_ENDS_LHV_MJ_KG * NG_HEAT_GWP_PER_MJ)

    inv["lhv"]     = SAF_LHV_MJ_KG if sc == 1 else BLEND_LHV_MJ_KG
    inv["h2_source"] = h2_src
    inv["scenario"]  = sc
    return inv


def compute_impacts_per_kg(inv: dict, factors: dict[str, dict[str, float]],
                           wco_mode=None, char_credit_on=None, combustion_on=None) -> dict:
    """
    Multiply inventory by TRACI 2.1 factors; return {category: value per kg SAF}.
    Structured contributions: H₂, heat, SPK, WCO credit, char credit.
    """
    wco_mode        = WCO_CREDIT_MODE     if wco_mode is None        else wco_mode
    char_credit_on  = INCLUDE_CHAR_CREDIT if char_credit_on is None  else char_credit_on
    combustion_on   = INCLUDE_COMBUSTION  if combustion_on is None   else combustion_on
    # Scale factor for SMR non-GWP: ratio of literature SMR GWP to APME proxy GWP
    smr_gwp_apme  = factors["smr_h2"].get("Global warming", 1.697)
    smr_gwp_scale = SMR_GWP_PER_KG_H2 / smr_gwp_apme

    # NG electricity → heat proxy scale: heat is ~(gen_eff/boiler_eff) × electricity impact
    # gen_eff = 0.40, boiler_eff = 0.82 → factor ≈ 0.49
    NG_HEAT_SCALE = 0.49  # heat vs electricity impact per MJ energy

    results     = {}   # {category: total per kg SAF}
    contribs    = {}   # {category: {contributor: value per kg SAF}}

    h2  = inv["h2_per_saf"]
    h2k = inv["h2_source_key"]
    oil = inv["oil_per_saf"]
    char= inv["char_per_saf"]
    spk = inv["spk_per_saf"]
    wat = inv["water_per_saf"]
    ht  = inv["process_heat_per_saf"]      # MJ NG heat / kg SAF
    el  = inv["elec_kwh_per_saf"]

    for cat in CATEGORIES:
        # — H₂ production impact —
        if h2k == "smr":
            if cat == "Global warming":
                h2_val = h2 * SMR_GWP_PER_KG_H2
            else:
                h2_val = h2 * factors["smr_h2"].get(cat, 0.0) * smr_gwp_scale
        elif h2k == "soec_ngcc":
            # SOEC electrolyzes stoichiometric water like Photocatalysis, but is
            # powered by NGCC grid electricity (hydrogen_production.py's SOEC_H2Unit),
            # not solar PV — using ng_elec here, not pv_elec.
            h2_val = (wat * factors["water"].get(cat, 0.0)
                      + el * factors["ng_elec"].get(cat, 0.0))
        else:  # photo: water input + aux electricity from PV
            h2_val = (wat * factors["water"].get(cat, 0.0)
                      + el * factors["pv_elec"].get(cat, 0.0))

        # — Process heat from NG —
        if cat == "Global warming":
            ht_val = ht * NG_HEAT_GWP_PER_MJ + inv.get("offgas_co2_per_saf", 0.0)   # + on-site off-gas firing
        else:
            # Use NG electricity data scaled by heat/electricity ratio
            ng_per_kwh = factors["ng_elec"].get(cat, 0.0)
            ht_val = (ht / 3.6) * ng_per_kwh * NG_HEAT_SCALE

        # — Purchased SPK (Sc2 only) —
        spk_val = spk * (spk_gwp_per_kg(factors) if cat == "Global warming" else factors["aviation"].get(cat, 0.0))

        # — WCO avoided treatment credit (Sc1) —
        oil_credit = (-oil * factors["waste_oil"].get(cat, 0.0)) if wco_mode == "incineration" else 0.0

        # — Char co-product credit (GWP only, coal displacement) —
        if cat == "Global warming" and char_credit_on:
            char_credit = -char * inv.get("char_credit_gwp_per_kg", CHAR_CREDIT_GWP)
        else:
            char_credit = 0.0

        # — Combustion of fossil carbon at end use (GWP only; well-to-wake) —
        comb_val = inv["fossil_comb_per_saf"] if (cat == "Global warming" and combustion_on) else 0.0

        total_per_kg = h2_val + ht_val + spk_val + oil_credit + char_credit + comb_val

        results[cat] = total_per_kg
        contribs[cat] = {
            "H₂ production":        h2_val,
            "Process heat (NG)":    ht_val,
            "Purchased SPK":        spk_val,
            "WCO treatment credit": oil_credit,
            "Char credit":          char_credit,
            "Fossil C combustion":  comb_val,
        }

    return results, contribs


# ══════════════════════════════════════════════════════════════════════════════
# 3. Run All 6 Scenarios
# ══════════════════════════════════════════════════════════════════════════════
def run_lca():
    print("Loading OpenLCA impact factors …")
    factors = load_all_impacts()

    all_results  = {}
    all_contribs = {}
    all_inv      = {}
    summary_rows = []
    treat_rows   = []

    for label, (sc, h2) in zip(LABEL_ORDER, [
        (1, "SMR"), (1, "SOEC"), (1, "Photocatalysis"),
        (2, "SMR"), (2, "SOEC"), (2, "Photocatalysis"),
    ]):
        print(f"  Computing {label} …")
        cfg = simulate_config(sc, h2)
        inv = compute_inventory(cfg)
        res, cont = compute_impacts_per_kg(inv, factors)
        # R1: GWP reported per MJ (LHV): convert kg CO2-eq/kg fuel -> g CO2-eq/MJ for all downstream plots/CSVs
        _k = 1000.0 / inv["lhv"]
        res["Global warming"] *= _k
        for _c in cont["Global warming"]:
            cont["Global warming"][_c] *= _k

        all_results[label]  = res
        all_contribs[label] = cont
        all_inv[label]      = inv

        row = {"scenario": label}
        for cat in CATEGORIES:
            row[cat] = res[cat]
        row["GWP_reduction_vs_fossil_pct"] = (
            (FOSSIL_JET_G_PER_MJ - res["Global warming"]) / FOSSIL_JET_G_PER_MJ * 100
        )
        row["LHV_MJ_per_kg"]    = inv["lhv"]
        row["GWP_g_per_MJ"]     = res["Global warming"]
        row["GWP_kg_per_kg"]    = res["Global warming"] * inv["lhv"] / 1000.0
        summary_rows.append(row)

        # credit-treatment sensitivity (reviewer R2.3): well-to-gate vs well-to-wake
        for cname, (wm, ch, cb) in {
            "A cradle-to-gate, incineration credit (as submitted)": ("incineration", True, False),
            "B cradle-to-gate, no WCO credit":                     ("none", True, False),
            "C cradle-to-gate, no WCO, no char credit":            ("none", False, False),
            "D well-to-wake, incineration credit":                 ("incineration", True, True),
            "E well-to-wake, no WCO credit (BASE)":                ("none", True, True),
            "F well-to-wake, no WCO, no char credit":              ("none", False, True),
        }.items():
            r2, _ = compute_impacts_per_kg(inv, factors, wm, ch, cb)
            g = r2["Global warming"]
            treat_rows.append({"scenario": label, "treatment": cname,
                               "GWP_kg_per_kg": g, "GWP_g_per_MJ": g / inv["lhv"] * 1000.0,
                               "reduction_vs_JetA_WTW_pct": (FOSSIL_JET_G_PER_MJ - g / inv["lhv"] * 1000.0) / FOSSIL_JET_G_PER_MJ * 100
                               if cb else float("nan")})

    pd.DataFrame(treat_rows).to_csv(os.path.join(DATA_DIR, "lca_credit_treatments.csv"), index=False)
    return all_results, all_contribs, all_inv, summary_rows, factors


# ══════════════════════════════════════════════════════════════════════════════
# 4. Save CSV
# ══════════════════════════════════════════════════════════════════════════════
def save_csvs(summary_rows, all_contribs):
    df = pd.DataFrame(summary_rows)
    df.to_csv(os.path.join(DATA_DIR, "lca_results.csv"), index=False)

    rows = []
    for label, cont_dict in all_contribs.items():
        for cat, contrib in cont_dict.items():
            for contributor, val in contrib.items():
                rows.append({
                    "scenario": label,
                    "impact_category": cat,
                    "contributor": contributor,
                    "value_per_kg_SAF": val,
                })
    pd.DataFrame(rows).to_csv(
        os.path.join(DATA_DIR, "lca_contributions.csv"), index=False
    )


# ══════════════════════════════════════════════════════════════════════════════
# 5. Plot 1 — GHG Intensity Bar Chart
# ══════════════════════════════════════════════════════════════════════════════
def plot_ghg_bar(all_results, out_path):
    gwp = [all_results[lbl]["Global warming"] for lbl in LABEL_ORDER]
    fossil_g = FOSSIL_JET_G_PER_MJ

    # Compute y-axis range FIRST so all labels can use it
    gwp_min = min(gwp)
    gwp_max = max(gwp)
    y_lo = gwp_min - abs(gwp_min) * 0.22    # extra space below for % labels
    y_hi = max(gwp_max * 4 + 0.3, 0.6)      # space above zero for fossil jet annotation

    fig, ax = plt.subplots(figsize=(9.5, 5.8))
    x = np.arange(len(LABEL_ORDER))

    bars = ax.bar(x, gwp, width=0.62,
                  color=[SC_COLORS[l] for l in LABEL_ORDER],
                  edgecolor="white", linewidth=0.6, zorder=3)

    ax.axhline(0, color="black", lw=0.7, zorder=2)

    # Fossil jet annotation at top of axes (off-scale — bars are all much lower)
    ax.annotate(
        f"Fossil Jet-A reference: {fossil_g:.1f} g CO2 eq/MJ  (off-scale, >> fuel bars)",
        xy=(0.5, 0.97), xycoords="axes fraction", ha="center", va="top",
        fontsize=8.5, color="#B71C1C", fontweight="bold",
        bbox=dict(fc="#FFEBEE", ec="#B71C1C", lw=0.9, boxstyle="round,pad=0.3"),
    )

    # Value labels on bars
    for bar, val in zip(bars, gwp):
        if val <= 0:
            ypos = val - abs(y_lo) * 0.012
            va = "top"
        else:
            ypos = val + y_hi * 0.012
            va = "bottom"
        ax.text(bar.get_x() + bar.get_width() / 2, ypos,
                f"{val:.2f}", ha="center", va=va, fontsize=8.5, fontweight="bold")

    # GHG reduction vs fossil jet — annotated at bottom of each bar
    for i, val in enumerate(gwp):
        red_pct = (fossil_g - val) / fossil_g * 100
        ax.text(i, y_lo + abs(y_lo) * 0.02,
                f"{red_pct:.0f}% vs fossil",
                ha="center", va="bottom", fontsize=7.5,
                color="#1B5E20", style="italic")

    ax.set_xticks(x)
    ax.set_xticklabels(LABEL_ORDER, fontsize=10)
    ax.set_ylabel("GHG Intensity (g CO2 eq / MJ fuel)", fontsize=11)
    ax.set_title("Cradle-to-Gate GHG Intensity -- SAF from Waste Polystyrene",
                 fontsize=12, pad=10)
    ax.set_xlim(-0.5, len(LABEL_ORDER) - 0.5)
    ax.set_ylim(y_lo, y_hi)
    ax.yaxis.grid(True, ls=":", lw=0.5, alpha=0.6)
    ax.set_axisbelow(True)

    # Scenario divider and labels (placed below the fossil jet annotation)
    ax.axvline(2.5, color="#90909070", lw=1.0, ls=":")
    ax.text(1.0, y_hi * 0.44, "Scenario 1\n(co-hydropyrolysis)",
            ha="center", fontsize=8.5, color="#444")
    ax.text(4.0, y_hi * 0.44, "Scenario 2\n(PS-only + SPK blend)",
            ha="center", fontsize=8.5, color="#444")

    fig.text(0.5, 0.005, "System boundary: well-to-gate | FU: 1 kg SAF | TRACI 2.1",
             ha="center", fontsize=7.5, color="#555")

    fig.tight_layout(rect=[0, 0.035, 1, 1])
    fig.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.show()
    plt.close(fig)
    print(f"  Saved -> {out_path}")


# ══════════════════════════════════════════════════════════════════════════════
# 6. Plot 2 — GHG Contribution Stacked Bar
# ══════════════════════════════════════════════════════════════════════════════
def plot_ghg_stack(all_contribs, out_path):
    contrib_order = [
        "H₂ production", "Process heat (NG)", "Purchased SPK", "Fossil C combustion",
        "WCO treatment credit", "Char credit",
    ]

    x = np.arange(len(LABEL_ORDER))
    fig, ax = plt.subplots(figsize=(10, 5.5))

    bottoms_pos = np.zeros(len(LABEL_ORDER))
    bottoms_neg = np.zeros(len(LABEL_ORDER))

    for contrib in contrib_order:
        vals = np.array([
            all_contribs[lbl]["Global warming"].get(contrib, 0.0)
            for lbl in LABEL_ORDER
        ])
        pos = np.where(vals > 0, vals, 0.0)
        neg = np.where(vals < 0, vals, 0.0)

        ax.bar(x, pos, bottom=bottoms_pos, width=0.6,
               color=CONTRIB_COLORS[contrib], label=contrib,
               edgecolor="white", linewidth=0.4)
        ax.bar(x, neg, bottom=bottoms_neg, width=0.6,
               color=CONTRIB_COLORS[contrib],
               edgecolor="white", linewidth=0.4)
        bottoms_pos += pos
        bottoms_neg += neg

    # Net GHG dot
    net_vals = [
        sum(all_contribs[lbl]["Global warming"].values())
        for lbl in LABEL_ORDER
    ]
    ax.plot(x, net_vals, "D", color="#212121", ms=6, zorder=5, label="Net GHG")

    ax.axhline(FOSSIL_JET_G_PER_MJ, color="#B71C1C", lw=1.4,
               ls="--", label=f"Fossil Jet-A ({FOSSIL_JET_G_PER_MJ:.1f} g/MJ)")
    ax.axhline(0, color="black", lw=0.7)

    ax.set_xticks(x)
    ax.set_xticklabels(LABEL_ORDER, fontsize=10)
    ax.set_ylabel("GHG Contribution (g CO₂ eq / MJ fuel)", fontsize=11)
    ax.set_title("Cradle-to-Gate GHG Contribution Analysis — TRACI 2.1",
                 fontsize=12, pad=10)
    ax.yaxis.grid(True, ls=":", lw=0.5, alpha=0.6)
    ax.set_axisbelow(True)
    ax.legend(loc="upper right", fontsize=8.5, framealpha=0.9, ncol=2)

    # Scenario divider
    ax.axvline(2.5, color="#90909070", lw=1.0, ls=":")

    fig.tight_layout()
    fig.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.show()
    plt.close(fig)
    print(f"  Saved -> {out_path}")


# ══════════════════════════════════════════════════════════════════════════════
# 7. Plot 3 — Multi-category TRACI Heatmap (normalized to fossil jet GHG)
# ══════════════════════════════════════════════════════════════════════════════
def plot_traci_heatmap(all_results, out_path):
    """Heatmap: rows = TRACI categories, cols = scenarios.
    Normalized so that each row's maximum absolute value = 1 (or fossil reference for GWP).
    """
    # Build matrix
    mat = np.zeros((len(CATEGORIES), len(LABEL_ORDER)))
    for j, lbl in enumerate(LABEL_ORDER):
        for i, cat in enumerate(CATEGORIES):
            mat[i, j] = all_results[lbl][cat]

    # Normalize each category by its max absolute value across all scenarios
    row_max = np.max(np.abs(mat), axis=1, keepdims=True)
    row_max[row_max == 0] = 1.0
    mat_norm = mat / row_max

    fig, ax = plt.subplots(figsize=(10, 6.5))
    im = ax.imshow(mat_norm, cmap="RdYlGn_r", aspect="auto",
                   vmin=-1.0, vmax=1.0)

    ax.set_xticks(np.arange(len(LABEL_ORDER)))
    ax.set_xticklabels(LABEL_ORDER, fontsize=10)
    ax.set_yticks(np.arange(len(CATEGORIES)))
    ax.set_yticklabels(
        [f"{CAT_SHORT[c]}  [{CAT_UNITS[c]}]" for c in CATEGORIES],
        fontsize=9,
    )

    # Annotate cells
    for i in range(len(CATEGORIES)):
        for j in range(len(LABEL_ORDER)):
            raw = mat[i, j]
            if abs(raw) < 1e-12:
                txt = "0"
            elif abs(raw) < 1e-6:
                txt = f"{raw:.1e}"
            elif abs(raw) < 0.001:
                txt = f"{raw:.2e}"
            else:
                txt = f"{raw:.3f}"
            color = "white" if abs(mat_norm[i, j]) > 0.65 else "black"
            ax.text(j, i, txt, ha="center", va="center", fontsize=6.5, color=color)

    cbar = fig.colorbar(im, ax=ax, fraction=0.02, pad=0.03)
    cbar.set_label("Normalized impact\n(1 = max across scenarios)", fontsize=8.5)

    ax.set_title("TRACI 2.1 Multi-Category LCA — All 6 Configurations\n"
                 "(cradle-to-gate, 1 kg SAF functional unit)",
                 fontsize=11, pad=10)

    ax.tick_params(top=True, labeltop=True, bottom=False, labelbottom=False)
    ax.set_xticks(np.arange(len(LABEL_ORDER)))
    ax.set_xticklabels(LABEL_ORDER, fontsize=9.5)

    fig.tight_layout()
    fig.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved -> {out_path}")


# ══════════════════════════════════════════════════════════════════════════════
# 8. Plot 4 — Radar / Spider Chart
# ══════════════════════════════════════════════════════════════════════════════
def plot_radar(all_results, out_path):
    """Radar chart: 10 TRACI categories, 6 scenarios + fossil jet reference.
    Each spoke is normalized to max absolute value across all scenarios (incl. fossil).
    Fossil jet GWP = reference; others N/A → 0 for fossil on non-GWP spokes.
    """
    N = len(CATEGORIES)
    angles = np.linspace(0, 2 * np.pi, N, endpoint=False).tolist()
    angles += angles[:1]  # close the loop

    # Build normalized matrix
    raw_mat = {}
    for lbl in LABEL_ORDER:
        raw_mat[lbl] = [all_results[lbl][c] for c in CATEGORIES]
    # Fossil reference (GWP only, others 0)
    fossil_vals = [FOSSIL_JET_G_PER_MJ if c == "Global warming" else 0.0
                   for c in CATEGORIES]
    raw_mat["Fossil Jet-A"] = fossil_vals

    # Max absolute per category (including fossil)
    col_max = []
    for i in range(N):
        vals = [abs(raw_mat[lbl][i]) for lbl in raw_mat]
        col_max.append(max(vals) if max(vals) > 0 else 1.0)

    norm_mat = {}
    for lbl in raw_mat:
        norm_mat[lbl] = [
            raw_mat[lbl][i] / col_max[i] for i in range(N)
        ]

    fig, ax = plt.subplots(figsize=(8, 8), subplot_kw=dict(polar=True))

    for lbl in LABEL_ORDER:
        vals = norm_mat[lbl] + norm_mat[lbl][:1]
        ax.plot(angles, vals, color=SC_COLORS[lbl], lw=1.8, label=lbl, zorder=3)
        ax.fill(angles, vals, color=SC_COLORS[lbl], alpha=0.07)

    # Fossil jet reference
    fvals = norm_mat["Fossil Jet-A"] + norm_mat["Fossil Jet-A"][:1]
    ax.plot(angles, fvals, color="#B71C1C", lw=1.8, ls="--",
            label="Fossil Jet-A (GWP ref.)", zorder=4)

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels([CAT_SHORT[c] for c in CATEGORIES], fontsize=10)
    ax.set_ylim(-1.05, 1.05)
    ax.set_yticks([0.25, 0.50, 0.75, 1.0])
    ax.set_yticklabels(["0.25×", "0.5×", "0.75×", "1×"], fontsize=7.5, color="#666")
    ax.grid(color="#BDBDBD", ls="--", lw=0.6)
    ax.set_title("TRACI 2.1 Multi-Criteria Comparison\n"
                 "(normalized to max value per impact category)",
                 fontsize=11, pad=22)

    ax.legend(loc="upper right", bbox_to_anchor=(1.38, 1.18),
              fontsize=8.5, framealpha=0.9)

    fig.tight_layout()
    fig.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved -> {out_path}")


# ══════════════════════════════════════════════════════════════════════════════
# 9. Plot 5 — H₂ Source Comparison Panel (GHG breakdown by H₂ route)
# ══════════════════════════════════════════════════════════════════════════════
def plot_h2_comparison(all_results, all_contribs, out_path):
    """2-panel figure: Sc1 (top) and Sc2 (bottom), each with 3 H₂ bars."""
    contrib_order = [
        "H₂ production", "Process heat (NG)", "Purchased SPK", "Fossil C combustion",
        "WCO treatment credit", "Char credit",
    ]

    fig, axes = plt.subplots(1, 2, figsize=(11, 5.5), sharey=False)
    scenario_labels = [
        (["Sc1+SMR", "Sc1+SOEC", "Sc1+Photo"], "Scenario 1 — Co-hydropyrolysis"),
        (["Sc2+SMR", "Sc2+SOEC", "Sc2+Photo"], "Scenario 2 — PS-only + SPK blend"),
    ]

    for ax, (lbls, title) in zip(axes, scenario_labels):
        x = np.arange(len(lbls))
        bottoms_pos = np.zeros(3)
        bottoms_neg = np.zeros(3)

        for contrib in contrib_order:
            vals = np.array([
                all_contribs[l]["Global warming"].get(contrib, 0.0)
                for l in lbls
            ])
            pos = np.where(vals > 0, vals, 0.0)
            neg = np.where(vals < 0, vals, 0.0)
            ax.bar(x, pos, bottom=bottoms_pos, width=0.55,
                   color=CONTRIB_COLORS[contrib], label=contrib,
                   edgecolor="white", linewidth=0.4)
            ax.bar(x, neg, bottom=bottoms_neg, width=0.55,
                   color=CONTRIB_COLORS[contrib], edgecolor="white", linewidth=0.4)
            bottoms_pos += pos
            bottoms_neg += neg

        # Net GHG
        net = [sum(all_contribs[l]["Global warming"].values()) for l in lbls]
        ax.plot(x, net, "D", color="#212121", ms=7, zorder=5, label="Net GHG")
        for xi, v in zip(x, net):
            ax.text(xi + 0.01, v + 0.06 if v >= 0 else v - 0.10,
                    f"{v:.2f}", ha="center", fontsize=9, fontweight="bold")

        ax.axhline(FOSSIL_JET_G_PER_MJ, color="#B71C1C", lw=1.4,
                   ls="--", label="Fossil Jet-A")
        ax.axhline(0, color="black", lw=0.7)
        ax.set_xticks(x)
        ax.set_xticklabels(["SMR", "SOEC\n(NGCC)", "Photo\ncatalysis"],
                           fontsize=10.5)
        ax.set_title(title, fontsize=10.5, fontweight="bold", pad=8)
        ax.set_ylabel("g CO₂ eq / MJ fuel", fontsize=10)
        ax.yaxis.grid(True, ls=":", lw=0.5, alpha=0.6)
        ax.set_axisbelow(True)

    # Shared legend
    handles, labels_ = axes[0].get_legend_handles_labels()
    seen = {}
    hl = [(h, l) for h, l in zip(handles, labels_) if not (l in seen or seen.update({l: 1}))]
    fig.legend([h for h, l in hl], [l for h, l in hl],
               loc="lower center", ncol=4, fontsize=8.5, framealpha=0.9,
               bbox_to_anchor=(0.5, -0.02))

    fig.suptitle("GHG Intensity by H₂ Production Route — Cradle-to-Gate TRACI 2.1",
                 fontsize=12, y=1.01)
    fig.tight_layout()
    fig.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.show()
    plt.close(fig)
    print(f"  Saved -> {out_path}")


# ══════════════════════════════════════════════════════════════════════════════
# 10. Plot 6 — Full TRACI Dashboard (all categories, all scenarios)
# ══════════════════════════════════════════════════════════════════════════════
def plot_traci_bars(all_results, out_path):
    """10-panel figure: one sub-plot per TRACI category."""
    fig, axes = plt.subplots(2, 5, figsize=(18, 7))
    axes_flat = axes.flatten()

    for idx, cat in enumerate(CATEGORIES):
        ax = axes_flat[idx]
        vals = [all_results[lbl][cat] for lbl in LABEL_ORDER]
        colors = [SC_COLORS[l] for l in LABEL_ORDER]
        x = np.arange(len(LABEL_ORDER))
        ax.bar(x, vals, color=colors, edgecolor="white", linewidth=0.4, width=0.6)
        ax.axhline(0, color="black", lw=0.6)
        ax.set_xticks(x)
        ax.set_xticklabels(
            ["S1\nSMR", "S1\nSOEC", "S1\nPh", "S2\nSMR", "S2\nSOEC", "S2\nPh"],
            fontsize=7.5,
        )
        ax.set_title(f"{CAT_SHORT[cat]}", fontsize=9.5, fontweight="bold")
        ax.set_ylabel(CAT_UNITS[cat], fontsize=7, labelpad=2)
        ax.yaxis.grid(True, ls=":", lw=0.4, alpha=0.6)
        ax.set_axisbelow(True)
        ax.tick_params(axis="y", labelsize=7)

    # Legend
    legend_elements = [
        mpatches.Patch(facecolor=SC_COLORS[l], label=l) for l in LABEL_ORDER
    ]
    fig.legend(handles=legend_elements, loc="lower center", ncol=6,
               fontsize=8.5, bbox_to_anchor=(0.5, -0.03), framealpha=0.9)

    fig.suptitle("TRACI 2.1 — All Impact Categories per kg fuel (GWP: g CO2e/MJ, well-to-wake)",
                 fontsize=12, y=1.01)
    fig.tight_layout(rect=[0, 0.04, 1, 1])
    fig.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.show()
    plt.close(fig)
    print(f"  Saved -> {out_path}")


# ══════════════════════════════════════════════════════════════════════════════
# 11. Plot 7 — Percentage Contribution Stacked Bar (all TRACI categories)
# ══════════════════════════════════════════════════════════════════════════════
def plot_percent_stack(all_contribs, out_path):
    """
    10-panel figure (2 rows × 5 cols), one panel per TRACI 2.1 category.

    For each category × scenario:
      - Positive contributors stacked to 100 % of gross positive total.
      - Credit contributors shown as negative % of that same gross positive
        total (so the net bar can exceed -100 % when credits dominate).
      - A black line/marker shows the NET % (= net / gross_positive * 100).
    Panels where all contributions are essentially zero are left blank with a
    "No significant impact" note.
    """
    contrib_order_pos = ["H2 production", "Process heat (NG)", "Purchased SPK"]
    contrib_order_neg = ["WCO treatment credit", "Char credit"]
    # Internal dict keys use Unicode; map to display labels here:
    key_pos = ["H₂ production", "Process heat (NG)", "Purchased SPK", "Fossil C combustion"]
    key_neg = ["WCO treatment credit", "Char credit"]
    colors_pos = ["#E57373", "#FF8A65", "#FFB74D", "#6D4C41"]
    colors_neg = ["#66BB6A", "#26A69A"]

    fig, axes = plt.subplots(2, 5, figsize=(18, 8), sharey=False)
    axes_flat = axes.flatten()

    for idx, cat in enumerate(CATEGORIES):
        ax = axes_flat[idx]
        x = np.arange(len(LABEL_ORDER))

        # Collect values for this category
        pos_vals  = {k: np.zeros(len(LABEL_ORDER)) for k in key_pos}
        neg_vals  = {k: np.zeros(len(LABEL_ORDER)) for k in key_neg}

        for j, lbl in enumerate(LABEL_ORDER):
            c = all_contribs[lbl][cat]
            for k in key_pos:
                pos_vals[k][j] = max(c.get(k, 0.0), 0.0)
            for k in key_neg:
                neg_vals[k][j] = min(c.get(k, 0.0), 0.0)

        gross_pos = sum(pos_vals[k] for k in key_pos)  # shape (6,)

        # Skip near-zero panels
        if np.max(np.abs(gross_pos)) < 1e-15:
            ax.text(0.5, 0.5, "No significant\npositive impact",
                    ha="center", va="center", transform=ax.transAxes,
                    fontsize=8, color="#888")
            ax.set_title(CAT_SHORT[cat], fontsize=9.5, fontweight="bold")
            ax.set_xticks(x)
            ax.set_xticklabels(
                ["S1\nSMR", "S1\nSOEC", "S1\nPh", "S2\nSMR", "S2\nSOEC", "S2\nPh"],
                fontsize=7)
            continue

        # Normalize to % of gross_pos (avoid div/0)
        safe_gp = np.where(gross_pos > 0, gross_pos, np.nan)

        # Plot positive stacked bars (0 → 100 %)
        bottoms = np.zeros(len(LABEL_ORDER))
        for k, col in zip(key_pos, colors_pos):
            pct = np.where(~np.isnan(safe_gp), pos_vals[k] / safe_gp * 100, 0.0)
            ax.bar(x, pct, bottom=bottoms, width=0.6, color=col,
                   edgecolor="white", linewidth=0.35, label=k)
            # In-segment label if segment is large enough
            for xi, (b, p) in enumerate(zip(bottoms, pct)):
                if p > 8:
                    ax.text(xi, b + p / 2, f"{p:.0f}%",
                            ha="center", va="center", fontsize=6.5, color="white",
                            fontweight="bold")
            bottoms = bottoms + pct

        # Plot credit bars below zero (as % of gross_pos)
        neg_bottoms = np.zeros(len(LABEL_ORDER))
        for k, col in zip(key_neg, colors_neg):
            pct = np.where(~np.isnan(safe_gp), neg_vals[k] / safe_gp * 100, 0.0)
            ax.bar(x, pct, bottom=neg_bottoms, width=0.6, color=col,
                   edgecolor="white", linewidth=0.35, label=k, alpha=0.85)
            for xi, (b, p) in enumerate(zip(neg_bottoms, pct)):
                if abs(p) > 8:
                    ax.text(xi, b + p / 2, f"{p:.0f}%",
                            ha="center", va="center", fontsize=6.5, color="white",
                            fontweight="bold")
            neg_bottoms = neg_bottoms + pct

        # Net % marker
        gross_neg = sum(neg_vals[k] for k in key_neg)
        net = gross_pos + gross_neg
        net_pct = np.where(~np.isnan(safe_gp), net / safe_gp * 100, 0.0)
        ax.plot(x, net_pct, "D", color="#212121", ms=5, zorder=5,
                label="Net" if idx == 0 else "_nolegend_")
        for xi, np_ in enumerate(net_pct):
            offset = 4 if np_ >= 0 else -4
            ax.text(xi, np_ + offset, f"{np_:.0f}",
                    ha="center", va="center" if np_ >= 0 else "top",
                    fontsize=5.5, color="#212121", fontweight="bold")

        ax.axhline(0, color="black", lw=0.7)
        ax.axhline(100, color="#BDBDBD", lw=0.5, ls=":")
        ax.set_xticks(x)
        ax.set_xticklabels(
            ["S1\nSMR", "S1\nSOEC", "S1\nPh", "S2\nSMR", "S2\nSOEC", "S2\nPh"],
            fontsize=7.5)
        ax.set_title(f"{CAT_SHORT[cat]}\n[{CAT_UNITS[cat]}]",
                     fontsize=8.5, fontweight="bold")
        ax.set_ylabel("% of gross positive", fontsize=7, labelpad=2)
        ax.tick_params(axis="y", labelsize=7)
        ax.yaxis.grid(True, ls=":", lw=0.4, alpha=0.5)
        ax.set_axisbelow(True)

    # Shared legend
    legend_elements = (
        [mpatches.Patch(fc=c, label=k) for k, c in zip(key_pos, colors_pos)]
        + [mpatches.Patch(fc=c, label=k, alpha=0.85) for k, c in zip(key_neg, colors_neg)]
        + [Line2D([0], [0], marker="D", color="w", markerfacecolor="#212121",
                  ms=6, label="Net impact")]
    )
    fig.legend(handles=legend_elements, loc="lower center", ncol=6,
               fontsize=8.5, bbox_to_anchor=(0.5, -0.03), framealpha=0.9)

    fig.suptitle(
        "Percentage Environmental Impact by Life Cycle Stage -- TRACI 2.1\n"
        "(bars = % of gross positive impact; credits shown below zero; "
        "diamond = net %)",
        fontsize=11, y=1.01,
    )
    fig.tight_layout(rect=[0, 0.05, 1, 1])
    fig.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.show()
    plt.close(fig)
    print(f"  Saved -> {out_path}")


# ══════════════════════════════════════════════════════════════════════════════
# 12. Plot 8 — Normalized Impact Stacked Bar (all TRACI categories)
# ══════════════════════════════════════════════════════════════════════════════
def plot_normalized_stack(all_results, all_contribs, out_path):
    """
    10-panel figure (2 rows x 5 cols), one panel per TRACI 2.1 category,
    stacked by contributor on a normalized scale.

    Global warming is normalized to the fossil Jet-A GWP benchmark
    (FOSSIL_JET_G_PER_MJ, a real literature value) -- bars show each
    scenario's contributor breakdown as a fraction of the fossil impact.

    The other 9 categories have no real fossil-jet TRACI benchmark available
    (the OpenLCA library only has a bio-based Jet-A surrogate, not conventional
    fossil kerosene), so they fall back to the same convention as
    plot_traci_heatmap(): normalized by the max absolute NET value across the
    6 scenarios. The two normalization bases are visually and textually
    distinguished so they aren't mistaken for the same thing.
    """
    contrib_order = [
        "H₂ production", "Process heat (NG)", "Purchased SPK", "Fossil C combustion",
        "WCO treatment credit", "Char credit",
    ]

    fig, axes = plt.subplots(2, 5, figsize=(18, 8.5), sharey=False)
    axes_flat = axes.flatten()

    for idx, cat in enumerate(CATEGORIES):
        ax = axes_flat[idx]
        x = np.arange(len(LABEL_ORDER))

        if cat == "Global warming":
            norm = FOSSIL_JET_G_PER_MJ
            ylabel = "Fraction of fossil Jet-A"
            fossil_normalized = True
        else:
            net_vals = np.array([all_results[lbl][cat] for lbl in LABEL_ORDER])
            norm = np.max(np.abs(net_vals))
            if norm == 0:
                norm = 1.0
            ylabel = "Fraction of max |scenario|"
            fossil_normalized = False

        bottoms_pos = np.zeros(len(LABEL_ORDER))
        bottoms_neg = np.zeros(len(LABEL_ORDER))
        for contrib in contrib_order:
            vals = np.array([
                all_contribs[lbl][cat].get(contrib, 0.0) for lbl in LABEL_ORDER
            ]) / norm
            pos = np.where(vals > 0, vals, 0.0)
            neg = np.where(vals < 0, vals, 0.0)
            ax.bar(x, pos, bottom=bottoms_pos, width=0.6, color=CONTRIB_COLORS[contrib],
                   edgecolor="white", linewidth=0.35,
                   label=contrib if idx == 0 else "_nolegend_")
            ax.bar(x, neg, bottom=bottoms_neg, width=0.6, color=CONTRIB_COLORS[contrib],
                   edgecolor="white", linewidth=0.35)
            bottoms_pos += pos
            bottoms_neg += neg

        net_norm = np.array([
            sum(all_contribs[lbl][cat].values()) for lbl in LABEL_ORDER
        ]) / norm
        ax.plot(x, net_norm, "D", color="#212121", ms=5, zorder=5,
                label="Net (normalized)" if idx == 0 else "_nolegend_")
        for xi, v in enumerate(net_norm):
            ax.text(xi, v + (0.03 if v >= 0 else -0.03), f"{v:.2f}",
                    ha="center", va="bottom" if v >= 0 else "top",
                    fontsize=5.8, color="#212121", fontweight="bold")

        if fossil_normalized:
            ax.axhline(1.0, color="#B71C1C", lw=1.3, ls="--",
                       label="Fossil Jet-A" if idx == 0 else "_nolegend_")

        ax.axhline(0, color="black", lw=0.7)
        ax.set_xticks(x)
        ax.set_xticklabels(
            ["S1\nSMR", "S1\nSOEC", "S1\nPh", "S2\nSMR", "S2\nSOEC", "S2\nPh"],
            fontsize=7.5)
        basis_tag = "fossil-normalized" if fossil_normalized else "max-normalized"
        ax.set_title(f"{CAT_SHORT[cat]}\n({basis_tag})", fontsize=8.5, fontweight="bold")
        ax.set_ylabel(ylabel, fontsize=6.5, labelpad=2)
        ax.tick_params(axis="y", labelsize=7)
        ax.yaxis.grid(True, ls=":", lw=0.4, alpha=0.5)
        ax.set_axisbelow(True)

    legend_elements = (
        [mpatches.Patch(fc=CONTRIB_COLORS[c], label=c) for c in contrib_order]
        + [Line2D([0], [0], marker="D", color="w", markerfacecolor="#212121",
                  ms=6, label="Net (normalized)")]
        + [Line2D([0], [0], color="#B71C1C", lw=1.3, ls="--", label="Fossil Jet-A (GWP only)")]
    )
    fig.legend(handles=legend_elements, loc="lower center", ncol=4,
               fontsize=8.5, bbox_to_anchor=(0.5, -0.04), framealpha=0.9)

    fig.suptitle(
        "Normalized Environmental Impact by Life Cycle Stage -- TRACI 2.1\n"
        "GWP panel normalized to the fossil Jet-A benchmark; the other 9 categories are\n"
        "normalized to the max |scenario value| instead (no fossil TRACI data available for them)",
        fontsize=10.5, y=1.03,
    )
    fig.tight_layout(rect=[0, 0.06, 1, 0.95])
    fig.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.show()
    plt.close(fig)
    print(f"  Saved -> {out_path}")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("=" * 60)
    print("  Cradle-to-Gate LCA — SAF from Waste Polystyrene")
    print("=" * 60)

    all_results, all_contribs, all_inv, summary_rows, factors = run_lca()

    print("\nSaving CSVs …")
    save_csvs(summary_rows, all_contribs)

    print("\nGenerating plots …")
    plots = {
        "lca_ghg.pdf":           lambda: plot_ghg_bar(all_results,
                                     os.path.join(OUT_DIR, "lca_ghg.pdf")),
        "lca_ghg_stack.pdf":     lambda: plot_ghg_stack(all_contribs,
                                     os.path.join(OUT_DIR, "lca_ghg_stack.pdf")),
        "lca_traci_heatmap.pdf": lambda: plot_traci_heatmap(all_results,
                                     os.path.join(OUT_DIR, "lca_traci_heatmap.pdf")),
        "lca_radar.pdf":         lambda: plot_radar(all_results,
                                     os.path.join(OUT_DIR, "lca_radar.pdf")),
        "lca_h2_comparison.pdf": lambda: plot_h2_comparison(all_results, all_contribs,
                                     os.path.join(OUT_DIR, "lca_h2_comparison.pdf")),
        "lca_traci_bars.pdf":    lambda: plot_traci_bars(all_results,
                                     os.path.join(OUT_DIR, "lca_traci_bars.pdf")),
        "lca_percent_stack.pdf": lambda: plot_percent_stack(all_contribs,
                                     os.path.join(OUT_DIR, "lca_percent_stack.pdf")),
        "lca_normalized_stack.pdf": lambda: plot_normalized_stack(all_results, all_contribs,
                                     os.path.join(OUT_DIR, "lca_normalized_stack.pdf")),
    }

    for name, fn in plots.items():
        try:
            fn()
        except Exception as e:
            print(f"  [ERROR] {name}: {e}")

    print("\n-- SUMMARY " + "-" * 46)
    print(f"{'Scenario':<15} {'GHG (g CO2/MJ)':>20} {'vs Fossil':>12}")
    print("-" * 46)
    for row in summary_rows:
        gwp_kg = row["Global warming"]
        red    = row["GWP_reduction_vs_fossil_pct"]
        print(f"{row['scenario']:<15} {gwp_kg:>18.3f}   {red:>8.1f}%")
    print(f"\n{'Fossil Jet-A':<15} {FOSSIL_JET_G_PER_MJ:>18.3f}   {'---':>8}")
    print("=" * 60)
    print("LCA complete. Outputs saved to:")
    print(f"  Data: {DATA_DIR}")
    print(f"  Plots: {OUT_DIR}")
