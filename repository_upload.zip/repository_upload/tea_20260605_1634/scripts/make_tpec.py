"""
make_tpec.py — TPEC by process area for all 6 SAF configurations.
Data comes directly from BioSTEAM unit purchase_costs via main.py simulation.

Figure 1 (tpec_by_area.pdf):
    2-panel (Sc1 left | Sc2 right) stacked bar by the 3 main process areas.
Figure 2 (tpec_subequipment.pdf):
    Same 2-panel layout but stacked at sub-equipment level.
"""

import os, warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np
import sys as _s, os as _o
_s.path.insert(0, _o.path.dirname(_o.path.dirname(_o.path.dirname(_o.path.abspath(__file__)))))
import scenario_relabel  # R1.14: display swap Sc1<->Sc2 (set SCENARIO_RELABEL=0 to disable)
import matplotlib
# Standalone run: force Agg (fast, headless). Loaded by main.py inside an
# IPython/Jupyter session: leave the backend main.py already configured
# (inline / TkAgg) alone so plt.show() calls below actually render.
try:
    get_ipython()
except NameError:
    matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib as mpl
import matplotlib.ticker as mticker
import matplotlib.patches as mpatches

import tea_bridge as tb

DATA_DIR  = tb.DATA_DIR
PLOTS_DIR = tb.PLOTS_DIR

# ── run simulation (main.py process + tea_model.py Humbird 2011 DCFROR) ───────
# TPEC is purely an equipment-cost rollup (no financial assumptions involved),
# but the process simulation is shared with the other scripts via tea_bridge.
print("=" * 65)
print("Simulating 6 configurations (main.py process + Humbird 2011 DCFROR) ...")
print("=" * 65)
RESULTS = tb.simulate_all()

# ── scenario label mapping ─────────────────────────────────────────────────────
LABEL_ORDER = ["Sc1_SMR", "Sc1_SOEC", "Sc1_Photocatalysis",
               "Sc2_SMR", "Sc2_SOEC", "Sc2_Photocatalysis"]
KEY_MAP = {
    "Sc1_SMR":            (1, "SMR"),
    "Sc1_SOEC":           (1, "SOEC"),
    "Sc1_Photocatalysis": (1, "Photocatalysis"),
    "Sc2_SMR":            (2, "SMR"),
    "Sc2_SOEC":           (2, "SOEC"),
    "Sc2_Photocatalysis": (2, "Photocatalysis"),
}

# ── style ─────────────────────────────────────────────────────────────────────
mpl.rcParams.update({
    "font.family":    "serif",
    "font.serif":     ["DejaVu Serif", "Times New Roman", "serif"],
    "axes.labelsize": 10,
    "axes.titlesize": 10,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "figure.dpi":     150,
    "savefig.dpi":    300,
    "savefig.bbox":   "tight",
})

# ── process area mapping ───────────────────────────────────────────────────────
UNIT_TO_AREA = {
    "PSPretreatmentUnit":        "PS Pretreatment",
    "SMR_H2Unit":                "H₂ Production",
    "Photocatalysis_H2Unit":     "H₂ Production",
    "SOEC_H2Unit":               "H₂ Production",
    "Pyrolyzer":                 "Pyrolysis",
    "HydrogenationUnit":         "Hydrogenation & Upgrading",
    "SelectiveHydrogenationUnit":"Hydrogenation & Upgrading",
    "SPKBlendingUnit":           "Hydrogenation & Upgrading",
}

SUB_EQUIP_COLORS = {
    # PS Pretreatment (greys)
    "Shredder":                        "#455a64",
    "Wash / screen system":            "#78909c",
    "Dryer":                           "#b0bec5",
    # Pyrolysis (greens)
    "Pyrolyzer vessel":                "#2d6a2d",
    "Heat exchanger feed":             "#52b152",
    "Condenser":                       "#88cc88",
    "Char separator":                  "#c2e8c2",
    # H2 Production — SMR (blues)
    "SMR reactor & PSA":               "#1565c0",
    "Heat exchangers":                 "#42a5f5",
    "WGS reactor":                     "#90caf9",
    # H2 Production — Photocatalysis (purples)
    "Photocatalytic panels":           "#4a148c",
    "Water treatment":                 "#8e24aa",
    "H2 separation (PC)":              "#ce93d8",
    # H2 Production — SOEC (teals)
    "SOEC stack":                      "#004d5a",
    "Power electronics":               "#00838f",
    "H2 compression (SOEC)":          "#80cbc4",
    # Hydrogenation Sc1 (oranges)
    "Hydrogenation reactor":           "#bf360c",
    "Pd/SBA-15 catalyst":              "#f4511e",
    "Separator/distillation":          "#ff8a65",
    "Heat exchangers (HXU)":           "#ffccbc",
    # Hydrogenation Sc2 (roses)
    "Selective hydrogenation reactor": "#880e4f",
    "Pd/Al2O3 catalyst":               "#e91e63",
    "EB distillation column":          "#f8bbd0",
    # SPK blending (yellows)
    "SPK day-storage tank":            "#f9a825",
    "Blending vessel + pumps":         "#fff59d",
}

AREA_COLORS = {
    "PS Pretreatment":           "#607d8b",
    "Pyrolysis":                 "#2ca02c",
    "H₂ Production":        "#1f77b4",
    "Hydrogenation & Upgrading": "#d55e00",
}
AREA_ORDER = ["PS Pretreatment", "Pyrolysis", "H₂ Production", "Hydrogenation & Upgrading"]

H2_ORDER   = ["SMR", "SOEC", "Photocatalysis"]
SC_CONFIGS = {
    1: ["Sc1_SMR", "Sc1_SOEC", "Sc1_Photocatalysis"],
    2: ["Sc2_SMR", "Sc2_SOEC", "Sc2_Photocatalysis"],
}
SC_TITLES = {
    1: "Scenario 1 — Co-hydropyrolysis (Pd/SBA-15)",
    2: "Scenario 2 — PS-only + SPK blend (Pd/Al₂O₃)",
}
CFG_LABELS = {
    "Sc1_SMR": "SMR", "Sc1_SOEC": "SOEC", "Sc1_Photocatalysis": "Photo",
    "Sc2_SMR": "SMR", "Sc2_SOEC": "SOEC", "Sc2_Photocatalysis": "Photo",
}


# ── build DataFrame from unit purchase_costs ──────────────────────────────────
def _build_unit_df():
    rows = []
    for lbl, key in KEY_MAP.items():
        res = RESULTS.get(key)
        if res is None:
            continue
        units = [res['pretreat'], res['pyrolyzer'], res['h2_unit'], res['hydro']]
        if res.get('blender') is not None:
            units.append(res['blender'])
        for unit in units:
            unit_type = type(unit).__name__
            pc = unit.purchase_costs
            row = {
                'scenario':              lbl,
                'type':                  unit_type,
                'purchase_cost_2023_usd': sum(pc.values()),
            }
            for name, cost in pc.items():
                row[f'pc_{name}'] = cost
            rows.append(row)
    return pd.DataFrame(rows).fillna(0.0)


df = _build_unit_df()
df["process_area"] = df["type"].map(UNIT_TO_AREA)
df["cost_M"] = df["purchase_cost_2023_usd"] / 1e6

PC_COLS = [c for c in df.columns if c.startswith("pc_")]

# ── build area-level summary ───────────────────────────────────────────────────
tpec_area = (
    df.groupby(["scenario", "process_area"])["cost_M"]
    .sum()
    .unstack("process_area")
    .reindex(columns=AREA_ORDER, fill_value=0.0)
    .reset_index()
)
tpec_area.columns.name = None
tpec_area["TPEC_total_M"] = tpec_area[AREA_ORDER].sum(axis=1)
tpec_area.to_csv(os.path.join(DATA_DIR, "tpec_by_area.csv"), index=False)
print(f"\nSaved tpec_by_area.csv ({len(tpec_area)} rows)")
print(tpec_area.to_string(index=False).encode("ascii", "replace").decode("ascii"))

# ── melt sub-equipment rows ────────────────────────────────────────────────────
rows_sub = []
for _, row in df.iterrows():
    for col in PC_COLS:
        val = row[col]
        if pd.notna(val) and val > 0:
            rows_sub.append({
                "scenario": row["scenario"],
                "area":     row["process_area"],
                "sub_equip": col.replace("pc_", ""),
                "cost_M":   val / 1e6,
            })
df_sub = pd.DataFrame(rows_sub)


# ════════════════════════════════════════════════════════════════════════════
# Helper: draw one stacked bar panel
# ════════════════════════════════════════════════════════════════════════════
def draw_bar_panel(ax, sc, data_dict, color_dict, segment_order, label_threshold=0.5):
    cfgs  = SC_CONFIGS[sc]
    x     = np.arange(len(cfgs))
    bar_w = 0.55
    bottoms = np.zeros(len(cfgs))
    handles = []
    for seg in segment_order:
        vals = np.array([data_dict[c].get(seg, 0.0) for c in cfgs])
        if vals.sum() == 0:
            continue
        col  = color_dict.get(seg, "#aaaaaa")
        ax.bar(x, vals, bottom=bottoms, width=bar_w,
               color=col, edgecolor="white", linewidth=0.5, zorder=3)
        handles.append(mpatches.Patch(color=col, label=seg))
        for xi, (v, b) in enumerate(zip(vals, bottoms)):
            if v >= label_threshold:
                ax.text(xi, b + v / 2, f"${v:.1f}M",
                        ha="center", va="center",
                        fontsize=6.5, color="white", fontweight="bold", zorder=5)
        bottoms += vals

    for xi, tot in enumerate(bottoms):
        ax.text(xi, tot + tot * 0.015, f"${tot:.1f}M",
                ha="center", va="bottom", fontsize=8, fontweight="bold")

    ax.set_xticks(x)
    ax.set_xticklabels([CFG_LABELS[c] for c in cfgs], fontsize=10)
    ax.set_ylabel("TPEC (M$, 2023 USD)", fontsize=9.5)
    ax.set_title(SC_TITLES[sc], fontsize=9.5, fontweight="bold")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"${v:,.0f}M"))
    ax.set_xlim(-0.5, len(cfgs) - 0.5)
    ax.set_ylim(0, bottoms.max() * 1.12)
    ax.grid(axis="y", linewidth=0.35, alpha=0.45, linestyle="--", zorder=1)
    for sp in ax.spines.values():
        sp.set_linewidth(0.7)
    return handles


# ════════════════════════════════════════════════════════════════════════════
# Figure 1: TPEC by process area
# ════════════════════════════════════════════════════════════════════════════
print("\n[Figure 1] TPEC by process area ...")

def build_area_data(sc):
    cfgs = SC_CONFIGS[sc]
    data = {}
    for cfg in cfgs:
        sub = df[df["scenario"] == cfg]
        data[cfg] = {area: float(sub[sub["process_area"] == area]["cost_M"].sum())
                     for area in AREA_ORDER}
    return data

fig1, axes1 = plt.subplots(1, 2, figsize=(14, 7))
fig1.suptitle(
    "Total Purchased Equipment Cost (TPEC) by Process Area\n"
    "All 6 SAF Configurations — 2023 USD (CEPCI 797.9)",
    fontsize=12, fontweight="bold"
)

all_handles = []
for ax, sc in zip(axes1, [1, 2]):
    area_data = build_area_data(sc)
    h = draw_bar_panel(ax, sc, area_data, AREA_COLORS, AREA_ORDER, label_threshold=0.3)
    all_handles = h

fig1.legend(handles=all_handles, title="Process Area",
            loc="lower center", ncol=3, fontsize=9,
            bbox_to_anchor=(0.5, -0.03), framealpha=0.92, edgecolor="gray",
            title_fontsize=9.5)
fig1.tight_layout(rect=[0, 0.06, 1, 0.95])
out1 = os.path.join(PLOTS_DIR, "tpec_by_area.pdf")
fig1.savefig(out1)
plt.show()
plt.close(fig1)
print(f"  -> Saved: {out1}")


# ════════════════════════════════════════════════════════════════════════════
# Figure 2: TPEC sub-equipment detail
# ════════════════════════════════════════════════════════════════════════════
print("[Figure 2] TPEC sub-equipment detail ...")

SUB_ORDER_SC1 = [
    "Pyrolyzer vessel", "Condenser", "Heat exchanger feed", "Char separator",
    "SMR reactor & PSA", "Heat exchangers", "WGS reactor",
    "Photocatalytic panels", "Water treatment", "H2 separation (PC)",
    "SOEC stack", "Power electronics", "H2 compression (SOEC)",
    "Hydrogenation reactor", "Separator/distillation",
    "Pd/SBA-15 catalyst", "Heat exchangers (HXU)",
]
SUB_ORDER_SC2 = [
    "Pyrolyzer vessel", "Condenser", "Heat exchanger feed", "Char separator",
    "SMR reactor & PSA", "Heat exchangers", "WGS reactor",
    "Photocatalytic panels", "Water treatment", "H2 separation (PC)",
    "SOEC stack", "Power electronics", "H2 compression (SOEC)",
    "Selective hydrogenation reactor", "EB distillation column",
    "Pd/Al2O3 catalyst",
    "SPK day-storage tank", "Blending vessel + pumps",
]


def build_sub_data(sc, sub_order):
    cfgs = SC_CONFIGS[sc]
    data = {}
    for cfg in cfgs:
        sub = df_sub[df_sub["scenario"] == cfg]
        kv  = sub.set_index("sub_equip")["cost_M"].to_dict()
        data[cfg] = {s: kv.get(s, 0.0) for s in sub_order}
    return data


fig2, axes2 = plt.subplots(1, 2, figsize=(16, 8))
fig2.suptitle(
    "Total Purchased Equipment Cost (TPEC) — Sub-Equipment Breakdown\n"
    "All 6 SAF Configurations — 2023 USD (CEPCI 797.9)",
    fontsize=12, fontweight="bold"
)

all_handles2 = {}
for ax, sc, sub_ord in zip(axes2, [1, 2], [SUB_ORDER_SC1, SUB_ORDER_SC2]):
    sub_data = build_sub_data(sc, sub_ord)
    h = draw_bar_panel(ax, sc, sub_data, SUB_EQUIP_COLORS, sub_ord, label_threshold=0.5)
    for p in h:
        all_handles2[p.get_label()] = p

# Area divider lines
AREA_BREAK = {
    "SMR reactor & PSA":              True,
    "Photocatalytic panels":          True,
    "SOEC stack":                     True,
    "Hydrogenation reactor":          True,
    "Selective hydrogenation reactor":True,
}

def add_area_dividers(ax, sc, sub_ord):
    cfgs = SC_CONFIGS[sc]
    bar_w = 0.55
    for cfg_i, cfg in enumerate(cfgs):
        sub = df_sub[df_sub["scenario"] == cfg]
        kv  = sub.set_index("sub_equip")["cost_M"].to_dict()
        cum = 0.0
        for seg in sub_ord:
            v = kv.get(seg, 0.0)
            if seg in AREA_BREAK and cum > 0:
                ax.plot([cfg_i - bar_w/2, cfg_i + bar_w/2], [cum, cum],
                        color="black", linewidth=1.5, zorder=6)
            cum += v

for ax, sc, sub_ord in zip(axes2, [1, 2], [SUB_ORDER_SC1, SUB_ORDER_SC2]):
    add_area_dividers(ax, sc, sub_ord)

# Grouped legend
def area_title_proxy(label):
    return mpatches.Patch(color="none", label=f"── {label} ──")

final_handles = []
final_handles.append(area_title_proxy("Pyrolysis"))
for k in ["Pyrolyzer vessel", "Condenser", "Heat exchanger feed", "Char separator"]:
    if k in all_handles2:
        final_handles.append(all_handles2[k])

final_handles.append(area_title_proxy("H₂ Production — SMR"))
for k in ["SMR reactor & PSA", "Heat exchangers", "WGS reactor"]:
    if k in all_handles2:
        final_handles.append(all_handles2[k])

final_handles.append(area_title_proxy("H₂ Production — Photocatalysis"))
for k in ["Photocatalytic panels", "Water treatment", "H2 separation (PC)"]:
    if k in all_handles2:
        final_handles.append(all_handles2[k])

final_handles.append(area_title_proxy("H₂ Production — SOEC"))
for k in ["SOEC stack", "Power electronics", "H2 compression (SOEC)"]:
    if k in all_handles2:
        final_handles.append(all_handles2[k])

final_handles.append(area_title_proxy("Hydrogenation & Upgrading — Sc1"))
for k in ["Hydrogenation reactor", "Separator/distillation",
          "Pd/SBA-15 catalyst", "Heat exchangers (HXU)"]:
    if k in all_handles2:
        final_handles.append(all_handles2[k])

final_handles.append(area_title_proxy("Hydrogenation & Upgrading — Sc2"))
for k in ["Selective hydrogenation reactor", "EB distillation column",
          "Pd/Al2O3 catalyst", "SPK day-storage tank", "Blending vessel + pumps"]:
    if k in all_handles2:
        final_handles.append(all_handles2[k])

fig2.legend(handles=final_handles,
            loc="lower center", ncol=4, fontsize=7.5,
            bbox_to_anchor=(0.5, -0.01), framealpha=0.92, edgecolor="gray")

fig2.tight_layout(rect=[0, 0.17, 1, 0.95])
out2 = os.path.join(PLOTS_DIR, "tpec_subequipment.pdf")
fig2.savefig(out2)
plt.show()
plt.close(fig2)
print(f"  -> Saved: {out2}")

print("\nAll TPEC plots complete.")
