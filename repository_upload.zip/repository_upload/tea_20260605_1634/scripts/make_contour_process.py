"""
make_contour_process.py
=======================
Contour plots of MFSP vs. true process operating conditions.
Process engineering sourced from main.py's BioSTEAM simulation; all financial
math (Peters/Timmerhaus/West capital, 60/40 debt/equity, MACRS7, 35% tax) comes
from tea_model.py's NREL DCFROR engine via tea_bridge.py — same engine as
make_plots.py / make_npv.py / etc.

Figure 1 (2x3) — Pyrolysis Temperature x Residence Time, all 6 configurations
Figure 2 (1x3) — Co-pyrolysis PS:Oil Ratio x Temperature, Scenario 1 only
Figure 3 (1x3) — SPK Blend Fraction x Pyrolysis Temperature, Scenario 2 only

Temperature-yield correlations are physics-informed empirical models calibrated to
the base-case values (Sc1: 86 wt% liquid at 480 degC / 45 min;
Sc2: 90 wt% at 550 degC / 30 min).
"""

import os, warnings
warnings.filterwarnings("ignore")

import numpy as np
import sys as _s, os as _o
_s.path.insert(0, _o.path.dirname(_o.path.dirname(_o.path.dirname(_o.path.abspath(__file__)))))
import scenario_relabel  # R1.14: display swap Sc1<->Sc2 (set SCENARIO_RELABEL=0 to disable)
import matplotlib
# Standalone run: force Agg (fast, headless). Loaded by main.py inside an
# IPython/Jupyter session: leave the backend main.py already configured
# (inline / TkAgg) alone so plt.show() calls below actually render.
try:
    get_ipython()
except NameError:
    matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.colors import TwoSlopeNorm

import tea_bridge as tb
import tea_model as tm

PLOTS_DIR = tb.PLOTS_DIR

# ── matplotlib style ─────────────────────────────────────────────────────────
mpl.rcParams.update({
    "font.family":   "serif",
    "font.serif":    ["DejaVu Serif", "Times New Roman", "serif"],
    "axes.labelsize": 10, "axes.titlesize": 10,
    "xtick.labelsize": 8, "ytick.labelsize": 8,
    "figure.dpi": 150, "savefig.dpi": 300, "savefig.bbox": "tight",
})

# $/kg SAF fossil-jet reference, on Sc1 SAF LHV basis (fossil jet ~$3.10/GGE)
FOSSIL_JET_KG = 3.10 / tm.to_gge(1.0, 1)

PANEL_META = {
    (1, "SMR"):            {"label": "Sc1 + SMR",            "color": "#0072B2"},
    (1, "SOEC"):           {"label": "Sc1 + SOEC",           "color": "#56B4E9"},
    (1, "Photocatalysis"): {"label": "Sc1 + Photocatalysis", "color": "#009E73"},
    (2, "SMR"):            {"label": "Sc2 + SMR",            "color": "#D55E00"},
    (2, "SOEC"):           {"label": "Sc2 + SOEC",           "color": "#CC79A7"},
    (2, "Photocatalysis"): {"label": "Sc2 + Photocatalysis", "color": "#E69F00"},
}
PANEL_ORDER = [
    (1, "SMR"), (1, "SOEC"), (1, "Photocatalysis"),
    (2, "SMR"), (2, "SOEC"), (2, "Photocatalysis"),
]

# ── Scenario-specific process parameters ─────────────────────────────────────
# Sc1: co-hydropyrolysis at 480 degC, 0.15 MPa H2, ~45 min residence, 86 wt% liquid
# Sc2: PS-only pyrolysis at 550 degC, atmospheric, ~30 min residence, 90 wt% liquid
SC_PARAMS = {
    1: {"T_opt": 480, "T_width": 100, "tau_base": 45,
        "tau_char": 12, "k_crack": 0.005, "yield_base": 0.86},
    2: {"T_opt": 550, "T_width": 110, "tau_base": 30,
        "tau_char": 15, "k_crack": 0.006, "yield_base": 0.90},
}
# Pure-component pyrolysis liquid yields (for co-pyrolysis ratio model)
YIELD_PS_PURE  = 0.80   # PS-only liquid yield (wt%)
YIELD_OIL_PURE = 0.95   # waste-oil liquid yield (wt%)
CHAR_PS_FRAC   = 0.06   # char yield from PS fraction
CHAR_OIL_FRAC  = 0.02   # char yield from oil fraction

# ── simulate base cases (main.py process + tea_model.py NREL DCFROR) ──────────
print("=" * 65)
print("Simulating 6 configurations (main.py process + Humbird 2011 DCFROR) ...")
print("=" * 65)
RESULTS = tb.simulate_all()
for k in PANEL_ORDER:
    r = RESULTS.get(k)
    if r:
        print(f"  Sc{k[0]}_{k[1]}: MFSP = ${r['mfsp_per_kg']:.2f}/kg SAF")


# ════════════════════════════════════════════════════════════════════════════
# Yield correlations (physics-informed empirical models, unchanged)
# ════════════════════════════════════════════════════════════════════════════

def _yield_ratio_T_tau(T, tau, sc):
    """
    Returns liquid_yield / yield_base for the given scenario.
    Gaussian temperature effect x first-order conversion with secondary cracking.
    Normalized so that (T_opt, tau_base) -> 1.0 exactly.
    """
    p = SC_PARAMS[sc]
    f_T    = np.exp(-0.5 * ((T - p["T_opt"]) / p["T_width"]) ** 2)
    f_tau  = (1 - np.exp(-tau           / p["tau_char"])) * np.exp(-p["k_crack"] * tau)
    f_tau0 = (1 - np.exp(-p["tau_base"] / p["tau_char"])) * np.exp(-p["k_crack"] * p["tau_base"])
    return (f_T) * (f_tau / f_tau0)


def _yield_ratio_T_only(T, sc):
    """Yield multiplier from temperature alone (at base residence time)."""
    p = SC_PARAMS[sc]
    return float(np.exp(-0.5 * ((T - p["T_opt"]) / p["T_width"]) ** 2))


# ── DCFROR MFSP helper (Humbird 2011 cash-flow structure via tea_model) ──────

def _mfsp_from_flows(FCI, WC, utility_hr, feedstock_hr, product_kg_hr, byproduct_hr):
    """MFSP ($/kg) via tea_model's DCFROR solver, given hourly flow rates and
    a fixed capital base (FCI/WC unchanged from the base-case simulation —
    these process-condition sweeps vary yield/feedstock/utility, not equipment
    sizing)."""
    VOC_annual = (utility_hr + feedstock_hr) * tm.OPERATING_HR
    FOC_annual = tm.fixed_operating_cost(FCI)
    byproduct_annual = byproduct_hr * tm.OPERATING_HR
    product_kg_yr    = product_kg_hr * tm.OPERATING_HR
    return tm.dcfror_mfsp(FCI, WC, VOC_annual, FOC_annual, product_kg_yr, byproduct_annual)


def _msp_yield_mult(key, mult):
    """MFSP ($/kg SAF) when saf_out_kg_hr is scaled by mult (all else fixed)."""
    res    = RESULTS[key]
    saf_hr = res['saf_out_kg_hr'] * mult
    return _mfsp_from_flows(res['FCI'], res['WC'], res['utility_cost_hr'],
                            res['feedstock_cost_hr'], saf_hr, res['byproduct_revenue_hr'])


# ════════════════════════════════════════════════════════════════════════════
# MFSP helper: co-pyrolysis PS:oil ratio + temperature (Scenario 1)
# ════════════════════════════════════════════════════════════════════════════

def mfsp_copyo(sc, h2, res, ps_frac, T):
    """
    Sc1 MFSP ($/kg SAF) at a given PS mass fraction (ps_frac) and temperature (T).

    ps_frac: fraction of total feed that is PS (base = 0.60)
    T      : pyrolysis temperature (degC)
    """
    ps_kg_hr     = res['ps_kg_hr']       # clean PS reaching the pyrolyzer (physical basis)
    raw_ps_kg_hr = res['raw_ps_kg_hr']   # raw PS purchased (pricing basis; pretreatment
                                          # recovery is held fixed across this sweep)
    oil_kg_hr_b = ps_kg_hr * tm.OIL_TO_PS_RATIO   # R1: base oil:PS = 2.5 (Li et al. 2025)

    oil_kg_hr_new  = ps_kg_hr * (1.0 - ps_frac) / ps_frac
    total_feed_new = ps_kg_hr + oil_kg_hr_new

    # Weighted liquid yield adjusted for temperature
    T_ratio       = _yield_ratio_T_only(T, sc)
    liq_frac_new  = min(0.97, (YIELD_PS_PURE * ps_frac + YIELD_OIL_PURE * (1.0 - ps_frac)) * T_ratio)
    liq_kg_hr_new = total_feed_new * liq_frac_new

    # H2 demand scales with liquid mass at the base-case H2/liquid ratio (derived from
    # res['H2_demand'], which now comes from HydrogenationUnit's own per-species
    # stoichiometry rather than a flat heuristic — see tea_model.py/main.py H2_demand fix).
    liq_kg_hr_base = (ps_kg_hr + oil_kg_hr_b) * tm.SCENARIO1_LIQUID_FRACTION
    h2_per_liq_base = res['H2_demand'] / max(liq_kg_hr_base, 1e-6)
    H2_demand_new  = liq_kg_hr_new * h2_per_liq_base
    H2_ratio       = H2_demand_new / max(res['H2_demand'], 1e-6)

    # Char: weighted by PS/oil fractions
    char_frac_new  = max(0.005, CHAR_PS_FRAC * ps_frac + CHAR_OIL_FRAC * (1.0 - ps_frac))
    char_kg_hr_new = total_feed_new * char_frac_new
    byproduct_hr_new = char_kg_hr_new * tm.CHAR_PRICE_KG

    # Feedstock cost: PS + oil + H2 source (scale H2 cost by H2 ratio).
    # PS is priced on the raw (purchased) mass, not the clean mass reaching
    # the reactor -- matches tea_bridge.py's feedstock_cost_hr convention.
    ps_oil_cost_base = raw_ps_kg_hr * tm.PS_PRICE_KG + oil_kg_hr_b  * tm.OIL_PRICE_KG
    ps_oil_cost_new  = raw_ps_kg_hr * tm.PS_PRICE_KG + oil_kg_hr_new * tm.OIL_PRICE_KG

    if h2 == "SMR":
        h2_feed_cost_base = res['feedstock_cost_hr'] - ps_oil_cost_base
        feedstock_hr_new  = ps_oil_cost_new + h2_feed_cost_base * H2_ratio
        utility_hr_new    = res['utility_cost_hr']
    else:
        feedstock_hr_new  = ps_oil_cost_new
        utility_hr_new    = res['utility_cost_hr'] * H2_ratio

    return _mfsp_from_flows(res['FCI'], res['WC'], utility_hr_new, feedstock_hr_new,
                            liq_kg_hr_new, byproduct_hr_new)


# ════════════════════════════════════════════════════════════════════════════
# MFSP helper: SPK blend fraction + temperature (Scenario 2)
# ════════════════════════════════════════════════════════════════════════════

def mfsp_spk_blend(sc, h2, res, spk_frac, T):
    """
    Sc2 MFSP ($/kg SAF) at a given SPK blend fraction and pyrolysis temperature (T).

    spk_frac: fraction of product that is HEFA-SPK by mass (base = 0.50)
    T       : pyrolysis temperature (degC)
    """
    # EB-rich oil production: base blend is oil + SPK at 50:50 -> oil_base = blend/2
    eb_kg_hr_base = res['saf_out_kg_hr'] / 2.0

    T_ratio      = _yield_ratio_T_only(T, sc)
    eb_kg_hr_new = eb_kg_hr_base * T_ratio

    spk_frac = float(np.clip(spk_frac, 0.05, 0.95))
    spk_kg_hr_new = eb_kg_hr_new * spk_frac / (1.0 - spk_frac)
    product_kg_hr = eb_kg_hr_new + spk_kg_hr_new

    # Feedstock: adjust SPK purchase, scale remainder with T_ratio
    spk_cost_base     = (res['saf_out_kg_hr'] / 2.0) * tm.SPK_PRICE_KG
    non_spk_feed_base = res['feedstock_cost_hr'] - spk_cost_base
    feedstock_hr_new  = non_spk_feed_base * T_ratio + spk_kg_hr_new * tm.SPK_PRICE_KG

    utility_hr_new   = res['utility_cost_hr'] * T_ratio
    byproduct_hr_new = res['byproduct_revenue_hr'] * T_ratio

    return _mfsp_from_flows(res['FCI'], res['WC'], utility_hr_new, feedstock_hr_new,
                            product_kg_hr, byproduct_hr_new)


# ════════════════════════════════════════════════════════════════════════════
# Plot helper
# ════════════════════════════════════════════════════════════════════════════

def _draw_panel(ax, X, Y, Z, meta, base_mfsp, x_base, y_base,
                x_label, y_label, show_fossil=True):
    vmin, vmax = float(Z.min()), float(Z.max())

    if show_fossil and vmin < FOSSIL_JET_KG < vmax:
        norm = TwoSlopeNorm(vmin=vmin, vcenter=FOSSIL_JET_KG, vmax=vmax)
    else:
        norm = mpl.colors.Normalize(vmin=vmin, vmax=vmax)

    cf = ax.contourf(X, Y, Z, levels=25, cmap="RdYlGn_r", norm=norm, alpha=0.92)
    cbar = plt.colorbar(cf, ax=ax, shrink=0.88, pad=0.02)
    cbar.set_label("MFSP ($/kg SAF)", fontsize=8)
    cbar.ax.tick_params(labelsize=7)

    n_lines = max(6, min(12, int((vmax - vmin) / 0.25)))
    cs = ax.contour(X, Y, Z, levels=n_lines,
                    colors="black", linewidths=0.35, alpha=0.45)
    ax.clabel(cs, fmt="$%.2f", fontsize=6.0, inline=True, inline_spacing=2)

    if show_fossil and vmin < FOSSIL_JET_KG < vmax:
        cs_f = ax.contour(X, Y, Z, levels=[FOSSIL_JET_KG],
                          colors=["navy"], linewidths=2.0)
        ax.clabel(cs_f, fmt=f"Fossil ${FOSSIL_JET_KG:.2f}", fontsize=7, inline=True)

    ax.plot(x_base, y_base, "*", color="white", markersize=13,
            markeredgecolor="black", markeredgewidth=0.8, zorder=10,
            label=f"Base: ${base_mfsp:.2f}/kg SAF")
    ax.axvline(x_base, color="white", linestyle="--", linewidth=0.8, alpha=0.5, zorder=9)
    ax.axhline(y_base, color="white", linestyle="--", linewidth=0.8, alpha=0.5, zorder=9)

    ax.set_xlabel(x_label, fontsize=9)
    ax.set_ylabel(y_label, fontsize=9)
    ax.set_title(meta["label"], fontsize=10, fontweight="bold", color=meta["color"])
    ax.legend(loc="lower right", fontsize=7.5, framealpha=0.85, edgecolor="gray")
    for sp in ax.spines.values():
        sp.set_linewidth(0.7)


# ════════════════════════════════════════════════════════════════════════════
# Figure 1: Temperature × Residence Time → MFSP (2×3, all 6 configs)
# ════════════════════════════════════════════════════════════════════════════
print("\n[Figure 1] Temperature x Residence Time (all 6 configs)")

T_sc1    = np.linspace(380, 600, 35)
T_sc2    = np.linspace(400, 650, 35)
tau_vals = np.linspace(10, 90, 28)

fig1, axes1 = plt.subplots(2, 3, figsize=(16, 10))
fig1.suptitle(
    "MFSP Contour: Pyrolysis Temperature x Residence Time\n"
    f"All 6 Configurations — 2023 USD (CEPCI 797.9)  |"
    f"  * = base case  |  Navy = fossil jet (${FOSSIL_JET_KG:.2f}/kg SAF)",
    fontsize=12, fontweight="bold",
)

for ax, key in zip(axes1.flat, PANEL_ORDER):
    sc, h2 = key
    meta   = PANEL_META[key]
    res    = RESULTS.get(key)
    p      = SC_PARAMS[sc]
    T_arr  = T_sc1 if sc == 1 else T_sc2

    if res is None:
        ax.text(0.5, 0.5, "No data", ha="center", va="center", transform=ax.transAxes)
        continue

    print(f"  Sc{sc}_{h2} ({len(T_arr)}x{len(tau_vals)}) ...", end=" ", flush=True)
    Z = np.array([
        [_msp_yield_mult(key, _yield_ratio_T_tau(T, tau, sc))
         for T in T_arr]
        for tau in tau_vals
    ])
    print(f"${Z.min():.2f}-${Z.max():.2f}/kg SAF")

    _draw_panel(
        ax, T_arr, tau_vals, Z, meta,
        base_mfsp = res['mfsp_per_kg'],
        x_base    = p["T_opt"],
        y_base    = p["tau_base"],
        x_label   = f"Pyrolysis temperature (degC)  [base = {p['T_opt']} degC]",
        y_label   = f"Residence time (min)  [base = {p['tau_base']} min]",
    )

fig1.tight_layout(rect=[0, 0, 1, 0.94])
out1 = os.path.join(PLOTS_DIR, "contour_T_vs_tau.pdf")
fig1.savefig(out1)
plt.show()
plt.close(fig1)
print(f"  -> Saved: {out1}\n")


# ════════════════════════════════════════════════════════════════════════════
# Figure 2: Co-pyrolysis PS:Oil Ratio × Temperature (1×3, Scenario 1)
# ════════════════════════════════════════════════════════════════════════════
print("[Figure 2] Co-pyrolysis PS fraction x Temperature (Scenario 1)")

ps_fracs = np.linspace(0.15, 0.85, 36)   # R1: widened so the oil-rich base (PS fraction 0.29) is inside the axis
T_sc1_2  = np.linspace(380, 600, 28)

fig2, axes2 = plt.subplots(1, 3, figsize=(16, 5.5))
fig2.suptitle(
    "MFSP Contour (Scenario 1): Co-Pyrolysis PS:Oil Feed Ratio x Pyrolysis Temperature\n"
    f"PS base = 60 wt% of total feed (PS:oil = 60:40)  |  * = base case  |"
    f"  Navy = fossil jet (${FOSSIL_JET_KG:.2f}/kg SAF)",
    fontsize=11, fontweight="bold",
)

SC1_ORDER = [(1, "SMR"), (1, "SOEC"), (1, "Photocatalysis")]
for ax, key in zip(axes2, SC1_ORDER):
    sc, h2 = key
    meta   = PANEL_META[key]
    res    = RESULTS.get(key)

    if res is None:
        ax.text(0.5, 0.5, "No data", ha="center", va="center", transform=ax.transAxes)
        continue

    print(f"  Sc{sc}_{h2} ({len(ps_fracs)}x{len(T_sc1_2)}) ...", end=" ", flush=True)
    Z = np.array([
        [mfsp_copyo(sc, h2, res, ps_f, T)
         for ps_f in ps_fracs]
        for T in T_sc1_2
    ])
    print(f"${Z.min():.2f}-${Z.max():.2f}/kg SAF")

    _draw_panel(
        ax, ps_fracs, T_sc1_2, Z, meta,
        base_mfsp = res['mfsp_per_kg'],
        x_base    = 1.0 / (1.0 + tm.OIL_TO_PS_RATIO),
        y_base    = 480.0,
        x_label   = f"PS mass fraction in feed  [base = {1.0/(1.0+tm.OIL_TO_PS_RATIO):.2f} (oil:PS = {tm.OIL_TO_PS_RATIO:g})]",
        y_label   = "Pyrolysis temperature (degC)  [base = 480 degC]",
    )
    ax2 = ax.twiny()
    ax2.set_xlim(ax.get_xlim())
    ratio_ticks = np.array([0.40, 0.50, 0.60, 0.70, 0.80, 0.85])
    ax2.set_xticks(ratio_ticks)
    ax2.set_xticklabels([f"{int(r*100)}:{int((1-r)*100)}" for r in ratio_ticks], fontsize=6.5)
    ax2.set_xlabel("PS : oil ratio", fontsize=8, labelpad=2)

fig2.tight_layout(rect=[0, 0, 1, 0.90])
out2 = os.path.join(PLOTS_DIR, "contour_sc1_copyo_ratio_vs_T.pdf")
fig2.savefig(out2)
plt.show()
plt.close(fig2)
print(f"  -> Saved: {out2}\n")


# ════════════════════════════════════════════════════════════════════════════
# Figure 3: SPK Blend Fraction × Pyrolysis Temperature (1×3, Scenario 2)
# ════════════════════════════════════════════════════════════════════════════
print("[Figure 3] SPK blend fraction x Temperature (Scenario 2)")

spk_fracs = np.linspace(0.20, 0.80, 32)
T_sc2_3   = np.linspace(400, 650, 28)

fig3, axes3 = plt.subplots(1, 3, figsize=(16, 5.5))
fig3.suptitle(
    "MFSP Contour (Scenario 2): SPK Blend Fraction x Pyrolysis Temperature\n"
    f"SPK base = 0.50 (50:50 EB:HEFA-SPK blend by mass)  |  * = base case  |"
    f"  Navy = fossil jet (${FOSSIL_JET_KG:.2f}/kg SAF)",
    fontsize=11, fontweight="bold",
)

SC2_ORDER = [(2, "SMR"), (2, "SOEC"), (2, "Photocatalysis")]
for ax, key in zip(axes3, SC2_ORDER):
    sc, h2 = key
    meta   = PANEL_META[key]
    res    = RESULTS.get(key)

    if res is None:
        ax.text(0.5, 0.5, "No data", ha="center", va="center", transform=ax.transAxes)
        continue

    print(f"  Sc{sc}_{h2} ({len(spk_fracs)}x{len(T_sc2_3)}) ...", end=" ", flush=True)
    Z = np.array([
        [mfsp_spk_blend(sc, h2, res, spk_f, T)
         for spk_f in spk_fracs]
        for T in T_sc2_3
    ])
    print(f"${Z.min():.2f}-${Z.max():.2f}/kg SAF")

    _draw_panel(
        ax, spk_fracs, T_sc2_3, Z, meta,
        base_mfsp = res['mfsp_per_kg'],
        x_base    = 0.50,
        y_base    = 550.0,
        x_label   = "SPK blend fraction  [base = 0.50  (50:50 EB:HEFA-SPK)]",
        y_label   = "Pyrolysis temperature (degC)  [base = 550 degC]",
    )
    ax.axvspan(0.20, 0.49, alpha=0.06, color="navy",
               label="Higher EB fraction\n(aromatic-richer blend)")
    ax.axvspan(0.51, 0.80, alpha=0.06, color="red",
               label="Higher SPK fraction\n(costlier, lower aromatic)")

fig3.tight_layout(rect=[0, 0, 1, 0.90])
out3 = os.path.join(PLOTS_DIR, "contour_sc2_spk_blend_vs_T.pdf")
fig3.savefig(out3)
plt.show()
plt.close(fig3)
print(f"  -> Saved: {out3}\n")

print("All process-condition contour plots complete.")
print(f"  {out1}")
print(f"  {out2}")
print(f"  {out3}")
