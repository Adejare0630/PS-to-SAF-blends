"""
make_material_balance.py — Material balance stream diagram for all 6 SAF
configurations.

Process engineering (and every mass flow labeled on the diagram) comes
directly from main.py's BioSTEAM simulation via tea_bridge.py — the same
process/pricing engine used for the report, plots, and contour figures.
No numbers are hand-typed; every stream total is read from the actual
simulated Stream objects (main.py's Pyrolyzer / H2 units / Hydrogenation /
SPKBlendingUnit).

Outputs
-------
plots/material_balance_diagram.pdf   2x3 schematic PFD, one panel per config,
                                     every stream arrow labeled with its
                                     total mass flow (kg/hr).
data/material_balance_streams.csv    Full component-level material balance
                                     (long format: scenario, unit, stream,
                                     phase, component, kg/hr) backing the
                                     diagram.
data/material_balance_totals.csv     Stream totals only (one row per named
                                     stream per scenario) — the numbers shown
                                     on the diagram.
"""

import os, warnings
warnings.filterwarnings("ignore")

import pandas as pd
import sys as _s, os as _o
_s.path.insert(0, _o.path.dirname(_o.path.dirname(_o.path.dirname(_o.path.abspath(__file__)))))
import scenario_relabel  # R1.14: display swap Sc1<->Sc2 (set SCENARIO_RELABEL=0 to disable)
import matplotlib
# Standalone run: force Agg (fast, headless). Loaded by main.py inside an
# IPython/Jupyter session: leave the backend main.py already configured
# (inline / TkAgg) alone so plt.show() calls below actually render.
try:
    get_ipython()
except NameError:
    matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

import tea_bridge as tb

DATA_DIR  = tb.DATA_DIR
PLOTS_DIR = tb.PLOTS_DIR

H2_LABELS = {
    "SMR":            "SMR Unit\n(CH4+H2O->H2)",
    "Photocatalysis": "Photocatalytic\nSplitting\n(Solar, 5% STH)",
    "SOEC":           "SOEC Unit\n(H2O->H2, NGCC)",
}
H2_COLORS = {
    "SMR":            "#a29bfe",
    "Photocatalysis": "#a29bfe",
    "SOEC":           "#a29bfe",
}

STREAM_DESC = {
    's_ps_raw': 'Raw waste PS bales (pretreatment feed)',
    's_wash_water': 'Wash water (pretreatment)',
    'pretreat_reject': 'Pretreatment reject (moisture + contaminants + PS fines + wash water)',
    's_ps': 'Clean PS feed (to pyrolyzer)', 's_oil': 'Waste cooking oil feed',
    's_ch4': 'Methane feed (SMR)', 's_steam': 'Steam feed (SMR)',
    's_water_pc': 'Water feed (PC)', 's_water_se': 'Water feed (SOEC)',
    'pyro_oil': 'Pyrolysis oil', 'char': 'Char by-product', 'gas': 'Pyrolysis gas',
    'h2_out': 'Hydrogen product', 'flue': 'Flue gas / CO2 (SMR)',
    'o2_pc': 'Oxygen by-product (PC)', 'o2_soec': 'Oxygen by-product (SOEC)',
    'saf': 'SAF product (Sc1)', 'offgas': 'H2 off-gas',
    'eb_oil': 'EB-rich oil (Sc2 selective hydro. outlet)',
    's_spk': 'Purchased HEFA-SPK feed', 'eb_spk_blend': 'EB-SPK blend product (50:50)',
    'dist_bottoms': 'Distillation bottoms (empty)',
}


# ════════════════════════════════════════════════════════════════════════════
# Simulate all 6 configurations (main.py process + tea_model.py NREL DCFROR)
# ════════════════════════════════════════════════════════════════════════════
print("=" * 65)
print("Simulating 6 configurations (main.py process + Humbird 2011 DCFROR) ...")
print("=" * 65)
RESULTS = tb.simulate_all()


# ════════════════════════════════════════════════════════════════════════════
# Build the full component-level + totals material balance tables
# ════════════════════════════════════════════════════════════════════════════
def collect_streams(res):
    """Return ordered list of (stream_id, Stream) for one config, ins-then-outs
    of each unit in process order, de-duplicated, skipping near-empty streams."""
    units = [u for u in [res['pretreat'], res['pyrolyzer'], res['h2_unit'], res['hydro'], res.get('blender')]
             if u is not None]
    seen, ordered = set(), []
    for u in units:
        for s in list(u.ins) + list(u.outs):
            if s.ID not in seen and s.F_mass > 1e-6:
                seen.add(s.ID)
                ordered.append(s)
    return ordered


rows_long, rows_totals = [], []
for (sc, h2), res in RESULTS.items():
    label = f"Sc{sc}_{h2}"
    for s in collect_streams(res):
        rows_totals.append({
            "scenario": label, "stream_id": s.ID,
            "description": STREAM_DESC.get(s.ID, s.ID),
            "phase": s.phase, "total_kg_hr": round(s.F_mass, 3),
        })
        for chem in s.chemicals:
            try:
                kg_hr = s.get_flow("kg/hr", chem.ID)
            except Exception:
                kg_hr = 0.0
            if kg_hr > 1e-6:
                rows_long.append({
                    "scenario": label, "stream_id": s.ID,
                    "description": STREAM_DESC.get(s.ID, s.ID),
                    "phase": s.phase, "component": chem.ID,
                    "kg_hr": round(kg_hr, 4),
                })

df_long   = pd.DataFrame(rows_long)
df_totals = pd.DataFrame(rows_totals)
df_long.to_csv(os.path.join(DATA_DIR, "material_balance_streams.csv"), index=False)
df_totals.to_csv(os.path.join(DATA_DIR, "material_balance_totals.csv"), index=False)
print(f"\nSaved material_balance_streams.csv ({len(df_long)} rows), "
      f"material_balance_totals.csv ({len(df_totals)} rows)")


# ════════════════════════════════════════════════════════════════════════════
# Diagram helpers
# ════════════════════════════════════════════════════════════════════════════
def box(ax, x, y, w, h, label, bg="#ecf0f1", fontsize=6.3):
    rect = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.08",
                          facecolor=bg, edgecolor="#2c3e50", linewidth=1.0)
    ax.add_patch(rect)
    ax.text(x + w/2, y + h/2, label, ha="center", va="center",
            fontsize=fontsize, fontweight="bold", multialignment="center")


def arrow(ax, x1, y1, x2, y2, label="", col="#7f8c8d", label_dy=0.13):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="->", color=col, lw=1.3))
    if label:
        mx, my = (x1+x2)/2, (y1+y2)/2
        ax.text(mx, my + label_dy, label, ha="center", va="bottom",
                fontsize=5.6, color="#1a1a1a",
                bbox=dict(boxstyle="round,pad=0.12", facecolor="white",
                          edgecolor="none", alpha=0.75))


def kg(v):
    return f"{v:,.0f} kg/hr"


# ════════════════════════════════════════════════════════════════════════════
# Panel drawer — Scenario 1 (co-hydropyrolysis)
# ════════════════════════════════════════════════════════════════════════════
def draw_sc1_panel(ax, h2_src, res):
    ps  = res['pyrolyzer'].ins[0]
    oil = res['pyrolyzer'].ins[1]
    pyro_oil = res['pyrolyzer'].outs[0]
    char     = res['pyrolyzer'].outs[1]
    gas      = res['pyrolyzer'].outs[2]
    h2_out   = res['h2_unit'].outs[0]
    saf      = res['hydro'].outs[0]
    offgas   = res['hydro'].outs[1]
    raw_ps   = res['pretreat'].ins[0]
    reject   = res['pretreat'].outs[1]

    ax.set_xlim(0, 10); ax.set_ylim(0, 6); ax.axis("off")

    box(ax, 0.1, 4.05, 1.55, 0.75,
        f"Raw PS bales\n{kg(raw_ps.F_mass)}\n-> clean {kg(ps.F_mass)}",
        bg="#ffeaa7", fontsize=5.4)
    ax.text(0.875, 4.88, f"pretreat. reject: {kg(reject.F_mass)}",
            ha="center", va="bottom", fontsize=4.8, color="#c0392b", style="italic")
    box(ax, 0.1, 2.9,  1.55, 0.75, f"Waste Oil\n{kg(oil.F_mass)}", bg="#ffeaa7")
    box(ax, 2.15, 3.25, 2.05, 1.15, "Co-Hydropyrolysis\n480 C, 0.15 MPa H2", bg="#fab1a0")
    arrow(ax, 1.65, 4.42, 2.15, 3.95)
    arrow(ax, 1.65, 3.27, 2.15, 3.55)
    arrow(ax, 3.55, 3.25, 4.05, 2.55, kg(char.F_mass), col="#636e72")
    box(ax, 4.05, 2.15, 1.35, 0.65, "Char\n(by-product)", bg="#dfe6e9", fontsize=5.6)
    arrow(ax, 3.55, 4.4, 4.05, 4.9, kg(gas.F_mass), col="#636e72")
    box(ax, 4.05, 4.65, 1.35, 0.65, "Pyro. gas", bg="#dfe6e9", fontsize=5.6)

    box(ax, 2.15, 0.95, 2.05, 1.0, H2_LABELS[h2_src], bg=H2_COLORS[h2_src])
    arrow(ax, 3.4, 0.95, 5.55, 2.5, kg(h2_out.F_mass))

    box(ax, 5.55, 2.75, 2.05, 1.2, "Pd/SBA-15\nHydrogenation\n350 C", bg="#81ecec")
    arrow(ax, 4.2, 3.8, 5.55, 3.75, kg(pyro_oil.F_mass))
    arrow(ax, 7.6, 3.6, 8.2, 4.4, kg(offgas.F_mass), col="#636e72")
    box(ax, 8.2, 4.15, 1.6, 0.6, "H2 off-gas\n(recycle)", bg="#dfe6e9", fontsize=5.6)

    box(ax, 8.1, 2.55, 1.75, 0.9, f"SAF Product\n{kg(saf.F_mass)}", bg="#55efc4")
    arrow(ax, 7.6, 3.2, 8.1, 3.0)


# ════════════════════════════════════════════════════════════════════════════
# Panel drawer — Scenario 2 (PS-only + SPK blend)
# ════════════════════════════════════════════════════════════════════════════
def draw_sc2_panel(ax, h2_src, res):
    ps  = res['pyrolyzer'].ins[0]
    pyro_oil = res['pyrolyzer'].outs[0]
    char     = res['pyrolyzer'].outs[1]
    gas      = res['pyrolyzer'].outs[2]
    h2_out   = res['h2_unit'].outs[0]
    eb_oil   = res['hydro'].outs[0]
    spk      = res['blender'].ins[1]
    blend    = res['blender'].outs[0]
    raw_ps   = res['pretreat'].ins[0]
    reject   = res['pretreat'].outs[1]

    ax.set_xlim(0, 10); ax.set_ylim(0, 6); ax.axis("off")

    box(ax, 0.1, 4.05, 1.55, 0.75,
        f"Raw PS bales\n{kg(raw_ps.F_mass)}\n-> clean {kg(ps.F_mass)}",
        bg="#ffeaa7", fontsize=5.4)
    ax.text(0.875, 4.88, f"pretreat. reject: {kg(reject.F_mass)}",
            ha="center", va="bottom", fontsize=4.8, color="#c0392b", style="italic")
    box(ax, 2.15, 3.25, 2.05, 1.15, "PS Pyrolysis\n550 C, atm.", bg="#fab1a0")
    arrow(ax, 1.65, 4.42, 2.15, 3.95)
    arrow(ax, 3.55, 3.25, 4.05, 2.55, kg(char.F_mass), col="#636e72")
    box(ax, 4.05, 2.15, 1.35, 0.65, "Char\n(by-product)", bg="#dfe6e9", fontsize=5.6)
    arrow(ax, 3.55, 4.4, 4.05, 4.9, kg(gas.F_mass), col="#636e72")
    box(ax, 4.05, 4.65, 1.35, 0.65, "Pyro. gas", bg="#dfe6e9", fontsize=5.6)

    box(ax, 2.15, 0.95, 2.05, 1.0, H2_LABELS[h2_src], bg=H2_COLORS[h2_src])
    arrow(ax, 3.4, 0.95, 5.55, 2.5, kg(h2_out.F_mass))

    box(ax, 5.55, 2.75, 2.05, 1.2, "Extended\nHydrogenation\n200 C, Pd/Al2O3", bg="#81ecec")
    arrow(ax, 4.2, 3.8, 5.55, 3.75, kg(pyro_oil.F_mass))

    box(ax, 8.1, 1.35, 1.6, 0.7, f"HEFA-SPK\n(purchased)\n{kg(spk.F_mass)}", bg="#ffeaa7", fontsize=5.6)
    box(ax, 8.1, 2.75, 1.6, 1.0, "Blending\n1:1 by mass", bg="#dfe6e9", fontsize=5.6)
    arrow(ax, 7.6, 3.35, 8.1, 3.25, kg(eb_oil.F_mass))
    arrow(ax, 8.9, 2.05, 8.9, 2.75)

    box(ax, 8.1, 4.15, 1.6, 0.75, f"EB-SPK Blend\n{kg(blend.F_mass)}", bg="#55efc4", fontsize=5.6)
    arrow(ax, 8.9, 3.75, 8.9, 4.15)


# ════════════════════════════════════════════════════════════════════════════
# Assemble 2x3 figure
# ════════════════════════════════════════════════════════════════════════════
H2_ORDER = ["SMR", "Photocatalysis", "SOEC"]
fig, axes = plt.subplots(2, 3, figsize=(21, 10.5))
fig.suptitle(
    "Material Balance Stream Diagram — SAF from Waste Polystyrene\n"
    "All 6 Configurations (250 MT/day PS basis) — mass flows from main.py's "
    "BioSTEAM simulation, 2023 USD basis (CEPCI 797.9)",
    fontsize=13, fontweight="bold", y=0.995,
)

for col, h2_src in enumerate(H2_ORDER):
    res1 = RESULTS[(1, h2_src)]
    draw_sc1_panel(axes[0][col], h2_src, res1)
    axes[0][col].set_title(f"Sc1 + {h2_src}  |  MFSP ${res1['mfsp_per_kg']:.2f}/kg SAF",
                           fontsize=9.5, fontweight="bold", color="#0072B2", pad=3)

    res2 = RESULTS[(2, h2_src)]
    draw_sc2_panel(axes[1][col], h2_src, res2)
    axes[1][col].set_title(f"Sc2 + {h2_src}  |  MFSP ${res2['mfsp_per_kg']:.2f}/kg SAF",
                           fontsize=9.5, fontweight="bold", color="#D55E00", pad=3)

fig.text(0.01, 0.5, "Scenario 1 — Co-hydropyrolysis (Pd/SBA-15)", rotation=90,
          va="center", ha="left", fontsize=9, fontweight="bold", color="#0072B2")
fig.text(0.01, 0.03, "Scenario 2 — PS-only + SPK blend (Pd/Al2O3)", rotation=0,
          va="center", ha="left", fontsize=9, fontweight="bold", color="#D55E00")

fig.tight_layout(rect=[0.02, 0.03, 1, 0.95])
out = os.path.join(PLOTS_DIR, "material_balance_diagram.pdf")
fig.savefig(out)
plt.close(fig)
print(f"Saved: {out}")
