"""
tea_model.py — SAF from Waste Polystyrene: Full NREL/Humbird 2011 DCFROR TEA
=============================================================================
6 configurations: Scenario 1 (co-hydropyrolysis) × 3 H2 sources
                  Scenario 2 (PS-only + SPK blend) × 3 H2 sources

Run: python tea_model.py   (from any directory — all paths resolved internally)

Outputs: ../data/*.csv  ../plots/*.pdf  (paths relative to this script's parent)
"""

from __future__ import annotations

import os
import sys
import warnings
warnings.filterwarnings("ignore")

# ── resolve paths ─────────────────────────────────────────────────────────────
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
RUN_DIR    = os.path.dirname(SCRIPT_DIR)           # tea_20260605_1634/
MODULE_DIR = os.path.dirname(RUN_DIR)              # Module/ (source code)
DATA_DIR   = os.path.join(RUN_DIR, "data")
PLOTS_DIR  = os.path.join(RUN_DIR, "plots")

sys.path.insert(0, MODULE_DIR)

import numpy as np
import pandas as pd
import chaospy as cp
from scipy import stats
import biosteam as bst
import thermosteam as tmo

from compounds import (
    define_chemicals,
    SCENARIO1_LIQUID_FRACTION, SCENARIO2_LIQUID_FRACTION,
    SCENARIO1_PYRO_YIELDS, HYDROGENATION_CONVERSION, OIL_HDO_H2_KG_PER_KG_OIL, SC1_OIL_TO_PS_RATIO, SC1_CASE,
    SCENARIO2_PYRO_YIELDS, SELECTIVE_H2_STOICH,
    SC2_EXTENDED_HYDRO_CONVERSION, SC2_EXTENDED_H2_STOICH, sc2_h2_demand_kg_hr,
    SC2_DISTILL16, SC2_BLEND_LHV_MJ_KG, SC2_ENDS_LHV_MJ_KG, SC2_CASE, SC2_ADDITIVE_MASS_FRAC,
    PRETREAT_MOISTURE_FRAC, PRETREAT_CONTAM_FRAC, PRETREAT_PS_LOSS_FRAC,
)
from pretreatment import PSPretreatmentUnit
from pyrolyzer import Pyrolyzer
from hydrogen_production import SMR_H2Unit, Photocatalysis_H2Unit, SOEC_H2Unit
from hydrogenation import HydrogenationUnit, SelectiveHydrogenationUnit, SPKBlendingUnit

# ── global constants ──────────────────────────────────────────────────────────
CEPCI_2023       = 797.9
bst.CE           = CEPCI_2023

PS_FEED_KG_HR    = 250_000 / 24        # 250 MT/day → 10,416.67 kg/hr
# R1.4 equal-product basis: scale the PS feed of the PS-only route (physical scenario 2, blend product)
# so its product output equals the co-hydropyrolysis route (13,455 kg/h). 1.0 = equal-feed basis (as submitted).
SC2_FEED_SCALE   = float(os.environ.get("SC2_FEED_SCALE", 1.0))
# R2.1: waste-oil : clean-PS mass ratio of the co-hydropyrolysis route. Set by the case in compounds.py (env SC1_CASE):
#   Li25 (default) = 2.5, Li et al. 2025 as measured;  Extrap34 = 3.4, extrapolation (aromatics 23-25 vol%).
# Env OIL_TO_PS_RATIO overrides the ratio only (e.g. 0.6667 = submitted); keep SC1_CASE consistent with it.
OIL_TO_PS_RATIO  = float(os.environ.get("OIL_TO_PS_RATIO", SC1_OIL_TO_PS_RATIO))

# Financial (Humbird 2011 / NREL DCFROR)
IRR              = 0.10
INCOME_TAX       = float(os.environ.get("INCOME_TAX", 0.35))   # Humbird 2011 convention; current US = 21 % federal + state (~25-27 %): run INCOME_TAX=0.25 as sensitivity
PLANT_LIFE       = 30                  # years
OPERATING_DAYS   = 330                 # 90 % on-stream
OPERATING_HR     = OPERATING_DAYS * 24
FINANCE_FRAC     = 0.60               # debt fraction
FINANCE_INT      = 0.08               # loan interest rate
FINANCE_YRS      = 10                 # loan term
CONSTRUCTION_SCH = (0.08, 0.60, 0.32) # fraction of TCI spent in years -3,-2,-1

# Startup (year 1 of operation)
STARTUP_MONTHS   = 6
STARTUP_PROD_FRAC = 0.50              # 50 % of full production
STARTUP_VOC_FRAC  = 0.75             # 75 % of full variable cost
STARTUP_FOC_FRAC  = 1.00             # 100 % of full fixed cost

# ── Capital cost factors — Peters, Timmerhaus & West, "Percentage of
# Delivered Equipment Cost" method (Method C, Table 6-9), Solid-Fluid
# Processing Plant category. Humbird 2011 Table 33 (developed for
# lignocellulosic-to-ethanol biochemical plants) is not used for capital
# costing here — this is a pyrolysis/catalytic-hydrogenation SAF process,
# not biochemical ethanol production. All fractions below are of the
# DELIVERED equipment cost (DEC = TPEC x (1 + DELIVERY_FRAC)).
DELIVERY_FRAC        = 0.10   # freight/delivery, fraction of TPEC
INSTALLATION_FRAC    = 0.39   # purchased-equipment installation, installed
INSTRUMENTATION_FRAC = 0.26   # instrumentation & controls, installed
PIPING_FRAC          = 0.31   # piping, installed
ELECTRICAL_FRAC      = 0.10   # electrical systems, installed
BUILDINGS_FRAC       = 0.29   # buildings, incl. services
YARD_FRAC            = 0.12   # yard improvements
SERVICE_FRAC         = 0.55   # service facilities, installed
ENGINEERING_FRAC     = 0.32   # engineering & supervision
CONSTRUCTION_FRAC    = 0.34   # construction expenses
LEGAL_FRAC           = 0.04   # legal expenses
CONTRACTOR_FRAC      = 0.19   # contractor's fee
CONTINGENCY_FRAC     = 0.37   # contingency
WC_OVER_DEC          = 0.75   # working capital, fraction of delivered equipment cost
# derived (solid-fluid plant): direct-installed = DEC*2.02; total direct = DEC*3.02;
#           indirect = DEC*1.26; FCI = DEC*4.28 = TPEC*4.708; WC = DEC*0.75 = TPEC*0.825;
#           TCI = TPEC*5.533

# Fixed operating cost fractions (of FCI, annual)
MAINTENANCE_FRAC = 0.030
INSURANCE_TAX_FRAC = 0.007
LABOR_FRAC_OF_FCI  = 0.050   # legacy (submitted): labour = 5 % of FCI. Unphysical: labour scaled with capital.
# R1 (update 15): labour is now a FIXED headcount-based cost, the same for all six configurations (same operation,
# same throughput). Salaries + 90 % labour burden (Humbird 2011 convention). Default salaries $2.5M/yr (2023 USD)
# ~ 30 staff (operators on 5 shifts + supervision/maintenance/lab/admin) -- ASSUMPTION, replace with a cited staffing table.
# Env LABOR_MODE=fci reproduces the submitted basis.
LABOR_MODE           = os.environ.get("LABOR_MODE", "fixed")
LABOR_SALARIES_USD_YR = float(os.environ.get("LABOR_SALARIES_USD_YR", 2.5e6))
LABOR_BURDEN_FRAC     = 0.90
# R1 (update 15): precious-metal catalyst replacement. Initial charge stays in TPEC (as submitted); an annual
# replacement/refining cost = CATALYST_ANNUAL_FRAC x initial charge is added to operating cost
# (0.10/yr ~ 3-yr life with ~70 % Pd value recovered on refining -- ASSUMPTION; set 0 to reproduce submitted).
CATALYST_ANNUAL_FRAC  = float(os.environ.get("CATALYST_ANNUAL_FRAC", 0.10))


def labor_cost(FCI):
    """Annual labour + burden (USD/yr)."""
    if LABOR_MODE == "fci":
        return FCI * LABOR_FRAC_OF_FCI
    return LABOR_SALARIES_USD_YR * (1.0 + LABOR_BURDEN_FRAC)


def fixed_operating_cost(FCI):
    """Annual fixed operating cost (USD/yr): maintenance + insurance/property tax (fractions of FCI) + labour."""
    return FCI * (MAINTENANCE_FRAC + INSURANCE_TAX_FRAC) + labor_cost(FCI)


def catalyst_inventory_usd(units):
    """Sum of initial catalyst charges (purchase-cost lines whose name contains 'catalyst')."""
    return sum(v for u in units if u is not None for k, v in u.purchase_costs.items() if "catalyst" in k.lower())

# Feedstock prices
# R1: $0.60/kg kept as a conservative base (clean HIPS regrind quoted ~$0.68/kg, 2017; mixed-plastic bales 2025 were
# only ~$0.10-0.12/kg: PP 5.6 c/lb, PET 4.7 c/lb). PS-specific bale quote still needed; Monte Carlo spans $0.15-0.70/kg.
PS_PRICE_KG       = float(__import__("os").environ.get("PS_PRICE_KG", 0.60))  # USD/kg waste PS
import os as _os
# R1: $0.08/kg was far below market. Used cooking oil traded ~$0.46-0.92/kg (2023-24 trade/USDA ranges).
# Midpoint used as default; override with env var OIL_PRICE_KG; REPLACE with a cited price+year before submission.
OIL_PRICE_KG      = float(_os.environ.get("OIL_PRICE_KG", 0.70))  # USD/kg waste cooking oil
CH4_PRICE_GJ      = 4.15    # USD/GJ natural gas (EIA industrial avg 2023: $4.53/Mcf -> ~$4.15/GJ)
CH4_HHV_GJ_KG    = 0.0555  # GJ/kg methane
H2_HHV_GJ_KG      = 0.142   # GJ/kg hydrogen (142 MJ/kg HHV)
WATER_PRICE_KG    = 0.001
CHAR_PRICE_KG     = 0.15    # byproduct char credit
OXYGEN_PRICE_KG   = 0.10    # byproduct O2 credit (photocatalysis / SOEC)
# R1: $1.50/kg was below market. Consensus outright HEFA-SPK: EASA 2024-25 EUR 1,925-2,085/t (~$2.1-2.3/kg);
# IATA 2024 premium ~$1,000/t over jet (~$1.8/kg); Argus late-2025 >$2,900/t (~$2.9/kg). Base = $2.10/kg.
SPK_PRICE_KG      = float(__import__("os").environ.get("SPK_PRICE_KG", 2.10))  # purchased HEFA-SPK, USD/kg

# Utility prices
ELEC_PRICE_KWH    = 0.0804  # USD/kWh (Humbird $0.0682/kWh escalated to 2023 EIA industrial avg)
HEAT_PRICE_GJ     = 6.50    # USD/GJ steam/heat

# Product LHV conversion to $/GGE
GASOLINE_LHV_MJ_GAL = 122.5           # MJ/gal (LHV basis)
SAF_LHV_MJ_KG       = 43.2            # MJ/kg (Jet-A equivalent, Sc1)
BLEND_LHV_MJ_KG     = SC2_BLEND_LHV_MJ_KG   # MJ/kg: 16 vol% EB additive (~18 wt%) in HEFA-SPK = 43.5 (base); blend-share sensitivity overrides
SAF_DENSITY_KG_M3   = 780.0           # kg/m³

# R1: single capacity-scaling exponent for aggregate capital in sensitivity/Monte Carlo. Was 0.6 here while the
# H2 units, pretreatment, pyrolyzer vessel and hydrogenation reactors use 0.65 (unit-level exponents 0.55-0.65 are kept).
CAPACITY_SCALING_EXPONENT = 0.65

MACRS7 = [0.1429, 0.2449, 0.1749, 0.1249, 0.0893, 0.0892, 0.0893, 0.0446]

# ════════════════════════════════════════════════════════════════════════════
# Capital cost helpers (Peters, Timmerhaus & West — Solid-Fluid Processing Plant)
# ════════════════════════════════════════════════════════════════════════════

def peters_timmerhaus_capital(tpec: float) -> dict:
    """
    Compute DEC -> FCI -> TCI from total purchased equipment cost (2023 USD)
    using Peters, Timmerhaus & West's "Percentage of Delivered Equipment
    Cost" method for a solid-fluid processing plant. Handles solid PS/char
    feed plus fluid process streams (pyrolysis oil, H2, hydrogenation) —
    the appropriate category for this process, unlike Humbird 2011's
    biochemical-ethanol-specific Table 33 factors.
    """
    dec = tpec * (1 + DELIVERY_FRAC)                       # delivered equipment cost
    direct_installed = dec * (
        INSTALLATION_FRAC + INSTRUMENTATION_FRAC + PIPING_FRAC
        + ELECTRICAL_FRAC + BUILDINGS_FRAC + YARD_FRAC + SERVICE_FRAC
    )
    total_direct = dec + direct_installed                  # includes equipment itself
    indirect = dec * (
        ENGINEERING_FRAC + CONSTRUCTION_FRAC + LEGAL_FRAC
        + CONTRACTOR_FRAC + CONTINGENCY_FRAC
    )
    fci = total_direct + indirect
    wc  = dec * WC_OVER_DEC
    tci = fci + wc
    return dict(TPEC=tpec, DEC=dec, DirectInstalled=direct_installed,
                TotalDirect=total_direct, Indirect=indirect,
                FCI=fci, WC=wc, TCI=tci)


# ════════════════════════════════════════════════════════════════════════════
# DCFROR solver (Humbird 2011 — 30 yr, MACRS7, 35 % tax, 60/40 debt/equity)
# ════════════════════════════════════════════════════════════════════════════

def _loan_schedule(principal: float, rate: float, years: int) -> list[tuple]:
    """Return [(interest, principal_payment)] for each loan year."""
    pmt = principal * rate * (1+rate)**years / ((1+rate)**years - 1)
    bal = principal
    schedule = []
    for _ in range(years):
        intr = bal * rate
        prcp = pmt - intr
        schedule.append((intr, prcp))
        bal  -= prcp
    return schedule


def dcfror_mfsp(
    FCI: float, WC: float,
    VOC_annual: float,
    FOC_annual: float,
    product_kg_yr: float,
    byproduct_revenue_yr: float,
    irr: float = IRR,
    income_tax: float = INCOME_TAX,
    plant_life: int = PLANT_LIFE,
    finance_frac: float = FINANCE_FRAC,
    finance_int: float = FINANCE_INT,
    finance_yrs: int = FINANCE_YRS,
    construction_sch: tuple = CONSTRUCTION_SCH,
) -> float:
    """
    Find MFSP via Newton-Raphson on equity NPV = 0.

    Cash flow structure follows Humbird 2011 NREL DCFROR:
    - 3-year construction with spending schedule (8/60/32 % of TCI)
    - 60 % debt financed at 8 % over 10 years; 40 % equity upfront
    - Working capital borrowed at end of construction
    - MACRS 7-year depreciation; 35 % federal income tax
    - 6-month startup in year 1 at 50 % production / 75 % VOC / 100 % FOC
    """
    n_constr = len(construction_sch)
    TCI      = FCI + WC
    debt     = TCI * finance_frac
    equity   = TCI * (1 - finance_frac)

    # Loan schedule (principal + interest each operating year)
    loan_sched = _loan_schedule(debt, finance_int, finance_yrs)

    # MACRS depreciation basis = FCI  (7-yr schedule, 8-yr tax life with half-year)
    depr = [FCI * r for r in MACRS7] + [0.0] * (plant_life - len(MACRS7))

    def _npv(saf_price: float) -> float:
        # ── construction period equity cash flows ─────────────────────────
        cf = []
        for frac in construction_sch:
            cf.append(-TCI * frac * (1 - finance_frac))   # equity portion

        # ── operating years ───────────────────────────────────────────────
        for yr in range(1, plant_life + 1):
            # startup adjustment in year 1
            if yr == 1:
                prod_frac = 0.5 * (STARTUP_MONTHS/12) + 1.0 * (1 - STARTUP_MONTHS/12)
                voc_frac  = 0.75 * (STARTUP_MONTHS/12) + 1.0 * (1 - STARTUP_MONTHS/12)
            else:
                prod_frac = 1.0
                voc_frac  = 1.0

            revenue    = product_kg_yr * prod_frac * saf_price + byproduct_revenue_yr * prod_frac
            voc        = VOC_annual * voc_frac
            foc        = FOC_annual

            # debt service
            if yr <= finance_yrs:
                interest, principal = loan_sched[yr - 1]
            else:
                interest = principal = 0.0

            dep      = depr[yr - 1] if yr <= len(depr) else 0.0
            taxable  = revenue - voc - foc - dep - interest
            tax      = max(0.0, taxable * income_tax)
            net_inc  = taxable - tax
            op_cf    = net_inc + dep - principal   # after debt service

            # WC recovered in final year
            if yr == plant_life:
                op_cf += WC

            cf.append(op_cf)

        # ── equity NPV ────────────────────────────────────────────────────
        npv = sum(c / (1 + irr) ** t for t, c in enumerate(cf))
        return npv

    # Newton-Raphson to find price where NPV = 0
    price = 1.0   # initial guess (USD/kg)
    for _ in range(200):
        f  = _npv(price)
        df = (_npv(price * 1.001) - f) / (price * 0.001 + 1e-9)
        if abs(df) < 1e-12:
            break
        price -= f / df
        price  = max(0.01, min(price, 100.0))

    return price   # USD/kg


def npv_at_price(
    FCI: float, WC: float,
    VOC_annual: float, FOC_annual: float,
    product_kg_yr: float, byproduct_revenue_yr: float,
    price_usd_per_kg: float,
    irr: float = IRR,
    income_tax: float = INCOME_TAX,
    plant_life: int = PLANT_LIFE,
    finance_frac: float = FINANCE_FRAC,
    finance_int: float = FINANCE_INT,
    finance_yrs: int = FINANCE_YRS,
    construction_sch: tuple = CONSTRUCTION_SCH,
) -> float:
    """Equity NPV (USD) at a fixed SAF selling price (USD/kg). Mirrors Humbird 2011 cash flow."""
    TCI        = FCI + WC
    debt       = TCI * finance_frac
    loan_sched = _loan_schedule(debt, finance_int, finance_yrs)
    depr       = [FCI * r for r in MACRS7] + [0.0] * (plant_life - len(MACRS7))

    cf = [-TCI * frac * (1 - finance_frac) for frac in construction_sch]

    for yr in range(1, plant_life + 1):
        if yr == 1:
            prod_frac = 0.5 * (STARTUP_MONTHS / 12) + 1.0 * (1 - STARTUP_MONTHS / 12)
            voc_frac  = 0.75 * (STARTUP_MONTHS / 12) + 1.0 * (1 - STARTUP_MONTHS / 12)
        else:
            prod_frac = voc_frac = 1.0

        revenue  = product_kg_yr * prod_frac * price_usd_per_kg + byproduct_revenue_yr * prod_frac
        voc      = VOC_annual * voc_frac
        interest, principal = loan_sched[yr - 1] if yr <= finance_yrs else (0.0, 0.0)
        dep      = depr[yr - 1] if yr <= len(depr) else 0.0
        taxable  = revenue - voc - FOC_annual - dep - interest
        tax      = max(0.0, taxable * income_tax)
        op_cf    = taxable - tax + dep - principal
        if yr == plant_life:
            op_cf += WC
        cf.append(op_cf)

    return sum(c / (1 + irr) ** t for t, c in enumerate(cf))


def compute_cashflows(
    FCI: float, WC: float,
    VOC_annual: float, FOC_annual: float,
    product_kg_yr: float, byproduct_revenue_yr: float,
    price_usd_per_kg: float,
    irr: float = IRR,
    income_tax: float = INCOME_TAX,
    plant_life: int = PLANT_LIFE,
    finance_frac: float = FINANCE_FRAC,
    finance_int: float = FINANCE_INT,
    finance_yrs: int = FINANCE_YRS,
    construction_sch: tuple = CONSTRUCTION_SCH,
):
    """
    Return full annual cash flow stream at a fixed selling price.

    Returns
    -------
    year_labels    : list[int]  — e.g. [-3,-2,-1, 1,2,...,30]
    annual_cf      : np.ndarray — equity cash flow each period (USD)
    cum_undiscounted: np.ndarray — running sum of annual_cf (USD)
    cum_discounted  : np.ndarray — running sum discounted at IRR (USD, equity NPV buildup)
    """
    n_constr   = len(construction_sch)
    TCI        = FCI + WC
    debt       = TCI * finance_frac
    loan_sched = _loan_schedule(debt, finance_int, finance_yrs)
    depr       = [FCI * r for r in MACRS7] + [0.0] * (plant_life - len(MACRS7))

    year_labels = list(range(-n_constr, 0)) + list(range(1, plant_life + 1))
    annual_cf   = []

    for frac in construction_sch:
        annual_cf.append(-TCI * frac * (1 - finance_frac))

    for yr in range(1, plant_life + 1):
        if yr == 1:
            prod_frac = 0.5  * (STARTUP_MONTHS / 12) + 1.0 * (1 - STARTUP_MONTHS / 12)
            voc_frac  = 0.75 * (STARTUP_MONTHS / 12) + 1.0 * (1 - STARTUP_MONTHS / 12)
        else:
            prod_frac = voc_frac = 1.0
        revenue  = product_kg_yr * prod_frac * price_usd_per_kg + byproduct_revenue_yr * prod_frac
        voc      = VOC_annual * voc_frac
        interest, principal = loan_sched[yr - 1] if yr <= finance_yrs else (0.0, 0.0)
        dep      = depr[yr - 1] if yr <= len(depr) else 0.0
        taxable  = revenue - voc - FOC_annual - dep - interest
        tax      = max(0.0, taxable * income_tax)
        op_cf    = taxable - tax + dep - principal
        if yr == plant_life:
            op_cf += WC
        annual_cf.append(op_cf)

    annual_cf       = np.array(annual_cf)
    cum_undiscounted = np.cumsum(annual_cf)
    cum_discounted   = np.array([
        sum(c / (1 + irr) ** t for t, c in enumerate(annual_cf[: i + 1]))
        for i in range(len(annual_cf))
    ])

    return year_labels, annual_cf, cum_undiscounted, cum_discounted


def to_gge(price_usd_per_kg: float, scenario: int) -> float:
    """Convert $/kg → $/GGE using LHV-based equivalence."""
    lhv = SAF_LHV_MJ_KG if scenario == 1 else BLEND_LHV_MJ_KG
    # $/GGE = ($/kg) × (LHV_SAF / LHV_gasoline_per_gal × density_kg_per_gal)
    # simplifies to ($/kg) × GASOLINE_LHV_MJ_GAL / lhv_mj_kg × (1/density_gal_per_kg)
    density_kg_gal = SAF_DENSITY_KG_M3 * 0.00378541   # kg/gal
    lhv_mj_gal     = lhv * density_kg_gal
    return price_usd_per_kg * density_kg_gal * (GASOLINE_LHV_MJ_GAL / lhv_mj_gal)


# ════════════════════════════════════════════════════════════════════════════
# Simulate one configuration and return financial inputs
# ════════════════════════════════════════════════════════════════════════════

def simulate_config(scenario: int, h2_source: str) -> dict:
    """
    Run BioSTEAM units for one (scenario, h2_source) pair.
    Returns dict with all values needed for TEA.
    """
    bst.main_flowsheet.clear()
    define_chemicals()

    raw_ps_kg_hr = PS_FEED_KG_HR * (SC2_FEED_SCALE if scenario == 2 else 1.0)   # 250 MT/day (x scale for equal-product basis)
    # Pretreatment (shred/wash/dry) recovers clean PS from the raw bale stream.
    # Computed analytically here too (matches PSPretreatmentUnit._run() exactly)
    # so downstream sizing can proceed before the unit object below is built —
    # same pattern already used for H2_demand.
    _ps_in_kg_hr = raw_ps_kg_hr * (1 - PRETREAT_MOISTURE_FRAC - PRETREAT_CONTAM_FRAC)
    ps_kg_hr     = _ps_in_kg_hr * (1 - PRETREAT_PS_LOSS_FRAC)   # clean PS reaching the pyrolyzer

    oil_kg_hr = ps_kg_hr * OIL_TO_PS_RATIO if scenario == 1 else 0.0
    total_feed = ps_kg_hr + oil_kg_hr

    # ── H2 demand ─────────────────────────────────────────────────────────
    if scenario == 2:
        liq_kg_hr    = total_feed * SCENARIO2_LIQUID_FRACTION
        H2_demand    = sc2_h2_demand_kg_hr(liq_kg_hr)   # R1: single source (compounds.py)
    else:
        liq_kg_hr = total_feed * SCENARIO1_LIQUID_FRACTION
        # Per-species stoichiometric H2 demand, matching HydrogenationUnit's own
        # HYDROGENATION_CONVERSION / H2_CONSUMPTION_RATIO chemistry (matches main.py's
        # build_flowsheet — previously a flat 0.06 kg H2/kg liquid heuristic here
        # overestimated demand ~1.8x relative to the reactor's actual consumption).
        H2_demand = 0.0
        for _sp, (_, _conv) in HYDROGENATION_CONVERSION.items():
            _sp_kg_hr = liq_kg_hr * SCENARIO1_PYRO_YIELDS.get(_sp, 0.0)
            H2_demand += _sp_kg_hr * _conv * HydrogenationUnit.H2_CONSUMPTION_RATIO.get(_sp, 0.06)
        H2_demand += oil_kg_hr * OIL_HDO_H2_KG_PER_KG_OIL   # R1: oxygen removal from waste oil (assumption)

    # ── streams ───────────────────────────────────────────────────────────
    # Raw PS bales -> pretreatment (shred/wash/dry) -> clean PS to pyrolyzer.
    s_ps_raw     = bst.Stream("s_ps_raw", Polystyrene=raw_ps_kg_hr, units="kg/hr", phase="s")
    s_wash_water = bst.Stream("s_wash_water")   # flow set internally by PSPretreatmentUnit
    pretreat = PSPretreatmentUnit("Pretreat", ins=[s_ps_raw, s_wash_water],
                                  outs=[bst.Stream("s_ps"), bst.Stream("pretreat_reject")],
                                  electricity_price=ELEC_PRICE_KWH)
    pretreat.simulate()
    s_ps  = pretreat.outs[0]
    s_oil = bst.Stream("s_oil", WasteCookingOil=oil_kg_hr, units="kg/hr", phase="l")

    if h2_source == "SMR":
        s_ch4   = bst.Stream("s_ch4",   Methane=1.0, units="kg/hr")
        s_steam = bst.Stream("s_steam", Water=1.0,   units="kg/hr")
        h2_unit = SMR_H2Unit("H2_SMR", ins=[s_ch4, s_steam],
                             outs=[bst.Stream("h2_out"), bst.Stream("flue")],
                             H2_demand=H2_demand)
    elif h2_source == "Photocatalysis":
        s_water_pc = bst.Stream("s_water_pc", Water=1.0, units="kg/hr")
        h2_unit    = Photocatalysis_H2Unit("H2_PC", ins=[s_water_pc],
                                           outs=[bst.Stream("h2_out"),
                                                 bst.Stream("o2_pc")],
                                           H2_demand=H2_demand,
                                           electricity_price=ELEC_PRICE_KWH)
    else:  # SOEC
        s_water_se = bst.Stream("s_water_se", Water=1.0, units="kg/hr")
        s_elec     = bst.Stream("s_elec")
        h2_unit    = SOEC_H2Unit("H2_SOEC", ins=[s_water_se, s_elec],
                                 outs=[bst.Stream("h2_out"), bst.Stream("o2_soec")],
                                 H2_demand=H2_demand,
                                 electricity_price=ELEC_PRICE_KWH)

    pyrolyzer = Pyrolyzer("Pyrolyzer",
                          ins=[s_ps, s_oil],
                          outs=[bst.Stream("pyro_oil"),
                                bst.Stream("char"),
                                bst.Stream("gas")],
                          scenario=scenario if scenario == 1 else 2)

    if scenario == 1:
        hydro = HydrogenationUnit("Hydrogenation",
                                  ins=[pyrolyzer.outs[0], h2_unit.outs[0]],
                                  outs=[bst.Stream("saf"), bst.Stream("offgas")],
                                  scenario=1, catalyst="Pd/SBA-15")
    else:
        hydro = SelectiveHydrogenationUnit("SelHydro",
                                           ins=[pyrolyzer.outs[0], h2_unit.outs[0]],
                                           outs=[bst.Stream("eb_oil"),
                                                 bst.Stream("offgas")])

    # ── simulate all units ────────────────────────────────────────────────
    h2_unit.simulate()
    pyrolyzer.simulate()
    hydro.simulate()

    # ── Scenario 2: EB extraction + SPK blending (50:50 by mass) ──────────
    # Matches main.py's build_flowsheet — previously this unit (and its
    # equipment cost) was entirely omitted from this replica.
    blender = None
    if scenario == 2:
        s_spk   = bst.Stream("s_spk", SPK=1.0, units="kg/hr", phase="l")
        blender = SPKBlendingUnit("SPKBlender",
                                  ins=[hydro.outs[0], s_spk],
                                  outs=[bst.Stream("eb_spk_blend"),
                                        bst.Stream("dist_bottoms")])
        blender.simulate()

    # ── purchased equipment costs ─────────────────────────────────────────
    tpec = (sum(pretreat.purchase_costs.values())
            + sum(pyrolyzer.purchase_costs.values())
            + sum(h2_unit.purchase_costs.values())
            + sum(hydro.purchase_costs.values())
            + (sum(blender.purchase_costs.values()) if blender else 0.0))

    # ── utility costs (USD/hr) ────────────────────────────────────────────
    # All heat-consuming units add heat utilities via add_heat_utility();
    # priced here at the Humbird-consistent HEAT_PRICE_GJ (not BioSTEAM's
    # own default utility-agent prices) so this matches tea_bridge.py's
    # pricing for the same units when run via main.py.
    def _heat_cost_hr(unit):
        return sum(hu.duty for hu in unit.heat_utilities) / 3600 * HEAT_PRICE_GJ / 277.778

    pretreat_heat_hr = _heat_cost_hr(pretreat)
    pretreat_util_hr = getattr(pretreat, "_utility_cost_hr", 0.0)   # shredder electricity + wash water
    pyro_heat_hr  = _heat_cost_hr(pyrolyzer)
    hydro_heat_hr = _heat_cost_hr(hydro)
    blend_heat_hr = _heat_cost_hr(blender) if blender else 0.0
    # H2 unit utilities (proprietary _utility_cost_hr):
    # For SMR this is a heuristic NG-intensity estimate that duplicates the
    # stoichiometric CH4 feedstock cost computed below, so it is excluded here
    # — natural gas is costed once, as a feedstock, not also as a utility.
    h2_util_hr = 0.0 if h2_source == "SMR" else getattr(h2_unit, "_utility_cost_hr", 0.0)
    utility_cost_hr = (pretreat_heat_hr + pretreat_util_hr
                        + pyro_heat_hr + hydro_heat_hr + blend_heat_hr + h2_util_hr)
    # R1 (update 15): catalyst replacement charged as an operating cost (carried in utility_cost_hr so every
    # downstream TEA path -- run_tea, sensitivity, Monte Carlo, main.py, tea_bridge -- picks it up).
    catalyst_cost_hr = catalyst_inventory_usd([hydro, blender]) * CATALYST_ANNUAL_FRAC / OPERATING_HR
    utility_cost_hr += catalyst_cost_hr

    # ── feedstock costs (USD/hr) ──────────────────────────────────────────
    # Priced on the RAW PS intake (what's purchased/collected), not the
    # clean PS reaching the pyrolyzer after pretreatment losses.
    feedstock_cost_hr = raw_ps_kg_hr * PS_PRICE_KG + oil_kg_hr * OIL_PRICE_KG
    if h2_source == "SMR":
        ch4_kg_hr = h2_unit.ins[0].get_flow("kg/hr", "Methane")
        feedstock_cost_hr += ch4_kg_hr * CH4_HHV_GJ_KG * CH4_PRICE_GJ

    # ── product / byproduct ───────────────────────────────────────────────
    if scenario == 1:
        saf_kg_hr = hydro.outs[0].F_mass
        spk_kg_hr = 0.0
    else:
        # Full EB-rich oil stream (all species) blended 1:1 with purchased
        # SPK — matches main.py's SPKBlendingUnit (previously this replica
        # blended only the pure Ethylbenzene component, understating both
        # product mass and SPK feedstock cost).
        eb_kg_hr  = blender.eb_kg_hr
        spk_kg_hr = blender.spk_kg_hr
        saf_kg_hr = blender.blend_kg_hr
        feedstock_cost_hr += spk_kg_hr * SPK_PRICE_KG

    char_kg_hr = pyrolyzer.outs[1].F_mass
    byproduct_revenue_hr = char_kg_hr * CHAR_PRICE_KG
    ends_kg_hr = blender.ends_kg_hr if blender else 0.0
    byproduct_revenue_hr += ends_kg_hr * SC2_ENDS_LHV_MJ_KG / 1000.0 * HEAT_PRICE_GJ   # R1: other-ends at fuel (heat) value only

    # O2 credit for PC and SOEC
    if h2_source in ("Photocatalysis", "SOEC"):
        o2_kg_hr = h2_unit.outs[1].F_mass
        byproduct_revenue_hr += o2_kg_hr * OXYGEN_PRICE_KG

    # Pyrolysis off-gas heat credit: the gas stream (60% CH4, 10% H2 by mass)
    # has real fuel value that a real plant would burn on-site for process
    # heat rather than vent unused. Credited as an avoided-purchase offset
    # against the purchased process heat (pretreat + pyro + hydro + blend),
    # at the same HEAT_PRICE_GJ used to price that heat — capped at the
    # actual heat spend, since this model doesn't credit excess heat/power
    # export (that would need a turbogenerator, out of scope here).
    gas = pyrolyzer.outs[2]
    gas_ch4_kg_hr = gas.get_flow("kg/hr", "Methane")
    gas_h2_kg_hr  = gas.get_flow("kg/hr", "Hydrogen")
    gas_fuel_value_hr = (gas_ch4_kg_hr * CH4_HHV_GJ_KG
                          + gas_h2_kg_hr * H2_HHV_GJ_KG) * HEAT_PRICE_GJ
    purchased_heat_hr = pretreat_heat_hr + pyro_heat_hr + hydro_heat_hr + blend_heat_hr
    gas_heat_credit_hr = min(gas_fuel_value_hr, purchased_heat_hr)
    byproduct_revenue_hr += gas_heat_credit_hr

    # ── CO2 intensity ─────────────────────────────────────────────────────
    co2_kg_per_kgSAF = (h2_unit.CO2_emissions_kg_per_kgH2 * H2_demand) / max(saf_kg_hr, 1e-6)

    # ── unit-by-unit data (for export) ────────────────────────────────────
    unit_rows = []
    for u in [u for u in [pretreat, h2_unit, pyrolyzer, hydro, blender] if u is not None]:
        row = {"unit": u.ID, "type": type(u).__name__,
               "purchase_cost_2023_usd": sum(u.purchase_costs.values())}
        for k, v in u.purchase_costs.items():
            row[f"pc_{k}"] = v
        unit_rows.append(row)

    return dict(
        scenario=scenario, h2_source=h2_source,
        tpec=tpec, utility_cost_hr=utility_cost_hr,
        feedstock_cost_hr=feedstock_cost_hr,
        byproduct_revenue_hr=byproduct_revenue_hr,
        saf_kg_hr=saf_kg_hr, spk_kg_hr=spk_kg_hr,
        additive_kg_hr=(blender.additive_kg_hr if blender else 0.0), ends_kg_hr=ends_kg_hr,
        H2_demand=H2_demand, co2_kg_per_kgSAF=co2_kg_per_kgSAF,
        unit_rows=unit_rows,
        streams=dict(
            ps_kg_hr=raw_ps_kg_hr,          # raw PS purchased (pricing basis)
            clean_ps_kg_hr=ps_kg_hr,        # clean PS reaching the pyrolyzer
            pretreat_reject_kg_hr=pretreat.outs[1].F_mass,
            oil_kg_hr=oil_kg_hr,
            char_kg_hr=char_kg_hr,
            h2_kg_hr=H2_demand,
            gas_ch4_kg_hr=gas_ch4_kg_hr,    # R1: pyrolysis off-gas, used by the LCA (same treatment as TEA)
            gas_h2_kg_hr=gas_h2_kg_hr,
        ),
        catalyst_cost_hr=catalyst_cost_hr,
    )


# ════════════════════════════════════════════════════════════════════════════
# TEA for one configuration
# ════════════════════════════════════════════════════════════════════════════

def run_tea(cfg: dict) -> dict:
    sc  = cfg["scenario"]
    cap = peters_timmerhaus_capital(cfg["tpec"])
    FCI = cap["FCI"]
    WC  = cap["WC"]

    VOC_annual = (cfg["utility_cost_hr"] + cfg["feedstock_cost_hr"]) * OPERATING_HR
    FOC_annual = fixed_operating_cost(FCI)
    byproduct_annual = cfg["byproduct_revenue_hr"] * OPERATING_HR
    product_kg_yr    = cfg["saf_kg_hr"] * OPERATING_HR

    mfsp_per_kg = dcfror_mfsp(FCI, WC, VOC_annual, FOC_annual,
                               product_kg_yr, byproduct_annual)
    mfsp_gge    = to_gge(mfsp_per_kg, sc)   # secondary unit — kept for fossil-jet/literature comparison only

    # ── MFSP decomposition ($/kg SAF contributions summing to net) ───────
    feedstock_contr  = cfg["feedstock_cost_hr"] * OPERATING_HR / product_kg_yr
    utility_contr    = cfg["utility_cost_hr"]   * OPERATING_HR / product_kg_yr
    foc_contr        = FOC_annual / product_kg_yr
    byproduct_credit = -byproduct_annual / product_kg_yr

    # Capital contribution = remainder so that sum = mfsp_per_kg
    capital_contr = mfsp_per_kg - feedstock_contr - utility_contr - foc_contr - byproduct_credit

    return dict(
        **cap,
        VOC_annual_MM=VOC_annual/1e6, FOC_annual_MM=FOC_annual/1e6,
        byproduct_annual_MM=byproduct_annual/1e6,
        product_kg_yr=product_kg_yr,
        mfsp_per_kg=mfsp_per_kg, mfsp_gge=mfsp_gge,
        feedstock_contr=feedstock_contr, utility_contr=utility_contr,
        foc_contr=foc_contr, capital_contr=capital_contr,
        byproduct_credit=byproduct_credit,
    )


# ════════════════════════════════════════════════════════════════════════════
# Sensitivity (±20%, one-at-a-time)
# ════════════════════════════════════════════════════════════════════════════

def sensitivity_mfsp(scenario, h2_source, base_cfg, base_tea, **overrides) -> float:
    """
    Re-run TEA with one or more parameters changed. overrides are scalar
    multipliers (default 1.0 = no change), applied independently and composed
    multiplicatively so results are the same regardless of how many overrides
    are passed together or in what order — needed because run_uncertainty()
    passes all 7 parameters at once on every Monte Carlo draw. (A prior
    version mutated a shared cfg dict through sequential if-blocks, so any
    later override on a shared field — e.g. tpec_mult after capacity_mult —
    silently discarded the earlier one's effect on that field.)
    """
    ps_mult      = overrides.get("ps_price_mult", 1.0)
    oil_mult     = overrides.get("oil_price_mult", 1.0)   # R1: waste-oil price was missing from sensitivity/MC
    cap_mult     = overrides.get("capacity_mult", 1.0)
    h2_mult      = overrides.get("h2_cost_mult", 1.0)
    tpec_mult    = overrides.get("tpec_mult", 1.0)
    yield_mult   = overrides.get("liq_yield_mult", 1.0)
    spk_mult     = overrides.get("spk_price_mult", 1.0)
    op_days_mult = overrides.get("operating_days_mult", 1.0)
    irr_mult     = overrides.get("irr_mult", 1.0)

    # Decompose base feedstock cost into PS / SPK / other portions (at nominal
    # prices), so each price multiplier scales only its own portion.
    ps_base_cost_hr    = base_cfg["streams"]["ps_kg_hr"] * PS_PRICE_KG
    spk_base_cost_hr   = base_cfg.get("spk_kg_hr", 0.0) * SPK_PRICE_KG
    oil_base_cost_hr   = base_cfg["streams"].get("oil_kg_hr", 0.0) * OIL_PRICE_KG
    other_base_cost_hr = base_cfg["feedstock_cost_hr"] - ps_base_cost_hr - spk_base_cost_hr - oil_base_cost_hr

    # Capacity scales all throughput-linked quantities proportionally
    # (capital at the usual 0.6 power); every other multiplier composes on top.
    feedstock_cost_hr = (ps_base_cost_hr * ps_mult
                          + spk_base_cost_hr * spk_mult * (yield_mult if scenario == 2 else 1.0)   # R1: SPK is bought in a fixed ratio to the PS-derived additive
                          + oil_base_cost_hr * oil_mult
                          + other_base_cost_hr) * cap_mult
    tpec                  = base_cfg["tpec"] * (cap_mult ** CAPACITY_SCALING_EXPONENT) * tpec_mult
    saf_kg_hr             = base_cfg["saf_kg_hr"] * cap_mult * yield_mult
    utility_cost_hr       = base_cfg["utility_cost_hr"] * cap_mult * h2_mult
    byproduct_revenue_hr  = base_cfg["byproduct_revenue_hr"] * cap_mult

    cap    = peters_timmerhaus_capital(tpec)
    FCI    = cap["FCI"]
    WC     = cap["WC"]
    op_hr  = OPERATING_HR * op_days_mult
    irr    = IRR * irr_mult

    VOC_annual = (utility_cost_hr + feedstock_cost_hr) * op_hr
    FOC_annual = fixed_operating_cost(FCI)
    byproduct_annual = byproduct_revenue_hr * op_hr
    product_kg_yr    = saf_kg_hr * op_hr

    mfsp_per_kg = dcfror_mfsp(FCI, WC, VOC_annual, FOC_annual,
                               product_kg_yr, byproduct_annual, irr=irr)
    return mfsp_per_kg


# ── R1 (R2.4): sourced parameter ranges for the tornado and Monte Carlo ───────────────────────────────────────
# main.py's tornado and Monte Carlo now use R1_mc_distributions.csv (same table as run_R1_analysis.py and the paper):
# sourced low/mode/high multipliers, incl. waste-oil and HEFA-SPK prices. Env R1_LEGACY_RANGES=1 restores +/-20 %.
def _r1_ranges(scenario):
    """[(name, key, low, mode, high)] for this scenario, or None if the table is missing / legacy mode is on."""
    if os.environ.get("R1_LEGACY_RANGES", "0") == "1":
        return None
    path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "R1_mc_distributions.csv")
    if not os.path.exists(path):
        return None
    d = pd.read_csv(path)
    d = d[d.applies_to.isin(["all", f"sc{scenario}"])].reset_index(drop=True)
    out = []
    for r in d.itertuples():
        lo, mo, hi = float(r.low), float(r.mode), float(r.high)
        if r.key == "liq_yield_mult":       # absolute yield ranges, re-based on the active case
            liq = SCENARIO1_LIQUID_FRACTION if scenario == 1 else SCENARIO2_LIQUID_FRACTION
            lo, hi = ((0.65, 0.90) if scenario == 1 else (0.76, 0.987))
            lo, mo, hi = lo / liq, 1.0, hi / liq
        out.append((r.parameter, r.key, lo, mo, hi))
    return out


def run_sensitivity(scenario, h2_source, base_cfg, base_tea) -> pd.DataFrame:
    base_mfsp = base_tea["mfsp_per_kg"]

    params = [
        ("PS feedstock cost",         dict(ps_price_mult=0.8),   dict(ps_price_mult=1.2)),
        ("Plant capacity",            dict(capacity_mult=0.8),   dict(capacity_mult=1.2)),
        ("IRR",                       dict(irr_mult=0.8),        dict(irr_mult=1.2)),
        ("Pyrolysis liquid yield",    dict(liq_yield_mult=0.8),  dict(liq_yield_mult=1.2)),
        ("H2 / energy cost",          dict(h2_cost_mult=0.8),    dict(h2_cost_mult=1.2)),
        ("Total installed capital",   dict(tpec_mult=0.8),       dict(tpec_mult=1.2)),
        ("On-stream factor",          dict(operating_days_mult=0.8), dict(operating_days_mult=1.2)),
    ]
    if scenario == 2:
        params.append(
            ("SPK feedstock price", dict(spk_price_mult=0.8), dict(spk_price_mult=1.2))
        )

    r1 = _r1_ranges(scenario)
    if r1 is not None:
        params = [(nm, {k: lo}, {k: hi}) for nm, k, lo, mo, hi in r1]
    rows = []
    for name, low_kw, high_kw in params:
        m_low  = sensitivity_mfsp(scenario, h2_source, base_cfg, base_tea, **low_kw)
        m_high = sensitivity_mfsp(scenario, h2_source, base_cfg, base_tea, **high_kw)
        rows.append(dict(
            parameter=name, base_value=1.0, low_value=list(low_kw.values())[0], high_value=list(high_kw.values())[0],
            mfsp_base=base_mfsp, mfsp_low=m_low, mfsp_high=m_high,
            delta_low=m_low - base_mfsp, delta_high=m_high - base_mfsp,
        ))

    df = pd.DataFrame(rows)
    df["abs_total"] = df["delta_low"].abs() + df["delta_high"].abs()
    return df.sort_values("abs_total", ascending=False).drop(columns="abs_total").reset_index(drop=True)


# ════════════════════════════════════════════════════════════════════════════
# Uncertainty (Monte Carlo, N=1000, Latin Hypercube)
# ════════════════════════════════════════════════════════════════════════════

def run_uncertainty(scenario, h2_source, base_cfg, base_tea, n=1000) -> tuple:
    base_mfsp = base_tea["mfsp_per_kg"]
    # Parameter names and ±20% triangular distributions
    param_names = [
        "PS feedstock cost", "Plant capacity", "IRR",
        "Pyrolysis liquid yield", "H2 / energy cost",
        "Total installed capital", "On-stream factor",
    ]
    r1 = _r1_ranges(scenario)
    if r1 is not None:
        param_names = [nm for nm, *_ in r1]
    d = len(param_names)

    # Latin hypercube samples in [0,1]^d
    lhs = cp.create_latin_hypercube_samples(n, d).T   # (n, d)

    def triangular_ppf(u, lo, mode, hi):
        Fc = (mode - lo) / (hi - lo)
        if u < Fc:
            return lo + np.sqrt(u * (hi - lo) * (mode - lo))
        else:
            return hi - np.sqrt((1 - u) * (hi - lo) * (hi - mode))

    sample_rows = []
    mfsp_vals   = []
    for i in range(n):
        mults = {}
        row   = {}
        for j, pname in enumerate(param_names):
            u = float(lhs[i, j])
            lo_, mo_, hi_ = (r1[j][2], r1[j][3], r1[j][4]) if r1 is not None else (0.8, 1.0, 1.2)
            m = triangular_ppf(u, lo_, mo_, hi_)
            row[pname] = m
            mults[pname] = m
        if r1 is not None:
            mfsp_i = sensitivity_mfsp(scenario, h2_source, base_cfg, base_tea, **{r1[j][1]: mults[r1[j][0]] for j in range(d)})
            row["mfsp"] = mfsp_i
            mfsp_vals.append(mfsp_i)
            sample_rows.append(row)
            continue

        kw = {
            "ps_price_mult":      mults["PS feedstock cost"],
            "capacity_mult":      mults["Plant capacity"],
            "irr_mult":           mults["IRR"],
            "liq_yield_mult":     mults["Pyrolysis liquid yield"],
            "h2_cost_mult":       mults["H2 / energy cost"],
            "tpec_mult":          mults["Total installed capital"],
            "operating_days_mult": mults["On-stream factor"],
        }
        mfsp_i = sensitivity_mfsp(scenario, h2_source, base_cfg, base_tea, **kw)
        row["mfsp"] = mfsp_i
        mfsp_vals.append(mfsp_i)
        sample_rows.append(row)

    mfsp_arr = np.array(mfsp_vals)
    samples_df = pd.DataFrame(sample_rows)

    summary = {k: getattr(np, k)(mfsp_arr) if hasattr(np, k) else None
               for k in []}
    summary = {
        "mean": float(np.mean(mfsp_arr)),
        "std":  float(np.std(mfsp_arr, ddof=1)),
        "min":  float(np.min(mfsp_arr)),
        "P5":   float(np.quantile(mfsp_arr, 0.05)),
        "P25":  float(np.quantile(mfsp_arr, 0.25)),
        "P50":  float(np.quantile(mfsp_arr, 0.50)),
        "P75":  float(np.quantile(mfsp_arr, 0.75)),
        "P95":  float(np.quantile(mfsp_arr, 0.95)),
        "max":  float(np.max(mfsp_arr)),
        "base": base_mfsp,
        "unit": "$/kg",
    }

    spearman_rows = []
    for pname in param_names:
        rho, pval = stats.spearmanr(samples_df[pname], samples_df["mfsp"])
        spearman_rows.append({"parameter": pname, "spearman_rho": float(rho),
                               "p_value": float(pval)})
    spearman_df = pd.DataFrame(spearman_rows)
    spearman_df["abs_rho"] = spearman_df["spearman_rho"].abs()
    spearman_df = (spearman_df.sort_values("abs_rho", ascending=False)
                               .drop(columns="abs_rho").reset_index(drop=True))

    return samples_df, pd.DataFrame([summary]), spearman_df


# ════════════════════════════════════════════════════════════════════════════
# CSV exporters
# ════════════════════════════════════════════════════════════════════════════

CONFIGS = [
    (1, "SMR"), (1, "Photocatalysis"), (1, "SOEC"),
    (2, "SMR"), (2, "Photocatalysis"), (2, "SOEC"),
]


def main():
    print("=" * 70)
    print("SAF-from-PS NREL/Humbird 2011 DCFROR TEA  |  CEPCI 797.9 (2023 USD)")
    print("=" * 70)

    all_cfg  = {}
    all_tea  = {}
    all_sens = {}

    # ── Phase 1-3: simulate + TEA ──────────────────────────────────────────
    print("\n[Phase 1-3] Simulating 6 configurations ...\n")
    unit_rows_all = []
    stream_rows   = []

    for sc, h2 in CONFIGS:
        label = f"Sc{sc}_{h2}"
        print(f"  {label} ...", end=" ", flush=True)
        cfg = simulate_config(sc, h2)
        tea = run_tea(cfg)
        all_cfg[label]  = cfg
        all_tea[label]  = tea
        print(f"MFSP = ${tea['mfsp_per_kg']:.2f}/kg  |  FCI = ${tea['FCI']/1e6:.1f} MM")

        # stream rows
        stream_rows.append({
            "scenario": label, "phase": "l/s",
            "PS_raw_kg_hr": cfg["streams"]["ps_kg_hr"],
            "PS_feed_kg_hr": cfg["streams"]["clean_ps_kg_hr"],
            "oil_feed_kg_hr": cfg["streams"]["oil_kg_hr"],
            "H2_demand_kg_hr": cfg["streams"]["h2_kg_hr"],
            "SAF_product_kg_hr": cfg["saf_kg_hr"],
            "char_kg_hr": cfg["streams"]["char_kg_hr"],
            "pretreat_reject_kg_hr": cfg["streams"]["pretreat_reject_kg_hr"],
        })

        for ur in cfg["unit_rows"]:
            ur["scenario"] = label
            unit_rows_all.append(ur)

    # ── streams.csv ───────────────────────────────────────────────────────
    pd.DataFrame(stream_rows).to_csv(os.path.join(DATA_DIR, "streams.csv"), index=False)

    # ── unit_results.csv ──────────────────────────────────────────────────
    pd.DataFrame(unit_rows_all).to_csv(os.path.join(DATA_DIR, "unit_results.csv"), index=False)

    # ── capex.csv ─────────────────────────────────────────────────────────
    capex_rows = []
    for label, tea in all_tea.items():
        for item in ["TPEC", "DEC", "DirectInstalled", "TotalDirect", "Indirect", "FCI", "WC", "TCI"]:
            capex_rows.append({"scenario": label, "item": item,
                                "value_2023_usd": tea[item]})
    pd.DataFrame(capex_rows).to_csv(os.path.join(DATA_DIR, "capex.csv"), index=False)

    # ── opex.csv ──────────────────────────────────────────────────────────
    opex_rows = []
    for label, (cfg, tea) in {k: (all_cfg[k], all_tea[k]) for k in all_cfg}.items():
        FCI = tea["FCI"]
        opex_rows += [
            {"scenario": label, "category": "Variable operating",
             "item": "Feedstock", "value_2023_usd_per_yr": cfg["feedstock_cost_hr"] * OPERATING_HR},
            {"scenario": label, "category": "Variable operating",
             "item": "Utilities", "value_2023_usd_per_yr": cfg["utility_cost_hr"] * OPERATING_HR},
            {"scenario": label, "category": "Fixed operating",
             "item": "Maintenance (3 % FCI)",
             "value_2023_usd_per_yr": FCI * MAINTENANCE_FRAC},
            {"scenario": label, "category": "Fixed operating",
             "item": "Insurance + taxes (0.7 % FCI)",
             "value_2023_usd_per_yr": FCI * INSURANCE_TAX_FRAC},
            {"scenario": label, "category": "Fixed operating",
             "item": ("Labor + burden (5 % FCI)" if LABOR_MODE == "fci" else "Labor + burden (fixed headcount)"),
             "value_2023_usd_per_yr": labor_cost(FCI)},
            {"scenario": label, "category": "Co-product credit",
             "item": "Char + O2 revenue",
             "value_2023_usd_per_yr": -cfg["byproduct_revenue_hr"] * OPERATING_HR},
        ]
    pd.DataFrame(opex_rows).to_csv(os.path.join(DATA_DIR, "opex.csv"), index=False)

    # ── mfsp.csv ──────────────────────────────────────────────────────────
    mfsp_rows = []
    for label, tea in all_tea.items():
        sc = all_cfg[label]["scenario"]
        mfsp_rows += [
            {"scenario": label, "category": "Feedstock",
             "value": tea["feedstock_contr"], "sign": "cost"},
            {"scenario": label, "category": "Capital depreciation",
             "value": tea["capital_contr"], "sign": "cost"},
            {"scenario": label, "category": "Fixed operating",
             "value": tea["foc_contr"], "sign": "cost"},
            {"scenario": label, "category": "Utilities",
             "value": tea["utility_contr"], "sign": "cost"},
            {"scenario": label, "category": "Co-product credit",
             "value": tea["byproduct_credit"], "sign": "credit"},
        ]
    pd.DataFrame(mfsp_rows).to_csv(os.path.join(DATA_DIR, "mfsp.csv"), index=False)

    mfsp_summary = [{"scenario": k, "mfsp_net": v["mfsp_per_kg"],
                      "mfsp_gge": v["mfsp_gge"], "unit": "$/kg"}
                    for k, v in all_tea.items()]
    pd.DataFrame(mfsp_summary).to_csv(os.path.join(DATA_DIR, "mfsp_summary.csv"), index=False)

    print(f"\n  Written: streams.csv, unit_results.csv, capex.csv, opex.csv, mfsp.csv")

    # ── Phase 4: Sensitivity ──────────────────────────────────────────────
    print("\n[Phase 4] Running sensitivity (±20%) for each configuration ...")
    all_sens_dfs = {}
    for label in all_cfg:
        sc, h2 = all_cfg[label]["scenario"], all_cfg[label]["h2_source"]
        df = run_sensitivity(sc, h2, all_cfg[label], all_tea[label])
        all_sens_dfs[label] = df
        print(f"  {label}: top driver = {df.iloc[0]['parameter']}")

    # Save sensitivity for the best Sc1 config (SMR as base case illustration)
    # and best Sc2 config (SMR) — plus aggregate all configs
    all_sens_rows = []
    for label, df in all_sens_dfs.items():
        df2 = df.copy()
        df2.insert(0, "scenario", label)
        all_sens_rows.append(df2)
    pd.concat(all_sens_rows).to_csv(os.path.join(DATA_DIR, "sensitivity.csv"), index=False)

    # Save the Sc1_SMR sensitivity separately (used for tornado plot)
    all_sens_dfs["Sc1_SMR"].to_csv(
        os.path.join(DATA_DIR, "sensitivity_Sc1_SMR.csv"), index=False)
    print(f"  Written: sensitivity.csv")

    # ── Phase 5: Uncertainty ──────────────────────────────────────────────
    print("\n[Phase 5] Monte Carlo uncertainty (N=1000) for all 6 configurations ...")
    unc_summary_rows = []
    unc_spearman_rows = []

    for label in all_cfg.keys():
        sc, h2 = all_cfg[label]["scenario"], all_cfg[label]["h2_source"]
        print(f"  {label} ...", end=" ", flush=True)
        samples_df, summary_df, spearman_df = run_uncertainty(
            sc, h2, all_cfg[label], all_tea[label], n=1000)

        samples_df.insert(0, "scenario", label)
        summary_df.insert(0, "scenario", label)
        spearman_df.insert(0, "scenario", label)

        samples_df.to_csv(
            os.path.join(DATA_DIR, f"uncertainty_samples_{label}.csv"), index=False)
        unc_summary_rows.append(summary_df)
        unc_spearman_rows.append(spearman_df)
        print(f"P5={summary_df['P5'].values[0]:.2f}  P95={summary_df['P95'].values[0]:.2f} $/kg")

    pd.concat(unc_summary_rows).to_csv(
        os.path.join(DATA_DIR, "uncertainty_summary.csv"), index=False)
    pd.concat(unc_spearman_rows).to_csv(
        os.path.join(DATA_DIR, "uncertainty_spearman.csv"), index=False)

    # Also save Sc1_SMR samples separately for CDF plot
    pd.read_csv(os.path.join(DATA_DIR, "uncertainty_samples_Sc1_SMR.csv")).to_csv(
        os.path.join(DATA_DIR, "uncertainty_samples.csv"), index=False)

    print(f"  Written: uncertainty_*.csv")

    # ── Literature CSV (placeholder — populated in Phase 6) ───────────────
    lit_rows = [
        {"citation_key": "Tanzil_2021",   "year_reported": 2021,
         "original_mfsp": 3.21, "original_units": "$/GGE",
         "cepci_year": 607.5,   "normalized_mfsp_2023": round(3.21 * 797.9/607.5, 2),
         "feedstock": "Various biomass",
         "product": "SAF (HEFA/FT/ATJ)", "capacity": "Various",
         "notes": "Strategic assessment; CEPCI normalized from 2019"},
        {"citation_key": "Umenweke_2022", "year_reported": 2022,
         "original_mfsp": 2.85, "original_units": "$/GGE",
         "cepci_year": 816.0,   "normalized_mfsp_2023": round(2.85 * 797.9/816.0, 2),
         "feedstock": "Sewage sludge",
         "product": "SAF (HTG pathway)", "capacity": "2000 dry t/d",
         "notes": "CEPCI normalized from 2022"},
        {"citation_key": "Brandt_2023",   "year_reported": 2023,
         "original_mfsp": 4.10, "original_units": "$/GGE",
         "cepci_year": 797.9,   "normalized_mfsp_2023": 4.10,
         "feedstock": "Cellulosic biomass",
         "product": "SAF (FT-SPK)", "capacity": "2000 dry t/d",
         "notes": "Federal/state policy impact study; 2023 USD"},
        {"citation_key": "Okolie_2024",   "year_reported": 2024,
         "original_mfsp": 3.50, "original_units": "$/GGE",
         "cepci_year": 797.9,   "normalized_mfsp_2023": 3.50,
         "feedstock": "Plastic waste (mixed)",
         "product": "SAF (pyrolysis route)", "capacity": "100 t/d",
         "notes": "Data-driven TEA; 2023 USD basis"},
        {"citation_key": "NREL_Jones_2019", "year_reported": 2019,
         "original_mfsp": 3.80, "original_units": "$/GGE",
         "cepci_year": 607.5,   "normalized_mfsp_2023": round(3.80 * 797.9/607.5, 2),
         "feedstock": "Algae / woody biomass",
         "product": "SAF (HTL-upgrading)", "capacity": "2000 dry t/d",
         "notes": "PNNL design report; CEPCI normalized from 2019"},
        {"citation_key": "this_study_Sc1_SMR", "year_reported": 2023,
         "original_mfsp": round(all_tea["Sc1_SMR"]["mfsp_gge"], 2),
         "original_units": "$/GGE",
         "cepci_year": 797.9,
         "normalized_mfsp_2023": round(all_tea["Sc1_SMR"]["mfsp_gge"], 2),
         "feedstock": "Waste PS (250 MT/d)",
         "product": "SAF Sc1 + SMR H2", "capacity": "250 MT PS/d",
         "notes": "This study — Humbird 2011 DCFROR; 2023 USD"},
        {"citation_key": "this_study_Sc2_SMR", "year_reported": 2023,
         "original_mfsp": round(all_tea["Sc2_SMR"]["mfsp_gge"], 2),
         "original_units": "$/GGE",
         "cepci_year": 797.9,
         "normalized_mfsp_2023": round(all_tea["Sc2_SMR"]["mfsp_gge"], 2),
         "feedstock": "Waste PS (250 MT/d)",
         "product": "SAF Sc2 + SMR H2", "capacity": "250 MT PS/d",
         "notes": "This study — Humbird 2011 DCFROR; 2023 USD"},
    ]
    pd.DataFrame(lit_rows).to_csv(os.path.join(DATA_DIR, "literature.csv"), index=False)
    print(f"  Written: literature.csv")

    print("\n[Done] All CSVs written to", DATA_DIR)

    # ── print summary table ────────────────────────────────────────────────
    print("\n" + "-" * 70)
    print(f"{'Config':<22} {'FCI (MM$)':>10} {'TCI (MM$)':>10} "
          f"{'MFSP ($/kg)':>14} {'CO2 (kg/kg)':>12}")
    print("-" * 70)
    for label in all_cfg:
        t = all_tea[label]
        c = all_cfg[label]
        print(f"  {label:<20} {t['FCI']/1e6:>10.1f} {t['TCI']/1e6:>10.1f} "
              f"{t['mfsp_per_kg']:>14.2f} {c['co2_kg_per_kgSAF']:>12.3f}")
    print("-" * 70)

    return all_cfg, all_tea, all_sens_dfs


if __name__ == "__main__":
    main()
