"""
make_contour.py — 2D MFSP contour plots for all 6 configurations.
Process engineering sourced from main.py's BioSTEAM simulation; all financial
math (Peters/Timmerhaus/West capital, 60/40 debt/equity, MACRS7, 35% tax, 3-yr
construction, 6-month startup) comes from tea_model.py's NREL DCFROR engine
via tea_bridge.py — same engine as make_plots.py / make_npv.py / etc.

Figure 1: Pyrolysis liquid yield × On-stream factor
Figure 2: Pyrolysis liquid yield × Total installed capital
Figure 3 (Sc2 only): SPK feedstock price × Liquid yield
"""

import os, warnings
warnings.filterwarnings("ignore")

import numpy as np
import sys as _s, os as _o
_s.path.insert(0, _o.path.dirname(_o.path.dirname(_o.path.dirname(_o.path.abspath(__file__)))))
import scenario_relabel  # R1.14: display swap Sc1<->Sc2 (set SCENARIO_RELABEL=0 to disable)
import matplotlib
# Standalone run: force Agg (fast, headless). Loaded by main.py inside an
# IPython/Jupyter session: leave the backend main.py already configured
# (inline / TkAgg) alone so plt.show() calls below actually render.
try:
    get_ipython()
except NameError:
    matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.colors import TwoSlopeNorm

import tea_bridge as tb
import tea_model as tm

PLOTS_DIR = tb.PLOTS_DIR

# ── matplotlib style ─────────────────────────────────────────────────────────
mpl.rcParams.update({
    "font.family":      "serif",
    "font.serif":       ["DejaVu Serif", "Times New Roman", "serif"],
    "axes.labelsize":   10,
    "axes.titlesize":   10,
    "xtick.labelsize":  8,
    "ytick.labelsize":  8,
    "figure.dpi":       150,
    "savefig.dpi":      300,
    "savefig.bbox":     "tight",
})

# $/kg SAF fossil-jet reference, on Sc1 SAF LHV basis (fossil jet ~$3.10/GGE)
FOSSIL_JET_KG = 3.10 / tm.to_gge(1.0, 1)

PANEL_META = {
    (1, "SMR"):            {"label": "Sc1 + SMR",            "color": "#0072B2",
                            "base_yield": 0.86, "base_days": tm.OPERATING_DAYS},
    (1, "SOEC"):           {"label": "Sc1 + SOEC",           "color": "#56B4E9",
                            "base_yield": 0.86, "base_days": tm.OPERATING_DAYS},
    (1, "Photocatalysis"): {"label": "Sc1 + Photocatalysis", "color": "#009E73",
                            "base_yield": 0.86, "base_days": tm.OPERATING_DAYS},
    (2, "SMR"):            {"label": "Sc2 + SMR",            "color": "#D55E00",
                            "base_yield": 0.90, "base_days": tm.OPERATING_DAYS},
    (2, "SOEC"):           {"label": "Sc2 + SOEC",           "color": "#CC79A7",
                            "base_yield": 0.90, "base_days": tm.OPERATING_DAYS},
    (2, "Photocatalysis"): {"label": "Sc2 + Photocatalysis", "color": "#E69F00",
                            "base_yield": 0.90, "base_days": tm.OPERATING_DAYS},
}
PANEL_ORDER = [
    (1, "SMR"), (1, "SOEC"), (1, "Photocatalysis"),
    (2, "SMR"), (2, "SOEC"), (2, "Photocatalysis"),
]

# ── simulate base cases (main.py process + tea_model.py NREL DCFROR) ──────────
print("=" * 65)
print("Simulating 6 configurations (main.py process + Humbird 2011 DCFROR) ...")
print("=" * 65)
RESULTS = tb.simulate_all()
for k in PANEL_ORDER:
    r = RESULTS.get(k)
    if r:
        print(f"  Sc{k[0]}_{k[1]}: MFSP = ${r['mfsp_per_kg']:.2f}/kg SAF")


# ── sensitivity helper — thin wrapper around tea_model's own composable
# sensitivity_mfsp() (same engine used for the tornado/uncertainty plots) ─────
def _sensitivity_msp(key, **overrides):
    """MFSP ($/kg SAF) for config `key` with parameter overrides (see
    tea_model.sensitivity_mfsp for the recognized override names: ps_price_mult,
    capacity_mult, h2_cost_mult, tpec_mult, liq_yield_mult, spk_price_mult,
    operating_days_mult, irr_mult)."""
    sc, h2 = key
    res = RESULTS[key]
    return tm.sensitivity_mfsp(sc, h2, res, res, **overrides)


# ── grid builder ──────────────────────────────────────────────────────────────
def build_grid(key, x_key, x_vals, y_key, y_vals):
    """Returns Z[i,j] = MFSP ($/kg SAF) at (y_vals[i], x_vals[j])."""
    ny, nx = len(y_vals), len(x_vals)
    Z = np.empty((ny, nx))
    for i, yv in enumerate(y_vals):
        for j, xv in enumerate(x_vals):
            Z[i, j] = _sensitivity_msp(key, **{x_key: xv, y_key: yv})
    return Z


# ── contour figure helper ─────────────────────────────────────────────────────
def draw_contour_figure(x_key, y_key, x_range, y_range, nx, ny,
                        x_label_fn, y_label_fn, title, out_name,
                        panel_set=None):
    x_vals = np.linspace(*x_range, nx)
    y_vals = np.linspace(*y_range, ny)
    panels = panel_set if panel_set is not None else PANEL_ORDER

    ncols = len(panels)
    nrows = 1 if ncols <= 3 else 2
    ncols_plot = 3 if ncols > 3 else ncols

    fig, axes = plt.subplots(nrows, ncols_plot, figsize=(16 if ncols_plot == 3 else 15,
                                                          10 if nrows == 2 else 5))
    if nrows == 1 and ncols_plot == 1:
        axes = np.array([[axes]])
    elif nrows == 1:
        axes = axes.reshape(1, -1)
    elif ncols_plot == 1:
        axes = axes.reshape(-1, 1)

    fig.suptitle(title, fontsize=13, fontweight="bold")

    for ax, key in zip(axes.flat, panels):
        meta      = PANEL_META[key]
        res       = RESULTS.get(key)
        if res is None:
            ax.text(0.5, 0.5, "No data", ha="center", va="center",
                    transform=ax.transAxes)
            ax.set_title(meta["label"]); continue

        base_mfsp = res['mfsp_per_kg']
        fossil_kg = FOSSIL_JET_KG

        lbl_str = f"Sc{key[0]}_{key[1]}"
        print(f"  {lbl_str} grid ({nx}x{ny}) ...", end=" ", flush=True)
        Z = build_grid(key, x_key, x_vals, y_key, y_vals)
        print(f"${Z.min():.2f} - ${Z.max():.2f}/kg SAF")

        vmin, vmax = float(Z.min()), float(Z.max())
        norm = (TwoSlopeNorm(vmin=vmin, vcenter=fossil_kg, vmax=vmax)
                if vmin < fossil_kg < vmax
                else mpl.colors.Normalize(vmin=vmin, vmax=vmax))

        cf = ax.contourf(x_vals, y_vals, Z, levels=25,
                         cmap="RdYlGn_r", norm=norm, alpha=0.92)
        cbar = plt.colorbar(cf, ax=ax, shrink=0.88, pad=0.02)
        cbar.set_label("MFSP ($/kg SAF)", fontsize=8)
        cbar.ax.tick_params(labelsize=7)

        n_lines = min(10, max(5, int((vmax - vmin) / 0.1)))
        cs = ax.contour(x_vals, y_vals, Z, levels=n_lines,
                        colors="black", linewidths=0.35, alpha=0.45)
        ax.clabel(cs, fmt="$%.2f", fontsize=6, inline=True, inline_spacing=2)

        if vmin < fossil_kg < vmax:
            cs_f = ax.contour(x_vals, y_vals, Z, levels=[fossil_kg],
                              colors=["navy"], linewidths=2.0)
            ax.clabel(cs_f, fmt=f"Fossil ${fossil_kg:.2f}", fontsize=7, inline=True)

        ax.plot(1.0, 1.0, "*", color="white", markersize=13,
                markeredgecolor="black", markeredgewidth=0.8, zorder=10,
                label=f"Base: ${base_mfsp:.2f}/kg SAF")
        ax.axvline(1.0, color="white", linestyle="--", linewidth=0.8,
                   alpha=0.55, zorder=9)
        ax.axhline(1.0, color="white", linestyle="--", linewidth=0.8,
                   alpha=0.55, zorder=9)

        ax.set_xlabel(x_label_fn(meta), fontsize=9)
        ax.set_ylabel(y_label_fn(meta), fontsize=9)
        ax.set_title(meta["label"], fontsize=10, fontweight="bold",
                     color=meta["color"])
        ax.legend(loc="lower right", fontsize=7.5, framealpha=0.85, edgecolor="gray")
        for sp in ax.spines.values():
            sp.set_linewidth(0.7)

    # Hide empty axes if panels < nrows*ncols_plot
    for ax in list(axes.flat)[len(panels):]:
        ax.set_visible(False)

    fig.tight_layout(rect=[0, 0, 1, 0.95])
    out = os.path.join(PLOTS_DIR, out_name)
    fig.savefig(out)
    plt.show()
    plt.close(fig)
    print(f"  -> Saved: {out}\n")


# ════════════════════════════════════════════════════════════════════════════
# Figure 1: Liquid yield × On-stream factor
# ════════════════════════════════════════════════════════════════════════════
print("\n[Figure 1] Liquid yield x On-stream factor")
draw_contour_figure(
    x_key      = "liq_yield_mult",
    y_key      = "operating_days_mult",
    x_range    = (0.65, 1.30),
    y_range    = (0.70, 1.20),
    nx=35, ny=28,
    x_label_fn = lambda m: (
        f"Liquid yield multiplier\n"
        f"(base ~ {m['base_yield']*100:.0f} wt%;  "
        f"range {m['base_yield']*0.65*100:.0f}-{m['base_yield']*1.30*100:.0f} wt%)"
    ),
    y_label_fn = lambda m: (
        f"On-stream factor multiplier\n"
        f"(base ~ {m['base_days']} days/yr;  "
        f"range {int(m['base_days']*0.70)}-{int(m['base_days']*1.20)} days/yr)"
    ),
    title    = ("MFSP Contour: Pyrolysis Liquid Yield x On-Stream Factor  [$/kg SAF]\n"
                "All 6 Configurations — 2023 USD (CEPCI 797.9)  |  * = base case"),
    out_name = "contour_yield_vs_onstream.pdf",
)


# ════════════════════════════════════════════════════════════════════════════
# Figure 2: Liquid yield × Total installed capital
# ════════════════════════════════════════════════════════════════════════════
print("[Figure 2] Liquid yield x Total installed capital")
draw_contour_figure(
    x_key      = "liq_yield_mult",
    y_key      = "tpec_mult",
    x_range    = (0.65, 1.30),
    y_range    = (0.70, 1.30),
    nx=35, ny=28,
    x_label_fn = lambda m: (
        f"Liquid yield multiplier  (base ~ {m['base_yield']*100:.0f} wt%)"
    ),
    y_label_fn = lambda _: "Total installed capital multiplier  (+-30% of base TPEC)",
    title    = ("MFSP Contour: Pyrolysis Liquid Yield x Installed Capital  [$/kg SAF]\n"
                "All 6 Configurations — 2023 USD (CEPCI 797.9)  |  * = base case"),
    out_name = "contour_yield_vs_capital.pdf",
)

# ════════════════════════════════════════════════════════════════════════════
# Figure 3 (Sc2 only): SPK price × Liquid yield
# ════════════════════════════════════════════════════════════════════════════
print("[Figure 3] SPK price x Liquid yield (Scenario 2 only)")
SC2_PANELS = [(2, "SMR"), (2, "SOEC"), (2, "Photocatalysis")]

draw_contour_figure(
    x_key      = "spk_price_mult",
    y_key      = "liq_yield_mult",
    x_range    = (0.60, 1.40),
    y_range    = (0.65, 1.30),
    nx=35, ny=28,
    x_label_fn = lambda _: (
        f"SPK price multiplier  (base = ${tm.SPK_PRICE_KG:.2f}/kg;  "
        f"range ${tm.SPK_PRICE_KG*0.60:.2f}-${tm.SPK_PRICE_KG*1.40:.2f}/kg)"
    ),
    y_label_fn = lambda m: (
        f"Liquid yield multiplier  (base ~ {m['base_yield']*100:.0f} wt%)"
    ),
    title    = (
        "MFSP Contour (Scenario 2): SPK Feedstock Price x Pyrolysis Liquid Yield\n"
        f"2023 USD (CEPCI 797.9)  |  * = base case  |  "
        f"Navy line = fossil jet (${FOSSIL_JET_KG:.2f}/kg SAF)"
    ),
    out_name   = "contour_sc2_spk_vs_yield.pdf",
    panel_set  = SC2_PANELS,
)

print("All contour plots complete.")
