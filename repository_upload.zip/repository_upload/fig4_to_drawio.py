"""Export the revised Fig. 4 (well-to-wake system boundary) as an editable draw.io diagram.
Re-uses the panel() layout of make_fig4_boundary.py: every box, arrow and label becomes a draw.io object.
Arrows that start or end on a box are connected to it, so they follow the box when it is moved.

    python fig4_to_drawio.py [make_fig4_boundary.py] [output.drawio]
"""
import sys, re, html
from xml.sax.saxutils import escape

SRC = sys.argv[1] if len(sys.argv) > 1 else "make_fig4_boundary.py"
OUT = sys.argv[2] if len(sys.argv) > 2 else "Fig4_LCA_system_boundary_WTW.drawio"
S = 12.0            # px per layout unit
PANEL_H = 60
GAP = 2             # units between panels
PT = 2.3            # px per matplotlib point at this scale

cells, boxes = [], []
_id = [1]


def nid():
    _id[0] += 1
    return f"c{_id[0]}"


class Ctx:
    yoff = 0.0   # layout units, added downward


def X(x): return round(x * S, 1)
def Y(y): return round((PANEL_H - y + Ctx.yoff) * S, 1)


def lab(t):
    return escape(t).replace("\n", "&lt;br&gt;")


def esc_attr(s):
    return s.replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;").replace(">", "&gt;")


def vertex(text, x, y, w, h, style):
    i = nid()
    cells.append(f'<mxCell id="{i}" value="{esc_attr(text.replace(chr(10), "<br>"))}" style="{style}" vertex="1" parent="1">'
                 f'<mxGeometry x="{X(x)}" y="{Y(y + h)}" width="{round(w * S, 1)}" height="{round(h * S, 1)}" as="geometry"/></mxCell>')
    return i


def box(ax, x, y, w, h, text, fc, tc="white", bold=True, fs=6.0, ec=None, ls="-", style=None):
    st = (f"rounded=1;arcSize=12;whiteSpace=wrap;html=1;fillColor={fc};strokeColor={ec or fc};fontColor={tc};"
          f"fontSize={round(fs * PT, 1)};fontStyle={1 if bold else 0};fontFamily=Arial;spacing=2;"
          + ("dashed=1;" if ls != "-" else "") + ("fillColor=none;" if fc == "white" else ""))
    i = vertex(text, x, y, w, h, st)
    boxes.append((i, x, y + Ctx.yoff * 0, w, h, Ctx.yoff))
    return (x, y, w, h)


def _attach(pt):
    """Return (cell id, relX, relY) if pt lies on the border of a box in the current panel."""
    px, py = pt
    for i, x, y, w, h, off in boxes:
        if off != Ctx.yoff:
            continue
        tol = 0.25
        if x - tol <= px <= x + w + tol and y - tol <= py <= y + h + tol:
            on_edge = (abs(px - x) < tol or abs(px - x - w) < tol or abs(py - y) < tol or abs(py - y - h) < tol)
            if on_edge:
                return i, min(max((px - x) / w, 0), 1), min(max(1 - (py - y) / h, 0), 1)
    return None


def edge(pts, color="#404040", ls="-", lw=0.9, head=True):
    i = nid()
    src, tgt = _attach(pts[0]), _attach(pts[-1])
    st = (f"edgeStyle=none;html=1;rounded=0;strokeColor={color};strokeWidth={round(lw * 1.6, 2)};"
          + (f"endArrow=block;endFill=1;endSize=5;" if head else "endArrow=none;")
          + ("dashed=1;dashPattern=6 4;" if ls not in ("-", "solid") else ""))
    attrs = ""
    if src:
        attrs += f' source="{src[0]}"'; st += f"exitX={src[1]:.3f};exitY={src[2]:.3f};exitDx=0;exitDy=0;exitPerimeter=0;"
    if tgt:
        attrs += f' target="{tgt[0]}"'; st += f"entryX={tgt[1]:.3f};entryY={tgt[2]:.3f};entryDx=0;entryDy=0;entryPerimeter=0;"
    way = "".join(f'<mxPoint x="{X(p[0])}" y="{Y(p[1])}"/>' for p in pts[1:-1])
    geo = (f'<mxGeometry relative="1" as="geometry">'
           + ("" if src else f'<mxPoint x="{X(pts[0][0])}" y="{Y(pts[0][1])}" as="sourcePoint"/>')
           + ("" if tgt else f'<mxPoint x="{X(pts[-1][0])}" y="{Y(pts[-1][1])}" as="targetPoint"/>')
           + (f'<Array as="points">{way}</Array>' if way else "") + "</mxGeometry>")
    cells.append(f'<mxCell id="{i}" style="{st}" edge="1" parent="1"{attrs}>{geo}</mxCell>')


def arrow(ax, p, q, color="#404040", ls="-", lw=0.9, label=None, lpos=0.5, loff=(0, 1.0), lc=None, fs=5.4, conn="arc3", ha="center"):
    edge([p, q], color, ls, lw, True)
    if label:
        x = p[0] + (q[0] - p[0]) * lpos + loff[0]; y = p[1] + (q[1] - p[1]) * lpos + loff[1]
        ax.text(x, y, label, ha=ha, va="center", fontsize=fs, color=lc or color, style="italic")


def poly(ax, pts, color, ls="-", lw=0.9):
    edge(list(pts), color, ls, lw, True)


class Rectangle:
    def __init__(self, xy, w, h, fill=True, fc="none", ec="none", lw=0.9, ls="-", zorder=0):
        self.xy, self.w, self.h, self.fc, self.ec, self.ls = xy, w, h, (fc if fill else "none"), ec, ls


class Ax:
    def set_xlim(self, *a): pass
    def set_ylim(self, *a): pass
    def axis(self, *a): pass

    def add_patch(self, r):
        dashed = r.ls not in ("-", "solid")
        st = (f"rounded=0;html=1;fillColor={r.fc};strokeColor={r.ec};" + ("dashed=1;dashPattern=8 4;" if dashed else "")
              + "strokeWidth=1.4;movable=1;")
        i = nid()
        # backgrounds go first so they sit behind everything
        cells.insert(0, f'<mxCell id="{i}" value="" style="{st}" vertex="1" parent="1"><mxGeometry x="{X(r.xy[0])}" '
                        f'y="{Y(r.xy[1] + r.h)}" width="{round(r.w * S, 1)}" height="{round(r.h * S, 1)}" as="geometry"/></mxCell>')

    def plot(self, xs, ys, color="#404040", lw=0.9, ls="-", zorder=2, **k):
        edge([(xs[0], ys[0]), (xs[1], ys[1])], color, ls, lw, head=False)

    def text(self, x, y, s, ha="left", va="baseline", fontsize=6.0, color="#000000", fontweight="normal", style="normal",
             zorder=None, linespacing=1.2, rotation=0, **k):
        lines = s.split("\n")
        fs_px = fontsize * PT
        w = max(len(l) for l in lines) * fontsize * 0.62 / S * PT + 1.0     # layout units
        h = len(lines) * fs_px * 1.25 / S + 0.4
        x0 = x if ha == "left" else (x - w / 2 if ha == "center" else x - w)
        if va in ("center", "center_baseline"): y0 = y - h / 2
        elif va == "bottom": y0 = y
        elif va == "top": y0 = y - h
        else: y0 = y - 0.25 * h
        fstyle = (1 if fontweight == "bold" else 0) + (2 if style == "italic" else 0)
        st = (f"text;html=1;whiteSpace=wrap;align={ha if ha in ('left', 'center', 'right') else 'left'};verticalAlign=middle;"
              f"fontSize={round(fs_px, 1)};fontColor={color};fontStyle={fstyle};fontFamily=Arial;spacing=0;")
        vertex(s, x0, y0, w, h, st)


# ---- pull panel() and the constants out of the figure script and run them on the draw.io recorder ----
src = open(SRC, encoding="utf-8").read()
consts = src[src.index("C_IN, C_PROC"):src.index("def box(")]
lambdas = src[src.index("R = lambda"):src.index("def panel(")]
panel_src = src[src.index("def panel("):src.index("fig, axes")]
ns = {"box": box, "arrow": arrow, "poly": poly, "Rectangle": Rectangle}
exec(consts, ns); exec(lambdas, ns); exec(panel_src, ns)

ax = Ax()
for k, sc in enumerate((1, 2)):
    Ctx.yoff = k * (PANEL_H + GAP)
    ns["panel"](ax, sc)

# ---- legend ----
Ctx.yoff = PANEL_H + GAP   # same frame as panel 2; legend sits just below it
items = [("material flow", "#404040", "-"), ("fuel product (1 MJ)", "#2E7D32", "-"), ("hydrogen", "#1565C0", "-"),
         ("energy / utility", "#E07B39", "--"), ("fossil CO₂ (counted)", "#C62828", "-"),
         ("avoided burden (credit)", "#2E7D32", "--"), ("excluded / not counted", "#9E9E9E", "--")]
x = 2.0
for name, col, ls in items:
    edge([(x, -2.0), (x + 3.5, -2.0)], col, ls, 1.0, head=False)
    ax.text(x + 4.0, -2.0, name, ha="left", va="center", fontsize=5.4, color="#333333")
    x += 4.5 + len(name) * 0.55 * 5.4 * PT / S * 0.75 + 1.5

W, H = int(101 * S), int((2 * (PANEL_H + GAP) + 6) * S)
xml = (f'<mxfile host="app.diagrams.net"><diagram name="Fig4 WTW boundary" id="fig4">'
       f'<mxGraphModel dx="{W}" dy="{H}" grid="1" gridSize="6" guides="1" tooltips="1" connect="1" arrows="1" fold="1" '
       f'page="1" pageScale="1" pageWidth="{W}" pageHeight="{H}" math="0" shadow="0"><root><mxCell id="0"/>'
       f'<mxCell id="1" parent="0"/>' + "".join(cells) + "</root></mxGraphModel></diagram></mxfile>")
open(OUT, "w", encoding="utf-8").write(xml)
print("wrote", OUT, len(cells), "objects")
