"""
R1_sensitivity_runs.py  --  one command for every scenario/audit case the response letter needs (R1 update 15).

    python R1_sensitivity_runs.py              # all cases  (~1 min per case)
    python R1_sensitivity_runs.py base soec_2500 # selected cases

Each case runs in a fresh Python process with its own environment variables (hydrogen_production.py and compounds.py
read their switches at import time), simulates all six configurations with BioSTEAM and prices them with
tea_model.run_tea. Nothing in the main output folders is overwritten.

Output: R1_outputs/R1_sensitivity_cases.csv   (one row per case x configuration; NEW scenario labels)
        R1_outputs/R1_mfsp_breakdown_base.csv  (MFSP decomposition of the base case: replaces the stale mfsp.csv)
"""
import os, sys, json, subprocess

ROOT = os.path.dirname(os.path.abspath(__file__))
SCRIPTS = os.path.join(ROOT, "tea_20260605_1634", "scripts")
OUT = os.path.join(ROOT, "R1_outputs"); os.makedirs(OUT, exist_ok=True)

CASES = {
    "base":               {},
    "submitted_opex":     {"LABOR_MODE": "fci", "CATALYST_ANNUAL_FRAC": "0"},            # labour 5 % FCI, no catalyst repl.
    "tax_25pct":          {"INCOME_TAX": "0.25"},                                       # 21 % federal + state
    "soec_1000_per_kW":   {"SOEC_CAPEX_USD_PER_KW": "1000"},                            # audit R1.10 - cite source
    "soec_2500_per_kW":   {"SOEC_CAPEX_USD_PER_KW": "2500"},
    "smr_ref_30M":        {"SMR_REF_COST_USD": "30000000"},                             # installed SMR+PSA at 1,000 kg H2/h
    "photo_irr_250":      {"PHOTO_IRRADIANCE_W_M2": "250"},                             # annual-mean irradiance sizing
    "oil_0.46":           {"OIL_PRICE_KG": "0.46"},
    "oil_0.92":           {"OIL_PRICE_KG": "0.92"},
    "ps_0.15":            {"PS_PRICE_KG": "0.15"},
    "ps_0.70":            {"PS_PRICE_KG": "0.70"},
    "spk_1.80":           {"SPK_PRICE_KG": "1.80"},
    "spk_2.90":           {"SPK_PRICE_KG": "2.90"},
    "blend_12vol":        {"SC2_BLEND_VOL_PCT": "12"},
    "blend_20vol":        {"SC2_BLEND_VOL_PCT": "20"},
    "blend_25vol":        {"SC2_BLEND_VOL_PCT": "25"},
    "extrap_ratio_3.4":   {"SC1_CASE": "Extrap34"},                                     # EXTRAPOLATED beyond Li's 2.5
    "submitted_ratio_60_40": {"OIL_TO_PS_RATIO": "0.6667"},                             # yields still Li 2.5: indicative only
}
NEW = {1: "S2 co-hydropyrolysis", 2: "S1 PS-only + SPK blend"}
H2S = {"SMR": "SMR", "SOEC": "SOEC", "Photocatalysis": "Photo"}


def worker():
    sys.path[:0] = [ROOT, SCRIPTS]
    import warnings; warnings.filterwarnings("ignore")
    import matplotlib; matplotlib.use("Agg")
    import tea_model as tm
    rows = []
    for sc in (2, 1):
        for h2 in ("SMR", "SOEC", "Photocatalysis"):
            cfg = tm.simulate_config(sc, h2); t = tm.run_tea(cfg)
            lhv = tm.SAF_LHV_MJ_KG if sc == 1 else tm.BLEND_LHV_MJ_KG
            rows.append(dict(scenario=f"{NEW[sc]} + {H2S[h2]}", internal_id=f"Sc{sc}_{h2}",
                             product_kg_hr=cfg["saf_kg_hr"], H2_kg_hr=cfg["H2_demand"], LHV_MJ_kg=lhv,
                             TPEC_MM=cfg["tpec"] / 1e6, FCI_MM=t["FCI"] / 1e6, TCI_MM=t["TCI"] / 1e6,
                             FOC_MM_yr=t["FOC_annual_MM"], VOC_MM_yr=t["VOC_annual_MM"],
                             MFSP_usd_kg=t["mfsp_per_kg"], MFSP_usd_GJ=t["mfsp_per_kg"] / lhv * 1000,
                             MFSP_usd_GGE=t["mfsp_gge"], vs_parity_1p09_pct=100 * (t["mfsp_per_kg"] / 1.09 - 1),
                             feedstock=t["feedstock_contr"], capital=t["capital_contr"], fixed_operating=t["foc_contr"],
                             utilities_incl_catalyst=t["utility_contr"], coproduct_credit=t["byproduct_credit"],
                             catalyst_usd_kg=cfg.get("catalyst_cost_hr", 0.0) / max(cfg["saf_kg_hr"], 1e-9)))
    print("@@JSON@@" + json.dumps(rows))


def main(selected):
    import pandas as pd
    allrows = []
    for name in selected:
        env = dict(os.environ); env.update(CASES[name])
        print(f"[{name}] {CASES[name] or 'defaults'} ...", flush=True)
        p = subprocess.run([sys.executable, os.path.abspath(__file__), "--worker"], env=env, cwd=ROOT,
                           capture_output=True, text=True)
        line = next((l for l in p.stdout.splitlines() if l.startswith("@@JSON@@")), None)
        if line is None:
            print(p.stdout[-2000:], p.stderr[-3000:]); continue
        for r in json.loads(line[8:]):
            allrows.append({"case": name, "env": json.dumps(CASES[name]), **r})
        d = pd.DataFrame(allrows)
        d.to_csv(os.path.join(OUT, "R1_sensitivity_cases.csv"), index=False)
        if name == "base":
            d[d.case == "base"].to_csv(os.path.join(OUT, "R1_mfsp_breakdown_base.csv"), index=False)
        print(d[d.case == name][["scenario", "MFSP_usd_kg", "MFSP_usd_GJ", "vs_parity_1p09_pct"]].round(2).to_string(index=False))
    print("\nWritten:", os.path.join(OUT, "R1_sensitivity_cases.csv"))


if __name__ == "__main__":
    if "--worker" in sys.argv:
        worker()
    else:
        sel = [a for a in sys.argv[1:] if a in CASES] or list(CASES)
        main(sel)
