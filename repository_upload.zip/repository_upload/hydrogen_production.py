# hydrogen_production.py
# Modular hydrogen production: SMR | Photocatalysis | SOEC

import biosteam as bst

# ----- R1 (reviewer R1.10) audit switches: defaults reproduce the submitted model -----
# Set env vars to test audited costs, e.g.  SOEC_CAPEX_USD_PER_KW=1500  SMR_CAPEX_USD_PER_KG_H2_H=
# PHOTO_IRRADIANCE_W_M2=250  (annual-mean irradiance instead of the 1000 W/m2 peak).
import os as _os
_SOEC_USD_PER_KW = _os.environ.get("SOEC_CAPEX_USD_PER_KW")          # UNINSTALLED system cost $/kW(el) (stack+power electronics+compression); tea_model then applies the Peters-Timmerhaus factors (FCI = 4.71 x TPEC), so do NOT enter an installed cost. Submitted ~ $106/kW
_SMR_REF_COST    = _os.environ.get("SMR_REF_COST_USD")               # UNINSTALLED SMR+PSA+WGS equipment cost at 1,000 kg H2/h (installation factors are applied in tea_model)
_PHOTO_IRR       = float(_os.environ.get("PHOTO_IRRADIANCE_W_M2", 1000.0))


# ============================================================
# (a) Steam Methane Reforming (SMR)
# ============================================================
class SMR_H2Unit(bst.Unit):
    """
    Steam Methane Reforming hydrogen production unit.

    Reactions:
        CH4 + H2O  → CO  + 3H2     (reforming,  ΔH = +206 kJ/mol)
        CO  + H2O  → CO2 + H2      (WGS,        ΔH =  -41 kJ/mol)
    Net: CH4 + 2H2O → CO2 + 4H2   (ΔH = +165 kJ/mol)

    Parameters
    ----------
    H2_demand : float
        Required H2 flow rate in kg/hr.
    CH4_price : float
        Natural gas price in USD/GJ. Default 4.0.
    """

    _N_ins  = 2   # methane, steam
    _N_outs = 2   # hydrogen, CO2/flue gas

    CH4_MW = 16.04
    H2_MW  =  2.016
    H2_per_CH4_mass = (4 * 2.016) / 16.04   # kg H2 / kg CH4 ≈ 0.503

    SMR_EFFICIENCY = 0.78
    CAPEX_COEFF    = (float(_SMR_REF_COST) / 1.40 if _SMR_REF_COST else 4_500_000, 1000, 0.65)  # /1.40: sum of the three cost lines
    NG_INTENSITY_GJ_per_kgH2 = 0.18          # GJ consumed per kg H2 produced

    def __init__(self, ID='', ins=(), outs=(), H2_demand=100.0, CH4_price=4.0):
        super().__init__(ID, ins, outs)
        self.H2_demand = H2_demand   # kg/hr
        self.CH4_price = CH4_price   # USD/GJ
        self._utility_cost_hr = 0.0

    def _run(self):
        methane, steam = self.ins
        hydrogen, flue = self.outs

        H2_kg      = self.H2_demand
        CH4_needed = H2_kg / (self.H2_per_CH4_mass * self.SMR_EFFICIENCY)
        H2O_needed = CH4_needed * (2 * 18.015 / self.CH4_MW)

        methane.set_flow(CH4_needed, 'kg/hr', 'Methane')
        steam.set_flow(H2O_needed,   'kg/hr', 'Water')
        hydrogen.set_flow(H2_kg,     'kg/hr', 'Hydrogen')

        CO2_kg = CH4_needed * (44.01 / self.CH4_MW)
        flue.set_flow(CO2_kg, 'kg/hr', 'CarbonDioxide')

    def _design(self):
        base, ref, exp = self.CAPEX_COEFF
        self.purchase_costs['SMR reactor & PSA'] = base * (self.H2_demand / ref) ** exp
        self.purchase_costs['Heat exchangers']   = base * 0.25 * (self.H2_demand / ref) ** exp
        self.purchase_costs['WGS reactor']       = base * 0.15 * (self.H2_demand / ref) ** exp

    def _cost(self):
        ng_flow_GJ_hr = self.H2_demand * self.NG_INTENSITY_GJ_per_kgH2
        self._utility_cost_hr = ng_flow_GJ_hr * self.CH4_price

    @property
    def CO2_emissions_kg_per_kgH2(self):
        return 44.01 / (self.CH4_MW * self.H2_per_CH4_mass * self.SMR_EFFICIENCY)   # R1 fix: was '/ 4' (gave 28 instead of 7.0 kg CO2/kg H2); TEA dashboard only, LCA uses 9.0


# ============================================================
# (b) Photocatalytic Water Splitting
# ============================================================
class Photocatalysis_H2Unit(bst.Unit):
    """
    Solar photocatalytic water splitting for hydrogen production.

    Reaction:  H2O → H2 + 0.5 O2   (solar driven, ΔG = +237 kJ/mol)
    Solar-to-hydrogen (STH) efficiency: 5% (TiO2-based state-of-art).

    Parameters
    ----------
    H2_demand : float
        Required H2 flow rate in kg/hr.
    solar_irradiance : float
        Solar irradiance in W/m2. Default 1000 (standard test condition).
    STH_efficiency : float
        Solar-to-hydrogen efficiency fraction. Default 0.05.
    electricity_price : float
        USD/kWh for auxiliary power. Default 0.07.
    """

    _N_ins  = 1   # water
    _N_outs = 2   # hydrogen, oxygen

    H2_HHV_kJ_per_kg = 142_000
    H2O_MW = 18.015
    H2_MW  =  2.016
    CAPEX_PER_M2 = 250   # USD/m2 installed (near-future optimistic)

    def __init__(self, ID='', ins=(), outs=(), H2_demand=100.0,
                 solar_irradiance=_PHOTO_IRR, STH_efficiency=0.05,
                 electricity_price=0.07):
        super().__init__(ID, ins, outs)
        self.H2_demand         = H2_demand
        self.solar_irradiance  = solar_irradiance
        self.STH_efficiency    = STH_efficiency
        self.electricity_price = electricity_price
        self._utility_cost_hr  = 0.0

    @property
    def required_area_m2(self):
        H2_power_kW    = self.H2_demand * self.H2_HHV_kJ_per_kg / 3600
        solar_power_kW = H2_power_kW / self.STH_efficiency
        return solar_power_kW * 1000 / self.solar_irradiance

    def _run(self):
        water = self.ins[0]
        hydrogen, oxygen = self.outs

        H2_kg       = self.H2_demand
        H2O_needed  = H2_kg * (self.H2O_MW / self.H2_MW)
        O2_produced = H2_kg * (16.0 / self.H2_MW)

        water.set_flow(H2O_needed,   'kg/hr', 'Water')
        hydrogen.set_flow(H2_kg,     'kg/hr', 'Hydrogen')
        oxygen.set_flow(O2_produced, 'kg/hr', 'Oxygen')

    def _design(self):
        area = self.required_area_m2
        self.purchase_costs['Photocatalytic panels'] = area * self.CAPEX_PER_M2
        self.purchase_costs['Water treatment']       = area * self.CAPEX_PER_M2 * 0.10
        self.purchase_costs['H2 separation (PC)']    = area * self.CAPEX_PER_M2 * 0.15
        self.design_results['Solar area (m2)']       = area
        self.design_results['STH efficiency (%)']    = self.STH_efficiency * 100

    def _cost(self):
        aux_elec_kW = self.H2_demand * 5
        self._utility_cost_hr = aux_elec_kW * self.electricity_price

    @property
    def CO2_emissions_kg_per_kgH2(self):
        return 0.05   # kg CO2/kg H2 (indirect from auxiliary electricity only)


# ============================================================
# (c) Solid Oxide Electrolysis Cell (SOEC) from NG electricity
# ============================================================
class SOEC_H2Unit(bst.Unit):
    """
    Solid Oxide Electrolysis Cell hydrogen production powered by NGCC electricity.

    Reaction:  H2O → H2 + 0.5 O2   (electrolytic, 700–900 °C)
    SOEC energy efficiency: 85% HHV basis.
    NGCC CO2 factor: 0.49 kg CO2/kWh (US EPA eGRID).

    Parameters
    ----------
    H2_demand : float
        Required H2 flow rate in kg/hr.
    electricity_price : float
        USD/kWh (NGCC-sourced). Default 0.06.
    """

    _N_ins  = 2   # water, electricity (placeholder stream)
    _N_outs = 2   # hydrogen, oxygen

    H2_HHV_kJ_per_kg = 142_000
    SOEC_EFFICIENCY   = 0.85
    NGCC_CO2_FACTOR   = 0.49      # kg CO2/kWh
    # /1.30 because stack + 20% power electronics + 10% compression are summed in _design
    CAPEX_COEFF       = ((float(_SOEC_USD_PER_KW) * 46_400 / 1.30) if _SOEC_USD_PER_KW else 3_800_000, 1000, 0.65)  # 46,400 kW per 1,000 kg H2/h

    @property
    def kWh_per_kgH2(self):
        return (self.H2_HHV_kJ_per_kg / 3600) / self.SOEC_EFFICIENCY   # ≈ 46.4 kWh/kg

    def __init__(self, ID='', ins=(), outs=(), H2_demand=100.0,
                 electricity_price=0.06):
        super().__init__(ID, ins, outs)
        self.H2_demand         = H2_demand
        self.electricity_price = electricity_price
        self._utility_cost_hr  = 0.0

    def _run(self):
        water, _ = self.ins
        hydrogen, oxygen = self.outs

        H2_kg       = self.H2_demand
        H2O_needed  = H2_kg * (18.015 / 2.016)
        O2_produced = H2_kg * (16.0 / 2.016)

        water.set_flow(H2O_needed,   'kg/hr', 'Water')
        hydrogen.set_flow(H2_kg,     'kg/hr', 'Hydrogen')
        oxygen.set_flow(O2_produced, 'kg/hr', 'Oxygen')

    def _design(self):
        base, ref, exp = self.CAPEX_COEFF
        self.purchase_costs['SOEC stack']            = base * (self.H2_demand / ref) ** exp
        self.purchase_costs['Power electronics']     = base * 0.20 * (self.H2_demand / ref) ** exp
        self.purchase_costs['H2 compression (SOEC)'] = base * 0.10 * (self.H2_demand / ref) ** exp
        self.design_results['Power demand (kW)']     = self.H2_demand * self.kWh_per_kgH2

    def _cost(self):
        power_kW = self.H2_demand * self.kWh_per_kgH2
        self._utility_cost_hr = power_kW * self.electricity_price

    @property
    def CO2_emissions_kg_per_kgH2(self):
        return self.kWh_per_kgH2 * self.NGCC_CO2_FACTOR
