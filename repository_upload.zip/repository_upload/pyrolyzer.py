# pyrolyzer.py
# Pyrolysis unit module — supports Scenario 1 (co-feed) and Scenario 2 (PS-only)

import biosteam as bst
from compounds import (
    SCENARIO1_PYRO_YIELDS, SCENARIO1_LIQUID_FRACTION,
    SCENARIO1_CHAR_FRACTION, SCENARIO1_GAS_FRACTION,
    SCENARIO2_PYRO_YIELDS, SCENARIO2_LIQUID_FRACTION,
    SCENARIO2_CHAR_FRACTION, SCENARIO2_GAS_FRACTION,
)


class Pyrolyzer(bst.Unit):
    """
    Two-stage fixed-bed pyrolysis reactor for PS and/or waste cooking oil feedstocks.

    Parameters
    ----------
    ID : str
        Unit identifier.
    ins : list
        ins[0] = PS feed stream, ins[1] = waste oil stream (Scenario 1 only).
    outs : list
        outs[0] = pyrolysis oil, outs[1] = char, outs[2] = gas.
    scenario : int
        1 = aromatization-free co-hydropyrolysis (Li et al., 2024).
        2 = PS-only aromatic SAF additive (Prajapati et al., 2024).
    T_pyrolysis : float
        Pyrolysis temperature in °C. Defaults to 480 (Sc1, Li et al.) or 400 (Sc2, Prajapati et al.; R1 - was 550).
    pressure_H2 : float
        H2 partial pressure in MPa (Scenario 1 only). Default 0.15 MPa.
    """

    _N_ins  = 2
    _N_outs = 3

    # Capital cost: C = base_cost * (capacity / ref_capacity) ** exponent
    # Basis: CEPCI 800 (2023), Peters & Timmerhaus sizing correlation
    _purchase_cost_coefficients = {
        'Pyrolyzer vessel':    (850_000, 1000, 0.65),
        'Heat exchanger feed': (120_000,  500, 0.60),
        'Condenser':           (180_000,  500, 0.65),
        'Char separator':      ( 60_000,  500, 0.55),
    }

    def __init__(self, ID='', ins=(), outs=(), scenario=1,
                 T_pyrolysis=None, pressure_H2=0.15):
        super().__init__(ID, ins, outs)
        self.scenario    = scenario
        self.pressure_H2 = pressure_H2
        self.T_pyrolysis = T_pyrolysis if T_pyrolysis else (480 if scenario == 1 else 400)   # R1: PS-only route at 400 C (Prajapati et al.); submitted 550 C

    def _run(self):
        ps_feed, oil_feed = self.ins
        pyro_oil, char, gas = self.outs

        total_feed_kg = ps_feed.F_mass + oil_feed.F_mass   # kg/hr

        if self.scenario == 1:
            yields   = SCENARIO1_PYRO_YIELDS
            liq_frac = SCENARIO1_LIQUID_FRACTION
            chr_frac = SCENARIO1_CHAR_FRACTION
            gas_frac = SCENARIO1_GAS_FRACTION
        else:
            yields   = SCENARIO2_PYRO_YIELDS
            liq_frac = SCENARIO2_LIQUID_FRACTION
            chr_frac = SCENARIO2_CHAR_FRACTION
            gas_frac = SCENARIO2_GAS_FRACTION

        liq_mass = total_feed_kg * liq_frac
        chr_mass = total_feed_kg * chr_frac
        gas_mass = total_feed_kg * gas_frac

        pyro_oil.empty()
        for species, frac in yields.items():
            pyro_oil.set_flow(liq_mass * frac, 'kg/hr', species)
        pyro_oil.T = self.T_pyrolysis + 273.15
        pyro_oil.P = (self.pressure_H2 * 1e6) if self.scenario == 1 else 101325

        char.empty()
        char.set_flow(chr_mass, 'kg/hr', 'Char')
        char.phase = 's'
        char.T = 298.15

        # Simplified gas: 60% CH4, 30% CO2, 10% H2 by mass
        gas.empty()
        gas.set_flow(gas_mass * 0.60, 'kg/hr', 'Methane')
        gas.set_flow(gas_mass * 0.30, 'kg/hr', 'CarbonDioxide')
        gas.set_flow(gas_mass * 0.10, 'kg/hr', 'Hydrogen')
        gas.T = self.T_pyrolysis + 273.15

    def _design(self):
        total_feed = self.F_mass_in
        for equip, (base_cost, ref_cap, exp) in self._purchase_cost_coefficients.items():
            self.purchase_costs[equip] = base_cost * (total_feed / ref_cap) ** exp

    def _cost(self):
        # Natural gas heating duty: ~1500 kJ/kg feed
        total_feed = self.F_mass_in
        heat_duty_kJ_hr = total_feed * 1500   # kJ/hr — add_heat_utility expects kJ/hr, not kW
        self.add_heat_utility(heat_duty_kJ_hr, T_in=298.15, T_out=self.T_pyrolysis + 273.15)
