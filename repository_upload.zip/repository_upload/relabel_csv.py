"""Swap scenario labels Sc1<->Sc2 (R1.14) in BioSTEAM output CSVs. Run ONCE after a full model rerun:
    python relabel_csv.py tea_20260605_1634/data
Writes a .relabelled marker to prevent double-swapping. Product-stream ids (saf / eb_spk_blend) are not renamed."""
import sys, os, re, glob, pandas as pd
d = sys.argv[1]; marker = os.path.join(d, ".relabelled")
if os.path.exists(marker): sys.exit("already relabelled")
sw = lambda v: re.sub(r"Sc([12])", lambda m: "Sc" + {"1": "2", "2": "1"}[m.group(1)], v) if isinstance(v, str) else v
for f in glob.glob(os.path.join(d, "*.csv")):
    df = pd.read_csv(f)
    if "scenario" in df.columns: df["scenario"] = df["scenario"].map(sw)
    if "config" in df.columns: df["config"] = df["config"].map(sw)
    df.to_csv(f, index=False)
open(marker, "w").write("done")
