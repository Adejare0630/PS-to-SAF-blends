"""
R1_replica_analysis.py - pre-rerun estimates of every TEA result the revised manuscript needs, from the validated
no-BioSTEAM replica (R1_tea_replica.py; reproduces the submitted MFSPs within $0.001/kg).
Outputs R1_outputs/replica/*.csv. Replace with the BioSTEAM outputs (R1_sensitivity_runs.py, run_R1_analysis.py)
before submission.

    python R1_replica_analysis.py
"""
import os, json, copy
import numpy as np
import pandas as pd
import R1_tea_replica as R
tm, cp = R.tm, R.cp

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "R1_outputs", "replica"); os.makedirs(OUT, exist_ok=True)
PAR = 1.09
CFGS = [(2, "SMR"), (2, "SOEC"), (2, "Photocatalysis"), (1, "SMR"), (1, "SOEC"), (1, "Photocatalysis")]
LAB = lambda sc, h2: f"{R.LABEL[sc]} + {h2 if h2 != 'Photocatalysis' else 'Photo'}"
lhv = lambda sc: tm.SAF_LHV_MJ_KG if sc == 1 else tm.BLEND_LHV_MJ_KG


def tea_row(sc, h2, c, t, case="base"):
    return dict(case=case, scenario=LAB(sc, h2), product_kg_h=c["saf_kg_hr"], TPEC_MM=c["tpec"] / 1e6, FCI_MM=t["FCI"] / 1e6,
                TCI_MM=t["TCI"] / 1e6, VOC_MM_yr=t["VOC_annual_MM"], FOC_MM_yr=t["FOC_annual_MM"], byproduct_MM_yr=t["byproduct_annual_MM"],
                MFSP_usd_kg=t["mfsp_per_kg"], MFSP_usd_GJ=t["mfsp_per_kg"] / lhv(sc) * 1000, MFSP_usd_GGE=t["mfsp_gge"],
                vs_parity_pct=100 * (t["mfsp_per_kg"] / PAR - 1), feedstock=t["feedstock_contr"], capital=t["capital_contr"],
                fixed_op=t["foc_contr"], utilities=t["utility_contr"], coproduct=t["byproduct_credit"])


def tea_tax(c, tax):
    cap = tm.peters_timmerhaus_capital(c["tpec"])
    voc = (c["utility_cost_hr"] + c["feedstock_cost_hr"]) * tm.OPERATING_HR
    return tm.dcfror_mfsp(cap["FCI"], cap["WC"], voc, tm.fixed_operating_cost(cap["FCI"]), c["saf_kg_hr"] * tm.OPERATING_HR,
                          c["byproduct_revenue_hr"] * tm.OPERATING_HR, income_tax=tax)


base = {}
rows = []
for sc, h2 in CFGS:
    c = R.build(sc, h2, "r1", R.R1_FLOWS[sc]); t = tm.run_tea(c)
    base[(sc, h2)] = (c, t); rows.append(tea_row(sc, h2, c, t))
pd.DataFrame(rows).to_csv(os.path.join(OUT, "tea_base.csv"), index=False)

# ---- equipment (TPEC) by area ----
pd.DataFrame([dict(scenario=LAB(sc, h2), **{k: v / 1e6 for k, v in base[(sc, h2)][0]["_pc"].items()}) for sc, h2 in CFGS]) \
    .to_csv(os.path.join(OUT, "tpec_by_area_MM.csv"), index=False)

# ---- price sweeps / breakevens (MFSP is linear in feedstock price) ----
be = []
for sc, h2 in CFGS:
    c, t = base[(sc, h2)]; P = c["saf_kg_hr"]; m0 = t["mfsp_per_kg"]
    d_oil = c["streams"]["oil_kg_hr"] / P; d_ps = c["streams"]["ps_kg_hr"] / P; d_spk = c["spk_kg_hr"] / P
    be.append(dict(scenario=LAB(sc, h2), MFSP=m0,
                   dMFSP_per_oil_usd=d_oil, breakeven_oil_usd_kg=(tm.OIL_PRICE_KG + (PAR - m0) / d_oil) if d_oil else None,
                   dMFSP_per_PS_usd=d_ps, breakeven_PS_usd_kg=tm.PS_PRICE_KG + (PAR - m0) / d_ps,
                   dMFSP_per_SPK_usd=d_spk, breakeven_SPK_usd_kg=(tm.SPK_PRICE_KG + (PAR - m0) / d_spk) if d_spk else None))
pd.DataFrame(be).to_csv(os.path.join(OUT, "breakevens.csv"), index=False)

# ---- implied cost of the PS-derived EB additive (Scenario 1) ----
add = R.R1_FLOWS[2]["product"] - R.R1_FLOWS[2]["spk"]
pd.DataFrame([dict(scenario=LAB(2, h2), additive_kg_h=add,
                   implied_additive_usd_kg=(base[(2, h2)][1]["mfsp_per_kg"] * R.R1_FLOWS[2]["product"] - tm.SPK_PRICE_KG * R.R1_FLOWS[2]["spk"]) / add)
              for h2 in ("SMR", "SOEC", "Photocatalysis")]).to_csv(os.path.join(OUT, "eb_additive_cost.csv"), index=False)

# ---- audit / scenario cases ----
cases = []
lab, cat = tm.LABOR_MODE, tm.CATALYST_ANNUAL_FRAC
for sc, h2 in CFGS:
    c, t = base[(sc, h2)]
    cases.append(dict(case="tax 25%", scenario=LAB(sc, h2), MFSP=tea_tax(c, 0.25)))
    tm.LABOR_MODE, tm.CATALYST_ANNUAL_FRAC = "fci", 0.0
    cases.append(dict(case="submitted opex (labour 5% FCI, no catalyst repl.)", scenario=LAB(sc, h2),
                      MFSP=tm.run_tea(R.build(sc, h2, "r1", R.R1_FLOWS[sc]))["mfsp_per_kg"] if True else None))
    tm.LABOR_MODE, tm.CATALYST_ANNUAL_FRAC = lab, cat
for sc in (2, 1):
    for usd_kw in (1000, 2500):
        c = R.build(sc, "SOEC", "r1", R.R1_FLOWS[sc])
        H2 = R.R1_FLOWS[sc]["h2"]
        new = R.pl(usd_kw * 46_400 / 1.30, 1000, 0.65, H2) * 1.30
        c["tpec"] += new - c["_pc"]["h2"]
        cases.append(dict(case=f"SOEC ${usd_kw}/kW (uninstalled)", scenario=LAB(sc, "SOEC"), MFSP=tm.run_tea(c)["mfsp_per_kg"]))
    c = R.build(sc, "SMR", "r1", R.R1_FLOWS[sc]); H2 = R.R1_FLOWS[sc]["h2"]
    c["tpec"] += R.pl(30e6 / 1.40, 1000, 0.65, H2) * 1.40 - c["_pc"]["h2"]
    cases.append(dict(case="SMR ref. cost $30M at 1,000 kg/h", scenario=LAB(sc, "SMR"), MFSP=tm.run_tea(c)["mfsp_per_kg"]))
    os.environ["PHOTO_IRRADIANCE_W_M2"] = "250"
    cases.append(dict(case="photocatalysis sized at 250 W/m2", scenario=LAB(sc, "Photocatalysis"),
                      MFSP=tm.run_tea(R.build(sc, "Photocatalysis", "r1", R.R1_FLOWS[sc]))["mfsp_per_kg"]))
    os.environ["PHOTO_IRRADIANCE_W_M2"] = "1000"
# equal product basis: Scenario 1 (physical 2) scaled to the Scenario 2 product rate
k = R.R1_FLOWS[1]["product"] / R.R1_FLOWS[2]["product"]
f_eq = {kk: (v * k if isinstance(v, float) else v) for kk, v in R.R1_FLOWS[2].items()}
for h2 in ("SMR", "SOEC", "Photocatalysis"):
    c = R.build(2, h2, "r1", f_eq); t = tm.run_tea(c)
    cases.append(dict(case=f"equal product basis (S1 x{k:.3f}, PS {250 * k:.0f} t/d)", scenario=LAB(2, h2), MFSP=t["mfsp_per_kg"]))
# blend share (Scenario 1)
for v in (12, 20, 25):
    w, lhv_b = cp.sc2_blend_params(v)
    spk = add * (1 - w) / w
    f_b = dict(R.R1_FLOWS[2]); f_b["spk"] = spk; f_b["product"] = add + spk
    for h2 in ("SMR",):
        c = R.build(2, h2, "r1", f_b); t = tm.run_tea(c)
        cases.append(dict(case=f"blend {v} vol% additive", scenario=LAB(2, h2), MFSP=t["mfsp_per_kg"], MFSP_GJ=t["mfsp_per_kg"] / lhv_b * 1000,
                          product_kg_h=add + spk))
cdf = pd.DataFrame(cases)
cdf = cdf.merge(pd.DataFrame(rows)[["scenario", "MFSP_usd_kg"]].rename(columns={"MFSP_usd_kg": "MFSP_base"}), on="scenario")
cdf["change_pct"] = 100 * (cdf.MFSP / cdf.MFSP_base - 1)
cdf.to_csv(os.path.join(OUT, "audit_cases.csv"), index=False)

# ---- one-at-a-time sensitivity over the sourced ranges + Monte Carlo ----
d = pd.read_csv(os.path.join(HERE, "R1_mc_distributions.csv"))
m = (d.key == "liq_yield_mult") & (d.applies_to == "sc1"); d.loc[m, "low"] = 0.65 / 0.84; d.loc[m, "high"] = 0.90 / 0.84
m = (d.key == "liq_yield_mult") & (d.applies_to == "sc2"); d.loc[m, "low"] = 0.76 / 0.96; d.loc[m, "high"] = 0.987 / 0.96
d["mean"] = (d.low + d["mode"] + d.high) / 3
d["sd"] = np.sqrt((d.low ** 2 + d["mode"] ** 2 + d.high ** 2 - d.low * d["mode"] - d.low * d.high - d["mode"] * d.high) / 18)
d.to_csv(os.path.join(OUT, "mc_distributions_used.csv"), index=False)


def tri_ppf(u, a, c, b):
    fc = (c - a) / (b - a) if b > a else 0.5
    return np.where(u < fc, a + np.sqrt(u * (b - a) * (c - a)), b - np.sqrt((1 - u) * (b - a) * (b - c)))


tor, mcs, conv = [], [], []
rng = np.random.default_rng(42)
for sc, h2 in CFGS:
    c, t = base[(sc, h2)]
    dd = d[d.applies_to.isin(["all", f"sc{sc}"])].reset_index(drop=True)
    m0 = t["mfsp_per_kg"]
    for r in dd.itertuples():
        lo = tm.sensitivity_mfsp(sc, h2, c, t, **{r.key: r.low}); hi = tm.sensitivity_mfsp(sc, h2, c, t, **{r.key: r.high})
        tor.append(dict(scenario=LAB(sc, h2), parameter=r.parameter, low_mult=r.low, high_mult=r.high, MFSP_low=lo, MFSP_high=hi,
                        swing=abs(hi - lo)))
    for N in ((1000, 3000) if h2 == "SMR" else (1000,)):
        U = (np.argsort(rng.random((N, len(dd))), axis=0) + rng.random((N, len(dd)))) / N      # Latin hypercube
        X = np.column_stack([tri_ppf(U[:, j], dd.low[j], dd["mode"][j], dd.high[j]) for j in range(len(dd))])
        vals = np.array([tm.sensitivity_mfsp(sc, h2, c, t, **{dd.key[j]: X[i, j] for j in range(len(dd))}) for i in range(N)])
        p = np.percentile(vals, [5, 25, 50, 75, 95])
        row = dict(scenario=LAB(sc, h2), N=N, base=m0, mean=vals.mean(), sd=vals.std(), P5=p[0], P25=p[1], P50=p[2], P75=p[3], P95=p[4],
                   prob_below_parity=(vals < PAR).mean())
        conv.append(row)
        if N == 1000:
            mcs.append(row)
            rk = lambda a: pd.Series(a).rank().values
            sp = {dd.parameter[j]: np.corrcoef(rk(X[:, j]), rk(vals))[0, 1] for j in range(len(dd))}
            mcs[-1]["spearman"] = json.dumps({k: round(v, 3) for k, v in sp.items()})
pd.DataFrame(tor).sort_values(["scenario", "swing"], ascending=[True, False]).to_csv(os.path.join(OUT, "tornado.csv"), index=False)
pd.DataFrame(mcs).to_csv(os.path.join(OUT, "mc_summary.csv"), index=False)
pd.DataFrame(conv).to_csv(os.path.join(OUT, "mc_convergence.csv"), index=False)

# ---- airline cost impact (R2.5) ----
air = []
for r in rows:
    prem = r["MFSP_usd_kg"] / PAR - 1
    for share in (0.10, 1.0):
        for fs in (0.25, 0.30):
            air.append(dict(scenario=r["scenario"], premium_pct=100 * prem, premium_usd_t=1000 * (r["MFSP_usd_kg"] - PAR),
                            blend_share=share, fuel_share=fs, opex_increase_pct=100 * prem * share * fs))
pd.DataFrame(air).to_csv(os.path.join(OUT, "airline_cost_impact.csv"), index=False)

pd.set_option("display.width", 250); pd.set_option("display.max_columns", 30)
print(pd.DataFrame(rows)[["scenario", "TPEC_MM", "FCI_MM", "TCI_MM", "VOC_MM_yr", "FOC_MM_yr", "MFSP_usd_kg", "MFSP_usd_GJ", "MFSP_usd_GGE",
                          "vs_parity_pct", "feedstock", "capital", "fixed_op", "utilities", "coproduct"]].round(3).to_string(index=False))
print(pd.DataFrame(be).round(3).to_string(index=False))
print(pd.read_csv(os.path.join(OUT, "eb_additive_cost.csv")).round(3).to_string(index=False))
print(cdf.round(3).to_string(index=False))
print(pd.DataFrame(mcs).drop(columns=["spearman"]).round(3).to_string(index=False))
print(pd.DataFrame(conv)[["scenario", "N", "P5", "P50", "P95"]].round(3).to_string(index=False))
tdf = pd.DataFrame(tor)
for s in tdf.scenario.unique():
    x = tdf[tdf.scenario == s].sort_values("swing", ascending=False).head(4)
    print(s, "|", "; ".join(f"{r.parameter} {r.MFSP_low:.2f}-{r.MFSP_high:.2f}" for r in x.itertuples()))
