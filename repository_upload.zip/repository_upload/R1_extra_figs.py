"""R1_extra_figs.py - remaining revised-manuscript figures and ESI tables (Update 20).
Outputs: R1_response/figs_R1/{Fig_TPEC_by_area, Fig_cashflow_NPV, Fig_literature_GJ, Fig_GWP_tornado, Fig_TRACI_heatmap}.png/.pdf
         R1_outputs/replica/{cashflow_payback.csv, gwp_tornado.csv}, R1_outputs/supplementary/R1_lca_inventory_per_MJ.csv
"""
import os, sys
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
import R1_supplementary as S          # installs module stubs, sets sys.path
import R1_tea_replica as R
import types
_src = open(os.path.join(HERE, "tea_20260605_1634", "scripts", "make_tornado.py"), encoding="utf-8").read().split("\n")
_a = next(i for i, l in enumerate(_src) if l.startswith("from make_lca import"))
_b = next(i for i, l in enumerate(_src) if l.startswith("def run_lca_sensitivity"))
MT = types.SimpleNamespace(); _ns = {"os": os, "sys": sys, "np": np, "pd": pd, "MODULE_DIR": HERE, "plt": __import__("matplotlib.pyplot").pyplot}
exec("\n".join(_src[_a:_b]).replace("os.makedirs(OUT_DIR, exist_ok=True)", ""), _ns); MT.__dict__.update(_ns)
tm = R.tm
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10})
FIG = os.path.join(HERE, "R1_response", "figs_R1"); REP = os.path.join(HERE, "R1_outputs", "replica"); SUP = os.path.join(HERE, "R1_outputs", "supplementary")
H2C = {"SMR": "#1f4e79", "SOEC": "#4a90c2", "Photocatalysis": "#e0a030"}
SHORT = {"SMR": "SMR", "SOEC": "SOEC", "Photocatalysis": "Photo"}
NAME = {2: "S1 PS-only", 1: "S2 co-hydropyrolysis"}
def save(f, n): f.savefig(os.path.join(FIG, n + ".png"), dpi=300, bbox_inches="tight"); f.savefig(os.path.join(FIG, n + ".pdf"), bbox_inches="tight"); plt.close(f)

# ---------- 1) TPEC by area ----------
tp = pd.read_csv(os.path.join(REP, "tpec_by_area_MM.csv")).fillna(0)
areas = [("pre", "Pretreatment"), ("pyr", "Pyrolysis"), ("hyd", "Hydrotreating"), ("bld", "Blending/distillation"), ("h2", "H$_2$ production")]
cols = ["#8da0cb", "#66c2a5", "#fc8d62", "#a6d854", "#e5c494"]
f, ax = plt.subplots(figsize=(7.2, 3.8)); y = np.arange(len(tp)); left = np.zeros(len(tp))
for (k, lab), c in zip(areas, cols):
    v = tp[k].values if k in tp else np.zeros(len(tp)); ax.barh(y, v, left=left, color=c, label=lab, edgecolor="white"); left += v
for i, t in enumerate(left): ax.text(t + 1.5, i, f"{t:.1f}", va="center", fontsize=9)
ax.set_yticks(y); ax.set_yticklabels(tp.scenario); ax.invert_yaxis(); ax.set_xlabel("Total purchased equipment cost (MM$, 2023 USD)")
ax.set_xlim(0, left.max() * 1.12); ax.legend(ncol=3, fontsize=8, loc="upper center", bbox_to_anchor=(0.5, -0.17), frameon=False)
ax.spines[["top", "right"]].set_visible(False); save(f, "Fig_TPEC_by_area")

# ---------- 2) cash flow / NPV / payback ----------
rows = []; f, axs = plt.subplots(1, 2, figsize=(10, 3.9), sharey=True)
for ax, price in zip(axs, (1.09, 1.31)):
    for sc in (1, 2):
        for h2 in ("SMR", "SOEC", "Photocatalysis"):
            c = R.build(sc, h2, "r1", R.R1_FLOWS[sc]); cap = tm.peters_timmerhaus_capital(c["tpec"])
            voc = (c["utility_cost_hr"] + c["feedstock_cost_hr"]) * tm.OPERATING_HR
            args = (cap["FCI"], cap["WC"], voc, tm.fixed_operating_cost(cap["FCI"]), c["saf_kg_hr"] * tm.OPERATING_HR, c["byproduct_revenue_hr"] * tm.OPERATING_HR, price)
            yrs, cf, cu, cd = tm.compute_cashflows(*args, income_tax=tm.INCOME_TAX)
            npv = cd[-1]; pb = next((yrs[i] for i in range(len(cu)) if yrs[i] > 0 and cu[i] >= 0), None)
            rows.append(dict(scenario=f"{NAME[sc]} + {SHORT[h2]}", price_usd_kg=price, NPV10_MM=npv / 1e6, payback_yr_after_startup=pb,
                             equity_MM=-sum(x for x in cf[:3]) / 1e6))
            ax.plot(yrs, cd / 1e6, color=H2C[h2], ls="-" if sc == 1 else "--", lw=1.6, label=f"{NAME[sc]} + {SHORT[h2]}")
    ax.axhline(0, color="k", lw=0.6); ax.set_title(f"Selling price ${price:.2f}/kg" + (" (Jet A parity)" if price == 1.09 else " (parity + 20%)"), fontsize=10)
    ax.set_xlabel("Project year"); ax.spines[["top", "right"]].set_visible(False)
axs[0].set_ylabel("Cumulative discounted cash flow at 10% (MM$)")
h, l = axs[0].get_legend_handles_labels(); f.legend(h, l, ncol=3, fontsize=8, loc="lower center", bbox_to_anchor=(0.5, -0.12), frameon=False)
save(f, "Fig_cashflow_NPV"); pd.DataFrame(rows).to_csv(os.path.join(REP, "cashflow_payback.csv"), index=False)

# ---------- 3) literature comparison, $/GJ ----------
tb = pd.read_csv(os.path.join(REP, "tea_base.csv"))
lit = [("Wang et al. (2026), plastics-to-jet, low", 1.0 / 43.2 * 1000), ("Wang et al. (2026), high", 1.8 / 43.2 * 1000),
       ("Rogachuk & Okolie (2024), $0.66/L", 0.66 / 0.80 / 43.0 * 1000), ("Rogachuk & Okolie (2024), $0.78/L", 0.78 / 0.80 / 43.0 * 1000)]
f, ax = plt.subplots(figsize=(7.2, 4.2))
labs = list(tb.scenario) + [a for a, _ in lit]; vals = list(tb.MFSP_usd_GJ) + [b for _, b in lit]
colr = [H2C[[k for k in H2C if SHORT[k] in s.split("+ ")[-1]][0]] for s in tb.scenario] + ["#999999"] * len(lit)
y = np.arange(len(labs)); ax.barh(y, vals, color=colr)
for i, v in enumerate(vals): ax.text(v + 0.5, i, f"{v:.1f}", va="center", fontsize=8.5)
par = 1.09 / 43.2 * 1000; ax.axvline(par, color="crimson", ls="--", lw=1); ax.text(par + 0.4, -0.65, f"Jet A parity \\$1.09/kg = {par:.1f} \\$/GJ", color="crimson", fontsize=8)
ax.set_yticks(y); ax.set_yticklabels(labs, fontsize=8.5); ax.set_ylim(len(labs) - 0.5, -1.1); ax.set_xlabel("Minimum selling price ($/GJ, LHV; literature values not escalated)")
ax.spines[["top", "right"]].set_visible(False); ax.set_xlim(0, max(vals) * 1.15); save(f, "Fig_literature_GJ")

# ---------- 4) GWP tornado (±20%) ----------
factors = MT.load_all_impacts(); cfgs = S.load_cfgs(); out = []
f, axs = plt.subplots(2, 3, figsize=(11, 5.6))
order = [("Sc2_SMR", 2, "SMR"), ("Sc2_SOEC", 2, "SOEC"), ("Sc2_Photocatalysis", 2, "Photocatalysis"), ("Sc1_SMR", 1, "SMR"), ("Sc1_SOEC", 1, "SOEC"), ("Sc1_Photocatalysis", 1, "Photocatalysis")]
for ax, (key, sc, h2) in zip(axs.flat, order):
    cfg = cfgs[(sc, h2)]; base = MT.ghg_base(cfg, factors); rr = []
    for pkey, pname, hf, sf in MT.LCA_PARAMS:
        if hf and h2 not in hf: continue
        if pkey == "wco_credit" and MT.WCO_CREDIT_MODE != "incineration": continue
        if pkey == "spk_impact" and sc != 2: continue
        ref = dict(smr_gwp=MT.SMR_GWP_PER_KG_H2, soec_elec=MT.SOEC_KWH_PER_KG_H2, photo_elec=MT.PHOTO_AUX_KWH_PER_KG_H2, process_heat=MT.PYRO_HEAT_MJ_PER_KG_FEED).get(pkey, 1.0)
        lo = MT.ghg_base(cfg, factors, **{pkey: ref * 0.8}) - base; hi = MT.ghg_base(cfg, factors, **{pkey: ref * 1.2}) - base
        rr.append((pname, lo, hi)); out.append(dict(scenario=f"{NAME[sc]} + {SHORT[h2]}", parameter=pname, base_g_MJ=base, minus20=lo, plus20=hi))
    rr.sort(key=lambda r: abs(r[1]) + abs(r[2]))
    yy = np.arange(len(rr)); ax.barh(yy, [r[1] for r in rr], color="#1976D2"); ax.barh(yy, [r[2] for r in rr], color="#D32F2F")
    ax.set_yticks(yy); ax.set_yticklabels([r[0] for r in rr], fontsize=7.5); ax.axvline(0, color="k", lw=0.6)
    ax.set_title(f"{NAME[sc]} + {SHORT[h2]} (base {base:.1f} g/MJ)", fontsize=8.5); ax.tick_params(axis="x", labelsize=7.5)
    ax.spines[["top", "right"]].set_visible(False)
for ax in axs[1]: ax.set_xlabel("Change in GWP (g CO$_2$e/MJ)", fontsize=8)
f.legend(handles=[plt.Rectangle((0, 0), 1, 1, color="#1976D2"), plt.Rectangle((0, 0), 1, 1, color="#D32F2F")], labels=["−20%", "+20%"], ncol=2, loc="lower center", bbox_to_anchor=(0.5, -0.03), frameon=False, fontsize=8)
f.tight_layout(rect=(0, 0.03, 1, 1)); save(f, "Fig_GWP_tornado"); pd.DataFrame(out).to_csv(os.path.join(REP, "gwp_tornado.csv"), index=False)

# ---------- 5) TRACI heat map (normalised to the maximum absolute value per category) ----------
tr = pd.read_csv(os.path.join(SUP, "R1_traci_per_MJ.csv")).set_index("scenario")
tr = tr.loc[[s for s in tr.index if s.startswith("S1")] + [s for s in tr.index if s.startswith("S2")]]
norm = tr / tr.abs().max()
f, ax = plt.subplots(figsize=(9, 3.6)); im = ax.imshow(norm.values, cmap="RdBu_r", vmin=-1, vmax=1, aspect="auto")
ax.set_xticks(range(tr.shape[1])); ax.set_xticklabels([c.split(" [")[0] for c in tr.columns], rotation=35, ha="right", fontsize=8)
ax.set_yticks(range(tr.shape[0])); ax.set_yticklabels(tr.index, fontsize=8)
for i in range(tr.shape[0]):
    for j in range(tr.shape[1]): ax.text(j, i, f"{norm.values[i, j]:.2f}", ha="center", va="center", fontsize=7, color="white" if abs(norm.values[i, j]) > 0.6 else "black")
cb = f.colorbar(im, ax=ax, fraction=0.03); cb.set_label("Normalised impact per MJ", fontsize=8); save(f, "Fig_TRACI_heatmap")

# ---------- 6) LCA inventory per MJ ----------
inv = []
for key, sc, h2 in order:
    cfg = cfgs[(sc, h2)]; saf = cfg["saf_kg_hr"]; lhv = tm.SAF_LHV_MJ_KG if sc == 1 else tm.BLEND_LHV_MJ_KG; MJ = saf * lhv; st = cfg["streams"]
    inv.append(dict(scenario=f"{NAME[sc]} + {SHORT[h2]}", product_kg_h=saf, LHV_MJ_kg=lhv, product_MJ_h=MJ,
                    clean_PS_g_MJ=st["clean_ps_kg_hr"] / MJ * 1e3, waste_oil_g_MJ=st["oil_kg_hr"] / MJ * 1e3, H2_g_MJ=cfg["H2_demand"] / MJ * 1e3,
                    purchased_SPK_g_MJ=cfg["spk_kg_hr"] / MJ * 1e3, char_g_MJ=st["char_kg_hr"] / MJ * 1e3,
                    pyrolysis_heat_kJ_MJ=MT.PYRO_HEAT_MJ_PER_KG_FEED * (st["clean_ps_kg_hr"] + st["oil_kg_hr"]) / MJ * 1e3,
                    electricity_kWh_MJ=(MT.SOEC_KWH_PER_KG_H2 if h2 == "SOEC" else MT.PHOTO_AUX_KWH_PER_KG_H2 if h2 == "Photocatalysis" else 0) * cfg["H2_demand"] / MJ,
                    GWP_g_MJ=MT.ghg_base(cfg, factors)))
pd.DataFrame(inv).to_csv(os.path.join(SUP, "R1_lca_inventory_per_MJ.csv"), index=False)
print(pd.DataFrame(rows).round(2).to_string()); print(pd.DataFrame(inv)[["scenario", "GWP_g_MJ"]].round(2).to_string())
