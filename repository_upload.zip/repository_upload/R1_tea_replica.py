"""
R1_tea_replica.py - stand-alone replica of tea_model.simulate_config() + run_tea() that needs no BioSTEAM.
It rebuilds each configuration's cfg dict from stream flows and the unit cost formulas in pretreatment.py,
pyrolyzer.py, hydrogenation.py and hydrogen_production.py, then prices it with tea_model.run_tea().

Purpose: (1) validate against the submitted results (mode 'submitted'); (2) give pre-rerun estimates of the
R1 base case (mode 'r1'). The BioSTEAM run (python R1_sensitivity_runs.py) remains the reference.
Heat-utility cost: BioSTEAM's heat utilities carry a heat-transfer efficiency; HEAT_FACTOR = 1.1085 is calibrated
so the submitted Sc1+SMR utility cost is reproduced. Off-gas heat credit is capped at purchased heat, so this
factor cancels wherever the off-gas covers the heat demand.

    python R1_tea_replica.py
"""
import os, sys, types, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [HERE, os.path.join(HERE, "tea_20260605_1634", "scripts")]


class _Any:
    def __init__(self, *a, **k): pass
    def __call__(self, *a, **k): return _Any()
    def __getattr__(self, n): return _Any()


for _n in ["biosteam", "thermosteam", "chaospy", "scipy", "scipy.stats", "scipy.optimize", "scipy.interpolate"]:
    try:
        __import__(_n)
    except Exception:
        _m = types.ModuleType(_n)
        _m.__getattr__ = lambda n: (type(n, (object,), {}) if n[:1].isupper() else _Any())
        sys.modules[_n] = _m

import tea_model as tm
import compounds as cp

HEAT_FACTOR = 1.1085
H2_HHV_KJ = 142_000


def pl(base, ref, exp, s):
    return base * (s / ref) ** exp


def build(sc, h2, mode="r1", flows=None):
    f = flows
    raw = f["raw_ps"]; ps = f["clean_ps"]; oil = f.get("oil", 0.0)
    total = ps + oil
    H2 = f["h2"]
    pc = {}
    # M-101 pretreatment
    pc["pre"] = pl(400e3, 1000, 0.65, raw) + pl(350e3, 1000, 0.60, raw) + pl(300e3, 1000, 0.65, raw)
    heat = {"pre": raw * 0.06 * 2700}
    util_pre = raw * 0.03 * tm.ELEC_PRICE_KWH + f.get("wash", raw * 0.30) * 0.001
    # R-201 pyrolyser
    pc["pyr"] = pl(850e3, 1000, 0.65, total) + pl(120e3, 500, 0.60, total) + pl(180e3, 500, 0.65, total) + pl(60e3, 500, 0.55, total)
    heat["pyr"] = total * 1500
    cat_inv = 0.0
    if sc == 1:   # physical Sc1 = co-hydropyrolysis
        Fh = f["liq"] + H2
        b = pl(1.2e6, 500, 0.65, Fh)
        cat = Fh * 0.005 * 50_000
        pc["hyd"] = b * (1 + 0.40 + 0.20) + cat
        cat_inv += cat
        heat["hyd"] = Fh * 800
    else:         # physical Sc2 = PS-only
        Fh = f["liq"] + H2
        b = pl(900e3, 500, 0.60, Fh)
        cat = Fh * 0.002 * 50_000
        pc["hyd"] = b * (1 + 0.25 + (0.50 if mode == "submitted" else 0.0)) + cat
        cat_inv += cat
        heat["hyd"] = Fh * (400 if mode == "submitted" else 100)
        Fb = f["eb_oil"] + f["spk"]
        bb = pl(600e3, 1000, 0.65, Fb)
        pc["bld"] = bb * (0.40 + 0.20) + (pl(450e3, 1000, 0.65, f["eb_oil"]) if mode != "submitted" else 0.0)
        heat["bld"] = (f["eb_oil"] * 630) if mode != "submitted" else Fb * 30
    # A-300 hydrogen
    h2_util = 0.0
    if h2 == "SMR":
        pc["h2"] = pl(4.5e6, 1000, 0.65, H2) * 1.40
        ch4 = H2 / ((4 * 2.016 / 16.04) * 0.78)
    elif h2 == "SOEC":
        pc["h2"] = pl(3.8e6, 1000, 0.65, H2) * 1.30
        h2_util = H2 * H2_HHV_KJ / 3600 / 0.85 * tm.ELEC_PRICE_KWH
        ch4 = 0.0
    else:
        area = H2 * H2_HHV_KJ / 3600 / 0.05 * 1000 / float(os.environ.get("PHOTO_IRRADIANCE_W_M2", 1000))
        pc["h2"] = area * 250 * 1.25
        h2_util = H2 * 5 * tm.ELEC_PRICE_KWH
        ch4 = 0.0
    tpec = sum(pc.values())
    hc = {k: v / 1e6 * tm.HEAT_PRICE_GJ * HEAT_FACTOR for k, v in heat.items()}   # $/h
    cat_hr = cat_inv * (tm.CATALYST_ANNUAL_FRAC if mode != "submitted" else 0.0) / tm.OPERATING_HR
    utility = sum(hc.values()) + util_pre + h2_util + cat_hr
    ps_price = tm.PS_PRICE_KG
    oil_price = 0.08 if mode == "submitted" else tm.OIL_PRICE_KG
    spk_price = 1.50 if mode == "submitted" else tm.SPK_PRICE_KG
    feed = raw * ps_price + oil * oil_price + ch4 * tm.CH4_HHV_GJ_KG * tm.CH4_PRICE_GJ + f.get("spk", 0.0) * spk_price
    byp = f["char"] * tm.CHAR_PRICE_KG + f.get("ends", 0.0) * 40 / 1000 * tm.HEAT_PRICE_GJ
    if h2 in ("SOEC", "Photocatalysis"):
        byp += H2 * 16.0 / 2.016 * tm.OXYGEN_PRICE_KG
    gas_fuel = (f["gas_ch4"] * tm.CH4_HHV_GJ_KG + f["gas_h2"] * tm.H2_HHV_GJ_KG) * tm.HEAT_PRICE_GJ
    byp += min(gas_fuel, sum(hc.values()))
    return dict(scenario=sc, h2_source=h2, tpec=tpec, utility_cost_hr=utility, feedstock_cost_hr=feed,
                byproduct_revenue_hr=byp, saf_kg_hr=f["product"], spk_kg_hr=f.get("spk", 0.0),
                streams=dict(ps_kg_hr=raw, oil_kg_hr=oil), H2_demand=H2, _pc=pc)


R1_FLOWS = {   # BioSTEAM run of 17 Nov 2026 (material_balance_*.csv)
    1: dict(raw_ps=10416.667, clean_ps=9085.417, oil=22713.542, liq=26711.125, char=2225.927, gas_ch4=1717.144, gas_h2=286.191,
            h2=394.461, product=26878.45, wash=3125.0),
    2: dict(raw_ps=10416.667, clean_ps=9085.417, liq=8722.0, char=181.708, gas_ch4=109.025, gas_h2=18.171, h2=117.589,
            eb_oil=8839.77, spk=17328.708, product=21134.177, ends=5034.301, wash=3125.0),
}
SUB_FLOWS_SC1 = dict(raw_ps=10416.667, clean_ps=9085.417, oil=6056.94, liq=13022.0, char=908.5, gas_ch4=726.8, gas_h2=121.1,
                     h2=433.0, product=13455.0, wash=3125.0)
SUBMITTED = {"SMR": 0.9014, "SOEC": 0.9702, "Photocatalysis": 1.9630}   # June mfsp.csv sums (submitted)
LABEL = {1: "S2 co-hydropyrolysis", 2: "S1 PS-only + SPK blend"}


def mfsp(cfg):
    t = tm.run_tea(cfg)
    return t


if __name__ == "__main__":
    # ---- 1) validation against the submitted co-hydropyrolysis results ----
    lab_mode, cat = tm.LABOR_MODE, tm.CATALYST_ANNUAL_FRAC
    tm.LABOR_MODE, tm.CATALYST_ANNUAL_FRAC = "fci", 0.0
    print("Validation (submitted basis, co-hydropyrolysis 60:40, oil $0.08, labour 5% FCI):")
    for h2 in ("SMR", "SOEC", "Photocatalysis"):
        t = mfsp(build(1, h2, "submitted", SUB_FLOWS_SC1))
        print(f"  {h2:15s} replica {t['mfsp_per_kg']:.4f}  submitted {SUBMITTED[h2]:.4f}  "
              f"feed {t['feedstock_contr']:.4f} cap {t['capital_contr']:.4f} foc {t['foc_contr']:.4f} util {t['utility_contr']:.4f} cr {t['byproduct_credit']:.4f}")
    tm.LABOR_MODE, tm.CATALYST_ANNUAL_FRAC = lab_mode, cat
    # ---- 2) R1 base case ----
    rows = []
    print("\nR1 base case (pre-rerun estimate):")
    for sc in (2, 1):
        for h2 in ("SMR", "SOEC", "Photocatalysis"):
            c = build(sc, h2, "r1", R1_FLOWS[sc]); t = mfsp(c)
            lhv = tm.SAF_LHV_MJ_KG if sc == 1 else tm.BLEND_LHV_MJ_KG
            r = dict(scenario=f"{LABEL[sc]} + {h2}", TPEC_MM=c["tpec"] / 1e6, FCI_MM=t["FCI"] / 1e6, TCI_MM=t["TCI"] / 1e6,
                     VOC_MM=t["VOC_annual_MM"], FOC_MM=t["FOC_annual_MM"], MFSP=t["mfsp_per_kg"], MFSP_GJ=t["mfsp_per_kg"] / lhv * 1000,
                     MFSP_GGE=t["mfsp_gge"], vs_parity=100 * (t["mfsp_per_kg"] / 1.09 - 1), feed=t["feedstock_contr"],
                     cap=t["capital_contr"], foc=t["foc_contr"], util=t["utility_contr"], credit=t["byproduct_credit"],
                     pc={k: round(v / 1e6, 3) for k, v in c["_pc"].items()})
            rows.append(r)
            print(f"  {r['scenario']:38s} MFSP {r['MFSP']:.3f} $/kg ({r['MFSP_GJ']:.1f} $/GJ, {r['vs_parity']:+.0f}%)  TCI {r['TCI_MM']:.0f} MM  "
                  f"feed {r['feed']:.3f} cap {r['cap']:.3f} foc {r['foc']:.3f} util {r['util']:.3f} cr {r['credit']:.3f}")
    import pandas as pd
    out = os.path.join(HERE, "R1_outputs", "R1_tea_replica_estimates.csv")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    pd.DataFrame(rows).to_csv(out, index=False)
    print("\nwritten", out)
