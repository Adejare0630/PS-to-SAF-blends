# OpenLCA background data (not included)

The LCA scripts (`tea_20260605_1634/scripts/make_lca.py`, `R1_supplementary.py`) read TRACI 2.1 impact
results exported from OpenLCA for nine ecoinvent 3 (cut-off) datasets. These exports are ecoinvent data and are
not redistributed here because of the ecoinvent licence. To run the LCA, place your own exports of the following
datasets in this folder with these file names:

- Ethylbenzene_styrene__at_plant___RNA.xlsx
- aviation_fuel__Jet_A_fuel_surrogate__bioconversion_of_poplar_biomass__at_biorefinery__45_5_MJ_kg___US.xlsx
- chlor_alkali_electrolysis__membrane_cell___hydrogen__liquid___Cutoff__U___RoW.xlsx
- electricity_production__natural_gas__10MW___electricity__high_voltage___Cutoff__U___RoW.xlsx
- electricity_production__photovoltaic__3kWp_flat_roof_installation__multi_Si___electricity__low_voltage___Cutoff__U___RoW.xlsx
- hydrogen_cracking__APME___hydrogen__liquid___Cutoff__U___RoW.xlsx
- polystyrene_production__high_impact___polystyrene__high_impact___Cutoff__U___RoW.xlsx
- treatment_of_waste_mineral_oil__hazardous_waste_incineration___waste_mineral_oil___Cutoff__U___RoW.xlsx
- water_production__deionised__from_tap_water__at_user___water__deionised__from_tap_water__at_user___Cutoff__U___RoW.xlsx

The impact results per MJ of fuel computed from them are in `R1_outputs/supplementary/`.
