# compounds.py
# Chemical species definitions for SAF-from-PS simulation

import thermosteam as tmo


def define_chemicals():
    """
    Define all chemical species used in the SAF-from-PS simulation.
    Returns a Chemicals object registered with thermosteam.
    """
    chems = tmo.Chemicals([
        # --- Feedstocks ---
        tmo.Chemical('Polystyrene',     search_db=False, CAS='9003-53-6', phase='s',
                     Hf=-99600,   # J/mol estimated
                     MW=104.15,   # repeat unit (C8H8)
                     Cp=1.3,      # kJ/kg/K
                     rho=1050),   # kg/m3

        tmo.Chemical('WasteCookingOil', search_ID='Triolein',
                     phase='l'),

        # --- Pyrolysis Products ---
        tmo.Chemical('Styrene'),
        tmo.Chemical('Ethylbenzene'),
        tmo.Chemical('Toluene'),
        tmo.Chemical('pXylene',         search_ID='106-42-3'),
        tmo.Chemical('Benzene'),
        tmo.Chemical('Naphthalene'),
        tmo.Chemical('Indane'),
        tmo.Chemical('Decane'),
        tmo.Chemical('Dodecane'),
        tmo.Chemical('Tetradecane'),
        tmo.Chemical('Hexadecane'),

        # Sc2 (Prajapati route): lumped styrene dimers/trimers/1,2-diphenylpropane + unidentified heavies.
        # APPROXIMATE pseudo-component (dimer C16H16 basis). Hf is an estimate; used only for mass/energy bookkeeping.
        tmo.Chemical('StyreneOligomers', search_db=False, phase='l',
                     CAS='0000-00-0', MW=208.3, Hf=120000, Cp=1.9, rho=1000.0),

        # Scenario 2: SPK blend component (HEFA-type synthetic paraffinic kerosene)
        # Modelled as a C12 isoparaffin pseudo-component — properties from ASTM D7566 Annex A2
        tmo.Chemical('SPK', search_db=False, phase='l',
                     CAS='68607-30-7',
                     MW=170.34,      # g/mol  (C12H26 average isoparaffin)
                     Hf=-291800,     # J/mol  (estimated, n-dodecane basis)
                     Cp=2.18,        # kJ/kg/K
                     rho=752.0),     # kg/m3  (ASTM D1655 jet-fuel density mid-range)

        # --- Hydrogenation Products (SAF components) ---
        tmo.Chemical('Ethylcyclohexane'),
        tmo.Chemical('nPropylbenzene',      search_ID='103-65-1'),
        tmo.Chemical('Isododecane',         search_ID='31807-55-3'),
        tmo.Chemical('Isooctane'),
        # Sc2 extended hydrogenation product: 1,2,3,4-tetrahydronaphthalene
        tmo.Chemical('Tetralin',            search_ID='119-64-2'),

        # --- Hydrogen Production Species ---
        tmo.Chemical('Hydrogen'),
        tmo.Chemical('Methane'),
        tmo.Chemical('Water'),
        tmo.Chemical('CarbonDioxide',   search_ID='124-38-9'),
        tmo.Chemical('CarbonMonoxide',  search_ID='630-08-0'),
        tmo.Chemical('Oxygen'),
        tmo.Chemical('Nitrogen'),

        # --- Char (pseudo-component) ---
        tmo.Chemical('Char',            search_db=False, CAS='7782-42-5', phase='s',
                     MW=12.011,
                     Hf=-393500),   # J/mol

        # --- Pretreatment reject (pseudo-component) ---
        # Lumped non-PS solids removed from raw waste PS bales: labels, adhesive
        # residue, dirt/grit, mixed-polymer fines. Treated as an inert generic
        # solid for mass-balance purposes (no reaction, no heating value credit).
        tmo.Chemical('Contaminants',    search_db=False, CAS='7440-44-0', phase='s',
                     MW=12.011,
                     Hf=0.0,
                     Cp=1.0,
                     rho=1200),
    ])

    # Set missing properties for Polystyrene as a pseudo-component
    Polystyrene = chems['Polystyrene']
    Polystyrene.at_state('s')

    # Lock SPK in liquid phase (purchased blend component, no phase change modelled)
    chems['SPK'].at_state('l')

    tmo.settings.set_thermo(chems)
    return chems


# ---- Key composition dictionaries ----

# Raw waste-PS bale composition (before pretreatment). Typical baled
# post-consumer/industrial waste plastic: a few percent surface moisture and
# a few percent non-PS contamination (labels, dirt/grit, mixed-polymer fines).
PRETREAT_MOISTURE_FRAC = 0.06   # wt fraction of raw feed that is moisture
PRETREAT_CONTAM_FRAC   = 0.05   # wt fraction of raw feed that is non-PS solids
PRETREAT_PS_LOSS_FRAC  = 0.02   # fraction of the PS content itself lost as
                                 # fines to wash water during washing/screening

# Scenario 1: Co-hydropyrolysis product distribution (Li et al., 2024)
# Optimum: 0.15 MPa H2, 480 °C pyrolysis, 350 °C hydrogenation, Pd/SBA-15
# ==============================================================================================================
# R1: Scenario 1 (co-hydropyrolysis) CASES.  Select with env var SC1_CASE  (default "Li25"):
#   "Li25"     = Li et al., Chem. Eng. Sci. 2025, 304, 121100, AS MEASURED: waste oil : PS = 2.5, 480 C, Pd/SBA-15 350 C.
#                From Li's Fig. 9 optimum: liquid 84.0 wt% of feed = ethylbenzene 28.1 + C11-C15 n-alkanes 43.0 +
#                C17 ~12.9 (by difference)  =>  product aromatics 33.5 wt% = 30.4 vol% (blendstock, above ~25 vol%).
#   "Extrap34" = EXTRAPOLATION beyond Li's tested ratio: oil : PS = 3.4, per-feed yields scaled linearly
#                (EB = 0.9835 x PS mass, n-alkanes = 0.7826 x oil mass)  =>  27.0 wt% = 24.3 vol% aromatics.
# ASSUMPTIONS (flagged): C11/C13/C15 split follows the palm-kernel-oil fatty-acid profile (C12:C14:C16 = 48:16:8);
# odd-carbon alkanes are represented by the even-carbon species defined above (C11 -> Decane/Dodecane, C13 ->
# Dodecane/Tetradecane, C15 -> Tetradecane/Hexadecane, C17 -> Hexadecane); char:gas split of the non-liquid remainder
# is kept at the submitted 7:9 (Li reports none). Submitted aromatic-rich table is kept as SCENARIO1_PYRO_YIELDS_SUBMITTED.
# ==============================================================================================================
import os as _os_c
SCENARIO1_PYRO_YIELDS_SUBMITTED = {
    'Styrene': 0.05, 'Ethylbenzene': 0.20, 'pXylene': 0.10, 'Toluene': 0.08, 'Naphthalene': 0.07,
    'Indane': 0.06, 'Decane': 0.15, 'Dodecane': 0.12, 'Tetradecane': 0.10, 'Hexadecane': 0.07,
}
_SC1_CASES = {
    "Li25": dict(ratio=2.5, liq=0.840, char=0.070, gas=0.090,
                 yields={'Styrene': 0.330, 'Decane': 0.172, 'Dodecane': 0.229, 'Tetradecane': 0.086, 'Hexadecane': 0.183}),
    "Extrap34": dict(ratio=3.4, liq=0.828, char=0.075, gas=0.097,
                     yields={'Styrene': 0.265, 'Decane': 0.189, 'Dodecane': 0.251, 'Tetradecane': 0.094, 'Hexadecane': 0.201}),
}
SC1_CASE = _os_c.environ.get("SC1_CASE", "Li25")
if SC1_CASE not in _SC1_CASES:
    raise ValueError(f"SC1_CASE must be one of {list(_SC1_CASES)}")
_c = _SC1_CASES[SC1_CASE]
SC1_OIL_TO_PS_RATIO       = _c["ratio"]            # default for OIL_TO_PS_RATIO in tea_model.py / main.py
SCENARIO1_PYRO_YIELDS     = dict(_c["yields"])     # wt fraction of pyrolysis oil BEFORE selective hydrogenation
SCENARIO1_LIQUID_FRACTION = _c["liq"]
SCENARIO1_CHAR_FRACTION   = _c["char"]
SCENARIO1_GAS_FRACTION    = _c["gas"]
# kg H2 per kg waste oil for oxygen removal (decarboxylation/decarbonylation route; Li reports no H2 balance).
# ASSUMPTION: 1 wt% (lower bound; full hydrodeoxygenation would be ~3-4 wt%).
OIL_HDO_H2_KG_PER_KG_OIL = 0.01

# Scenario 2: PS-only pyrolysis product distribution (Prajapati et al., 2024)
# Target: aromatic-rich oil for SPK blending
# (R1: the submitted 550 C / 50:50-blend / ring-saturation case has been REMOVED; see R1_CHANGES.md Update 13)

# ── R1: Sc2 case switch (physical Sc2 = PS-only route; displayed as "Scenario 1" after relabelling) ──
#   Measured basis (Prajapati et al., ACS Sustainable Chem. Eng. 2025, 13, 212-219; figure/slide-read, approx.):
#   thermal pyrolysis 400 C -> vinyl-only Pd/C hydrogenation (no ring saturation) -> distillation to an ~89-91 wt% EB additive
#   (+ other-ends by-product) -> blended into purchased HEFA-SPK.  Blend aromatic content is a SENSITIVITY: env SC2_BLEND_VOL_PCT
#   (12-25 vol% aromatics; 12 and 16 tested by Prajapati; default 16 = Prajapati's tested 16 vol% blend; 25 = finished-jet aromatics cap, verify ASTM D1655/D7566).
import os as _os_s2
SC2_CASE = "Prajapati"
SC2_DISTILL16 = True     # legacy flag kept for imports; the only Sc2 route
SC2_BLEND_VOL_PCT = float(_os_s2.environ.get("SC2_BLEND_VOL_PCT", "16"))
if not (12.0 <= SC2_BLEND_VOL_PCT <= 25.0):
    raise ValueError("SC2_BLEND_VOL_PCT must be within 12-25 (vol% aromatic additive in the SPK blend)")
SC2_EB_RHO, SC2_SPK_RHO = 867.0, 752.0    # kg/m3
SC2_EB_LHV, SC2_SPK_LHV = 40.9, 44.1      # MJ/kg


def sc2_blend_params(vol_pct):
    """Return (additive mass fraction, blend LHV MJ/kg) for an additive blended at vol_pct vol% into HEFA-SPK."""
    v = vol_pct / 100.0
    w = v * SC2_EB_RHO / (v * SC2_EB_RHO + (1 - v) * SC2_SPK_RHO)
    return w, w * SC2_EB_LHV + (1 - w) * SC2_SPK_LHV


if SC2_DISTILL16:
    # wt fraction of crude pyrolysis liquid (400 C). Styrene 55 wt% (Prajapati text 61 wt% at 400 C of product; slides ~55-57).
    # EB/toluene 1-3, alpha-methylstyrene ~4-5 (carried as nPropylbenzene/cumene surrogate), oligomers ~24 + unidentified heavies.
    SCENARIO2_PYRO_YIELDS = {
        'Styrene': 0.55, 'Ethylbenzene': 0.02, 'Toluene': 0.03,
        'nPropylbenzene': 0.05, 'StyreneOligomers': 0.35,
    }
    SCENARIO2_LIQUID_FRACTION = 0.96   # ~96 wt% at 400 C (Fig. 2, approx.); gas not collected -> liquid by difference
    SCENARIO2_CHAR_FRACTION   = 0.02
    SCENARIO2_GAS_FRACTION    = 0.02
    # Vinyl-bearing oligomers also consume H2 (assumed 90% of ~1 C=C per dimer: 2.016/208.3 kg/kg)
    SC2_OLIGOMER_H2 = 0.90 * 2.016 / 208.3
    SC2_HYDRO_T_C, SC2_HYDRO_P_PA, SC2_HYDRO_HEAT_KJ_KG = 70.0, 5.0e6, 100.0
    # Distillation (measured cut, Prajapati: 131-141 C cut = ~43.5% of hydrogenated oil at ~89.9 wt% EB)
    SC2_EB_RECOVERY = 0.70                    # fraction of EB reporting to the additive cut (0.435*0.899/0.55)
    SC2_CUT_COMPANIONS = {'nPropylbenzene': 6.2/89.9, 'Toluene': 2.3/89.9}   # kg per kg EB in cut (cumene, toluene)
    SC2_ADDITIVE_MASS_FRAC, SC2_BLEND_LHV_MJ_KG = sc2_blend_params(SC2_BLEND_VOL_PCT)
    SC2_ENDS_LHV_MJ_KG = 40.0                 # other-ends by-product, credited at fuel (heat) value only




# Hydrogenation conversion map: reactant -> (product, conversion_fraction)
# R1: Li's Pd/SBA-15 step is ring-PRESERVING (ethylbenzene is a product, not a reactant). Submitted ring-saturating
# conversions are kept as HYDROGENATION_CONVERSION_RING_SAT_SUBMITTED for reference.
HYDROGENATION_CONVERSION_RING_SAT_SUBMITTED = {
    'Styrene':      ('Ethylcyclohexane', 0.98),
    'Ethylbenzene': ('Ethylcyclohexane', 0.97),
    'pXylene':      ('Isooctane',        0.96),
    'Toluene':      ('Isooctane',        0.96),
    'Benzene':      ('Isooctane',        0.95),
    'Naphthalene':  ('Isododecane',      0.97),
    'Indane':       ('Ethylcyclohexane', 0.96),
}
HYDROGENATION_CONVERSION = {
    'Styrene':      ('Ethylbenzene', 0.98),   # Li et al.: styrene -> ethylbenzene over Pd/SBA-15; EB retained
}

# ── Scenario 2: PS pyrolysis → selective vinyl-bond hydrogenation → EB → SPK blend ──
# Selective hydrogenation: only the vinyl double bond of styrene → ethylbenzene
# C8H8 (styrene, MW 104.15) + H2 (MW 2.016) → C8H10 (ethylbenzene, MW 106.17)
SELECTIVE_HYDRO_CONVERSION = {
    'Styrene': ('Ethylbenzene', 0.95),
}
# kg H2 consumed per kg of styrene hydrogenated (stoichiometric)
SELECTIVE_H2_STOICH = {
    'Styrene': 2.016 / 104.15,   # ≈ 0.01937 kg H2/kg styrene
}

# ── Scenario 2 Option 1: extended partial ring saturation ─────────────────────
# Applied after vinyl-bond step; increases H2 demand and improves fuel quality
# (lower PNA content, improved cold-flow / freeze-point properties)
SC2_EXTENDED_HYDRO_CONVERSION = {
    # Naphthalene (C10H8) + 2H2 → Tetralin (C10H12): first ring saturated
    'Naphthalene': ('Tetralin',         0.70),
    # Indane (C9H10) + 3H2 → ring-sat bicyclic proxy (Ethylcyclohexane)
    'Indane':      ('Ethylcyclohexane', 0.70),
    # BTEX aromatics: partial ring saturation → cycloalkane proxies
    'pXylene':     ('Isooctane',        0.60),
    'Toluene':     ('Isooctane',        0.60),
    'Benzene':     ('Isooctane',        0.55),
}
# Stoichiometric kg H2 consumed per kg of species converted
SC2_EXTENDED_H2_STOICH = {
    'Naphthalene': 4.032  / 128.17,   # +2H2 → Tetralin;              ≈ 0.03147
    'Indane':      6.048  / 118.18,   # +3H2 → ring-sat proxy;        ≈ 0.05117
    'pXylene':     6.048  / 106.17,   # +3H2 → dimethylcyclohexane;   ≈ 0.05697
    'Toluene':     6.048  /  92.14,   # +3H2 → methylcyclohexane;     ≈ 0.06564
    'Benzene':     6.048  /  78.11,   # +3H2 → cyclohexane;           ≈ 0.07743
}

if SC2_DISTILL16:   # R1: Prajapati measured route is vinyl-only (Pd/C, 70 C): no ring saturation
    SELECTIVE_HYDRO_CONVERSION = {'Styrene': ('Ethylbenzene', 0.98)}
    SC2_EXTENDED_HYDRO_CONVERSION = {}
    SC2_EXTENDED_H2_STOICH = {}
    # (ring-saturating dicts above are unused (kept for reference only))

def sc2_h2_demand_kg_hr(liq_kg_hr):
    """kg H2/hr for the Sc2 hydrogenation step given crude liquid mass (kg/hr). Single source for main.py and tea_model.py."""
    y = SCENARIO2_PYRO_YIELDS
    h2 = 0.0
    for sp, (_, conv) in SELECTIVE_HYDRO_CONVERSION.items():
        h2 += liq_kg_hr * y.get(sp, 0.0) * conv * SELECTIVE_H2_STOICH[sp]
    for sp, (_, conv) in SC2_EXTENDED_HYDRO_CONVERSION.items():
        h2 += liq_kg_hr * y.get(sp, 0.0) * conv * SC2_EXTENDED_H2_STOICH[sp]
    h2 += liq_kg_hr * y.get('StyreneOligomers', 0.0) * SC2_OLIGOMER_H2
    return h2


# ----------------------------------------------------------------------------------------------------------------
# R1: Scenario-1 composition/yield as a continuous function of the oil:PS ratio r (used by the ratio sweep).
# Linear scaling of Li et al.'s per-feed yields measured at r = 2.5 (EB = 0.9835 x PS mass, n-alkanes = 0.7826 x oil
# mass).  Valid as MEASURED only at r = 2.5; everything else is an EXTRAPOLATION/INTERPOLATION assumption.
_LI_EB_PER_PS, _LI_ALK_PER_OIL = 0.9835, 0.7826
_ALK_SHARES = {'Decane': 0.2567, 'Dodecane': 0.3418, 'Tetradecane': 0.1284, 'Hexadecane': 0.2731}  # of the alkane mass
_RHO_EB, _RHO_ALK = 0.867, 0.752    # kg/L, ethylbenzene and the alkane mix


def sc1_composition_for_ratio(r):
    """Return dict(yields, liq, char, gas, aromatics_wt, aromatics_vol) for oil:PS = r."""
    liq = (_LI_EB_PER_PS + _LI_ALK_PER_OIL * r) / (1.0 + r)
    x_eb = _LI_EB_PER_PS / (_LI_EB_PER_PS + _LI_ALK_PER_OIL * r)          # EB mass fraction of the hydrogenated liquid
    sty_raw = x_eb * 104.15 / 106.17                                       # styrene precursor of that EB
    norm = sty_raw + (1.0 - x_eb)
    yields = {'Styrene': sty_raw / norm}
    for sp, sh in _ALK_SHARES.items():
        yields[sp] = (1.0 - x_eb) / norm * sh
    rest = 1.0 - liq
    char, gas = rest * 7 / 16, rest * 9 / 16                               # submitted 7:9 split kept (assumption)
    h2_in = yields['Styrene'] * 0.98 * 0.01937
    arom_wt = yields['Styrene'] * (0.98 * 106.17 / 104.15 + 0.02) / (1.0 + h2_in)
    vol = (arom_wt / _RHO_EB) / (arom_wt / _RHO_EB + (1.0 - arom_wt) / _RHO_ALK)
    return dict(yields=yields, liq=liq, char=char, gas=gas, aromatics_wt=arom_wt, aromatics_vol=vol)
