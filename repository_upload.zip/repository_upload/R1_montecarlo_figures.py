"""R1 reanalysis: equal-product basis, Monte Carlo with documented distributions and literature
yield ranges, Sc1<->Sc2 relabelling, regenerated figures.  numpy/pandas/matplotlib only.

IMPORTANT: this is a SURROGATE of the BioSTEAM/DCFROR model.  Elasticities are fitted to the 1,000
saved LHS samples per configuration (R^2 >= 0.999, see fit_quality.csv) and feedstock prices are
applied explicitly.  Replace by a true BioSTEAM Monte Carlo when the full model is rerun.
Usage: python R1_montecarlo_figures.py   (run inside Module_R1; reads tea_20260605_1634/data)
"""
import os, numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
D = "tea_20260605_1634/data/"; OUT = "R1_results/"; os.makedirs(OUT, exist_ok=True)
PARITY, HRS, N_MC, SEED = 1.09, 7920, 5000, 42
OLD2NEW = {"Sc1": "Sc2", "Sc2": "Sc1"}          # relabelling (R1.14)
def newlab(k):  # 'Sc1_SMR' -> 'Sc2+SMR'
    sc, h2 = k.split("_", 1); return f"{OLD2NEW[sc]}+" + {"Photocatalysis": "Photo"}.get(h2, h2)
SCN_NAME = {"Sc1": "Sc1 PS-only (reference)", "Sc2": "Sc2 co-hydropyrolysis (proposed)"}
CONFIGS = ["Sc1_SMR", "Sc1_Photocatalysis", "Sc1_SOEC", "Sc2_SMR", "Sc2_Photocatalysis", "Sc2_SOEC"]  # OLD ids
mf = pd.read_csv(D + "mfsp.csv"); ms = pd.read_csv(D + "mfsp_summary.csv").set_index("scenario")
tot = pd.read_csv(D + "material_balance_totals.csv")
def flow(k, sid): return float(tot[(tot.scenario == k) & (tot.stream_id == sid)].total_kg_hr.iloc[0])

# ---------- base prices (R1 placeholders: replace with cited values) ----------
P0 = dict(ps=0.60, oil_old=0.08, oil=0.70, spk=1.50)

# ---------- parameter distributions: (min, mode, max), triangular, independent ----------
LIQ = {"Sc1": (0.65, 0.86, 0.95), "Sc2": (0.75, 0.90, 0.987)}  # liquid fraction; lit. PS-only 75-98.7 wt%; co-pyrolysis with oil 64-80 wt% (sparse)
DIST = {  # old-id scenario applicability, basis
 "PS price ($/kg)":            ((0.30, 0.60, 0.90), "both", "market range, to be cited"),
 "Waste cooking oil ($/kg)":   ((0.40, 0.70, 0.95), "Sc1", "reported UCO range ~0.46-0.92 $/kg"),
 "HEFA-SPK price ($/kg)":      ((1.20, 1.50, 3.00), "Sc2", "skewed high: 2023-24 SPK quotes well above 1.5"),
 "Liquid fraction (Sc-specific)": (None, "both", "literature min / model base / max"),
 "Installed capital multiplier": ((0.70, 1.00, 1.50), "both", "AACE Class 4: -30%/+50%"),
 "IRR": ((0.08, 0.10, 0.15), "both", "8-15%"),
 "On-stream factor": ((0.80, 0.90, 0.95), "both", "292-347 d/yr"),
 "Plant capacity multiplier": ((0.80, 1.00, 1.20), "both", "+/-20%"),
 "H2 / energy cost multiplier": ((0.80, 1.00, 1.20), "both", "+/-20%"),
}
def tri_ppf(u, a, c, b):
    f = (c - a) / (b - a)
    return np.where(u < f, a + np.sqrt(u * (b - a) * (c - a)), b - np.sqrt((1 - u) * (b - a) * (b - c)))
def lhs(n, d, rng):
    return (np.argsort(rng.random((n, d)), axis=0) + rng.random((n, d))) / n

# ---------- surrogate: fitted elasticities + explicit feedstock ----------
NAMES = ["ps", "cap_ratio", "irr", "yield", "h2", "capex", "onstream"]
base_mult = {"irr": 0.10, "onstream": 0.90}
S = {}; fitq = []
for k in CONFIGS:
    s = pd.read_csv(D + f"uncertainty_samples_{k}.csv"); X = np.log(s.drop(columns=["scenario", "mfsp"]).values); y = np.log(s.mfsp.values)
    A = np.c_[np.ones(len(X)), X]; b = np.linalg.lstsq(A, y, rcond=None)[0]
    r2 = 1 - ((y - A @ b) ** 2).sum() / ((y - y.mean()) ** 2).sum(); fitq.append(dict(config=newlab(k), R2=r2, **dict(zip(s.columns[1:-1], b[1:]))))
    e = dict(zip(NAMES, b[1:]))
    sc = k[:3]; s1 = sc == "Sc1"; prod = flow(k, "saf" if s1 else "eb_spk_blend")
    ps_per = flow(k, "s_ps_raw") / prod; oil_per = flow(k, "s_oil") / prod if s1 else 0.0; spk_per = flow(k, "s_spk") / prod if not s1 else 0.0
    g = mf[mf.scenario == k].set_index("category").value; feed_old = g["Feedstock"]; nonfeed = g.sum() - feed_old
    other_feed = feed_old - ps_per * P0["ps"] - oil_per * P0["oil_old"] - spk_per * P0["spk"]   # CH4 etc.
    share_nf = 1 - e["ps"]
    S[k] = dict(e=e, ps_per=ps_per, oil_per=oil_per, spk_per=spk_per, other_feed=other_feed, nonfeed=nonfeed, share_nf=share_nf,
                base_liq=0.86 if s1 else 0.90, prod=prod)
pd.DataFrame(fitq).to_csv(OUT + "fit_quality.csv", index=False)

def mfsp_model(k, ps=None, oil=None, spk=None, liq=None, capex=1, irr=0.10, ons=0.90, cap=1, h2=1):
    m = S[k]; e = m["e"]
    ps = P0["ps"] if ps is None else ps; oil = P0["oil"] if oil is None else oil; spk = P0["spk"] if spk is None else spk
    yl = 1.0 if liq is None else liq / m["base_liq"]
    feed = m["ps_per"] * ps + m["oil_per"] * oil + m["spk_per"] * spk + m["other_feed"] * (1.0 if np.isscalar(h2) else 1.0)
    nf_exp = lambda name: e[name] / m["share_nf"]
    nonf = m["nonfeed"] * capex ** nf_exp("capex") * (irr / 0.10) ** nf_exp("irr") * (ons / 0.90) ** nf_exp("onstream") \
           * cap ** nf_exp("cap_ratio") * h2 ** nf_exp("h2")
    return (feed + nonf) / yl

# ---------- 1. base case (revised prices) and equal-product basis ----------
rows = []
for k in CONFIGS:
    m = S[k]; base_old = ms.loc[k, "mfsp_net"]; base_new = float(mfsp_model(k))
    k_eq = flow("Sc1_SMR", "saf") / m["prod"] if k.startswith("Sc2") else 1.0   # old Sc2 (PS-only) scaled to Sc1 product
    eq = float(mfsp_model(k, cap=k_eq))
    rows.append(dict(config=newlab(k), product_kg_hr=m["prod"], MFSP_submitted=base_old, MFSP_revised_prices=base_new,
                     scale_to_equal_product=k_eq, MFSP_equal_product=eq,
                     equal_vs_unequal_pct=(eq / base_new - 1) * 100, vs_parity_pct=(eq / PARITY - 1) * 100))
EQ = pd.DataFrame(rows); EQ.to_csv(OUT + "equal_product_basis.csv", index=False)

# ---------- 2. Monte Carlo ----------
rng = np.random.default_rng(SEED); mc_rows, conv, spear, samples = [], [], [], {}
for k in CONFIGS:
    sc = k[:3]; s1 = sc == "Sc1"; pnames = [n for n, v in DIST.items() if v[1] in ("both", sc)]
    U = lhs(N_MC, len(pnames), rng); X = {}
    for j, n in enumerate(pnames):
        lo, mo, hi = LIQ[sc] if n.startswith("Liquid") else DIST[n][0]; X[n] = tri_ppf(U[:, j], lo, mo, hi)
    y = mfsp_model(k, ps=X["PS price ($/kg)"], oil=X.get("Waste cooking oil ($/kg)"), spk=X.get("HEFA-SPK price ($/kg)"),
                   liq=X["Liquid fraction (Sc-specific)"], capex=X["Installed capital multiplier"], irr=X["IRR"],
                   ons=X["On-stream factor"], cap=X["Plant capacity multiplier"], h2=X["H2 / energy cost multiplier"])
    y = np.asarray(y); samples[k] = y
    mc_rows.append(dict(config=newlab(k), base=float(mfsp_model(k)), mean=y.mean(), std=y.std(), P5=np.percentile(y, 5), P50=np.percentile(y, 50),
                        P95=np.percentile(y, 95), prob_below_parity=(y <= PARITY).mean() * 100, N=N_MC))
    for n_ in (1000, 2000, 5000):
        conv.append(dict(config=newlab(k), N=n_, mean=y[:n_].mean(), P5=np.percentile(y[:n_], 5), P95=np.percentile(y[:n_], 95)))
    for n in pnames:
        r = np.corrcoef(pd.Series(X[n]).rank(), pd.Series(y).rank())[0, 1]; spear.append(dict(config=newlab(k), parameter=n, spearman=r))
MC = pd.DataFrame(mc_rows); MC.to_csv(OUT + "monte_carlo_summary.csv", index=False)
pd.DataFrame(conv).to_csv(OUT + "monte_carlo_convergence.csv", index=False)
SP = pd.DataFrame(spear); SP.to_csv(OUT + "monte_carlo_spearman.csv", index=False)
dr = []
for n, v in DIST.items():
    if v[0] is None:
        for scn, lab in (("Sc2", "Liquid fraction, Sc1 PS-only (old Sc2)"), ("Sc1", "Liquid fraction, Sc2 co-hydropyrolysis (old Sc1)")):
            dr.append(dict(parameter=lab, min=LIQ[scn][0], mode=LIQ[scn][1], max=LIQ[scn][2], applies_to=v[1], basis=v[2]))
    else:
        dr.append(dict(parameter=n, min=v[0][0], mode=v[0][1], max=v[0][2], applies_to=v[1], basis=v[2]))
pd.DataFrame(dr).to_csv(OUT + "monte_carlo_distribution_table.csv", index=False)

# ---------- 3. figures (relabelled) ----------
ORDER = ["Sc2_SMR", "Sc2_SOEC", "Sc2_Photocatalysis", "Sc1_SMR", "Sc1_SOEC", "Sc1_Photocatalysis"]  # new Sc1 (old Sc2) first
# Fig A: MFSP stacked, single panel, revised prices
fig, ax = plt.subplots(figsize=(9, 4.8)); bot_p = np.zeros(6); bot_n = np.zeros(6)
cols = {"Feedstock": "#C0392B", "Capital depreciation": "#2E86C1", "Fixed operating": "#8E44AD", "Utilities": "#F39C12", "Co-product credit": "#27AE60"}
nets = []
for i, k in enumerate(ORDER):
    g = mf[mf.scenario == k].set_index("category").value.copy(); m = S[k]
    g["Feedstock"] = m["ps_per"] * P0["ps"] + m["oil_per"] * P0["oil"] + m["spk_per"] * P0["spk"] + m["other_feed"]; nets.append(g.sum())
for cat, c in cols.items():
    v = np.array([mf[(mf.scenario == k) & (mf.category == cat)].value.iloc[0] if cat != "Feedstock" else
                  S[k]["ps_per"] * P0["ps"] + S[k]["oil_per"] * P0["oil"] + S[k]["spk_per"] * P0["spk"] + S[k]["other_feed"] for k in ORDER])
    pos = np.where(v > 0, v, 0); neg = np.where(v < 0, v, 0)
    ax.bar(range(6), pos, bottom=bot_p, color=c, label=cat, width=.6); ax.bar(range(6), neg, bottom=bot_n, color=c, width=.6); bot_p += pos; bot_n += neg
ax.scatter(range(6), nets, color="k", marker="D", zorder=5, label="Net MFSP")
for i, n in enumerate(nets): ax.text(i, n + .05, f"${n:.2f}", ha="center", fontsize=8)
ax.axhline(PARITY, color="navy", ls="--", lw=1.2, label="Fossil-jet parity $1.09/kg")
ax.set_xticks(range(6)); ax.set_xticklabels([newlab(k) for k in ORDER], fontsize=9); ax.set_ylabel("MFSP (USD/kg fuel)")
ax.set_title("MFSP decomposition, revised feedstock prices (oil $0.70/kg placeholder)", fontsize=10); ax.legend(fontsize=7, ncol=2, frameon=False); ax.spines[["top", "right"]].set_visible(False)
fig.tight_layout(); fig.savefig(OUT + "Fig_MFSP_stacked_R1.png", dpi=200); plt.close(fig)

# Fig B: Monte Carlo histograms 2x3
fig, axes = plt.subplots(2, 3, figsize=(13, 7))
for ax, k in zip(axes.ravel(), ORDER):
    y = samples[k]; ax.hist(y, bins=50, color="#5D8AA8", edgecolor="k", lw=.3, alpha=.8)
    for p, st in ((5, "--"), (50, "-"), (95, "--")): ax.axvline(np.percentile(y, p), color="k", ls=st, lw=1)
    ax.axvline(PARITY, color="navy", ls="-.", lw=1.3); ax.set_title(f"{newlab(k)}  P5-P95 \\${np.percentile(y,5):.2f}-\\${np.percentile(y,95):.2f}", fontsize=9)
    ax.set_xlabel("MFSP (USD/kg)"); ax.spines[["top", "right"]].set_visible(False)
fig.suptitle(f"Monte Carlo (N={N_MC}, LHS, triangular, independent); dash-dot = parity \\$1.09/kg", fontsize=10); fig.tight_layout()
fig.savefig(OUT + "Fig_MonteCarlo_R1.png", dpi=200); plt.close(fig)

# Fig C: equal-basis comparison
fig, ax = plt.subplots(figsize=(7, 4)); w = .38; x = np.arange(6)
ax.bar(x - w/2, [EQ.set_index("config").loc[newlab(k), "MFSP_revised_prices"] for k in ORDER], w, label="Equal PS feed (250 t/d)", color="#7FB3D5")
ax.bar(x + w/2, [EQ.set_index("config").loc[newlab(k), "MFSP_equal_product"] for k in ORDER], w, label="Equal product output", color="#1F618D")
ax.axhline(PARITY, color="navy", ls="--", lw=1); ax.set_xticks(x); ax.set_xticklabels([newlab(k) for k in ORDER], fontsize=8); ax.set_ylabel("MFSP (USD/kg)"); ax.legend(fontsize=8, frameon=False)
ax.spines[["top", "right"]].set_visible(False); fig.tight_layout(); fig.savefig(OUT + "Fig_EqualBasis_R1.png", dpi=200); plt.close(fig)

# Fig D: GWP well-to-wake stacked, g CO2-eq/MJ  (reads R1_results/lca_contributions.csv written by make_lca.py run, if present)
cf = D + "lca_contributions.csv"
try:
    lc = pd.read_csv(cf); lc = lc[lc.impact_category == "Global warming"]
    if lc[lc.contributor == "Fossil C combustion"].empty: raise FileNotFoundError("run the patched make_lca.py first (no combustion term in file)")
    old_lab = {"Sc1+SMR": "Sc1_SMR", "Sc1+SOEC": "Sc1_SOEC", "Sc1+Photo": "Sc1_Photocatalysis", "Sc2+SMR": "Sc2_SMR", "Sc2+SOEC": "Sc2_SOEC", "Sc2+Photo": "Sc2_Photocatalysis"}
    lc["new"] = lc.scenario.map(lambda s: newlab(old_lab[s])); fig, ax = plt.subplots(figsize=(9, 4.8)); bp = np.zeros(6); bn = np.zeros(6)
    cc = {"H₂ production": "#E57373", "Process heat (NG)": "#FF8A65", "Purchased SPK": "#FFB74D", "Fossil C combustion": "#6D4C41", "WCO treatment credit": "#81C784", "Char credit": "#4DB6AC"}
    labs = [newlab(k) for k in ORDER]
    for c, col in cc.items():
        v = np.array([lc[(lc.new == l) & (lc.contributor == c)].value_per_kg_SAF.sum() for l in labs]); pos = np.where(v > 0, v, 0); neg = np.where(v < 0, v, 0)
        ax.bar(range(6), pos, bottom=bp, color=col, label=c, width=.6); ax.bar(range(6), neg, bottom=bn, color=col, width=.6); bp += pos; bn += neg
    net = [lc[lc.new == l].value_per_kg_SAF.sum() for l in labs]; ax.scatter(range(6), net, color="k", marker="D", zorder=5, label="Net")
    for i, n in enumerate(net): ax.text(i, n + 2, f"{n:.0f}", ha="center", fontsize=8)
    ax.axhline(88.9, color="#B71C1C", ls="--", label="Jet-A well-to-wake 88.9"); ax.set_xticks(range(6)); ax.set_xticklabels(labs, fontsize=9)
    ax.set_ylabel("g CO₂-eq / MJ fuel (LHV)"); ax.set_ylim(-10, 105); ax.legend(fontsize=7, ncol=4, frameon=False, loc="upper center", bbox_to_anchor=(0.5, -0.08)); ax.spines[["top", "right"]].set_visible(False)
    ax.set_title("Well-to-wake GWP (no waste-oil incineration credit)", fontsize=10); fig.tight_layout(); fig.savefig(OUT + "Fig_GWP_WTW_gMJ_R1.png", dpi=200); plt.close(fig)
    print("GWP figure written")
except Exception as ex:
    print("GWP figure skipped:", ex)

pd.set_option("display.width", 220)
print(EQ.round(3).to_string()); print(MC.round(3).to_string()); print(pd.DataFrame(conv).round(3).to_string())
print(SP.sort_values("spearman", key=abs, ascending=False).groupby("config").head(2).round(2).to_string())
