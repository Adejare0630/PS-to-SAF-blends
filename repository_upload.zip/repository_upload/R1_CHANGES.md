# Module_R1: changes made for reviewer comments

Originals in `Module/` are untouched. Run order is unchanged: `python main.py`.

## What changed

| File | Change | Reviewer |
|---|---|---|
| `tea_20260605_1634/scripts/make_lca.py` | Well-to-wake boundary: new "Fossil C combustion" contributor (PS carbon only; waste-oil and HEFA carbon treated as biogenic). Waste-oil incineration credit OFF by default (`WCO_CREDIT_MODE`). Switches `INCLUDE_CHAR_CREDIT`, `INCLUDE_COMBUSTION`. New outputs `GWP_g_per_MJ`, `LHV_MJ_per_kg`. New `data/lca_credit_treatments.csv` (treatments A-F per scenario). Jet-A 88.9 g/MJ reference now matches the boundary. | R1.6, R1.15, R2.3 |
| `tea_20260605_1634/scripts/tea_model.py` | Waste-oil price 0.08 -> 0.70 $/kg default (env `OIL_PRICE_KG`). PS and SPK prices env-overridable (`PS_PRICE_KG`, `SPK_PRICE_KG`). | R1.5 |
| `main.py`, `make_cashflow.py`, `make_npv.py` | Premium-SAF reference ($1.80/kg, $5.50/GGE) removed. Replaced by fossil-jet parity ($1.09/kg) and parity +20%. | R1.13 |
| `hydrogen_production.py` | Audit switches; defaults reproduce the submitted values: `SOEC_CAPEX_USD_PER_KW`, `SMR_REF_COST_USD`, `PHOTO_IRRADIANCE_W_M2`. | R1.10 |

## You still need to do

1. **Replace placeholder prices with cited values.** $0.70/kg oil is a midpoint of reported ranges. Also cite PS price, SPK price, and natural gas ($4.15/GJ in code vs $4.00/GJ in Table 2).
2. **Audit the H2 capital costs.** The submitted SOEC costs about $106/kW (4.94M for 46.4 MW at the 1,000 kg/h reference). Cite a source, then run e.g. `set SOEC_CAPEX_USD_PER_KW=1500` (Windows cmd) and compare. Same for `SMR_REF_COST_USD`. For photocatalysis try `set PHOTO_IRRADIANCE_W_M2=250`.
3. **Electricity factor inconsistency.** `hydrogen_production.py` uses NGCC 0.49 kg CO2/kWh, but the LCA uses the ecoinvent 10 MW natural-gas plant (about 0.7 kg/kWh implied by Sc1+SOEC H2 = 1.07 kg/kg). Pick one and justify it.
4. **Fig. 14.** Regenerate it from the new `lca_results.csv`. The old SOEC bars disagree with Table S9.
5. **Sc2 "Purchased SPK" is -0.053 kg CO2-eq/kg (negative).** Check the sign and dataset.
6. **Carbon fractions** in `make_lca.py` (`C_FRAC_*`) are assumptions. Replace them with the composition from the BioSTEAM streams.
7. **Not implemented:** equal-product-basis run, Monte Carlo distribution table, product-property validation vs ASTM, Sc1/Sc2 relabelling, `CAT_UNITS` strings still say "per kg SAF".
8. `make_tornado.py`: the `wco_credit` bar is now zero in the base case (credit off).

## Tested

`make_lca.py` was executed with stubbed model streams from `data/material_balance_totals.csv`. It reproduces the R1 reanalysis numbers (e.g. Sc1+SMR 2.30 kg/kg, 40% below Jet-A). The BioSTEAM-dependent scripts were only syntax-checked, because BioSTEAM is not installable in my environment.

Note: `tea_20260605_1634/plots` in this folder was copied from your original and contains unrelated personal files (CVs, cover letters). Delete that subfolder from `Module_R1` if you do not need it.

---

## Update 2: GWP in g CO2-eq/MJ, and further model corrections

### GWP unit (as requested: g CO2-eq/MJ)
`make_lca.py` now converts GWP to **g CO2-eq/MJ (LHV)** immediately after the inventory calculation, so every plot, CSV and summary table uses it. Reference line = Jet-A well-to-wake 88.9 g/MJ (`FOSSIL_JET_G_PER_MJ`). LHV comes from the model: 43.2 MJ/kg (Sc1), 42.5 MJ/kg (Sc2 blend). `lca_results.csv` also carries `GWP_kg_per_kg` for reference. Other TRACI categories stay per kg of fuel. Note the column `value_per_kg_SAF` in `lca_contributions.csv` is in g/MJ for Global warming only.

Tested result (stubbed streams; base case = well-to-wake, no waste-oil credit): Sc1+SMR 53.2, Sc1+SOEC 71.3, Sc1+Photo 46.8, Sc2+SMR 39.2, Sc2+SOEC 45.0, Sc2+Photo 37.2 g CO2-eq/MJ (reductions vs 88.9: 40, 20, 47, 56, 49, 58 %).

### Further corrections made
- **make_tornado.py `ghg_base()` was stale for SOEC**: it used PV electricity and no water, so SOEC looked like photocatalysis. This is the likely cause of the Fig. 14 vs Table S9 SOEC mismatch (Fig. 14 base values -27.9 / -0.12 are PV-like). Fixed to NGCC electricity + water, as in `make_lca.py`. It also now follows the same well-to-wake / credit switches.

### Further problems found (NOT yet changed: need your decision)
1. **Labour = 5 % of FCI** (`tea_model.py`, `LABOR_FRAC_OF_FCI`). Labour then scales with capital: $32.7M/yr for Sc1+Photo vs $8.5M for Sc1+SMR for the same operation. Unphysical; it inflates photocatalysis fixed cost ($0.53/kg). Use a fixed headcount-based labour cost.
2. **TEA/LCA inconsistency on pyrolysis off-gas**: the TEA credits off-gas as on-site heat, but the LCA charges all process heat as purchased natural gas and does not count combustion of the off-gas. Make both treat it the same way.
3. **LCA inventory omissions**: pretreatment (wash water, electricity, effluent and 4,456 kg/h reject disposal), electricity for pyrolysis/pumps/compressors (only SOEC and photo-aux are included), Pd catalyst manufacture, collection/transport of PS and oil, SMR process water, and the O2 by-product (TEA credits O2, LCA does not). State these as cut-offs or add them.
4. **Catalyst is a one-time purchase** (`hydrogenation.py`: 0.5 % of feed mass x $50,000/kg Pd) with no replacement or regeneration cost in OpEx.
5. **Whole liquid stream treated as jet fuel** (13,455 kg/h at LHV 43.2): no distillation cut, though Table S6 has C6-C7 (benzene/toluene). Add a fractionation step or yield loss.
6. **Legacy `tea.py`** (20-yr life, 8,000 h, Lang factor 4.5, labour 15 % of FCI) conflicts with the active model (30 yr, 7,920 h, Peters-Timmerhaus, `tea_model.py`). Mark it legacy or delete it so it cannot be mistaken for the method in the paper.
7. **Pyrolyzer capital**: `Pyrolyzer vessel` = $850k x (feed/1,000)^0.65 gives about $6M for a 250 t/day reactor train; check against pilot-to-commercial data.
8. **`to_gge()`** uses one density (780 kg/m3) for both products and Sc2 parity is expressed on the Sc1 basis; use per-product density.
9. **Hydrogen demand**: model uses 0.033 kg H2/kg product (433 kg/h); the manuscript text says 0.06. Make the text match.
10. **Natural gas $4.15/GJ** in code vs $4.00/GJ in Table 2; income tax 35 % (federal 21 % + state now).

---

## Update 3: equal-product basis, Monte Carlo, yield ranges, relabelling, figures

Run `python R1_montecarlo_figures.py` in `Module_R1` (numpy/pandas/matplotlib only). Outputs in `R1_results/`.
This is a **surrogate** of the BioSTEAM model, not a rerun: elasticities fitted to your 1,000 saved LHS samples per configuration (R2 >= 0.999, `fit_quality.csv`), feedstock prices applied explicitly. Redo with BioSTEAM when possible.

- **Equal-product basis** (`equal_product_basis.csv`): PS-only route scaled to the co-hydropyrolysis product output (scale 0.806). MFSP changes by only +0.3 % (SMR/SOEC) and +1.2 % (photocatalysis); conclusion unaffected.
- **Monte Carlo** (`monte_carlo_distribution_table.csv`, `_summary.csv`, `_convergence.csv`, `_spearman.csv`): N = 5,000, Latin hypercube, independent triangular distributions with min/mode/max per parameter; convergence checked at 1,000/2,000/5,000 (P5/P95 stable to about 0.03 $/kg).
- **Yield ranges**: liquid fraction min/mode/max: PS-only 0.75 / 0.90 / 0.987 (literature PS-only liquid yields about 75-98.7 wt%); co-hydropyrolysis 0.65 / 0.86 / 0.95 (PS + oil co-pyrolysis data are sparse, about 64-80 wt%). **These ranges come from two quick searches, not a literature review: collect at least three cited sources per route before submission.**
- **Old Monte Carlo flaw**: +/-20 % on the liquid fraction allowed 0.90 x 1.19 = 1.07 (more than 100 % liquid). Now bounded.
- **Relabelling**: new figures/tables use Sc1 = PS-only (reference), Sc2 = co-hydropyrolysis (proposed). `relabel_csv.py` swaps the labels in BioSTEAM CSVs (run once, after a full rerun).
- **Figures** (relabelled, single panel): `Fig_MFSP_stacked_R1.png`, `Fig_GWP_WTW_gMJ_R1.png`, `Fig_MonteCarlo_R1.png`, `Fig_EqualBasis_R1.png`.
- Note: the stub test run overwrote `lca_results.csv`, `lca_contributions.csv` and `lca_credit_treatments.csv` in this Module_R1 copy with the new g/MJ, well-to-wake values (computed from stream totals saved in your CSVs). Originals in `Module/` are untouched.

---

## Update 3: equal-product basis, Monte Carlo + yield ranges, relabelling, figures

New/changed files:
| File | Purpose | Reviewer |
|---|---|---|
| `run_R1_analysis.py` | Driver: (1) equal-feed vs equal-product TEA, (2) price sweeps + breakeven prices vs parity, (3) Monte Carlo from a distribution table, (4) R1 figures. Run `python run_R1_analysis.py` (env: `R1_MC_N`, `R1_MC_CONV_N`, `R1_MC_CONV_CONFIGS`). Outputs in `R1_outputs/`. | R1.4, R1.5, R2.4 |
| `R1_mc_distributions.csv` | Editable table: parameter, applies_to (physical Sc numbering), low/mode/high multipliers, status, justification. Triangular, Latin hypercube. Adds the missing **waste-oil price** and **SPK price**; IRR 8-15 %; capital -30/+50 %; on-stream 80-95 %. | R2.4 |
| `R1_yield_ranges.csv` | Yield-source table. Search snippets give PS-only liquid yield 76-98.7 wt % (unverified secondary citations); **rows S5-S8 (Prajapati 2024, Li 2024, 2 independent co-pyrolysis studies) are blank: you must fill them**, then update the yield rows of the distribution table. | R1.2 |
| `tea_model.py` | `SC2_FEED_SCALE` (equal-product basis); `oil_price_mult` added to `sensitivity_mfsp()`. | R1.4, R1.5 |
| `main.py` | same `SC2_FEED_SCALE` | R1.4 |
| `scenario_relabel.py` + 1 import line in `main.py` and each `make_*.py` | **Display relabelling (R1.14)**: every matplotlib text swaps Sc1<->Sc2 at draw time, so all regenerated figures show Sc1 = PS-only (reference), Sc2 = co-hydropyrolysis (proposed). Internal IDs, CSV keys and code unchanged (physical scenario 1 = co-hydropyrolysis). Disable with `set SCENARIO_RELABEL=0`. | R1.14 |

Notes:
- CSVs from the old pipeline keep the OLD ids (`Sc1_SMR` = co-hydropyrolysis). CSVs written by `run_R1_analysis.py` use NEW labels in `scenario` and the old id in `model_label`.
- Plot order of the legacy figures is unchanged (co-hydropyrolysis bars first, now labelled Sc2). The R1 figures put the reference (new Sc1) first.
- `R1_mc_distributions.csv` uses PHYSICAL numbering in `applies_to` (sc1 = co-hydropyrolysis, has the waste oil).
- Capacity scaling exponent is 0.6 in `sensitivity_mfsp()` but 0.65 in the H2 units: harmonise.
- Regenerate the legacy figures with `python main.py` (relabelling is automatic).
- Tested with BioSTEAM replaced by stand-ins built from your saved CSVs: with oil at $0.08 the TEA reproduces your submitted MFSPs exactly. `R1_outputs/` currently holds only test files (see `README_STUBTEST.txt`); the real run overwrites them.

Also found in this folder (not created by this task): `R1_montecarlo_figures.py` and `R1_results/` (a surrogate-model Monte Carlo and figures dated today). I left them untouched. The surrogate fits elasticities to your saved samples; `run_R1_analysis.py` uses the real model and should replace it for the paper.

---

## Update 4: yield table, cited ranges, capacity exponent

- `R1_yield_ranges.csv`: PS-only range 76-98.7 wt% (4 secondary sources, verify originals); co-pyrolysis analogues (PS + biomass) 62-85 wt%. **Prajapati 2025 and Li 2025 yields could not be retrieved (paywalled): enter them from the papers.** Two notes added: (a) Table S6 says the PS-only composition follows Prajapati, but their thermal run was 400 C with crude-oil styrene ~55-57 wt%, whereas the model uses 550 C and 35 wt%; (b) the "2.5:1" ratio attributed to Li et al. vs the model's 60:40.
- `R1_mc_distributions.csv`: every range now carries a source or is labelled a judgement. Consensus changes: Sc1 (co-hydro) liquid-yield range 0.70-0.92 (was provisional), PS price $0.15-0.70, SPK $1.80-3.30, energy 0.68-1.40x.
- **Base-case change**: HEFA-SPK price default $1.50 -> **$2.10/kg** (`tea_model.py`, env `SPK_PRICE_KG`). PS stays $0.60 (conservative), oil $0.70.
- **Capacity exponent harmonised**: new `CAPACITY_SCALING_EXPONENT = 0.65` in `tea_model.py` replaces the hard-coded 0.6 in `sensitivity_mfsp()`.
- Indicative stand-in test (not model output, N=40): with SPK at $2.10 the PS-only route (new Sc1, SMR) is about $1.66/kg (+52 % vs $1.09 parity); co-hydropyrolysis (new Sc2, SMR) about $1.19/kg. Rerun for real numbers.

---

## Update 5: values taken from the two attached papers

**Li et al., Chem. Eng. Sci. 2025, 304, 121100** (source [9]): micro-scale (0.5 mg) two-stage fixed bed; palm kernel oil (also waste frying oil, cornus wisoniana oil) + PS foam; **waste oil : PS = 2.5 by mass (oil-rich, 71 wt% oil)**; 480 C / 0.15 MPa H2 / 350 C Pd/SBA-15. Liquid hydrocarbon yield 84.0 wt% best case (65.2-84.0 across PS types, 77.6-84.0 across oils); C8-C16 jet fraction 71.0 wt%, selectivity 84.5%. Yield = mass of C11/13/15/17 n-alkanes + ethylbenzene over total feed (not a full mass balance; no char/gas split).
**Prajapati et al., ACS Sustainable Chem. Eng. 2025, 13, 212-219** (source [4]): thermal PS pyrolysis at 375-400 C (not 550 C); liquid ~78 wt% (375 C) to ~96 wt% (400 C) read from Fig. 2 (approximate; gas not collected); styrene 44-61 wt% of product; Pd/C hydrogenation at 70 C near-quantitative; distilled EB 89.9 wt% with cumene 6.2, toluene 2.3, ethylcyclohexane 1.3 wt%.

Consequences:
1. **The model's PS:oil ratio (60:40, oil:PS = 0.67) is the inverse of Li's tested ratio (oil:PS = 2.5).** Li's yields/selectivities do not transfer to 60:40. New parameter `OIL_TO_PS_RATIO` (`tea_model.py`; env var also read by `main.py`) and a ratio sweep in `run_R1_analysis.py` -> `R1_outputs/R1_ratio_sweep.csv`. Direction (stand-in test; yields held fixed so the numbers are NOT results): more oil raises MFSP steeply because oil is priced at $0.70/kg. You must choose: adopt 2.5 (then re-derive the economics, and note PS becomes only 29 % of the feed, weakening the "PS valorisation" framing) or keep 60:40 and justify it with data at that ratio.
2. Yield ranges updated from the papers (`R1_yield_ranges.csv`, `R1_mc_distributions.csv`): co-hydropyrolysis liquid fraction range 0.65-0.90 (model 0.86 is above Li's 0.84 best case); PS-only 0.76-0.987.
3. Table S6 (PS-only composition "following Prajapati") does not match their conditions (375-400 C, styrene 44-61 wt%); the model uses 550 C and 35 wt% styrene. Source the 550 C profile elsewhere or move the model to 400 C.
4. Li's feed was palm kernel oil at micro-scale, not waste cooking oil at plant scale (WFO gave 77.6-84.0 wt%): add this as a limitation.

---

## Update 6: Li et al. oil:PS = 2.5 adopted as the base case

- `tea_model.py` and `main.py`: default `OIL_TO_PS_RATIO = 2.5` (71 wt% oil / 29 wt% PS). Set env `OIL_TO_PS_RATIO=0.6667` to reproduce the submitted 60:40 basis.
- `compounds.py`: Sc(physical 1) liquid fraction 0.86 -> **0.84** (Li best case); char/gas 0.07/0.09 (**assumption**: Li gives no split of the remaining 16 wt%; the submitted 6:8 proportion was kept).
- `R1_mc_distributions.csv` / `R1_yield_ranges.csv`: co-hydropyrolysis yield range re-based on 0.84 (multipliers 0.774-1.071).
- `make_contour_process.py`: base oil:PS ratio and the PS-fraction axis (now 0.15-0.85, base 0.29) follow `tm.OIL_TO_PS_RATIO`.
- PS stays at 250 t/day, so the oil feed becomes about 545 t/day (22.7 t/h; was 6.1 t/h) and the plant roughly doubles in product output (~2x). If you would rather fix total feed, change `PS_FEED_KG_HR`.
- LCA picks up the new streams automatically: the fossil (PS) share of product carbon falls from ~0.64 to ~0.32, so combustion CO2 of fossil carbon roughly halves; the waste-oil carbon is still treated as biogenic.
- Text to update in the manuscript: 167 t/day waste oil -> ~545 t/day; "PS:oil 60:40" -> "oil:PS 2.5"; Table S8 flows; the PS share of the feed (29 %) and any claim of PS valorisation scale.
- Rough hand estimate (not model output): feedstock cost per kg product is almost unchanged (~$0.8/kg at oil $0.70, PS $0.60), because PS and oil are similarly priced per kg and the liquid yield per kg feed is similar; capital per kg should fall with scale. So MFSP is likely to move less than the earlier stand-in sweep suggested, but the oil price becomes the dominant driver. Rerun `python run_R1_analysis.py` for real numbers.

---

## Update 7: Option A basis + Li's chemistry (ring-preserving hydrogenation, composition at oil:PS = 2.5)

Basis: **Option A** = PS fixed at 250 t/day (clean PS 9,085 kg/h), waste oil 22,714 kg/h (545 t/day), liquid 26,711 kg/h. No change needed to the feed code (already default).

Changed (Scenario "physical 1", i.e. co-hydropyrolysis):
- `compounds.py`: `SCENARIO1_PYRO_YIELDS` rebuilt from Li's Fig. 9 optimum: styrene 0.330 (-> ethylbenzene), Decane 0.172, Dodecane 0.229, Tetradecane 0.086, Hexadecane 0.183. Derivation: liquid 84.0 wt% of feed = EB 28.1 + C11-C15 n-alkanes 43.0 + C17 ~12.9 (by difference), read from Fig. 9c,d at 350 C. **Assumptions**: C11/C13/C15 split follows the palm-kernel fatty-acid profile; odd-carbon alkanes represented by the even-carbon species already defined. Submitted table kept as `SCENARIO1_PYRO_YIELDS_SUBMITTED`.
- `compounds.py`: `HYDROGENATION_CONVERSION` is now styrene -> ethylbenzene (0.98), ring preserved. The ring-saturating set is kept as `HYDROGENATION_CONVERSION_RING_SAT_SUBMITTED`.
- `hydrogenation.py`: styrene H2 ratio 0.078 -> 0.01937 (vinyl only); ethylbenzene now passes through the unit (otherwise it would be dropped from the mass balance).
- `compounds.py` + `tea_model.py` + `main.py`: new `OIL_HDO_H2_KG_PER_KG_OIL = 0.01` (**assumption**, lower bound) adds oxygen-removal H2 to the demand.
Hand calculation (no BioSTEAM): H2 demand ~394 kg/h (167 vinyl + 227 oxygen removal), product ~26.9 t/h, H2 ~0.015 kg/kg product. Product aromatics (ethylbenzene) ~33 wt% (~30 vol% by my density estimate), i.e. above the ~25 vol% finished-jet cap if used neat (verify against ASTM D1655/D7566): this is a **blendstock**, not a drop-in jet fuel.

Still open:
- Li reports no char/gas split or H2 balance; both are assumptions (see Update 6 and above).
- Real BioSTEAM run needed: `python run_R1_analysis.py` (and `python main.py`). Check Table S8, S6, the TPEC (the hydrogenation reactor now sees ~2x the throughput) and the material balance.
- The PS-only route (physical Sc2) is unchanged and still uses the ring-saturating extension in `SelectiveHydrogenationUnit`; apply the same ring-preserving review there for consistency (Prajapati stops at ethylbenzene).

---

## Update 8: product aromatics set to 23-25 vol% (oil:PS = 3.4)

Target (your choice): aromatics 23-25 vol% by raising the oil:PS ratio (volume basis; jet cap ~25 vol%, verify ASTM D1655/D7566).
- Li's per-feed yields at oil:PS 2.5 are EB = 0.9835 x PS mass and n-alkanes = 0.7826 x oil mass. Scaling them gives aromatics of 24.3 vol% (27.0 wt% ethylbenzene) at **oil:PS = 3.4**; the 23-25 vol% window corresponds to oil:PS 3.27-3.65 (density basis: EB 0.867, alkane mix 0.752 kg/L).
- `tea_model.py` / `main.py`: default `OIL_TO_PS_RATIO = 3.4` (env: 2.5 = Li as measured; 0.6667 = submitted).
- `compounds.py`: `SCENARIO1_PYRO_YIELDS` = styrene 0.265, Decane 0.189, Dodecane 0.251, Tetradecane 0.094, Hexadecane 0.201; liquid fraction 0.828, char 0.075, gas 0.097.
- MC yield range multipliers re-based (0.785-1.087); yield table model value 82.8.
- Hand calculation (not a BioSTEAM run): PS 9,085 kg/h (250 t/d), oil 30,890 kg/h (741 t/d), liquid 33.1 t/h, product 33.3 t/h, H2 ~475 kg/h, product aromatics 26.9 wt% = 24.2 vol%.
- CAUTION: 3.4 is outside Li's tested ratio (extrapolation). PS is only 23 % of the feed and the plant is ~2.5x the submitted product rate; oil supply 741 t/d is very large. Say this explicitly in the manuscript, and treat yields at 3.4 as an assumption.
- Re-run `python main.py` and `python run_R1_analysis.py`; check Table S6/S8 and that the product aromatics from the simulated stream sit in 23-25 vol%.

---

## Update 9: Li's 2.5 is the base case; 3.4 is a separate extrapolation scenario (supersedes the defaults in Updates 7-8)

Switch: env var **`SC1_CASE`** (read in `compounds.py`):
| Case | oil:PS | liquid / char / gas | pyrolysis-oil composition (styrene, C10, C12, C14, C16) | product aromatics |
|---|---|---|---|---|
| **`Li25` (default)** | 2.5 (Li as measured) | 0.840 / 0.070 / 0.090 | 0.330, 0.172, 0.229, 0.086, 0.183 | 33.5 wt% = 30.4 vol% (blendstock) |
| `Extrap34` | 3.4 (extrapolated) | 0.828 / 0.075 / 0.097 | 0.265, 0.189, 0.251, 0.094, 0.201 | 27.0 wt% = 24.3 vol% |

- `tea_model.py` and `main.py` take the ratio from the case (`SC1_OIL_TO_PS_RATIO`); env `OIL_TO_PS_RATIO` still overrides the ratio alone.
- `run_R1_analysis.py` writes to `R1_outputs/<case>/`; the MC liquid-yield multipliers are re-based on the active case (absolute range 0.65-0.90).
- **`run_R1_cases.py`** runs both cases and writes `R1_outputs/R1_case_comparison.csv` (MFSP, vs parity, MC P5/P50/P95, probability below parity).
- Windows (cmd): `set SC1_CASE=Extrap34` then `python main.py` / `python run_R1_analysis.py`; PowerShell: `$env:SC1_CASE="Extrap34"`.
- Tested: `compounds.py` loads both cases (composition sums = 1, fractions sum = 1, ratio and yields switch). The driver was syntax-checked only; the stand-in harness used earlier was lost, so the full driver has not been re-run since this change.
- Manuscript framing: Li25 = baseline (measured chemistry, blendstock with ~30 vol% aromatics); Extrap34 = sensitivity showing what an aromatics-compliant (<=25 vol%) product would need (more oil, PS only 23 % of feed, 741 t/d oil), with yields extrapolated.
- Files in `R1_outputs/` root (not in a case subfolder) are old stand-in test output (see README_STUBTEST.txt).

---

## Update 10: ratio sweep figure + sensitivity paragraph

- `compounds.py`: new `sc1_composition_for_ratio(r)` gives composition, liquid/char/gas fractions and product aromatics (wt%, vol%) for any oil:PS ratio from Li's per-feed yields (tested: r = 2.5 and 3.4 reproduce the case tables).
- `run_R1_analysis.py`: `ratio_sweep()` now sweeps r = 2.5, 2.75, 3.0, 3.25, 3.4, 3.5, 3.75 for the three H2 routes, rescaling composition and yields at each point (restores the active case afterwards); writes `R1_ratio_sweep.csv` (includes oil t/day, PS share, aromatics wt/vol%, MFSP, vs parity) and **`R1_fig_ratio_sweep.png`** (MFSP lines, aromatics curve, 23-25 vol% band, parity line; Li's 2.5 dotted, > 2.5 shaded as extrapolated). Layout tested on synthetic data; the real numbers need `python run_R1_analysis.py`.
- `R1_sensitivity_paragraph.md`: draft text for Methods, Results, caption, Conclusions limitation and the response to reviewers. Fill the [bracketed] values from the sweep CSV.

---

## Update 11: 3.4 kept as a labelled sensitivity

- Base case = `Li25` (oil:PS 2.5, measured). `Extrap34` and the ratio sweep stay, labelled as extrapolations.
- `run_R1_analysis.py`: every CSV now has a leading `case` column; figures of the `Extrap34` case carry the title/subtitle "EXTRAPOLATED CASE: oil:PS = 3.4, beyond Li's measured 2.5"; each output folder gets `CASE_NOTE.txt`; the ratio-sweep figure always shows 2.5 as measured and > 2.5 shaded as extrapolated.
- Report 3.4 only in the sensitivity section / SI (see `R1_sensitivity_paragraph.md`); headline numbers come from `R1_outputs/Li25/`.

---

## Update 12: PS-only route re-modelled on Prajapati et al. (physical Sc2; displayed "Scenario 1" after relabelling)

Switch: env **`SC2_CASE`** (read in `compounds.py`).

| Case | Basis | Chemistry / process |
|---|---|---|
| **`Prajapati16` (default)** | measured (ACS Sustainable Chem. Eng. 2025, 13, 212; values figure/slide-read, approximate) | 400 C thermal pyrolysis (liquid 0.96, char 0.02, gas 0.02; styrene 0.55, EB 0.02, toluene 0.03, cumene-type 0.05, lumped oligomers 0.35) -> vinyl-only Pd/C hydrogenation (70 C, 5 MPa, 98% styrene, **no ring saturation**) -> distillation to EB additive (EB recovery 0.70, ~91 wt% EB with cumene/toluene; paper cut 89.9 wt%) -> blend at **16 vol% (18.0 wt%)** in purchased HEFA-SPK |
| `Blend50` | EXTRAPOLATION (submitted) | 550 C composition, ring saturation at 200 C, 50:50 mass blend, no separation |

- `compounds.py`: new pseudo-component `StyreneOligomers` (MW 208.3, estimated Hf); `sc2_h2_demand_kg_hr()` is now the single source of Sc2 H2 demand (used by main.py and tea_model.py, including oligomer H2 = 90% x 2.016/208.3). New constants: `SC2_EB_RECOVERY`, `SC2_CUT_COMPANIONS`, `SC2_ADDITIVE_MASS_FRAC` (0.180), `SC2_BLEND_LHV_MJ_KG` (43.5 vs 42.5), `SC2_ENDS_LHV_MJ_KG` (40).
- `hydrogenation.py`: `SelectiveHydrogenationUnit` T/P/heat from the case, oligomer H2, no distillation cost line in `Prajapati16`; `SPKBlendingUnit` now contains the real EB distillation (cost coefficient DIST_COEFF and 600 kJ/kg heat are ASSUMPTIONS) and sets SPK = additive x (1-w)/w; outs[1] = other ends. New attributes `additive_kg_hr`, `ends_kg_hr`.
- Other ends (~58% of oil) are credited at fuel (heat) value only ($6.50/GJ x 40 MJ/kg) in main.py, tea_model.py and tea_bridge.py. In the LCA (make_lca.py, make_tornado.py) their net burden (fossil CO2 less displaced NG heat) is added to "Fossil C combustion" (GWP only).
- `run_R1_analysis.py`: outputs go to `R1_outputs/<SC1_CASE>[_Blend50]/`; new **`R1_EB_additive_cost.csv`** = implied EB additive cost = (blend MFSP x blend kg - SPK price x SPK kg) / additive kg, against market EB $1.10 / 1.25 / 1.70 per kg (2026 quotes ~$1,100-1,700/t: IMARC, Expert Market Research, ChemAnalyst - indicative, regional); MC PS-only liquid-yield range re-based on the active case (absolute 0.76-0.987).
- `R1_yield_ranges.csv`, `R1_mc_distributions.csv` updated.
- Tested: py_compile on all edited files; stand-alone mass balance (PS 9,085 kg/h): liquid 8,722; H2 118 kg/h; additive 3,805 kg/h (91% EB); SPK 17,328; blend 21,133; other ends ~5,030. BioSTEAM not available here: **run `python main.py`, `python run_R1_analysis.py` (and `set SC2_CASE=Blend50` for the extrapolation) in VS Code.**
- Caveats to state in the paper: the blend is SPK-dominated (82 wt%), so blended-fuel MFSP/GWP mainly reflect purchased HEFA; the EB additive cost is the primary metric. Composition, EB recovery, column cost/duty and the oligomer lump are approximations; EB-cut mass balance versus the paper (43.5% of oil at 89% EB) should be checked once the PDF figures are digitised. Ends credit at heat value is conservative.

---

## Update 13: 50:50 blend removed; blend aromatics 15-25 vol% sensitivity

- **Removed:** the submitted PS-only case (550 C composition, ring saturation, 50:50 mass blend, `SC2_CASE`/`Blend50`). Update 12's table row for `Blend50` no longer applies. `compounds.py` now has a single PS-only route (Prajapati measured basis).
- **Added:** env `SC2_BLEND_VOL_PCT` (15-25, default 16 = Prajapati's tested blend) and `compounds.sc2_blend_params(vol%)` (additive mass fraction, blend LHV). The additive (EB 91 wt% + cumene/toluene) is ~100% aromatic, so additive vol% = blend aromatics vol%.
- `run_R1_analysis.py`: `blend_sweep()` runs 15, 17.5, 20, 22.5, 25 vol% for the three H2 routes -> `R1_blend_sweep.csv` (additive/SPK/blend kg/h, LHV, blend MFSP, vs parity, implied EB-additive cost, blend GWP g/MJ) and `R1_fig_blend_sweep.png`. 16 vol% is the only tested point (12 and 16 tested by Prajapati); the rest are labelled extrapolated; 25 vol% = finished-jet aromatics cap (verify ASTM D1655/D7566).
- Behaviour to expect: additive output is fixed by the PS feed, so a higher blend share means less purchased SPK and less total fuel (additive 3.8 t/h -> blend 22.5 t/h at 15 vol%, 13.7 t/h at 25 vol%); blend MFSP rises toward the EB-additive cost, the implied additive cost is nearly unchanged.
- Syntax-checked only; not run (no BioSTEAM here).

---

## Update 14: 12 vol% tested point + blend-property table

- `SC2_BLEND_VOL_PCT` now accepts 12-25. `blend_sweep()` runs 12, 15, 17.5, 20, 22.5, 25 vol%; 12 and 16 vol% are labelled "tested by Prajapati", the rest "extrapolated". 8 vol% (possible seal-swell minimum) is shown only in the property table, not in the economics sweep, until the spec text is verified.
- New `blend_properties()` -> `R1_blend_properties.csv` (no BioSTEAM needed): ideal-mixing density, LHV (MJ/kg and MJ/L), additive mass %, flags for aromatics <= 25 vol% and density in 775-840 kg/m3, plus an `untested` column (distillation curve, freeze/flash point, viscosity, thermal stability, lubricity, seal swell, ASTM D4054 qualification).
- **Finding:** with HEFA-SPK at 752 kg/m3 and the additive at 867 kg/m3, ideal-mixing density of the blend is 770 kg/m3 at 16 vol% and reaches the 775 kg/m3 Jet A minimum only at ~20 vol%. So the tested 12 and 16 vol% blends sit below the density window on this estimate. Real HEFA-SPK density varies (about 750-770 kg/m3), so check the density of the SPK actually used and the spec text before drawing conclusions.

---

## Update 15: consistency fixes, supplementary analyses (17 Nov 2026)

Backups of every edited file: `_backup_before_update15/`.

| File | Change | Default / switch | Reviewer |
|---|---|---|---|
| `tea_model.py` | Labour is a fixed headcount cost (salaries $2.5M/yr + 90 % burden = $4.75M/yr), same for all six configurations, instead of 5 % of FCI. New `labor_cost()`, `fixed_operating_cost()`. | `LABOR_MODE=fci` reproduces submitted; `LABOR_SALARIES_USD_YR` | R1.8 (Sc1+Photo fixed cost), audit |
| `tea_model.py`, `tea_bridge.py` | Pd catalyst replacement added to operating cost: 10 %/yr of the initial charge (carried in `utility_cost_hr`, so every TEA path uses it). Initial charge stays in TPEC. | `CATALYST_ANNUAL_FRAC` (0 = submitted) | audit |
| `tea_model.py` | Income tax env-overridable (default 35 %, Humbird). | `INCOME_TAX=0.25` for the current-US sensitivity | strategy note |
| `tea_model.py`, `tea_bridge.py` | Off-gas CH4/H2 flows exported in `cfg["streams"]` for the LCA. | | R1.1 / consistency |
| `main.py`, `make_plots.py`, `make_contour_process.py` | Use `tm.fixed_operating_cost()` / `tm.labor_cost()`. | | |
| `make_lca.py`, `make_tornado.py` | (a) **Purchased HEFA-SPK GWP = CORSIA default UCO-HEFA 13.9 g CO2e/MJ** (well-to-wake core LCA). The OpenLCA poplar proxy had negative GWP (biogenic uptake) while SPK combustion is biogenic (0): double credit. (b) **Char credit net of the fossil CO2 of burning PS-derived char** (was gross coal displacement). (c) **Off-gas fired on site**: its LHV displaces purchased NG heat (capped at demand) and the CO2 of its fossil CH4 is charged (same as the TEA). (d) EB carbon fraction 0.88 -> 0.905. (e) "per kg SAF" labels -> "per kg fuel". | `SPK_GWP_MODE=openlca`, `CHAR_CREDIT_MODE=gross`, `OFFGAS_IN_LCA=0` reproduce the previous run | R1.6, R2.3 |
| `tea.py` | Marked LEGACY in its header (not used). | | |
| **`R1_supplementary.py`** (new) | Reads main.py outputs; writes `R1_outputs/supplementary/`: base GWP with new labels, credit/SPK treatments A-G, SOEC grid-intensity sensitivity + figure (break-even vs SMR), product-property screening vs ASTM D1655/D7566, airline cost impact (after run_R1_analysis.py). Runs without BioSTEAM. | | R1.3, R1.6, R2.2, R2.3, R2.5 |

### Results computed here (from your 17 Nov main.py stream totals; LCA only, no BioSTEAM needed)
Base case = well-to-wake, no WCO credit, net char credit, SPK = CORSIA UCO-HEFA. New labels: S1 = PS-only (reference), S2 = co-hydropyrolysis (proposed).

| Config | g CO2e/MJ | vs 88.9 |
|---|---|---|
| S1 + SMR / SOEC / Photo | 33.8 / 36.9 / 32.7 | -62 / -59 / -63 % |
| S2 + SMR / SOEC / Photo | 24.9 / 33.1 / 21.9 | -72 / -63 / -75 % |

- S1 is dominated by purchased SPK (11.6 g/MJ) and fossil-carbon combustion (19.8 g/MJ). With tallow-HEFA (22.5) S1 rises to ~41 g/MJ; with soybean-HEFA (40.4) to ~56 g/MJ.
- The submitted cradle-to-gate + incineration credit treatment gives -57 g/MJ for S2+SMR: the "carbon-negative" result came entirely from the boundary and the credit.
- Electricity dataset (ecoinvent NG 10 MW) = 716 g CO2e/kWh. SOEC beats SMR only below ~194 g/kWh (both scenarios).

### Product-property screening (pure-component data, ideal mixing; NOT measurements)
- S2 product (Li 2.5): density ~791 kg/m3 (pass), LHV 43.05 (pass), aromatics ~30 vol% (FAIL > 25), flash ~30-31 C (FAIL < 38; EB), freeze ~-8 to -15 C (FAIL; n-C16/C17 paraffins, would need hydroisomerisation, not modelled), FBP 287-302 C (marginal). => blendstock, not a finished fuel.
- S1 EB-additive blends in HEFA-SPK: density < 775 kg/m3 below ~20 vol%; flash point below 38 C above ~8-10 vol% (SPK flash 42-50 C assumed). No blend share satisfies both in this screen: light-ends (toluene) removal or blending into Jet A rather than SPK should be discussed. Measurements (D56, D86, D4052, D5972) are required before any claim.

### Still open (need your decision or data)
1. Cite every price (Table 2) and the staffing basis for labour.
2. SOEC/SMR capital audit (`SOEC_CAPEX_USD_PER_KW`, `SMR_REF_COST_USD`) and photocatalysis irradiance (`PHOTO_IRRADIANCE_W_M2`): run the sensitivity cases in RUN_CHECKLIST.
3. Electricity: hydrogen_production.py SOEC CO2 factor (NGCC 0.49 kg/kWh) vs LCA dataset (0.716): pick one.
4. LCA omissions still stated as cut-offs: pretreatment wash water/reject disposal, pump/compressor electricity, catalyst manufacture, feedstock collection/transport, O2 by-product credit.
5. Hydroisomerisation step for S2 (freeze point) is not modelled.

---

## Update 16: process flow diagrams (18 Nov 2026)

- New `make_pfd.py` -> `R1_response/PFD_Scenario1_PS_only.*`, `PFD_Scenario2_cohydropyrolysis.*` (PDF/SVG/600-dpi PNG): equipment tags (M-101, R-201, C-401, R-401, T-501, M-502, A-300, F-601), numbered streams, operating conditions, heat/power duties and a stream table from the 17 Nov run. `pfd_to_drawio.py` -> editable `R1_response/PFD_simulation_model.drawio` (2 pages). For R1.1 (replaces Figs. 2-3).
- `pyrolyzer.py`: PS-only route default temperature 550 -> 400 C (Prajapati basis). Affects only the stream temperature label (heat duty is 1,500 kJ/kg feed, independent of T).
- FOUND, NOT CHANGED: in the co-hydropyrolysis route the 227 kg/h of H2 allotted to oxygen removal (`OIL_HDO_H2_KG_PER_KG_OIL`) is costed but not consumed in the HydrogenationUnit mass balance; it leaves as stream 11 (off-gas). Either consume it in the unit (product oxygen removal) or state that the liquid yield already reflects deoxygenation and treat this H2 as excess sent to the fuel-gas header.
- Surplus heat: fuel gas (S2: 41 MW LHV vs 19.7 MW process heat) and side fractions (S1: 56 MW vs 6.1 MW) exceed demand. The TEA caps the off-gas credit but credits all side fractions at heat value; state this or cap it too.

---

## Update 17: styled PFDs + detailed hydrogen-production sheet (18 Nov 2026)

- `make_pfd_style.py` -> `R1_response/PFD_Scenario1_PS_only_style.*`, `PFD_Scenario2_cohydropyrolysis_style.*`, `PFD_Sheet3_H2_production_style.*` (PDF/SVG/PNG) and `PFD_simulation_model_style.drawio` (3 pages). Process-area bands, equipment symbols for every sub-item costed in each BioSTEAM unit (dashed outlines), stream diamonds = model streams. Sheet 3 details A-300: SMR (mixer, E-301/302/303, R-301 reformer, R-302 WGS, PSA, tail gas), SOEC (EL-301 stack, T-301 power electronics, C-311; P-311/E-311/E-313/V-311 marked * = not costed), photocatalysis (WT-321, PC-321 field, S-321 separation), streams H1-H10 with S1 | S2 flows.
- `PFD_stream_tables.xlsx`: ESI stream tables (both scenarios) with BioSTEAM stream IDs.
- `hydrogen_production.py`: SMR `CO2_emissions_kg_per_kgH2` fixed (was 4x too high: 28 -> 7.0 kg CO2/kg H2). Affects only the CO2 indicator on the TEA dashboard; the LCA uses 9.0 kg CO2e/kg H2.

---

## Update 18: TEA replica, revised results, Methods/Results text (18 Nov 2026)

- **`R1_tea_replica.py`**: stand-alone replica of simulate_config + run_tea (no BioSTEAM). Validated against the submitted results: MFSP 0.9015 / 0.9704 / 1.9642 vs submitted 0.9014 / 0.9702 / 1.9630 $/kg (co-hydropyrolysis SMR / SOEC / photo). Heat-utility factor 1.1085 calibrated (BioSTEAM heat-transfer efficiency); it cancels where the off-gas covers the heat demand.
- **`R1_replica_analysis.py`** -> `R1_outputs/replica/`: base TEA, TPEC by area, breakevens, implied EB-additive cost, audit cases (tax, labour basis, SOEC $/kW, SMR cost, PC irradiance, equal-product basis, blend share), tornado over sourced ranges, Monte Carlo (N=1,000; N=3,000 convergence for SMR), airline cost impact. Pre-rerun estimates: S1 (PS-only) MFSP 2.15 / 2.17 / 2.29 $/kg; S2 (co-hydropyrolysis) 1.08 / 1.12 / 1.46 $/kg (SMR / SOEC / photo).
- `tea_model.sensitivity_mfsp()`: SPK purchase cost now scales with the liquid-yield multiplier for the PS-only route (SPK is bought in a fixed ratio to the additive); previously higher yield gave more product without more SPK cost.
- `R1_outputs/supplementary/R1_traci_per_MJ.csv`: all TRACI categories per MJ with the Update 15 LCA.
- **`make_r1_results_figs.py`** -> `R1_response/figs_R1/`: Fig5_MFSP_breakdown, Fig7_capex_opex, Fig10_tornado, Fig12_GWP_WTW, FigS3_MonteCarlo (new labels, per MJ, parity line). After the BioSTEAM rerun set TEA_DIR to the rerun outputs and regenerate.
- **`R1_response/PS_Fuel_Methods_Results_Discussion.docx`**: full revised Sections 2 and 3.
- NOTE: the plots produced by main.py on 17 Nov predate Update 15 and still label co-hydropyrolysis "Sc1" (scenario_relabel did not apply to mfsp_stacked_bar). Regenerate and check labels.

---

## Update 19: main.py vs paper reconciliation (18 Nov 2026)

- See `R1_response/RECONCILIATION_main_vs_paper.md`. The 17-Nov main.py outputs predate Updates 15/18; the replica reproduces them exactly (MFSP and TPEC) with the 17-Nov settings.
- `tea_model.run_sensitivity()` / `run_uncertainty()` (used by main.py) now use the sourced ranges of `R1_mc_distributions.csv` (incl. waste-oil and SPK prices) instead of +/-20 %; `R1_LEGACY_RANGES=1` restores the old ranges. Verified: same tornado and Monte Carlo as the paper.

## Update 20 (18 Nov 2026): full revised manuscript and ESI
- New script `R1_extra_figs.py` (headless; loads only the LCA part of make_tornado.py, so main.py/BioSTEAM are not needed):
  Fig_TPEC_by_area, Fig_cashflow_NPV, Fig_literature_GJ, Fig_GWP_tornado, Fig_TRACI_heatmap (R1_response/figs_R1/),
  R1_outputs/replica/{cashflow_payback, gwp_tornado}.csv, R1_outputs/supplementary/R1_lca_inventory_per_MJ.csv.
- NPV(10%) at $1.09/kg: S2+SMR +7 MM$ (payback 12 yr), S2+SOEC -32, S2+PC -487, S1 -1,321 to -1,473 MM$.
  At $1.31/kg: S2+SMR +259 (3 yr), S2+SOEC +223 (4 yr), S2+PC -191 (19 yr), S1 -1,041 to -1,193 MM$.
- R1_response/PS_Fuel_Revised_Manuscript_Full.docx: full manuscript (title to references; Figs 1-14; refs 1-39,
  new 33-39 = ICAO doc 06, ReFuelEU 2023/2405, ASTM D1655, D7566, Liaw 2002, ISO 14040/44, Del. Reg. 2023/1185).
- R1_response/PS_Fuel_ESI.docx (Tables S1-S23, Figs S1-S2) and PS_Fuel_ESI_Data.xlsx (one sheet per table).
- TEA numbers are still replica estimates: after the BioSTEAM rerun, rerun R1_replica_analysis.py / R1_extra_figs.py
  equivalents on the BioSTEAM outputs and update. ESI Section S9 (oil:PS ratio sweep) awaits run_R1_analysis.py.

## Update 21 (18 Nov 2026): figures made legible in Word
- Figures were drawn at sizes that shrank text to 2.5-5 pt in Word. Word-sized versions now in R1_response/figs_word/
  (text >= 7.5 pt at print size for charts; ~5.5-6.5 pt minimum on the PFDs, previously ~2.5 pt).
- PFDs: make_pfd_word.py (labels x1.55, stream diamonds x1.3, overlapping labels repositioned); placed on landscape pages.
- System boundary figure split into (a) Scenario 1 and (b) Scenario 2, each on a landscape page.
- Charts: make_r1_results_figs_word.py, R1_extra_figs_word.py (larger fonts, figure widths = Word text width, legends
  moved out of the plot area); grid-sensitivity and price-sweep figures redrawn.
- Manuscript and ESI rebuilt with these images (manuscript now 28 pages including 6 landscape figure pages).

## Update 22 - Oil:PS ratio sweep (ESI S9)
- Ran run_R1_ratio_sweep.py in BioSTEAM (oil:PS 2.5, 2.75, 3.0, 3.25, 3.5, 3.75 x SMR/SOEC/Photocatalysis). At 2.5 it matches the base case exactly.
- ESI S9 placeholder replaced with text, Table S24 and Fig. S3 (figure redrawn so the legend is not clipped). Table S24 added to the data workbook.
- Manuscript Section 2.2.3: placeholder replaced with the ESI reference and a sentence on the trends (SMR MFSP 1.084 -> 1.073 $/kg; GWP 24.9 -> 17.6 g/MJ; WCO 545 -> 818 t/d; aromatics reach 25 vol% at oil:PS ~3.3). ESI and Data-availability ranges updated to Tables S1-S24, Figs. S1-S3.
- Outputs: PS_Fuel_Revised_Manuscript_Full_v4.docx, PS_Fuel_ESI_v4.docx, PS_Fuel_ESI_Data_v4.xlsx.
