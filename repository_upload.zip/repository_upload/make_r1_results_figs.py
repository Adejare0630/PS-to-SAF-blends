"""
make_r1_results_figs.py - revised Results figures (new scenario labels, per-MJ GWP, single panels, parity line).
Reads R1_outputs/replica/*.csv (or the BioSTEAM equivalents after the rerun: point TEA_DIR at them) and
R1_outputs/supplementary/R1_lca_base.csv. Writes R1_response/figs_R1/*.png|pdf.

    python make_r1_results_figs.py
"""
import os, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
TEA_DIR = os.path.join(HERE, "R1_outputs", "replica")
LCA = os.path.join(HERE, "R1_outputs", "supplementary", "R1_lca_base.csv")
OUT = os.path.join(HERE, "R1_response", "figs_R1"); os.makedirs(OUT, exist_ok=True)
plt.rcParams.update({"font.family": ["Arial", "Liberation Sans", "DejaVu Sans"], "font.size": 8, "pdf.fonttype": 42,
                     "axes.spines.top": False, "axes.spines.right": False})
ORDER = ["S1 PS-only + SPK blend + SMR", "S1 PS-only + SPK blend + SOEC", "S1 PS-only + SPK blend + Photo",
         "S2 co-hydropyrolysis + SMR", "S2 co-hydropyrolysis + SOEC", "S2 co-hydropyrolysis + Photo"]
TICK = ["S1\nSMR", "S1\nSOEC", "S1\nPhoto", "S2\nSMR", "S2\nSOEC", "S2\nPhoto"]
PAL = {"feedstock": "#2C4A6E", "capital": "#E1A23A", "fixed_op": "#4E9A7A", "utilities": "#C2563B", "coproduct": "#8FB3D9"}
PAR, JET = 1.09, 88.9


def save(fig, name):
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(OUT, f"{name}.{ext}"), dpi=400, bbox_inches="tight")
    plt.close(fig)


def groups(ax):
    ax.axvline(2.5, color="#BBBBBB", lw=0.8, ls=":")
    y = ax.get_ylim()[1]
    ax.text(1.0, y * 0.985, "Scenario 1: PS-only (reference)", ha="center", va="top", fontsize=7.5, color="#444444")
    ax.text(4.0, y * 0.985, "Scenario 2: co-hydropyrolysis (proposed)", ha="center", va="top", fontsize=7.5, color="#444444")


t = pd.read_csv(os.path.join(TEA_DIR, "tea_base.csv")).set_index("scenario").loc[ORDER]

# ---- Fig. MFSP decomposition ----
fig, ax = plt.subplots(figsize=(6.8, 3.6))
x = np.arange(6)
pos = np.zeros(6)
for k, lab in (("feedstock", "Feedstock"), ("capital", "Capital recovery"), ("fixed_op", "Fixed operating"), ("utilities", "Utilities + catalyst")):
    ax.bar(x, t[k], 0.6, bottom=pos, color=PAL[k], label=lab, zorder=3); pos += t[k].values
ax.bar(x, t["coproduct"], 0.6, color=PAL["coproduct"], label="Co-product credit", zorder=3)
ax.scatter(x, t["MFSP_usd_kg"], marker="D", s=22, color="black", zorder=5, label="Net MFSP")
for i, v in enumerate(t["MFSP_usd_kg"]):
    ax.text(i, pos[i] + 0.05, f"${v:.2f}\n({t['MFSP_usd_GJ'].iloc[i]:.1f} $/GJ)", ha="center", fontsize=6.6)
ax.axhline(PAR, color="#C62828", ls="--", lw=1); ax.text(5.45, PAR + 0.03, "fossil-jet parity $1.09/kg", ha="right", fontsize=6.8, color="#C62828")
ax.axhline(0, color="black", lw=0.6)
ax.set_xticks(x, TICK); ax.set_ylabel("MFSP (2023 USD per kg fuel)"); ax.set_ylim(-0.25, 2.95)
groups(ax); ax.legend(fontsize=6.6, ncol=6, loc="upper center", bbox_to_anchor=(0.5, -0.17), frameon=False, columnspacing=1.0)
ax.grid(axis="y", color="#EEEEEE", zorder=0)
save(fig, "Fig5_MFSP_breakdown")

# ---- Fig. capital and operating cost ----
fig, (a1, a2) = plt.subplots(1, 2, figsize=(6.8, 2.9))
a1.bar(x, t["TPEC_MM"], 0.6, color="#2C4A6E", label="Purchased equipment (TPEC)", zorder=3)
a1.bar(x, t["FCI_MM"] - t["TPEC_MM"], 0.6, bottom=t["TPEC_MM"], color="#8FB3D9", label="Installation + indirect", zorder=3)
a1.bar(x, t["TCI_MM"] - t["FCI_MM"], 0.6, bottom=t["FCI_MM"], color="#E1A23A", label="Working capital", zorder=3)
for i, v in enumerate(t["TCI_MM"]):
    a1.text(i, v + 15, f"{v:.0f}", ha="center", fontsize=6.6)
a1.set_xticks(x, TICK); a1.set_ylabel("Total capital investment (MM USD)"); a1.legend(fontsize=6.2, frameon=False); a1.set_title("(a) Capital", fontsize=8)
a2.bar(x, t["VOC_MM_yr"], 0.6, color="#2C4A6E", label="Variable (feedstock, utilities)", zorder=3)
a2.bar(x, t["FOC_MM_yr"], 0.6, bottom=t["VOC_MM_yr"], color="#4E9A7A", label="Fixed", zorder=3)
a2.bar(x, -t["byproduct_MM_yr"], 0.6, color="#8FB3D9", label="Co-product credit", zorder=3)
for i in range(6):
    a2.text(i, t["VOC_MM_yr"].iloc[i] + t["FOC_MM_yr"].iloc[i] + 6, f"{t['VOC_MM_yr'].iloc[i] + t['FOC_MM_yr'].iloc[i]:.0f}", ha="center", fontsize=6.6)
a2.axhline(0, color="black", lw=0.6)
a2.set_xticks(x, TICK); a2.set_ylabel("Annual operating cost (MM USD/yr)"); a2.legend(fontsize=6.2, frameon=False); a2.set_title("(b) Operating", fontsize=8)
for a in (a1, a2):
    a.axvline(2.5, color="#BBBBBB", lw=0.8, ls=":"); a.grid(axis="y", color="#EEEEEE", zorder=0)
fig.tight_layout(); save(fig, "Fig7_capex_opex")

# ---- Fig. Monte Carlo ----
mc_path = os.path.join(TEA_DIR, "mc_summary.csv")
if os.path.exists(mc_path):
    mc = pd.read_csv(mc_path).set_index("scenario").loc[ORDER]
    fig, ax = plt.subplots(figsize=(6.0, 3.0))
    for i, r in enumerate(mc.itertuples()):
        ax.plot([i, i], [r.P5, r.P95], color="#2C4A6E", lw=1)
        ax.add_patch(plt.Rectangle((i - 0.22, r.P25), 0.44, r.P75 - r.P25, fc="#DCE6F2", ec="#2C4A6E", lw=0.9, zorder=3))
        ax.plot([i - 0.22, i + 0.22], [r.P50, r.P50], color="#2C4A6E", lw=1.4, zorder=4)
        ax.scatter([i], [r.base], marker="D", s=14, color="black", zorder=5)
        ax.text(i + 0.27, r.P95, f"P(<parity)\n{100 * r.prob_below_parity:.0f}%", fontsize=6.0, va="top")
    ax.axhline(PAR, color="#C62828", ls="--", lw=1)
    ax.set_xticks(x, TICK); ax.set_ylabel("MFSP (USD per kg fuel)")
    ax.axvline(2.5, color="#BBBBBB", lw=0.8, ls=":"); ax.grid(axis="y", color="#EEEEEE", zorder=0)
    ax.set_title("Box: P25-P75; whiskers: P5-P95; line: P50; diamond: base case (N = 1,000, Latin hypercube)", fontsize=6.8)
    save(fig, "FigS3_MonteCarlo")

# ---- Fig. tornado (SMR configurations) ----
tor_path = os.path.join(TEA_DIR, "tornado.csv")
if os.path.exists(tor_path):
    tor = pd.read_csv(tor_path)
    fig, axs = plt.subplots(1, 2, figsize=(6.8, 2.9))
    for a, s, ttl in ((axs[0], ORDER[0], "(a) Scenario 1 + SMR"), (axs[1], ORDER[3], "(b) Scenario 2 + SMR")):
        d = tor[tor.scenario == s].sort_values("swing").tail(8)
        b = t.loc[s, "MFSP_usd_kg"]
        y = np.arange(len(d))
        a.barh(y, d.MFSP_low - b, left=b, color="#8FB3D9", zorder=3, label="low end of range")
        a.barh(y, d.MFSP_high - b, left=b, color="#2C4A6E", zorder=3, label="high end of range")
        a.axvline(b, color="black", lw=0.8); a.axvline(PAR, color="#C62828", ls="--", lw=0.9)
        a.set_yticks(y, d.parameter, fontsize=6.6); a.set_xlabel("MFSP (USD/kg)"); a.set_title(ttl, fontsize=8)
        a.grid(axis="x", color="#EEEEEE", zorder=0)
    axs[0].legend(fontsize=6.2, frameon=False, loc="lower right")
    fig.tight_layout(); save(fig, "Fig10_tornado")

# ---- Fig. GWP per MJ ----
l = pd.read_csv(LCA)
l["key"] = l.scenario.str.replace("Photo", "Photo")
l = l.set_index("scenario").loc[ORDER]
cols = [("H₂ production [g/MJ]", "H₂ production", "#C2563B"), ("Process heat (NG) [g/MJ]", "Process heat (NG, net of off-gas)", "#E1A23A"),
        ("Purchased SPK [g/MJ]", "Purchased HEFA-SPK", "#4E9A7A"), ("Fossil C combustion [g/MJ]", "Fossil-carbon combustion", "#6D4C41"),
        ("Char credit [g/MJ]", "Char credit (net)", "#8FB3D9"), ("WCO treatment credit [g/MJ]", "WCO credit (excluded)", "#BBBBBB")]
fig, ax = plt.subplots(figsize=(6.8, 3.4))
pos = np.zeros(6); neg = np.zeros(6)
for c, lab, col in cols:
    v = l[c].values
    p = np.where(v > 0, v, 0); n = np.where(v < 0, v, 0)
    if np.abs(v).sum() < 1e-9:
        continue
    ax.bar(x, p, 0.6, bottom=pos, color=col, label=lab, zorder=3); pos += p
    ax.bar(x, n, 0.6, bottom=neg, color=col, zorder=3); neg += n
ax.scatter(x, l["GWP_g_per_MJ"], marker="D", s=22, color="black", zorder=5, label="Net GWP")
for i, v in enumerate(l["GWP_g_per_MJ"]):
    ax.text(i, pos[i] + 2, f"{v:.1f}\n(−{l['reduction_vs_JetA_pct'].iloc[i]:.0f}%)", ha="center", fontsize=6.6)
ax.axhline(JET, color="#C62828", ls="--", lw=1); ax.text(5.45, JET + 1.5, "fossil Jet A 88.9 g CO₂e/MJ (well-to-wake)", ha="right", fontsize=6.8, color="#C62828")
ax.axhline(0, color="black", lw=0.6)
ax.set_xticks(x, TICK); ax.set_ylabel("GWP (g CO₂e per MJ fuel, LHV)"); ax.set_ylim(-10, 100)
groups(ax); ax.legend(fontsize=6.4, ncol=3, loc="upper left", bbox_to_anchor=(0.0, 0.9), frameon=False)
ax.grid(axis="y", color="#EEEEEE", zorder=0)
save(fig, "Fig12_GWP_WTW")
print("figures written to", OUT)
