# pretreatment.py
# Raw waste-PS pretreatment: shredding, washing, and drying before pyrolysis

import biosteam as bst
from compounds import (
    PRETREAT_MOISTURE_FRAC, PRETREAT_CONTAM_FRAC, PRETREAT_PS_LOSS_FRAC,
)


class PSPretreatmentUnit(bst.Unit):
    """
    Pretreatment of raw waste polystyrene bales prior to pyrolysis: size
    reduction (shredding), contaminant removal (washing / float-sink
    screening), and drying.

    A real waste-PS collection stream is not pure polymer -- baled
    post-consumer/industrial PS typically carries surface moisture and a few
    percent non-PS contamination (labels, adhesive residue, dirt/grit,
    mixed-polymer fines). Removing these protects the downstream Pd
    catalysts (used in hydrogenation) from halogen/ash-driven poisoning that
    is not otherwise modeled, and gives a physically honest mass balance
    between the plant's raw feedstock intake and the clean PS that actually
    reaches the pyrolysis reactor.

    Parameters
    ----------
    ID : str
        Unit identifier.
    ins : list
        ins[0] = raw waste PS feed (bales), ins[1] = wash water (flow set
        internally by this unit -- pass an empty placeholder stream).
    outs : list
        outs[0] = clean, dry PS (to pyrolyzer). outs[1] = reject stream
        (moisture + contaminants + PS fines + spent wash water).
    electricity_price : float
        USD/kWh for the shredder. Default 0.0804 (2023 EIA industrial avg.).
    water_price : float
        USD/kg for fresh wash water. Default 0.001.
    """

    _N_ins  = 2
    _N_outs = 2

    # Capital cost: C = base_cost * (capacity / ref_capacity) ** exponent
    # Basis: CEPCI 800 (2023), Peters & Timmerhaus sizing correlation.
    # Sized to the RAW feed throughput -- the equipment processes the full
    # incoming bale stream, not just the recovered PS.
    _purchase_cost_coefficients = {
        'Shredder':             (400_000, 1000, 0.65),
        'Wash / screen system': (350_000, 1000, 0.60),
        'Dryer':                (300_000, 1000, 0.65),
    }

    # Shredder specific energy (typical for rigid/foam plastic size reduction)
    SHRED_KWH_PER_KG = 0.03           # kWh electricity / kg raw feed
    # Dryer heat duty per kg moisture removed (latent heat + sensible/inefficiency margin)
    DRY_HEAT_KJ_PER_KG_WATER = 2700   # kJ/kg water evaporated
    # Fresh water makeup (float-sink separation + rinse, with recirculation --
    # only replaces water lost to evaporation/entrainment, not a full-throughput draw)
    WASH_WATER_RATIO = 0.3            # kg fresh wash water / kg raw feed

    def __init__(self, ID='', ins=(), outs=(), electricity_price=0.0804,
                 water_price=0.001):
        super().__init__(ID, ins, outs)
        self.electricity_price = electricity_price   # USD/kWh
        self.water_price       = water_price          # USD/kg
        self._utility_cost_hr  = 0.0
        self.wash_kg_hr        = 0.0

    def _run(self):
        raw_ps, wash_water = self.ins
        clean_ps, reject   = self.outs

        raw_kg = raw_ps.F_mass   # total raw feed, kg/hr

        moisture_kg = raw_kg * PRETREAT_MOISTURE_FRAC
        contam_kg   = raw_kg * PRETREAT_CONTAM_FRAC
        ps_in_kg    = raw_kg - moisture_kg - contam_kg
        ps_loss_kg  = ps_in_kg * PRETREAT_PS_LOSS_FRAC
        clean_kg    = ps_in_kg - ps_loss_kg
        wash_kg     = raw_kg * self.WASH_WATER_RATIO

        wash_water.empty()
        wash_water.set_flow(wash_kg, 'kg/hr', 'Water')

        clean_ps.empty()
        clean_ps.set_flow(clean_kg, 'kg/hr', 'Polystyrene')
        clean_ps.phase = 's'
        clean_ps.T = 298.15

        reject.empty()
        reject.set_flow(moisture_kg + wash_kg, 'kg/hr', 'Water')
        reject.set_flow(contam_kg,             'kg/hr', 'Contaminants')
        reject.set_flow(ps_loss_kg,            'kg/hr', 'Polystyrene')
        reject.T = 298.15

        self.raw_kg_hr      = raw_kg
        self.clean_kg_hr    = clean_kg
        self.moisture_kg_hr = moisture_kg
        self.contam_kg_hr   = contam_kg
        self.ps_loss_kg_hr  = ps_loss_kg
        self.wash_kg_hr     = wash_kg

    def _design(self):
        raw_kg = self.ins[0].F_mass
        for equip, (base_cost, ref_cap, exp) in self._purchase_cost_coefficients.items():
            self.purchase_costs[equip] = base_cost * (raw_kg / ref_cap) ** exp

    def _cost(self):
        raw_kg      = self.ins[0].F_mass
        moisture_kg = raw_kg * PRETREAT_MOISTURE_FRAC

        # Dryer heat duty -- kJ/hr (add_heat_utility expects kJ/hr, not kW)
        heat_duty_kJ_hr = moisture_kg * self.DRY_HEAT_KJ_PER_KG_WATER
        self.add_heat_utility(heat_duty_kJ_hr, T_in=298.15, T_out=373.15)

        # Shredder electricity + wash water purchase, priced at NREL-consistent
        # rates (not BioSTEAM's own default utility-agent pricing) -- same
        # convention as hydrogen_production.py's H2 units.
        shred_kwh_hr = raw_kg * self.SHRED_KWH_PER_KG
        wash_kg_hr   = self.wash_kg_hr
        self._utility_cost_hr = (shred_kwh_hr * self.electricity_price
                                  + wash_kg_hr * self.water_price)
