"""
R1_supplementary.py  --  reviewer-response analyses that do not need a BioSTEAM re-simulation
(R1 update 15). Run AFTER `python main.py` (it reads the stream totals main.py writes):

    python R1_supplementary.py

Outputs (R1_outputs/supplementary/):
  R1_lca_base.csv               GWP (g CO2e/MJ, LHV, well-to-wake) + contributions, NEW scenario labels   (R1.6, R1.15)
  R1_credit_treatments.csv      GWP under credit / boundary / SPK-burden treatments                        (R2.3, R1.6)
  R1_grid_sensitivity.csv/.png  SOEC-route GWP vs electricity carbon intensity, SMR and break-even         (R2.2)
  R1_product_properties.csv     screening estimates of fuel properties vs ASTM D1655 / D7566 limits        (R1.3)
  R1_airline_cost_impact.csv    premium per tonne and airline cost effect (only if R1 MFSP CSV exists)     (R2.5)

Scenario labels (R1.14): S1 = PS-only pyrolysis -> EB additive -> HEFA-SPK blend (reference; physical/internal Sc2)
                         S2 = co-hydropyrolysis of PS + waste cooking oil (proposed;  physical/internal Sc1)

Property values are SCREENING ESTIMATES from pure-component data and ideal-mixing rules (Liaw flash-point model,
ideal-solubility freeze point, component-boiling-point distillation). They are not a substitute for ASTM D86, D56,
D5972/D2386, D4052 measurements and must be described as such in the paper.
"""
import os, sys, math, types

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPTS = os.path.join(HERE, "tea_20260605_1634", "scripts")
DATA = os.path.join(HERE, "tea_20260605_1634", "data")
OUT = os.path.join(HERE, "R1_outputs", "supplementary")
os.makedirs(OUT, exist_ok=True)
sys.path[:0] = [HERE, SCRIPTS]
os.environ.setdefault("MPLBACKEND", "Agg")

# make_lca imports tea_model, which imports BioSTEAM/chaospy/scipy at module level. Only constants and pure
# functions are used here, so stub any of those that are missing (e.g. on a machine without BioSTEAM).
class _Any:
    def __init__(self, *a, **k): pass
    def __call__(self, *a, **k): return _Any()
    def __getattr__(self, n): return _Any()
for _n in ["biosteam", "thermosteam", "chaospy", "scipy", "scipy.stats", "scipy.optimize", "scipy.interpolate"]:
    try:
        __import__(_n)
    except Exception:
        _m = types.ModuleType(_n)
        _m.__getattr__ = lambda n: (type(n, (object,), {}) if n[:1].isupper() else _Any())
        sys.modules[_n] = _m

import pandas as pd
import numpy as np
import make_lca as L

JET_REF = L.FOSSIL_JET_G_PER_MJ            # 88.9 g/MJ well-to-wake
NEW_LABEL = {1: "S2 co-hydropyrolysis", 2: "S1 PS-only + SPK blend"}
H2_SHORT = {"SMR": "SMR", "SOEC": "SOEC", "Photocatalysis": "Photo"}


# ───────────────────────────── 1. configurations from main.py output ─────────────────────────────
def load_cfgs():
    tot = pd.read_csv(os.path.join(DATA, "material_balance_totals.csv"))
    comp = pd.read_csv(os.path.join(DATA, "material_balance_streams.csv"))
    T = {(r.scenario, r.stream_id): r.total_kg_hr for r in tot.itertuples()}
    C = {(r.scenario, r.stream_id, r.component): r.kg_hr for r in comp.itertuples()}
    cfgs = {}
    for key in sorted(tot.scenario.unique()):
        sc = int(key[2]); h2 = key.split("_", 1)[1]
        g = lambda s: T.get((key, s), 0.0)
        if sc == 1:
            saf, spk, ends = g("saf"), 0.0, 0.0
        else:
            saf, spk, ends = g("eb_spk_blend"), g("s_spk"), g("dist_bottoms")
        cfgs[(sc, h2)] = dict(
            scenario=sc, h2_source=h2, saf_kg_hr=saf, spk_kg_hr=spk, ends_kg_hr=ends, H2_demand=g("h2_out"),
            streams=dict(clean_ps_kg_hr=g("s_ps"), oil_kg_hr=g("s_oil"), char_kg_hr=g("char"),
                         gas_ch4_kg_hr=C.get((key, "gas", "Methane"), 0.0),
                         gas_h2_kg_hr=C.get((key, "gas", "Hydrogen"), 0.0)))
    return cfgs


def label(sc, h2):
    return f"{NEW_LABEL[sc]} + {H2_SHORT[h2]}"


# ───────────────────────────── 2. LCA base + treatments ─────────────────────────────
def lca_tables(cfgs, factors):
    base_rows, treat_rows = [], []
    treatments = [
        # name, wco_mode, char_on, combustion_on, char_mode, spk_mode/value
        ("A cradle-to-gate, WCO incineration credit, gross char credit (as submitted)", "incineration", True, False, "gross", ("openlca", None)),
        ("B well-to-wake, WCO incineration credit", "incineration", True, True, "net", ("corsia_uco", 13.9)),
        ("C well-to-wake, no WCO credit, net char credit (BASE)", "none", True, True, "net", ("corsia_uco", 13.9)),
        ("D well-to-wake, no WCO credit, no char credit", "none", False, True, "net", ("corsia_uco", 13.9)),
        ("E well-to-wake, no WCO credit, gross char credit", "none", True, True, "gross", ("corsia_uco", 13.9)),
        ("F base, SPK = CORSIA tallow-HEFA 22.5 g/MJ", "none", True, True, "net", ("corsia_uco", 22.5)),
        ("G base, SPK = CORSIA soybean-HEFA 40.4 g/MJ", "none", True, True, "net", ("corsia_uco", 40.4)),
    ]
    for (sc, h2), cfg in sorted(cfgs.items(), key=lambda kv: (-kv[0][0], kv[0][1])):
        inv = L.compute_inventory(cfg)
        res, con = L.compute_impacts_per_kg(inv, factors)
        lhv = inv["lhv"]
        row = dict(scenario=label(sc, h2), internal_id=f"Sc{sc}_{h2}", LHV_MJ_per_kg=lhv,
                   GWP_g_per_MJ=res["Global warming"] / lhv * 1e3,
                   reduction_vs_JetA_pct=100 * (1 - res["Global warming"] / lhv * 1e3 / JET_REF),
                   fossil_carbon_share_of_feed=inv["fossil_share"])
        for k, v in con["Global warming"].items():
            row[f"{k} [g/MJ]"] = v / lhv * 1e3
        base_rows.append(row)
        for name, wco, char_on, comb_on, char_mode, (spk_mode, spk_val) in treatments:
            L.CHAR_CREDIT_MODE, L.SPK_GWP_MODE = char_mode, spk_mode
            if spk_val is not None:
                L.SPK_CORSIA_G_PER_MJ = spk_val
            inv_t = L.compute_inventory(cfg)
            r_t, _ = L.compute_impacts_per_kg(inv_t, factors, wco_mode=wco, char_credit_on=char_on, combustion_on=comb_on)
            g = r_t["Global warming"] / lhv * 1e3
            treat_rows.append(dict(scenario=label(sc, h2), treatment=name, GWP_g_per_MJ=g,
                                   reduction_vs_JetA_WTW_pct=(100 * (1 - g / JET_REF)) if comb_on else None))
        L.CHAR_CREDIT_MODE, L.SPK_GWP_MODE, L.SPK_CORSIA_G_PER_MJ = "net", "corsia_uco", 13.9
    pd.DataFrame(base_rows).to_csv(os.path.join(OUT, "R1_lca_base.csv"), index=False)
    pd.DataFrame(treat_rows).to_csv(os.path.join(OUT, "R1_credit_treatments.csv"), index=False)
    return pd.DataFrame(base_rows), pd.DataFrame(treat_rows)


# ───────────────────────────── 3. grid carbon-intensity sensitivity (R2.2) ─────────────────────────────
def grid_sensitivity(cfgs, factors):
    ef_ng = factors["ng_elec"].get("Global warming", 0.0)        # kg CO2e/kWh of the ecoinvent dataset used
    rows = []
    ci_grid = np.arange(0, 801, 25)                              # g CO2e/kWh
    for sc in (2, 1):
        cfg = cfgs[(sc, "SOEC")]; inv = L.compute_inventory(cfg)
        res, con = L.compute_impacts_per_kg(inv, factors)
        lhv = inv["lhv"]; base = res["Global warming"]
        el = inv["elec_kwh_per_saf"]
        smr = L.compute_impacts_per_kg(L.compute_inventory(cfgs[(sc, "SMR")]), factors)[0]["Global warming"] / lhv * 1e3
        for ci in ci_grid:
            g = (base - el * ef_ng + el * ci / 1000.0) / lhv * 1e3
            rows.append(dict(scenario=NEW_LABEL[sc], grid_CI_g_per_kWh=ci, SOEC_GWP_g_per_MJ=g, SMR_GWP_g_per_MJ=smr))
        breakeven = (smr * lhv / 1e3 - (base - el * ef_ng)) / el * 1000.0
        rows.append(dict(scenario=NEW_LABEL[sc], grid_CI_g_per_kWh=f"break-even vs SMR = {breakeven:.0f}",
                         SOEC_GWP_g_per_MJ=None, SMR_GWP_g_per_MJ=smr))
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(OUT, "R1_grid_sensitivity.csv"), index=False)
    try:
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(6.5, 4))
        for sc, col in ((2, "#1f77b4"), (1, "#d62728")):
            d = df[(df.scenario == NEW_LABEL[sc]) & df.SOEC_GWP_g_per_MJ.notna()]
            x = d.grid_CI_g_per_kWh.astype(float)
            ax.plot(x, d.SOEC_GWP_g_per_MJ, color=col, label=f"{NEW_LABEL[sc]}: SOEC")
            ax.axhline(d.SMR_GWP_g_per_MJ.iloc[0], color=col, ls="--", lw=1, label=f"{NEW_LABEL[sc]}: SMR")
        for ci, name in ((ef_ng * 1000, "NG plant (base)"), (370, "US average ~370"), (30, "wind/PV ~30")):
            ax.axvline(ci, color="grey", ls=":", lw=1); ax.text(ci + 5, ax.get_ylim()[1] * 0.97, name, fontsize=7, rotation=90, va="top")
        ax.axhline(JET_REF, color="k", lw=0.8); ax.text(5, JET_REF + 1, "Fossil Jet A 88.9", fontsize=7)
        ax.set_xlabel("Electricity carbon intensity (g CO$_2$e/kWh)"); ax.set_ylabel("GWP (g CO$_2$e/MJ, well-to-wake)")
        ax.legend(fontsize=7, loc="center right"); fig.tight_layout()
        fig.savefig(os.path.join(OUT, "R1_grid_sensitivity.png"), dpi=300); plt.close(fig)
    except Exception as e:
        print("  grid figure skipped:", e)
    return df, ef_ng


# ───────────────────────────── 4. product properties (R1.3) ─────────────────────────────
# name: (MW, rho15 kg/m3, nbp C, Tm C, dHfus kJ/mol, flash C (closed cup), LHV MJ/kg, Antoine A,B,C [mmHg, C], aromatic?)
PURE = {
    "toluene":      (92.14, 871, 110.6, -95.0, 6.6, 4,   40.6, 6.95464, 1344.80, 219.482, True),
    "ethylbenzene": (106.17, 871, 136.2, -95.0, 9.2, 18,  40.9, 6.95719, 1424.255, 213.206, True),
    "cumene":       (120.19, 866, 152.4, -96.0, 7.3, 31,  41.2, 6.93666, 1460.793, 207.777, True),
    "n-C10":        (142.28, 734, 174.1, -29.7, 28.7, 46, 44.24, 6.94363, 1495.17, 193.858, False),
    "n-C11":        (156.31, 744, 195.9, -25.6, 22.2, 62, 44.20, 6.97220, 1569.57, 187.700, False),
    "n-C12":        (170.33, 753, 216.3, -9.6, 36.8, 74,  44.15, 6.98059, 1625.928, 180.311, False),
    "n-C13":        (184.36, 760, 235.4, -5.4, 28.5, 94,  44.11, 7.00756, 1690.67, 174.220, False),
    "n-C14":        (198.39, 767, 253.6, 5.9, 45.1, 99,   44.08, 7.01300, 1740.88, 167.720, False),
    "n-C15":        (212.41, 773, 270.6, 9.9, 34.6, 132,  44.06, 7.01360, 1789.95, 161.380, False),
    "n-C16":        (226.44, 777, 286.9, 18.2, 53.4, 135, 44.04, 7.02867, 1830.51, 154.450, False),
    "n-C17":        (240.47, 781, 302.0, 22.0, 40.2, 148, 44.02, 7.01430, 1865.10, 149.200, False),
    # HEFA-SPK lumped pseudo-component: density/LHV as in compounds.py; flash 42 C typical; vapour-pressure curve
    # shape of n-C11 (ASSUMPTION). Freeze point of the SPK itself is spec-compliant (<= -40 C, ASTM D7566 Annex A2).
    "HEFA-SPK":     (165.0, 752, 215.0, None, None, 42,  44.10, 6.97220, 1569.57, 187.700, False),
}
LIMITS = dict(rho_min=775, rho_max=840, lhv_min=42.8, arom_max=25.0, flash_min=38, freeze_max_JetA=-40,
              freeze_max_JetA1=-47, T10_max=205, FBP_max=300)


def _psat(sp, T):
    _, _, _, _, _, _, _, A, B, C, _ = PURE[sp]
    return 10 ** (A - B / (C + T))


def flash_point_liaw(x):
    """Closed-cup flash point of an ideal liquid mixture (Liaw et al. 2002): sum x_i P_i(T)/P_i(Tfp_i) = 1."""
    f = lambda T: sum(xi * _psat(s, T) / _psat(s, PURE[s][5]) for s, xi in x.items()) - 1.0
    lo, hi = -40.0, 200.0
    for _ in range(80):
        mid = 0.5 * (lo + hi)
        lo, hi = (mid, hi) if f(mid) < 0 else (lo, mid)
    return 0.5 * (lo + hi)


def freeze_point_ideal(x):
    """Temperature at which the first n-alkane saturates (ideal solubility, Schroder-van Laar). Screening only."""
    R, best, who = 8.314, -999.0, None
    for s, xi in x.items():
        Tm, dH = PURE[s][3], PURE[s][4]
        if Tm is None or xi <= 0 or PURE[s][10]:
            continue
        T = 1.0 / (1.0 / (Tm + 273.15) - R * math.log(xi) / (dH * 1000.0)) - 273.15
        if T > best:
            best, who = T, s
    return best, who


def props(name, w, spk_flash=42.0):
    """w: mass fractions by species. Returns property row. spk_flash = flash point assumed for the HEFA-SPK lump."""
    PURE["HEFA-SPK"] = PURE["HEFA-SPK"][:5] + (spk_flash,) + PURE["HEFA-SPK"][6:]
    w = {k: v / sum(w.values()) for k, v in w.items() if v > 0}
    mol = {k: v / PURE[k][0] for k, v in w.items()}; x = {k: m / sum(mol.values()) for k, m in mol.items()}
    vol = {k: v / PURE[k][1] for k, v in w.items()}; vt = sum(vol.values()); phi = {k: v / vt for k, v in vol.items()}
    rho = 1.0 / sum(v / PURE[k][1] for k, v in w.items())
    lhv = sum(v * PURE[k][6] for k, v in w.items())
    arom = 100 * sum(p for k, p in phi.items() if PURE[k][10])
    order = sorted(phi, key=lambda k: PURE[k][2]); cum, T10, FBP = 0.0, None, None
    for k in order:
        cum += phi[k]
        if T10 is None and cum >= 0.10:
            T10 = PURE[k][2]
        if phi[k] >= 0.005:
            FBP = PURE[k][2]
    spk_only = w.get("HEFA-SPK", 0) > 0.5
    if "HEFA-SPK" in w:          # lumped SPK has no boiling range: T10/FBP are set by the (D7566 A2-compliant) SPK
        T10_txt, T10_ok = "set by HEFA-SPK", "n/a (D7566 A2 SPK)"
        FBP_txt, FBP_ok = "set by HEFA-SPK", "n/a (D7566 A2 SPK)"
    else:
        T10_txt, T10_ok = T10, ("PASS" if T10 <= LIMITS["T10_max"] else "FAIL")
        FBP_txt, FBP_ok = FBP, ("PASS" if FBP <= LIMITS["FBP_max"] else "FAIL")
    fz, fz_sp = freeze_point_ideal(x)
    if fz_sp is None and not spk_only:
        fz_txt = "n/a (aromatics only, < -90)"
    elif spk_only and fz_sp is None:
        fz_txt = "<= -40 (governed by spec-compliant SPK; aromatic additive does not raise it)"
    else:
        fz_txt = f"{fz:.0f} (first solid: {fz_sp})"
    fp = flash_point_liaw(x)
    ok = lambda c: "PASS" if c else "FAIL"
    return dict(product=name, density_15C_kg_m3=round(rho, 1), density_check=ok(LIMITS["rho_min"] <= rho <= LIMITS["rho_max"]),
                LHV_MJ_kg=round(lhv, 2), LHV_check=ok(lhv >= LIMITS["lhv_min"]),
                aromatics_vol_pct=round(arom, 1), aromatics_check=ok(arom <= LIMITS["arom_max"]),
                T10_C_screening=T10_txt, T10_check=T10_ok,
                FBP_C_screening=FBP_txt, FBP_check=FBP_ok,
                flash_point_C_estimate=round(fp, 0), flash_check=ok(fp >= LIMITS["flash_min"]),
                SPK_flash_assumed_C=(spk_flash if "HEFA-SPK" in w else None),
                freeze_point_C_estimate=fz_txt,
                freeze_check=("PASS" if fz_sp is None else ok(fz <= LIMITS["freeze_max_JetA"])),
                carbon_range=("C7-C9 additive + C9-C16 SPK" if "HEFA-SPK" in w else
                              "C" + str(min(_cn(k) for k in w)) + "-C" + str(max(_cn(k) for k in w))),
                composition_wt=", ".join(f"{k} {100*v:.1f}" for k, v in w.items()))


def _cn(k):
    return {"toluene": 7, "ethylbenzene": 8, "cumene": 9, "HEFA-SPK": 9}.get(k, int(k.split("C")[-1]) if "n-C" in k else 0)


def product_properties():
    import compounds as cp
    rows = []
    # S2 co-hydropyrolysis product: (a) Li et al. reported species (C11/C13/C15 from the palm-kernel profile, C17 by
    # difference) and (b) the model surrogate (C10/C12/C14/C16). EB from hydrogenated styrene (98 %).
    for case, li in (("Li25", (28.1, 43.0 * 48 / 72, 43.0 * 16 / 72, 43.0 * 8 / 72, 12.9)),):
        eb, c11, c13, c15, c17 = li
        rows.append(props("S2 co-hydropyrolysis product, Li et al. species (C11-C17 n-alkanes + EB)",
                          {"ethylbenzene": eb, "n-C11": c11, "n-C13": c13, "n-C15": c15, "n-C17": c17}))
    y = cp.SCENARIO1_PYRO_YIELDS
    eb = y["Styrene"] * (0.98 * 106.17 / 104.15 + 0.02)
    rows.append(props(f"S2 co-hydropyrolysis product, model surrogate ({cp.SC1_CASE})",
                      {"ethylbenzene": eb, "n-C10": y["Decane"], "n-C12": y["Dodecane"],
                       "n-C14": y["Tetradecane"], "n-C16": y["Hexadecane"]}))
    # S1 PS-only: EB additive (Prajapati distilled cut) and its blends in HEFA-SPK
    add = {"ethylbenzene": 89.9, "cumene": 6.2, "toluene": 2.3}
    rows.append(props("S1 EB additive (distilled cut, neat)", add))
    for v in (8, 12, 16, 20, 25):
        wv, _ = cp.sc2_blend_params(v)
        a = sum(add.values())
        mix = {k: wv * val / a for k, val in add.items()}; mix["HEFA-SPK"] = 1 - wv
        for fl in (42.0, 50.0):
            rows.append(props(f"S1 blend: {v} vol% EB additive in HEFA-SPK", mix, spk_flash=fl))
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(OUT, "R1_product_properties.csv"), index=False)
    return df


# ───────────────────────────── 5. airline cost impact (R2.5) ─────────────────────────────
def airline_cost_impact(parity=1.09, fuel_share=(0.25, 0.30), blend_shares=(0.10, 1.0)):
    src = None
    for p in (os.path.join(HERE, "R1_outputs", "Li25", "R1_equal_basis.csv"),):
        if os.path.exists(p) and "README_STUBTEST" not in os.listdir(os.path.dirname(p)):
            src = p
    if src is None:
        print("  airline cost impact skipped: run run_R1_analysis.py first (R1_outputs/Li25/R1_equal_basis.csv)")
        return None
    d = pd.read_csv(src); d = d[d.basis.str.startswith("equal PS")]
    rows = []
    for r in d.itertuples():
        prem = (r.MFSP_usd_per_kg - parity) / parity
        for b in blend_shares:
            for fs in fuel_share:
                rows.append(dict(scenario=r.scenario, MFSP_usd_kg=r.MFSP_usd_per_kg, premium_pct=100 * prem,
                                 premium_usd_per_t=1000 * (r.MFSP_usd_per_kg - parity), blend_share=b,
                                 fuel_share_of_opex=fs, opex_increase_pct=100 * prem * b * fs, fuel_bill_increase_pct=100 * prem * b))
    df = pd.DataFrame(rows); df.to_csv(os.path.join(OUT, "R1_airline_cost_impact.csv"), index=False)
    return df


if __name__ == "__main__":
    pd.set_option("display.width", 220); pd.set_option("display.max_columns", 30)
    factors = L.load_all_impacts()
    cfgs = load_cfgs()
    base, treat = lca_tables(cfgs, factors)
    print("\nBase-case GWP (well-to-wake, g CO2e/MJ):"); print(base[["scenario", "GWP_g_per_MJ", "reduction_vs_JetA_pct"]].round(1).to_string(index=False))
    print("\nTreatments:"); print(treat.pivot(index="treatment", columns="scenario", values="GWP_g_per_MJ").round(1).to_string())
    g, ef = grid_sensitivity(cfgs, factors)
    print(f"\nElectricity dataset GWP = {ef*1000:.0f} g/kWh;", "; ".join(str(v) for v in g.grid_CI_g_per_kWh if isinstance(v, str)))
    pp = product_properties()
    print("\nProduct properties (screening):"); print(pp.drop(columns=["composition_wt"]).to_string(index=False))
    airline_cost_impact()
    print("\nWritten to", OUT)
