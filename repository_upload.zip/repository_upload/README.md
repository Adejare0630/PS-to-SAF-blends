# SAF-from-PS TEA/LCA Simulation

BioSTEAM process simulation, NREL/Humbird 2011 DCFROR techno-economic analysis, and
cradle-to-gate LCA (TRACI 2.1) for sustainable aviation fuel (SAF) produced from waste
polystyrene. 2 process scenarios x 3 H2 sources = 6 configurations.

## Setup

1. Install Python 3.11+ (developed/tested on 3.14.5).
2. Install Python dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Install the **Graphviz system binary** (separate from the `graphviz` pip package
   in requirements.txt) — required for BioSTEAM to draw process flow diagrams:
   - Windows: https://graphviz.org/download/ , or `choco install graphviz`
   - The code auto-detects Graphviz at `C:\Program Files\Graphviz\bin` on Windows.
     If you install it elsewhere, make sure `dot` is on your system PATH.
   - macOS: `brew install graphviz`
   - Linux: `apt install graphviz` / `dnf install graphviz`

Do not delete the `OpenLCA/` folder — it holds the ecoinvent background-data exports
(TRACI 2.1 impact factors) that the LCA step reads as input; it is not regenerated
by the code.

## Running

```
python main.py
```

Runs the full pipeline: chemistry/process setup, BioSTEAM simulation of all 6
configurations, TEA (dashboard, sensitivity, tornado, uncertainty), the full
`tea_20260605_1634/scripts/make_*.py` report plot set, and cradle-to-gate LCA —
then displays a curated subset of the generated plots inline.

- Run as a plain script (`python main.py` in a terminal): those plots open in
  separate windows one at a time — close each window to move on to the next.
- Run inside a Jupyter/IPython kernel (e.g. VS Code's Interactive Window, using the
  `#%%` cell markers in the file): they render inline below each cell instead.

Every figure is still saved to disk regardless of whether it's shown inline (see
Outputs below) — the inline display only shows a subset selected during development;
the rest are just as available as files.

A full run takes several minutes (BioSTEAM simulation is re-run independently by
several of the `make_*.py` scripts, and Monte-Carlo uncertainty analysis is slow).

## Outputs

All output directories are created automatically if missing — nothing needs to
pre-exist beyond `OpenLCA/`.

- Top-level `*.png` / `*.xlsx` — TEA dashboard, tornado, uncertainty, PFDs, material
  balances.
- `tea_20260605_1634/report/` — `tea_report.md` and `tea_report.pptx`.
- `tea_20260605_1634/data/` and `tea_20260605_1634/plots/` — underlying CSVs and
  per-figure plots from the `tea_20260605_1634/scripts/make_*.py` scripts.
- `TEA_Outputs_20260608/` — LCA plots (GHG bar/stack, TRACI heatmap, radar, etc.).

All of the above are regenerated on every run and safe to delete/regenerate.
