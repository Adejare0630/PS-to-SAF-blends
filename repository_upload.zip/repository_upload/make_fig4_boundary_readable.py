"""Fig. 4 (revised): well-to-wake LCA system boundaries for Scenario 1 (PS-only, reference) and Scenario 2
(co-hydropyrolysis, proposed). Outputs PDF (vector), SVG and 600-dpi PNG."""
import sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle

plt.rcParams.update({"font.family": ["Arial", "Liberation Sans", "DejaVu Sans"], "font.size": 6.2,
                     "svg.fonttype": "none", "pdf.fonttype": 42})

C_IN, C_PROC, C_H2, C_PROD, C_CRED, C_EMIS, C_BURD = "#7A8B99", "#2F3E4C", "#5B6F82", "#2E7D32", "#2E7D32", "#C62828", "#8D6E63"
C_UTIL = "#E07B39"


def box(ax, x, y, w, h, text, fc, tc="white", bold=True, fs=6.0, ec=None, ls="-", style="round,pad=0.02,rounding_size=0.6"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle=style, fc=fc, ec=ec or fc, lw=0.8, ls=ls, zorder=3))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", color=tc, fontsize=fs,
            fontweight="bold" if bold else "normal", zorder=4, linespacing=1.15)
    return (x, y, w, h)


def arrow(ax, p, q, color="#404040", ls="-", lw=0.9, label=None, lpos=0.5, loff=(0, 1.0), lc=None, fs=5.4, conn="arc3", ha="center"):
    ax.annotate("", xy=q, xytext=p, zorder=2,
                arrowprops=dict(arrowstyle="-|>", color=color, lw=lw, ls=ls, mutation_scale=7,
                                shrinkA=0, shrinkB=0, connectionstyle=conn))
    if label:
        x = p[0] + (q[0] - p[0]) * lpos + loff[0]; y = p[1] + (q[1] - p[1]) * lpos + loff[1]
        ax.text(x, y, label, ha=ha, va="center", fontsize=fs, color=lc or color, zorder=5, style="italic")


def poly(ax, pts, color, ls="-", lw=0.9):
    """Orthogonal path with arrowhead on the last segment."""
    for a, b in zip(pts[:-2], pts[1:-1]):
        ax.plot([a[0], b[0]], [a[1], b[1]], color=color, ls=ls, lw=lw, zorder=2, solid_capstyle="butt")
    arrow(ax, pts[-2], pts[-1], color=color, ls=ls, lw=lw)


R = lambda b: (b[0] + b[2], b[1] + b[3] / 2)       # right-mid
Lm = lambda b: (b[0], b[1] + b[3] / 2)             # left-mid
T = lambda b, f=0.5: (b[0] + b[2] * f, b[1] + b[3])
Bt = lambda b, f=0.5: (b[0] + b[2] * f, b[1])


def panel(ax, scen):
    ax.set_xlim(0, 100); ax.set_ylim(0, 60); ax.axis("off")
    s1 = scen == 1
    title = ("Scenario 1 (reference): PS-only pyrolysis → ethylbenzene additive → 16 vol% blend in HEFA-SPK"
             if s1 else "Scenario 2 (proposed): co-hydropyrolysis of waste PS with waste cooking oil (oil:PS = 2.5)")
    ax.text(0.5, 58.6, title, fontsize=7.2, fontweight="bold", va="center")

    # boundary: well-to-gate + gate-to-wake
    ax.add_patch(Rectangle((15.5, 7.5), 71.5, 46.5, fill=False, ec="#555555", lw=0.9, ls=(0, (4, 2.5)), zorder=1))
    ax.add_patch(Rectangle((75.0, 7.5), 12.0, 46.5, fc="#FBE9E7", ec="none", zorder=0))
    ax.plot([75.0, 75.0], [7.5, 54.0], color="#999999", lw=0.6, ls=":", zorder=1)
    ax.text(16.3, 52.4, "WELL-TO-WAKE SYSTEM BOUNDARY   |   functional unit: 1 MJ fuel (LHV)", fontsize=6.3,
            fontweight="bold", color="#333333", va="center")
    ax.text(45.0, 8.7, "well-to-gate (fuel production)", fontsize=5.6, color="#666666", ha="center", style="italic")
    ax.text(81.0, 8.7, "gate-to-wake\n(combustion)", fontsize=5.6, color="#666666", ha="center", style="italic", va="bottom")

    # ---- inputs (left, outside boundary) ----
    ps = box(ax, 0.5, 38.4, 12.5, 5.2, "WASTE PS\n(cut-off, burden-free)", C_IN, fs=5.6)
    if s1:
        ng = box(ax, 0.5, 28.5, 12.5, 4.8, "NATURAL GAS\n(process heat)", C_IN, fs=5.6)
    else:
        wco = box(ax, 0.5, 31.8, 12.5, 5.2, "WASTE COOKING OIL\n(cut-off; no incineration\ncredit; biogenic C)", C_IN, fs=5.0)
        ng = box(ax, 0.5, 25.6, 12.5, 4.8, "NATURAL GAS\n(process heat)", C_IN, fs=5.6)
    el = box(ax, 0.5, 19.0, 12.5, 5.6, "ELECTRICITY\nNG plant 716 g/kWh\n(SOEC); PV (photo aux.)", C_IN, fs=5.0)
    wat = box(ax, 0.5, 11.0, 12.5, 5.6, "NATURAL GAS (SMR)\nor DEIONISED WATER\n(SOEC, photocatalysis)", C_IN, fs=5.0)

    # ---- process chain ----
    y0, h0 = 37.5, 7.0
    pre = box(ax, 17.0, y0, 9.0, h0, "PRETREATMENT\nshred, wash,\ndry", C_PROC, fs=5.4)
    if s1:
        pyr = box(ax, 28.0, y0, 9.5, h0, "PYROLYSIS\n400 °C, atm.\nliquid 96 wt%", C_PROC, fs=5.4)
        hyd = box(ax, 39.5, y0, 10.0, h0, "VINYL\nHYDROGENATION\nPd/C, 70 °C, 5 MPa", C_PROC, fs=5.1)
        dis = box(ax, 51.5, y0, 9.5, h0, "DISTILLATION\nEB additive\n(~91 wt% EB)", C_PROC, fs=5.3)
        bld = box(ax, 63.0, y0, 9.5, h0, "BLENDING\n16 vol%\nadditive", C_PROC, fs=5.4)
        last = bld
        spk = box(ax, 58.8, 46.0, 15.8, 4.6, "PURCHASED HEFA-SPK\nCORSIA UCO-HEFA 13.9 g/MJ", C_BURD, fs=5.0)
        arrow(ax, Bt(spk, 0.6), T(bld, 0.6), color="#404040")
    else:
        pyr = box(ax, 28.0, y0, 11.5, h0, "CO-HYDROPYROLYSIS\n480 °C, 0.15 MPa H₂\nliquid 84 wt%", C_PROC, fs=5.1)
        hyd = box(ax, 42.0, y0, 11.0, h0, "UPGRADING\nPd/SBA-15, 350 °C\nstyrene→EB; HDO", C_PROC, fs=5.1)
        dis = box(ax, 55.5, y0, 10.0, h0, "PRODUCT\nSEPARATION", C_PROC, fs=5.4)
        last = dis
    arrow(ax, R(ps), Lm(pre))
    arrow(ax, R(pre), Lm(pyr), label=None)
    arrow(ax, R(pyr), Lm(hyd))
    arrow(ax, R(hyd), Lm(dis))
    if s1:
        arrow(ax, R(dis), Lm(bld))
    else:
        poly(ax, [R(wco), (27.0, R(wco)[1]), (27.0, 39.0), (28.0, 39.0)], "#404040")
    # pretreatment reject (cut-off)
    arrow(ax, T(pre), (21.5, 49.0), color="#9E9E9E", ls="--", lw=0.7)
    ax.text(22.2, 47.4, "rejects, wash water\n(excluded)", fontsize=4.7, color="#7F7F7F", va="center")

    # combustion
    comb = box(ax, 76.0, y0, 10.0, h0, "AIRCRAFT\nCOMBUSTION", C_EMIS, fs=5.6)
    prod_lbl = "fuel blend\n(82 wt% SPK)" if s1 else "blendstock\n33 wt% EB +\nC11–C17 n-alkanes"
    arrow(ax, R(last), Lm(comb), color=C_PROD, lw=1.3)
    ax.text((R(last)[0] + 76.0) / 2, y0 - 2.6 if not s1 else y0 - 2.0, prod_lbl, ha="center", va="center", fontsize=4.9,
            color=C_PROD, style="italic")
    # emissions out of combustion
    arrow(ax, T(comb, 0.3), (79.0, 55.2), color=C_EMIS, lw=1.0)
    ax.text(79.0, 55.6, "fossil CO₂ (PS carbon):\nCOUNTED", ha="center", va="bottom", fontsize=4.9, color=C_EMIS,
            fontweight="bold")
    arrow(ax, T(comb, 0.78), (83.8, 47.2), color="#9E9E9E", lw=0.8, ls="--")
    ax.text(87.6, 47.4, "biogenic CO₂\n(" + ("SPK" if s1 else "oil") + " carbon):\nnot counted", ha="left",
            va="bottom", fontsize=4.6, color="#7F7F7F")

    # ---- bottom row: H2 production | on-site combustion | char ----
    h2 = box(ax, 17.0, 15.0, 14.0, 8.0, "H\u2082 PRODUCTION\n(one per configuration)\nSMR | SOEC |\nphotocatalysis", C_H2, fs=5.0)
    oc = box(ax, 38.0, 15.0, 15.0, 8.0,
             "ON-SITE COMBUSTION\npyrolysis off-gas" + (" +\nside fractions" if s1 else "\n(CH\u2084, H\u2082)") + "\n+ purchased NG top-up",
             "#6D4C41", fs=5.0)
    char = box(ax, 61.0, 16.5, 9.5, 5.0, "CHAR\nco-product", "#455A64", fs=5.2)

    # utilities into H2 unit
    poly(ax, [R(el), (14.5, R(el)[1]), (14.5, 21.0), (17.0, 21.0)], C_UTIL, ls="--", lw=0.8)
    poly(ax, [R(wat), (15.2, R(wat)[1]), (15.2, 17.0), (17.0, 17.0)], "#404040", lw=0.8)
    # natural gas for heat into on-site combustion
    ngy = R(ng)[1]
    poly(ax, [R(ng), (34.5, ngy), (34.5, 19.0), (38.0, 19.0)], C_UTIL, ls="--", lw=0.8)

    # H2 header to hydrogenation (and to the co-hydropyrolyser in S2)
    hx = Bt(hyd, 0.5)[0]
    ax.plot([25.5, 25.5], [23.0, 33.0], color="#1565C0", lw=1.0, zorder=2)
    ax.plot([25.5, hx], [33.0, 33.0], color="#1565C0", lw=1.0, zorder=2)
    arrow(ax, (hx, 33.0), (hx, y0), color="#1565C0", lw=1.0)
    if not s1:
        arrow(ax, (Bt(pyr, 0.2)[0], 33.0), (Bt(pyr, 0.2)[0], y0), color="#1565C0", lw=1.0)
    ax.text(26.2, 28.0, "H\u2082", fontsize=5.8, color="#1565C0", fontweight="bold")

    # process-heat header (orange) from on-site combustion to the heated units
    ax.plot([50.5, 50.5], [23.0, 35.3], color=C_UTIL, lw=0.8, ls="--", zorder=2)
    targets = [Bt(pre, 0.5)[0], Bt(pyr, 0.45)[0]] + ([Bt(dis, 0.3)[0]] if s1 else [])
    ax.plot([min(targets), 50.5], [35.3, 35.3], color=C_UTIL, lw=0.8, ls="--", zorder=2)
    for tx in targets:
        arrow(ax, (tx, 35.3), (tx, y0), color=C_UTIL, ls="--", lw=0.8)
    ax.text(51.1, 29.0, "process\nheat", fontsize=4.8, color=C_UTIL, style="italic")

    # off-gas from pyrolysis down to on-site combustion
    gx = Bt(pyr, 0.85)[0]
    poly(ax, [(gx, y0), (gx, 27.5), (41.5, 27.5), (41.5, 23.0)], "#6D4C41", lw=0.8)
    ax.text(gx + 0.5, 29.8, "off-gas", fontsize=4.8, color="#6D4C41", style="italic")
    if s1:
        sx = Bt(dis, 0.75)[0]
        poly(ax, [(sx, y0), (sx, 27.5), (47.0, 27.5), (47.0, 23.0)], "#6D4C41", lw=0.8)
        ax.text(sx + 0.5, 30.8, "side\nfractions", fontsize=4.8, color="#6D4C41", style="italic")

    # char from pyrolysis to char box
    cx = Bt(pyr, 0.15)[0]
    poly(ax, [(cx, y0), (cx, 25.5), (65.75, 25.5), T(char)], "#455A64", lw=0.8)
    ax.text(57.0, 26.3, "char", fontsize=4.8, color="#455A64", style="italic")

    # emissions / exclusions from the bottom row
    arrow(ax, Bt(oc, 0.5), (45.5, 10.6), color=C_EMIS, lw=0.9)
    ax.text(46.2, 11.8, "fossil CO\u2082 counted;\noff-gas heat displaces NG", fontsize=4.7, color=C_EMIS, va="center")
    arrow(ax, Bt(h2, 0.5), (24.0, 11.2), color="#9E9E9E", ls="--", lw=0.7)
    ax.text(24.6, 12.0, "O\u2082 by-product\n(excluded)", fontsize=4.7, color="#7F7F7F", va="center")

    cred = box(ax, 57.0, 0.4, 17.5, 5.8,
               "AVOIDED COAL (solid fuel)\nnet credit = coal CO\u2082 \u2212 fossil\nCO\u2082 of burned char (GWP)", C_CRED, fs=4.9)
    arrow(ax, Bt(char), T(cred, 0.5), color=C_CRED, ls="--", lw=0.9)

    # ---- reference box (right) ----
    box(ax, 88.5, 31.0, 11.0, 13.5, "FOSSIL JET A\nreference\n88.9 g CO₂-eq/MJ\n(well-to-wake,\nCORSIA 89)",
        "white", tc="#333333", ec="#333333", ls="--", fs=5.0, bold=False)
    ax.text(94.0, 29.6, "compared on the\nsame boundary", fontsize=4.6, color="#555555", ha="center", va="top", style="italic")

    # ---- excluded note ----
    ax.text(0.5, 3.4, "Excluded (cut-off): feedstock collection & transport;\ncatalyst manufacture; pump/compressor electricity;\n"
            "pretreatment effluent & reject disposal; O₂ by-product.",
            fontsize=4.8, color="#555555", va="center", linespacing=1.25)



import matplotlib.axes as _ma
_orig = _ma.Axes.text
def _text(self, *a, **k):
    if "fontsize" in k:
        k["fontsize"] = max(k["fontsize"] * 1.28, 6.4) if k.get("zorder") == 4 else max(k["fontsize"] * SCALE, FLOOR)
    return _orig(self, *a, **k)
_ma.Axes.text = _text
SCALE, FLOOR = 1.4, 6.6
from matplotlib.lines import Line2D
for scen in (1, 2):
    fig = plt.figure(figsize=(9.4, 6.15))
    ax = fig.add_axes([0.005, 0.10, 0.99, 0.895])
    panel(ax, scen)
    h = [Line2D([], [], color="#404040", lw=1.0, label="material flow"),
         Line2D([], [], color=C_PROD, lw=1.4, label="fuel product (1 MJ)"),
         Line2D([], [], color="#1565C0", lw=1.0, label="hydrogen"),
         Line2D([], [], color=C_UTIL, lw=0.9, ls="--", label="energy / utility"),
         Line2D([], [], color=C_EMIS, lw=1.0, label="fossil CO₂ (counted)"),
         Line2D([], [], color=C_CRED, lw=0.9, ls="--", label="avoided burden (credit)"),
         Line2D([], [], color="#9E9E9E", lw=0.8, ls="--", label="excluded / not counted")]
    fig.legend(handles=h, loc="lower center", ncol=4, fontsize=7.6, frameon=False, bbox_to_anchor=(0.5, 0.0),
               handlelength=2.4, columnspacing=1.4)
    out = f"Fig4{'a_Scenario1' if scen == 1 else 'b_Scenario2'}_boundary_readable"
    for ext, kw in (("pdf", {}), ("svg", {}), ("png", {"dpi": 400})):
        fig.savefig(f"{out}.{ext}", **kw)
    plt.close(fig); print("saved", out)
