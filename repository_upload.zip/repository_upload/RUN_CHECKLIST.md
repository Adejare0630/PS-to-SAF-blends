# R1 rerun checklist (Windows, VS Code terminal)

All commands are run from `C:\Users\adesi\Module\Module_R1`. Use **cmd** (`set VAR=value`) or PowerShell (`$env:VAR="value"`). Open a **new terminal** before each run so that no variable from an earlier run is still set.

## 1. Base case (required)

```
cd C:\Users\adesi\Module\Module_R1
python main.py
python run_R1_analysis.py
python R1_supplementary.py
python R1_sensitivity_runs.py
```

| Step | Writes | Used in response to |
|---|---|---|
| `main.py` | all legacy figures and CSVs (`tea_20260605_1634/data`, `TEA_Outputs_20260608`), now with fixed labour, catalyst replacement and the LCA fixes | Figs. 5-15, Tables S6-S10 |
| `run_R1_analysis.py` | `R1_outputs/Li25/`: equal-feed vs equal-product basis, price sweeps and breakevens, blend and ratio sweeps, Monte Carlo (N = 1,000 + 5,000 convergence), R1 figures | R1.4, R1.5, R2.1, R2.4 |
| `R1_supplementary.py` | `R1_outputs/supplementary/`: GWP per MJ with new labels, credit treatments, grid sensitivity, product properties, airline cost impact | R1.3, R1.6, R1.15, R2.2, R2.3, R2.5 |
| `R1_sensitivity_runs.py` | `R1_outputs/R1_sensitivity_cases.csv`, `R1_mfsp_breakdown_base.csv` | R1.8, R1.10, R1.5, tax, labour |

After the run:
- [ ] Delete `R1_outputs/README_STUBTEST.txt` and the old stand-in CSV/PNG files in the `R1_outputs/` root (the real outputs are in `R1_outputs/Li25/`).
- [ ] Run `python R1_supplementary.py` once more, because the airline-cost table needs `R1_outputs/Li25/R1_equal_basis.csv`.

## 2. Checks before writing numbers into the paper

- [ ] `material_balance_totals.csv`: S2 (co-hydro) product about 26.9 t/h, oil 22.7 t/h, H2 about 394 kg/h. S1 blend about 21.1 t/h, SPK 17.3 t/h, additive 3.8 t/h.
- [ ] `R1_mfsp_breakdown_base.csv`: decide which component is largest in each configuration. This fills the corrected R1.8 sentence.
- [ ] `lca_results.csv` (from `main.py`) and `R1_outputs/supplementary/R1_lca_base.csv` agree to within 0.1 g/MJ.
- [ ] Fig. 14 base values match `lca_results.csv`, including SOEC (the old mismatch).
- [ ] Monte Carlo: P5/P95 are stable between N = 1,000 and N = 5,000 (`R1_mc_convergence.csv`). Copy the percentiles into the text from the same CSV used for Table S10.
- [ ] No figure, axis or caption still says "SAF", "carbon-negative", "premium", or "50:50". Search the PNGs/PDFs by eye; search the text with Ctrl+F.
- [ ] Scenario labels: S1 = PS-only (reference), S2 = co-hydropyrolysis (proposed) in every figure and table.

## 3. Cases run by `R1_sensitivity_runs.py` (no manual env setting needed)

| Case | Switch | Purpose |
|---|---|---|
| submitted_opex | `LABOR_MODE=fci`, `CATALYST_ANNUAL_FRAC=0` | shows the effect of the labour and catalyst fixes |
| tax_25pct | `INCOME_TAX=0.25` | current US tax (21 % federal + state) |
| soec_1000 / soec_2500 per kW | `SOEC_CAPEX_USD_PER_KW` | R1.10 capital audit: **replace with cited values** (DOE H2A / IEA) |
| smr_ref_30M | `SMR_REF_COST_USD=30000000` | R1.10 SMR audit: **replace with cited value** |
| photo_irr_250 | `PHOTO_IRRADIANCE_W_M2=250` | annual-mean irradiance panel sizing |
| oil / PS / SPK price low-high | `OIL_PRICE_KG`, `PS_PRICE_KG`, `SPK_PRICE_KG` | R1.5 price sensitivities |
| blend 12 / 20 / 25 vol% | `SC2_BLEND_VOL_PCT` | S1 blend share (density and aromatics trade-off) |
| extrap_ratio_3.4 | `SC1_CASE=Extrap34` | S2 at an aromatics-compliant ratio (**extrapolated**) |
| submitted_ratio_60_40 | `OIL_TO_PS_RATIO=0.6667` | indicative only (Li's yields do not apply at 60:40) |

`SOEC_CAPEX_USD_PER_KW` and `SMR_REF_COST_USD` are **uninstalled** equipment costs. `tea_model` multiplies the TPEC by 4.71 (Peters-Timmerhaus factors) to get the FCI, so entering an installed cost would count installation twice. If you change the H2 capital defaults after the audit, edit them in `hydrogen_production.py` and rerun section 1.

## 4. Values you must supply (cannot be computed)

1. A cited source and year for every Table 2 price: waste PS (the $0.60/kg basis), UCO ($0.70/kg is a midpoint), natural gas ($4.15/GJ, EIA 2023), HEFA-SPK ($2.10/kg), char, O2, and the $1.09/kg parity price.
2. A staffing table for the fixed labour cost ($2.5M/yr salaries, about 30 staff, plus 90 % burden).
3. Cited SOEC and SMR installed costs, and the photocatalyst panel cost ($250/m2).
4. Prajapati and Li yields entered into rows S5-S8 of `R1_yield_ranges.csv`, plus a third independent source per route.
5. The DOI of the Zenodo/GitHub deposit of `Module_R1` and the OpenLCA exports. Remove the personal files from `tea_20260605_1634/plots/` first.
