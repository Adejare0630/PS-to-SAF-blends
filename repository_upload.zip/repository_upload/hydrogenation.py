# hydrogenation.py
# Catalytic hydrogenation unit module (Pd/SBA-15 or Ni/Al2O3)

import biosteam as bst
from compounds import HYDROGENATION_CONVERSION


class HydrogenationUnit(bst.Unit):
    """
    Catalytic hydrogenation of PS pyrolysis oil to SAF-range hydrocarbons.

    Scenario 1: Gas-phase hydrogenation at 350 °C, 0.15 MPa H2, Pd/SBA-15.
    Scenario 2: Liquid-phase hydroprocessing at 300 °C, 3 MPa H2, Ni/Al2O3.

    Parameters
    ----------
    ID : str
        Unit identifier.
    ins : list
        ins[0] = pyrolysis oil, ins[1] = hydrogen stream.
    outs : list
        outs[0] = SAF product, outs[1] = off-gas (excess H2).
    scenario : int
        1 or 2 — determines operating T and P.
    catalyst : str
        'Pd/SBA-15' (Sc1) or 'Ni/Al2O3' (Sc2).
    """

    _N_ins  = 2
    _N_outs = 2

    # kg H2 consumed per kg of aromatic species hydrogenated
    H2_CONSUMPTION_RATIO = {
        # R1: Styrene value is now VINYL-ONLY hydrogenation (styrene -> EB: 2.016/104.15 = 0.0194; was 0.078 for full
        # ring saturation). The ring-saturation values below are no longer used by Scenario 1.
        'Styrene':      0.01937,
        'Ethylbenzene': 0.057,
        'pXylene':      0.057,
        'Toluene':      0.066,
        'Benzene':      0.077,
        'Naphthalene':  0.063,
        'Indane':       0.061,
    }

    CAPEX_COEFF = (1_200_000, 500, 0.65)

    def __init__(self, ID='', ins=(), outs=(), scenario=1, catalyst='Pd/SBA-15'):
        super().__init__(ID, ins, outs)
        self.scenario = scenario
        self.catalyst = catalyst
        if scenario == 1:
            self.T_rxn = 350 + 273.15   # K
            self.P_rxn = 0.15e6          # Pa
        else:
            self.T_rxn = 300 + 273.15
            self.P_rxn = 3.0e6

    def _run(self):
        pyro_oil, hydrogen = self.ins
        saf_product, offgas = self.outs

        saf_flows   = {}
        h2_consumed = 0.0

        for species, (product, conversion) in HYDROGENATION_CONVERSION.items():
            try:
                feed_kg = pyro_oil.get_flow('kg/hr', species)
            except Exception:
                feed_kg = 0.0

            if feed_kg > 0:
                converted_kg = feed_kg * conversion
                h2_used      = converted_kg * self.H2_CONSUMPTION_RATIO.get(species, 0.06)
                h2_consumed += h2_used

                # Product mass = reactant mass + H2 mass incorporated during hydrogenation
                saf_flows[product] = saf_flows.get(product, 0.0) + converted_kg + h2_used

                unconverted = feed_kg - converted_kg
                if unconverted > 0:
                    saf_flows[species] = saf_flows.get(species, 0.0) + unconverted

        # Pass n-alkanes through unchanged (already SAF-range)
        for sp in ['Decane', 'Dodecane', 'Tetradecane', 'Hexadecane', 'Ethylbenzene']:   # R1: EB now passes through (ring preserved)
            try:
                kg = pyro_oil.get_flow('kg/hr', sp)
            except Exception:
                kg = 0.0
            if kg > 0:
                saf_flows[sp] = saf_flows.get(sp, 0.0) + kg

        saf_product.empty()
        for sp, kg in saf_flows.items():
            saf_product.set_flow(kg, 'kg/hr', sp)
        saf_product.T = self.T_rxn
        saf_product.P = self.P_rxn

        try:
            h2_in = hydrogen.get_flow('kg/hr', 'Hydrogen')
        except Exception:
            h2_in = 0.0
        h2_excess = max(0.0, h2_in - h2_consumed)
        offgas.empty()
        offgas.set_flow(h2_excess, 'kg/hr', 'Hydrogen')
        self.h2_consumed_kg_hr = h2_consumed

    def _design(self):
        feed_mass = self.F_mass_in
        base, ref, exp = self.CAPEX_COEFF
        self.purchase_costs['Hydrogenation reactor'] = base * (feed_mass / ref) ** exp
        # Catalyst loading cost: Pd is expensive (~$50k/kg), Ni is cheap (~$5k/kg)
        if 'Pd' in self.catalyst:
            self.purchase_costs[f'{self.catalyst} catalyst'] = feed_mass * 0.005 * 50_000
        else:
            self.purchase_costs[f'{self.catalyst} catalyst'] = feed_mass * 0.020 *  5_000
        self.purchase_costs['Separator/distillation']   = base * 0.40 * (feed_mass / ref) ** exp
        self.purchase_costs['Heat exchangers (HXU)']    = base * 0.20 * (feed_mass / ref) ** exp

    def _cost(self):
        heat_duty_kJ_hr = self.F_mass_in * 800   # kJ/hr — add_heat_utility expects kJ/hr, not kW
        self.add_heat_utility(heat_duty_kJ_hr, T_in=298.15, T_out=self.T_rxn)


class SelectiveHydrogenationUnit(bst.Unit):
    """
    Extended hydrogenation for Sc2:
      (1) Vinyl-bond saturation: styrene → ethylbenzene  (80 °C step, mild)
      (2) Partial ring saturation: naphthalene/indane/BTEX → cycloalkane products
          Improves freeze point and reduces PNA content for SAF blending.
          200 °C, 3.0 MPa, Pd/Al2O3
    """

    _N_ins  = 2   # pyrolysis oil, hydrogen
    _N_outs = 2   # product oil, H2 off-gas

    CAPEX_COEFF = (900_000, 500, 0.60)

    def __init__(self, ID='', ins=(), outs=()):
        super().__init__(ID, ins, outs)
        from compounds import SC2_HYDRO_T_C, SC2_HYDRO_P_PA
        self.T_rxn = SC2_HYDRO_T_C + 273.15   # K — R1: 70 C vinyl-only (Prajapati)
        self.P_rxn = SC2_HYDRO_P_PA           # Pa

    def _run(self):
        from compounds import (SELECTIVE_HYDRO_CONVERSION, SELECTIVE_H2_STOICH,
                               SC2_EXTENDED_HYDRO_CONVERSION, SC2_EXTENDED_H2_STOICH, SC2_OLIGOMER_H2)
        pyro_oil, hydrogen = self.ins
        eb_oil, offgas = self.outs

        flows = {}
        h2_consumed = 0.0

        # Step 1: vinyl-bond saturation — styrene → ethylbenzene
        for species, (product, conversion) in SELECTIVE_HYDRO_CONVERSION.items():
            try:
                feed_kg = pyro_oil.get_flow('kg/hr', species)
            except Exception:
                feed_kg = 0.0
            if feed_kg <= 1e-9:
                continue
            converted_kg = feed_kg * conversion
            h2_consumed += converted_kg * SELECTIVE_H2_STOICH.get(species, 0.02)
            # MW ratio: ethylbenzene (106.17) / styrene (104.15)
            eb_kg = converted_kg * (106.17 / 104.15)
            flows[product] = flows.get(product, 0.0) + eb_kg
            unconverted = feed_kg - converted_kg
            if unconverted > 1e-9:
                flows[species] = flows.get(species, 0.0) + unconverted

        # Step 1b: partial ring saturation — naphthalene, indane, BTEX aromatics
        for species, (product, conversion) in SC2_EXTENDED_HYDRO_CONVERSION.items():
            try:
                feed_kg = pyro_oil.get_flow('kg/hr', species)
            except Exception:
                feed_kg = 0.0
            if feed_kg <= 1e-9:
                continue
            converted_kg = feed_kg * conversion
            h2_used = converted_kg * SC2_EXTENDED_H2_STOICH.get(species, 0.05)
            h2_consumed += h2_used
            # Product mass = reactant mass + H2 mass incorporated during ring saturation
            flows[product] = flows.get(product, 0.0) + converted_kg + h2_used
            unconverted = feed_kg - converted_kg
            if unconverted > 1e-9:
                flows[species] = flows.get(species, 0.0) + unconverted

        # Step 1c (R1): vinyl-bearing styrene oligomers take up H2 (mass added to the same lumped species)
        if SC2_OLIGOMER_H2 > 0:
            try:
                olig = pyro_oil.get_flow('kg/hr', 'StyreneOligomers')
            except Exception:
                olig = 0.0
            if olig > 1e-9:
                h2_o = olig * SC2_OLIGOMER_H2
                h2_consumed += h2_o
                flows['StyreneOligomers'] = flows.get('StyreneOligomers', 0.0) + olig + h2_o

        # Step 2: pass through all unhandled species (alkanes, etc.)
        handled = set(SELECTIVE_HYDRO_CONVERSION) | set(SC2_EXTENDED_HYDRO_CONVERSION)
        if SC2_OLIGOMER_H2 > 0:
            handled.add('StyreneOligomers')
        for chem in pyro_oil.chemicals:
            if chem.ID in handled:
                continue
            try:
                kg = pyro_oil.get_flow('kg/hr', chem.ID)
            except Exception:
                kg = 0.0
            if kg > 1e-9:
                flows[chem.ID] = flows.get(chem.ID, 0.0) + kg

        eb_oil.empty()
        for sp, kg in flows.items():
            eb_oil.set_flow(kg, 'kg/hr', sp)
        eb_oil.T = self.T_rxn
        eb_oil.P = self.P_rxn

        try:
            h2_in = hydrogen.get_flow('kg/hr', 'Hydrogen')
        except Exception:
            h2_in = 0.0
        offgas.empty()
        offgas.set_flow(max(0.0, h2_in - h2_consumed), 'kg/hr', 'Hydrogen')
        self.h2_consumed_kg_hr = h2_consumed

    def _design(self):
        feed_mass = self.F_mass_in
        base, ref, exp = self.CAPEX_COEFF
        self.purchase_costs['Extended hydrogenation reactor'] = base * (feed_mass / ref) ** exp
        self.purchase_costs['Pd/Al2O3 catalyst']             = feed_mass * 0.002 * 50_000
        from compounds import SC2_DISTILL16
        if not SC2_DISTILL16:   # R1: Prajapati16 costs the real column in SPKBlendingUnit instead (no double count)
            self.purchase_costs['EB distillation column']    = base * 0.50 * (feed_mass / ref) ** exp
        self.purchase_costs['High-pressure compressor']      = base * 0.25 * (feed_mass / ref) ** exp

    def _cost(self):
        from compounds import SC2_HYDRO_HEAT_KJ_KG
        heat_duty_kJ_hr = self.F_mass_in * SC2_HYDRO_HEAT_KJ_KG   # kJ/hr (R1: 100 kJ/kg at 70 C; 400 kJ/kg ring-sat case) (add_heat_utility expects kJ/hr, not kW)
        self.add_heat_utility(heat_duty_kJ_hr, T_in=298.15, T_out=self.T_rxn)


class SPKBlendingUnit(bst.Unit):
    """
    Sc2 downstream section; PS-only route, Prajapati measured basis (the 50:50 blend case was removed).

    Measured basis: the hydrogenated oil is distilled to an ethylbenzene-rich ADDITIVE cut
      (EB recovery SC2_EB_RECOVERY, companions cumene/toluene at the measured cut composition, ~89-90 wt% EB); everything
      else is an "other ends" by-product (credited at fuel value only).  The additive is blended at 16 vol%
      (~18 wt%) into purchased HEFA-SPK:  spk = additive*(1-w)/w.
    Blend share (vol% aromatic additive in SPK) is a 15-25 vol% sensitivity: compounds.SC2_BLEND_VOL_PCT.

    ins[0] : hydrogenated oil     ins[1] : purchased HEFA-SPK (flow set internally)
    outs[0]: blended fuel         outs[1]: other ends (Prajapati16) 
    Attributes: eb_kg_hr (additive or full oil), spk_kg_hr, blend_kg_hr, ends_kg_hr, additive_kg_hr
    """

    _N_ins  = 2
    _N_outs = 2
    CAPEX_COEFF = (600_000, 1000, 0.65)
    DIST_COEFF  = (450_000, 1000, 0.65)    # EB distillation column + condenser/reboiler (ASSUMPTION, scaled from the blender coefficients)

    def __init__(self, ID='', ins=(), outs=()):
        super().__init__(ID, ins, outs)
        self.eb_kg_hr = 0.0
        self.spk_kg_hr = 0.0
        self.blend_kg_hr = 0.0
        self.ends_kg_hr = 0.0
        self.additive_kg_hr = 0.0

    def _run(self):
        from compounds import (SC2_DISTILL16, SC2_EB_RECOVERY, SC2_CUT_COMPANIONS, SC2_ADDITIVE_MASS_FRAC)
        eb_oil, spk_feed = self.ins
        blend, bottoms   = self.outs

        species = {}
        for chem in eb_oil.chemicals:
            try:
                kg = eb_oil.get_flow('kg/hr', chem.ID)
            except Exception:
                kg = 0.0
            if kg > 1e-9:
                species[chem.ID] = kg
        total_oil_kg = sum(species.values())

        blend.empty(); bottoms.empty(); spk_feed.empty()
        if SC2_DISTILL16:
            cut = {}
            eb_cut = species.get('Ethylbenzene', 0.0) * SC2_EB_RECOVERY
            if eb_cut > 0:
                cut['Ethylbenzene'] = eb_cut
            for comp, per_eb in SC2_CUT_COMPANIONS.items():
                kg = min(species.get(comp, 0.0), eb_cut * per_eb)
                if kg > 0:
                    cut[comp] = kg
            additive = sum(cut.values())
            w = SC2_ADDITIVE_MASS_FRAC
            spk_kg = additive * (1.0 - w) / w
            for sp, kg in species.items():
                rest = kg - cut.get(sp, 0.0)
                if rest > 1e-9:
                    bottoms.set_flow(rest, 'kg/hr', sp)
            for sp, kg in cut.items():
                blend.set_flow(kg, 'kg/hr', sp)
            if spk_kg > 1e-9:
                spk_feed.set_flow(spk_kg, 'kg/hr', 'SPK')
                blend.set_flow(spk_kg, 'kg/hr', 'SPK')
            bottoms.T = 298.15
            self.additive_kg_hr = additive
            self.eb_kg_hr = additive
            self.spk_kg_hr = spk_kg
            self.blend_kg_hr = additive + spk_kg
            self.ends_kg_hr = total_oil_kg - additive
        else:
            spk_kg = total_oil_kg          # 1:1 by mass
            if spk_kg > 1e-9:
                spk_feed.set_flow(spk_kg, 'kg/hr', 'SPK')
            for sp, kg in species.items():
                blend.set_flow(kg, 'kg/hr', sp)
            try:
                existing_spk = blend.get_flow('kg/hr', 'SPK')
            except Exception:
                existing_spk = 0.0
            blend.set_flow(existing_spk + spk_kg, 'kg/hr', 'SPK')
            self.additive_kg_hr = total_oil_kg
            self.eb_kg_hr = total_oil_kg
            self.spk_kg_hr = spk_kg
            self.blend_kg_hr = total_oil_kg + spk_kg
            self.ends_kg_hr = 0.0
        blend.T = 298.15
        blend.P = 101_325.0

    def _design(self):
        from compounds import SC2_DISTILL16
        feed_mass      = self.F_mass_in
        base, ref, exp = self.CAPEX_COEFF
        self.purchase_costs['SPK day-storage tank']    = base * 0.40 * (feed_mass / ref) ** exp
        self.purchase_costs['Blending vessel + pumps'] = base * 0.20 * (feed_mass / ref) ** exp
        if SC2_DISTILL16:
            db, dref, dexp = self.DIST_COEFF
            oil_mass = self.eb_kg_hr + self.ends_kg_hr
            self.purchase_costs['EB distillation column'] = db * (oil_mass / dref) ** dexp

    def _cost(self):
        from compounds import SC2_DISTILL16
        # Blending: minimal heat.  Distillation (Prajapati16): ~600 kJ/kg of oil fed (ASSUMPTION; EB cut ~20-30% of feed vaporised)
        per_kg = 30 + (600 if SC2_DISTILL16 else 0)
        oil_mass = (self.eb_kg_hr + self.ends_kg_hr) if SC2_DISTILL16 else self.F_mass_in
        heat_duty_kJ_hr = (oil_mass * per_kg) if SC2_DISTILL16 else self.F_mass_in * 30   # kJ/hr
        self.add_heat_utility(heat_duty_kJ_hr, T_in=298.15, T_out=420.0 if SC2_DISTILL16 else 303.15)
