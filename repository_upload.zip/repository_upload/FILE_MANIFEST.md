# File manifest

Repository contents for: Techno-economic and well-to-wake life-cycle assessment of aviation fuel blendstocks from waste polystyrene (Adesiyan & Mba Wright).

## Process model (BioSTEAM)

- `compounds.py`
- `hydrogen_production.py`
- `hydrogenation.py`
- `main.py`
- `pretreatment.py`
- `pyrolyzer.py`
- `relabel_csv.py`
- `requirements.txt`
- `scenario_relabel.py`

## Techno-economic and LCA model

- `tea_20260605_1634/scripts/make_cashflow.py`
- `tea_20260605_1634/scripts/make_contour.py`
- `tea_20260605_1634/scripts/make_contour_process.py`
- `tea_20260605_1634/scripts/make_lca.py`
- `tea_20260605_1634/scripts/make_material_balance.py`
- `tea_20260605_1634/scripts/make_npv.py`
- `tea_20260605_1634/scripts/make_plots.py`
- `tea_20260605_1634/scripts/make_tornado.py`
- `tea_20260605_1634/scripts/make_tpec.py`
- `tea_20260605_1634/scripts/tea_bridge.py`
- `tea_20260605_1634/scripts/tea_model.py`

## Revision analysis scripts

- `R1_extra_figs.py`
- `R1_extra_figs_word.py`
- `R1_montecarlo_figures.py`
- `R1_replica_analysis.py`
- `R1_sensitivity_runs.py`
- `R1_supplementary.py`
- `R1_tea_replica.py`
- `fig4_to_drawio.py`
- `make_fig4_boundary.py`
- `make_fig4_boundary_readable.py`
- `make_pfd_style.py`
- `make_pfd_word.py`
- `make_r1_results_figs.py`
- `make_r1_results_figs_word.py`
- `run_R1_analysis.py`
- `run_R1_cases.py`

## Input data

- `OpenLCA/README.md`
- `R1_mc_distributions.csv`
- `R1_yield_ranges.csv`

## Model results (stream data)

- `Material_Streams_All_Scenarios.xlsx`
- `tea_20260605_1634/data/material_balance_streams.csv`
- `tea_20260605_1634/data/material_balance_totals.csv`

## TEA results (replica)

- `R1_outputs/replica/airline_cost_impact.csv`
- `R1_outputs/replica/audit_cases.csv`
- `R1_outputs/replica/breakevens.csv`
- `R1_outputs/replica/cashflow_payback.csv`
- `R1_outputs/replica/eb_additive_cost.csv`
- `R1_outputs/replica/gwp_tornado.csv`
- `R1_outputs/replica/mc_convergence.csv`
- `R1_outputs/replica/mc_distributions_used.csv`
- `R1_outputs/replica/mc_summary.csv`
- `R1_outputs/replica/tea_base.csv`
- `R1_outputs/replica/tornado.csv`
- `R1_outputs/replica/tpec_by_area_MM.csv`

## LCA and property results

- `R1_outputs/supplementary/R1_credit_treatments.csv`
- `R1_outputs/supplementary/R1_grid_sensitivity.csv`
- `R1_outputs/supplementary/R1_lca_base.csv`
- `R1_outputs/supplementary/R1_lca_inventory_per_MJ.csv`
- `R1_outputs/supplementary/R1_product_properties.csv`
- `R1_outputs/supplementary/R1_traci_per_MJ.csv`

## Supplementary data workbooks and editable diagrams

- `R1_response/Fig4_LCA_system_boundary_WTW.drawio`
- `R1_response/PFD_simulation_model_style.drawio`
- `R1_response/PFD_stream_tables.xlsx`
- `R1_response/PS_Fuel_ESI_Data.xlsx`

## Figures (manuscript layout)

- `R1_response/figs_R1/Fig10_tornado.pdf`
- `R1_response/figs_R1/Fig10_tornado.png`
- `R1_response/figs_R1/Fig12_GWP_WTW.pdf`
- `R1_response/figs_R1/Fig12_GWP_WTW.png`
- `R1_response/figs_R1/Fig5_MFSP_breakdown.pdf`
- `R1_response/figs_R1/Fig5_MFSP_breakdown.png`
- `R1_response/figs_R1/Fig7_capex_opex.pdf`
- `R1_response/figs_R1/Fig7_capex_opex.png`
- `R1_response/figs_R1/FigS3_MonteCarlo.pdf`
- `R1_response/figs_R1/FigS3_MonteCarlo.png`
- `R1_response/figs_R1/Fig_GWP_tornado.pdf`
- `R1_response/figs_R1/Fig_GWP_tornado.png`
- `R1_response/figs_R1/Fig_TPEC_by_area.pdf`
- `R1_response/figs_R1/Fig_TPEC_by_area.png`
- `R1_response/figs_R1/Fig_TRACI_heatmap.pdf`
- `R1_response/figs_R1/Fig_TRACI_heatmap.png`
- `R1_response/figs_R1/Fig_cashflow_NPV.pdf`
- `R1_response/figs_R1/Fig_cashflow_NPV.png`
- `R1_response/figs_R1/Fig_literature_GJ.pdf`
- `R1_response/figs_R1/Fig_literature_GJ.png`

## Figures (sized for Word)

- `R1_response/figs_word/Fig4_boundary_Scenario1_readable.pdf`
- `R1_response/figs_word/Fig4_boundary_Scenario1_readable.png`
- `R1_response/figs_word/Fig4_boundary_Scenario1_readable.svg`
- `R1_response/figs_word/Fig4a_Scenario1_boundary_readable.pdf`
- `R1_response/figs_word/Fig4a_Scenario1_boundary_readable.png`
- `R1_response/figs_word/Fig4a_Scenario1_boundary_readable.svg`
- `R1_response/figs_word/Fig4b_Scenario2_boundary_readable.pdf`
- `R1_response/figs_word/Fig4b_Scenario2_boundary_readable.png`
- `R1_response/figs_word/Fig4b_Scenario2_boundary_readable.svg`
- `R1_response/figs_word/FigS1_MonteCarlo.png`
- `R1_response/figs_word/FigS2_price_sweeps.png`
- `R1_response/figs_word/Fig_GWP_WTW.png`
- `R1_response/figs_word/Fig_GWP_tornado.pdf`
- `R1_response/figs_word/Fig_GWP_tornado.png`
- `R1_response/figs_word/Fig_MFSP_breakdown.png`
- `R1_response/figs_word/Fig_TPEC_by_area.pdf`
- `R1_response/figs_word/Fig_TPEC_by_area.png`
- `R1_response/figs_word/Fig_TRACI_heatmap.pdf`
- `R1_response/figs_word/Fig_TRACI_heatmap.png`
- `R1_response/figs_word/Fig_capex_opex.png`
- `R1_response/figs_word/Fig_cashflow_NPV.pdf`
- `R1_response/figs_word/Fig_cashflow_NPV.png`
- `R1_response/figs_word/Fig_grid_sensitivity.png`
- `R1_response/figs_word/Fig_literature_GJ.pdf`
- `R1_response/figs_word/Fig_literature_GJ.png`
- `R1_response/figs_word/Fig_tornado_MFSP.png`
- `R1_response/figs_word/PFD_Scenario1_word.png`
- `R1_response/figs_word/PFD_Scenario2_word.png`
- `R1_response/figs_word/PFD_Sheet3_H2_production_readable.pdf`
- `R1_response/figs_word/PFD_Sheet3_H2_production_readable.png`
- `R1_response/figs_word/PFD_Sheet3_H2_production_readable.svg`

## Documentation

- `R1_CHANGES.md`
- `README.md`
- `RUN_CHECKLIST.md`

## Oil:PS ratio sweep (added after BioSTEAM rerun)
- `run_R1_ratio_sweep.py`: BioSTEAM sweep of Scenario 2 over oil:PS = 2.5-3.75 for SMR, SOEC and photocatalysis H2 (MFSP, GWP, aromatics).
- `R1_outputs/Li25/R1_ratio_sweep.csv`, `R1_ratio_sweep_full.csv`: sweep results (ESI Table S24).
- `R1_response/figs_word/FigS3_ratio_sweep.png`: ESI Fig. S3.
