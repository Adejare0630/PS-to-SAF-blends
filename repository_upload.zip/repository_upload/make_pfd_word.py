"""Process flow diagrams of the BioSTEAM simulation model in landscape engineering style (process-area bands,
equipment symbols, numbered stream diamonds, products at the right edge). One layout, two renderers:
matplotlib (PDF/SVG/PNG) and draw.io (editable, one page per scenario). Sub-equipment drawn inside each dashed
outline is the equipment costed inside that BioSTEAM unit; stream numbers are the model streams (stream table:
PFD_stream_tables.xlsx). Values: BioSTEAM run of 17 Nov 2026, SMR base case.

    python make_pfd_style.py [outdir]
"""
import os, sys
from xml.sax.saxutils import escape

NAVY, FILL, BAND, BANDE, ORANGE, GREY, GREEN, BROWN = "#2C4A6E", "#EEF3FA", "#F6F6F6", "#D4D4D4", "#B9770E", "#7F7F7F", "#2E7D32", "#6D4C41"
W_U, H_U = 214.0, 88.0
FS = float(os.environ.get("PFD_FONT_SCALE", "1.55"))
FS_BIG = 1.15
DS = 1.3   # diamond (stream-number) scale


# ═══════════════════════════ renderers ═══════════════════════════
class Mpl:
    def __init__(self):
        import matplotlib; matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        plt.rcParams.update({"font.family": ["Arial", "Liberation Sans", "DejaVu Sans"], "svg.fonttype": "none", "pdf.fonttype": 42})
        self.plt = plt
        self.fig, self.ax = plt.subplots(figsize=(13.4, 5.5))
        self.ax.set_xlim(0, W_U); self.ax.set_ylim(0, H_U); self.ax.set_aspect("equal"); self.ax.axis("off")
        self.fig.subplots_adjust(left=0.003, right=0.997, top=0.997, bottom=0.003)

    def rect(self, x, y, w, h, fc=FILL, ec=NAVY, lw=1.0, ls="-", r=0.0, z=3):
        from matplotlib.patches import FancyBboxPatch, Rectangle
        if r:
            self.ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle=f"round,pad=0,rounding_size={r}", fc=fc, ec=ec, lw=lw, ls=ls, zorder=z))
        else:
            self.ax.add_patch(Rectangle((x, y), w, h, fc=fc, ec=ec, lw=lw, ls=ls, zorder=z))

    def ellipse(self, x, y, w, h, fc=FILL, ec=NAVY, lw=1.0, z=3):
        from matplotlib.patches import Ellipse
        self.ax.add_patch(Ellipse((x + w / 2, y + h / 2), w, h, fc=fc, ec=ec, lw=lw, zorder=z))

    def poly(self, pts, fc=FILL, ec=NAVY, lw=1.0, z=3):
        from matplotlib.patches import Polygon
        self.ax.add_patch(Polygon(pts, fc=fc, ec=ec, lw=lw, zorder=z))

    def trap(self, x, y, w, h, narrow="bottom", k=0.3, fc=FILL, ec=NAVY):
        if narrow == "bottom":
            self.poly([(x, y + h), (x + w, y + h), (x + w * (1 - k), y), (x + w * k, y)], fc, ec)
        else:
            self.poly([(x, y), (x + w, y), (x + w * (1 - k), y + h), (x + w * k, y + h)], fc, ec)

    def tri(self, x, y, w, h, fc=NAVY):
        self.poly([(x, y), (x, y + h), (x + w, y + h / 2)], fc=fc, ec=fc, z=4)

    def line(self, pts, color=NAVY, lw=1.0, ls="-", head=True, z=2):
        ax = self.ax
        for a, b in zip(pts[:-2], pts[1:-1]):
            ax.plot([a[0], b[0]], [a[1], b[1]], color=color, lw=lw, ls=ls, zorder=z, solid_capstyle="butt")
        if head:
            ax.annotate("", xy=pts[-1], xytext=pts[-2], zorder=z, arrowprops=dict(arrowstyle="-|>", color=color, lw=lw, ls=ls,
                        mutation_scale=8, shrinkA=0, shrinkB=0))
        else:
            ax.plot([pts[-2][0], pts[-1][0]], [pts[-2][1], pts[-1][1]], color=color, lw=lw, ls=ls, zorder=z)

    def text(self, x, y, s, ha="center", va="center", fs=6.4, color="#1A1A1A", bold=False, italic=False, rot=0):
        self.ax.text(x, y, s, ha=ha, va=va, fontsize=fs * (FS if fs <= 6.5 else FS_BIG), color=color, fontweight="bold" if bold else "normal",
                     style="italic" if italic else "normal", rotation=rot, zorder=7, linespacing=1.2)

    def save(self, base):
        for ext, kw in (("pdf", {}), ("svg", {}), ("png", {"dpi": 300})):
            self.fig.savefig(f"{base}.{ext}", **kw)
        self.plt.close(self.fig)


class Drawio:
    S, PT = 8.0, 1.80

    def __init__(self):
        self.cells, self.shapes, self.n = [], [], 1

    def _id(self):
        self.n += 1
        return f"p{self.n}"

    def X(self, x): return round(x * self.S, 1)
    def Y(self, y): return round((H_U - y) * self.S, 1)

    def _v(self, label, x, y, w, h, style, reg=True, front=True):
        i = self._id()
        val = escape(label).replace("\n", "&lt;br&gt;").replace('"', "&quot;")
        cell = (f'<mxCell id="{i}" value="{val}" style="{style}" vertex="1" parent="1"><mxGeometry x="{self.X(x)}" y="{self.Y(y + h)}" '
                f'width="{round(w * self.S, 1)}" height="{round(h * self.S, 1)}" as="geometry"/></mxCell>')
        self.cells.append(cell) if front else self.cells.insert(0, cell)
        if reg:
            self.shapes.append((i, x, y, w, h))
        return i

    def _st(self, fc, ec, lw, ls):
        return (f"html=1;whiteSpace=wrap;fillColor={fc if fc != 'none' else 'none'};strokeColor={ec if ec != 'none' else 'none'};"
                f"strokeWidth={round(lw * 1.3, 2)};" + ("dashed=1;" if ls != "-" else ""))

    def rect(self, x, y, w, h, fc=FILL, ec=NAVY, lw=1.0, ls="-", r=0.0, z=3):
        band = z < 1
        st = ("rounded=1;arcSize=" + str(int(min(50, r / min(w, h) * 100 * 2))) + ";" if r else "rounded=0;") + self._st(fc, ec, lw, ls)
        self._v("", x, y, w, h, st, reg=not band and ls == "-", front=not band)

    def ellipse(self, x, y, w, h, fc=FILL, ec=NAVY, lw=1.0, z=3):
        self._v("", x, y, w, h, "ellipse;" + self._st(fc, ec, lw, "-"))

    def trap(self, x, y, w, h, narrow="bottom", k=0.3, fc=FILL, ec=NAVY):
        self._v("", x, y, w, h, f"shape=trapezoid;perimeter=trapezoidPerimeter;size={k};" + ("flipV=1;" if narrow == "bottom" else "")
                + self._st(fc, ec, 1.0, "-"))

    def tri(self, x, y, w, h, fc=NAVY):
        self._v("", x, y, w, h, "triangle;" + self._st(fc, fc, 1.0, "-"), reg=False)

    def poly(self, pts, fc=FILL, ec=NAVY, lw=1.0, z=3):
        raise NotImplementedError

    def _attach(self, p):
        px, py = p
        for i, x, y, w, h in reversed(self.shapes):
            t = 0.35
            if x - t <= px <= x + w + t and y - t <= py <= y + h + t and (
                    abs(px - x) < t or abs(px - x - w) < t or abs(py - y) < t or abs(py - y - h) < t):
                return i, min(max((px - x) / w, 0), 1), min(max(1 - (py - y) / h, 0), 1)
        return None

    def line(self, pts, color=NAVY, lw=1.0, ls="-", head=True, z=2):
        i = self._id(); src, tgt = self._attach(pts[0]), self._attach(pts[-1])
        st = (f"edgeStyle=none;html=1;rounded=0;jumpStyle=arc;jumpSize=6;strokeColor={color};strokeWidth={round(lw * 1.3, 2)};"
              + ("endArrow=block;endFill=1;endSize=5;" if head else "endArrow=none;") + ("dashed=1;" if ls != "-" else ""))
        a = ""
        if src and head is not None: a += f' source="{src[0]}"'; st += f"exitX={src[1]:.3f};exitY={src[2]:.3f};exitPerimeter=0;"
        if tgt: a += f' target="{tgt[0]}"'; st += f"entryX={tgt[1]:.3f};entryY={tgt[2]:.3f};entryPerimeter=0;"
        way = "".join(f'<mxPoint x="{self.X(p[0])}" y="{self.Y(p[1])}"/>' for p in pts[1:-1])
        g = ('<mxGeometry relative="1" as="geometry">'
             + ("" if (src and head is not None) else f'<mxPoint x="{self.X(pts[0][0])}" y="{self.Y(pts[0][1])}" as="sourcePoint"/>')
             + ("" if tgt else f'<mxPoint x="{self.X(pts[-1][0])}" y="{self.Y(pts[-1][1])}" as="targetPoint"/>')
             + (f'<Array as="points">{way}</Array>' if way else "") + "</mxGeometry>")
        self.cells.append(f'<mxCell id="{i}" style="{st}" edge="1" parent="1"{a}>{g}</mxCell>')

    def text(self, x, y, s, ha="center", va="center", fs=6.4, color="#1A1A1A", bold=False, italic=False, rot=0):
        lines = s.split("\n")
        w = max(len(l) for l in lines) * fs * 0.58 * self.PT / self.S + 1.2
        h = len(lines) * fs * self.PT * 1.25 / self.S + 0.4
        if rot:
            w, h = h, w
        x0 = x if ha == "left" else (x - w / 2 if ha == "center" else x - w)
        y0 = y - h / 2 if va == "center" else (y if va == "bottom" else y - h)
        st = (f"text;html=1;whiteSpace=wrap;align={ha};verticalAlign=middle;fontFamily=Arial;spacing=0;"
              f"fontSize={round(fs * self.PT, 1)};fontColor={color};fontStyle={(1 if bold else 0) + (2 if italic else 0)};"
              + ("horizontal=0;" if rot else ""))
        self._v(s, x0, y0, w, h, st, reg=False)

    def page(self, name, pid):
        W, H = int(W_U * self.S), int(H_U * self.S)
        return (f'<diagram name="{name}" id="{pid}"><mxGraphModel dx="{W}" dy="{H}" grid="1" gridSize="5" guides="1" tooltips="1" '
                f'connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="{W}" pageHeight="{H}" math="0" shadow="0">'
                f'<root><mxCell id="0"/><mxCell id="1" parent="0"/>' + "".join(self.cells) + "</root></mxGraphModel></diagram>")


# ═══════════════════════════ symbols ═══════════════════════════
class Sym:
    def __init__(self, D):
        self.D = D

    def sn(self, x, y, n):
        D = self.D; w = 3.4 if len(str(n)) <= 2 else 5.2
        if isinstance(D, Mpl):
            w *= DS; hh = 1.7 * DS
            D.poly([(x - w / 2, y), (x, y + hh), (x + w / 2, y), (x, y - hh)], fc="white", ec=NAVY, z=5)
            D.text(x, y, str(n), fs=5.6 * DS / FS, color=NAVY, bold=True)
        else:
            D._v(str(n), x - w / 2, y - 1.7, w, 3.4, f"rhombus;html=1;whiteSpace=wrap;fillColor=#FFFFFF;strokeColor={NAVY};"
                 f"fontColor={NAVY};fontStyle=1;fontSize={round(5.6 * D.PT, 1)};fontFamily=Arial;", reg=False)

    def band(self, x0, x1, title):
        self.D.rect(x0, 3.0, x1 - x0, 78.0, fc=BAND, ec=BANDE, lw=0.8, z=0)
        self.D.text((x0 + x1) / 2, 78.2, title, fs=7.6, bold=True, color="#333333")

    def outline(self, x, y, w, h, tag):
        self.D.rect(x, y, w, h, fc="none", ec=GREY, lw=0.7, ls="--", r=1.0, z=1)
        self.D.text(x + 0.8, y + h - 1.3, tag, ha="left", fs=5.6, bold=True, color="#1F3864")

    def hopper(self, x, y, w=8, h=9):
        self.D.trap(x, y, w, h, "bottom", 0.28)

    def grinder(self, x, y, w=9, h=7):
        self.D.rect(x, y, w, h)
        r = h * 0.58
        self.D.ellipse(x + w * 0.5 - r - 0.25, y + (h - r) / 2, r, r)
        self.D.ellipse(x + w * 0.5 + 0.25, y + (h - r) / 2, r, r)

    def screen(self, x, y, w=9, h=7):
        self.D.rect(x, y, w, h)
        self.D.line([(x + 0.4, y + h - 0.8), (x + w - 0.4, y + 0.8)], lw=0.8, ls="--", head=False, z=4)

    def dryer(self, x, y, w=10, h=5):
        self.D.rect(x, y, w, h, r=h / 2)
        for k in (0.3, 0.5, 0.7):
            self.D.line([(x + w * k, y + 0.4), (x + w * k, y + h - 0.4)], lw=0.6, head=False, z=4)

    def hx(self, x, y, d=6):
        self.D.ellipse(x, y, d, d)
        self.D.line([(x + 0.5, y + d / 2), (x + d * 0.3, y + d * 0.75), (x + d * 0.55, y + d * 0.25), (x + d * 0.78, y + d * 0.75),
                     (x + d - 0.5, y + d / 2)], lw=0.8, head=False, z=4)

    def pump(self, x, y, d=5.5):
        self.D.ellipse(x, y, d, d)
        self.D.tri(x + d * 0.3, y + d * 0.25, d * 0.48, d * 0.5)

    def mixer(self, x, y, d=6):
        self.D.ellipse(x, y, d, d)
        self.D.text(x + d / 2, y + d / 2, "M", fs=7.0, color=NAVY)

    def vessel(self, x, y, w, h, label="", rot=False):
        self.D.rect(x, y, w, h, r=w / 2)
        if label:
            self.D.text(x + w / 2, y + h / 2, label, fs=6.0, rot=90 if rot else 0)

    def bed(self, x, y, w, h, label=""):
        self.D.rect(x, y, w, h, r=w / 2)
        for yy in (y + h * 0.36, y + h * 0.64):
            self.D.line([(x + 0.1, yy), (x + w - 0.1, yy)], lw=0.6, head=False, z=4)
        for k in range(4):
            x0 = x + w * (0.1 + 0.22 * k)
            self.D.line([(x0, y + h * 0.38), (x0 + w * 0.17, y + h * 0.62)], color=GREY, lw=0.5, head=False, z=4)
        if label:
            self.D.text(x + w / 2, y + h * 0.82, label, fs=5.6, bold=True, color=NAVY)

    def cyclone(self, x, y, w=6, h=12):
        self.D.rect(x, y + h * 0.55, w, h * 0.45, r=0)
        self.D.trap(x, y, w, h * 0.55, "bottom", 0.36)

    def column(self, x, y, w, h, n=12):
        self.D.rect(x, y, w, h, r=w / 2)
        for k in range(1, n + 1):
            yy = y + w * 0.5 + (h - w) * k / (n + 1)
            self.D.line([(x + 0.12, yy), (x + w - 0.12, yy)], color="#9FB3C8", lw=0.5, head=False, z=4)

    def tank(self, x, y, w, h):
        D = self.D
        if isinstance(D, Mpl):
            from matplotlib.patches import Ellipse, Rectangle, Arc
            e = h * 0.2
            D.ax.add_patch(Rectangle((x, y + e / 2), w, h - e, fc=FILL, ec="none", zorder=3))
            D.ax.plot([x, x], [y + e / 2, y + h - e / 2], color=NAVY, lw=1.0, zorder=3)
            D.ax.plot([x + w, x + w], [y + e / 2, y + h - e / 2], color=NAVY, lw=1.0, zorder=3)
            D.ax.add_patch(Ellipse((x + w / 2, y + h - e / 2), w, e, fc=FILL, ec=NAVY, lw=1.0, zorder=3))
            D.ax.add_patch(Arc((x + w / 2, y + e / 2), w, e, theta1=180, theta2=360, ec=NAVY, lw=1.0, zorder=3))
            D.ax.add_patch(Rectangle((x, y), w, h, fc="none", ec="none", zorder=3))
        else:
            D._v("", x, y, w, h, "shape=cylinder3;boundedLbl=1;backgroundOutline=1;size=4;" + D._st(FILL, NAVY, 1.0, "-"))

    def compressor(self, x, y, w=7, h=5.5):
        self.D.trap(x, y, w, h, "top", 0.22)

    def box(self, x, y, w, h, label, sub=None, ls="-", ec=NAVY):
        self.D.rect(x, y, w, h, ec=ec, ls=ls)
        self.D.text(x + w / 2, y + h / 2 + (1.0 if sub else 0), label, fs=5.4)
        if sub:
            self.D.text(x + w / 2, y + 1.6, sub, fs=5.0, color="#333333")


    def compressor_h(self, x, y, w=7, h=5.5):      # narrow end (outlet) to the right
        D = self.D
        if isinstance(D, Mpl):
            D.poly([(x, y), (x, y + h), (x + w, y + h * 0.78), (x + w, y + h * 0.22)])
        else:
            D._v("", x, y, w, h, "shape=trapezoid;perimeter=trapezoidPerimeter;size=0.22;direction=south;" + D._st(FILL, NAVY, 1.0, "-"))

    def reformer(self, x, y, w, h):
        self.D.rect(x, y, w, h)
        for k in range(1, 5):
            xx = x + w * k / 5
            self.D.line([(xx, y + h * 0.18), (xx, y + h * 0.88)], color="#9FB3C8", lw=0.9, head=False, z=4)
        for k in (0.3, 0.5, 0.7):                    # burners
            self.D.line([(x + w * k, y + 0.3), (x + w * k, y + h * 0.13)], color=ORANGE, lw=1.0, head=False, z=4)

    def psa(self, x, y, w=3.2, h=12, gap=1.2):
        self.D.rect(x, y, w, h, r=w / 2)
        self.D.rect(x + w + gap, y, w, h, r=w / 2)

    def stack(self, x, y, w, h):
        self.D.rect(x, y, w, h)
        for k in range(1, 9):
            xx = x + w * k / 9
            self.D.line([(xx, y + 0.5), (xx, y + h - 0.5)], color="#9FB3C8", lw=0.7, head=False, z=4)

    def panels(self, x, y, n=5, w=4.6, h=6.0, gap=1.6):
        D = self.D
        for k in range(n):
            x0 = x + k * (w + gap)
            if isinstance(D, Mpl):
                D.poly([(x0, y), (x0 + w, y), (x0 + w + 1.4, y + h), (x0 + 1.4, y + h)])
                for j in (1, 2):
                    D.line([(x0 + 0.47 * j * 1.4 / 1.4 + w * 0 + 1.4 * j / 3, y + h * j / 3), (x0 + w + 1.4 * j / 3, y + h * j / 3)],
                           color="#9FB3C8", lw=0.5, head=False, z=4)
            else:
                D._v("", x0, y, w + 1.4, h, "shape=parallelogram;perimeter=parallelogramPerimeter;size=0.23;" + D._st(FILL, NAVY, 1.0, "-"))

    def sun(self, x, y, r=1.6):
        import math
        self.D.ellipse(x - r, y - r, 2 * r, 2 * r, fc="#FFE082", ec=ORANGE)
        for k in range(8):
            a = k * math.pi / 4
            self.D.line([(x + 1.35 * r * math.cos(a), y + 1.35 * r * math.sin(a)), (x + 1.9 * r * math.cos(a), y + 1.9 * r * math.sin(a))],
                        color=ORANGE, lw=0.7, head=False, z=4)


# ═══════════════════════════ sheets ═══════════════════════════
def front_end(S):
    """Feed preparation band shared by both scenarios (M-101 = BioSTEAM unit 'Pretreat')."""
    D = S.D
    S.band(4, 50, "Feed preparation")
    D.text(1.0, 41.5, "Waste PS\n250 t/d", ha="left", fs=6.2)
    D.line([(0.6, 36.0), (8.5, 36.0)]); S.sn(4.6, 36.0, 1)
    S.hopper(8.5, 31.5)
    D.text(12.5, 28.0, "Feed handling\n(conveyor, hopper)", fs=5.6)
    S.outline(18.5, 22.0, 30.5, 26.0, "M-101  Pretreatment")
    D.line([(16.5, 36.0), (20.0, 36.0)])
    S.grinder(20.0, 32.5)
    D.text(24.5, 29.4, "Shredder", fs=5.6)
    D.line([(29.0, 36.0), (30.5, 36.0)])
    S.screen(30.5, 32.5)
    D.text(36.2, 28.6, "Wash /\nscreen", ha="left", fs=5.6)
    D.line([(39.5, 36.0), (41.0, 36.0)])
    S.dryer(41.0, 33.5, 7.2, 5.0)
    D.text(44.6, 41.2, "Dryer\nQ 0.47 MW", fs=5.6)
    D.text(35.0, 57.5, "Wash water", fs=5.8)
    D.line([(35.0, 56.0), (35.0, 39.5)]); S.sn(35.0, 52.0, 2)
    D.line([(35.0, 32.5), (35.0, 10.0)]); S.sn(35.0, 15.5, 3)
    D.text(35.0, 7.6, "Rejects to disposal\n(moisture, contaminants, fines)", fs=5.4)
    D.text(19.3, 43.6, "W 0.31 MW (shredder)", ha="left", fs=5.0, color=ORANGE)


def sheet(D, scen):
    S = Sym(D)
    s1 = scen == 1
    title = ("Process flow diagram - Scenario 1 (reference): PS-only pyrolysis, selective hydrogenation, EB distillation and HEFA-SPK blending "
             "(250 t/d PS, 400 °C, Prajapati et al. yields)" if s1 else
             "Process flow diagram - Scenario 2 (proposed): co-hydropyrolysis of waste PS with waste cooking oil "
             "(250 t/d PS, oil:PS = 2.5, 480 °C, Li et al. yields)")
    D.text(1.0, 85.5, title, ha="left", fs=8.2)
    front_end(S)
    # ---------------- pyrolysis & vapour recovery (R-201 = BioSTEAM 'Pyrolyzer') ----------------
    xb = 98 if s1 else 102
    S.band(50, xb, ("Pyrolysis" if s1 else "Co-hydropyrolysis") + " & vapour recovery")
    S.outline(52.0, 15.0, xb - 53.5, 50.0, "R-201  " + ("Pyrolyser" if s1 else "Co-hydropyrolyser"))
    if s1:
        D.line([(48.2, 36.0), (55.0, 36.0)]); S.sn(51.6, 36.0, 4)
        S.hx(55.0, 33.0)
        D.text(58.0, 29.4, "Feed heater", fs=5.6)
        D.line([(61.0, 36.0), (66.0, 36.0)])
    else:
        D.line([(48.2, 36.0), (66.0, 36.0)]); S.sn(52.6, 36.0, 4)
        D.text(51.0, 12.6, "Waste cooking oil\n545 t/d", ha="left", fs=6.0)
        D.line([(53.0, 16.2), (53.0, 30.0), (55.0, 30.0)]); S.sn(53.0, 22.0, 5)
        S.hx(55.0, 27.0)
        D.text(59.6, 24.0, "Feed\nheater", fs=5.6)
        D.line([(61.0, 30.0), (66.0, 30.0)])
    R = (66.0, 24.0, 10.5, 26.0)
    S.box(*R, "FB\npyrolyser" if s1 else "Co-hydro-\npyrolyser")
    D.text(70.5, 56.5, ("400 °C, 1.0 bar\nliquid 96 wt%\nQ 3.79 MW" if s1 else "480 °C, 1.5 bar H₂\nliquid 84 wt%\nQ 13.25 MW"),
           fs=5.8)
    D.line([(76.5, 46.0), (77.7, 46.0), (77.7, 44.0), (79.0, 44.0)])
    S.cyclone(79.0, 36.0, 6.0, 12.0)
    D.text(81.4, 31.6, "Char\nseparator", ha="right", fs=5.6)
    D.line([(82.0, 36.0), (82.0, 10.0)]); S.sn(82.0, 22.0, 6 if s1 else 7)
    D.text(82.0, 7.6, "Char (co-product)\n" + ("182 kg/h" if s1 else "2,226 kg/h"), fs=5.6)
    D.line([(82.0, 48.0), (82.0, 52.0), (85.0, 52.0)])
    S.hx(85.0, 49.0)
    D.text(87.4, 57.4, "Condenser", fs=5.6)
    vx = 92.5 if s1 else 94.5
    D.line([(91.0, 52.0), (vx, 52.0)])
    S.vessel(vx, 40.0, 4.2, 18.0, "Flash", rot=True)
    gx = vx + 2.1
    D.line([(gx, 58.0), (gx, 70.0)], color=BROWN, head=False)      # pyrolysis gas riser to fuel-gas header
    S.sn(gx, 66.5, 7 if s1 else 8)
    oil_n = 5 if s1 else 6
    # ---------------- hydrogenation / upgrading & H2 supply ----------------
    xc = 138 if s1 else 150
    S.band(xb, xc, ("Hydrogenation" if s1 else "Upgrading") + " & H₂ supply")
    D.line([(gx, 40.0), (gx, 34.0), (xb + 6.0, 34.0)]); S.sn(xb + 2.6, 34.0, oil_n)
    S.outline(xb + 4.5, 26.0 if s1 else 24.0, (28.0 if s1 else 40.0), (36.0 if s1 else 38.0),
              "R-401  " + ("Selective hydrogenation" if s1 else "Upgrading reactor"))
    S.hx(xb + 6.0, 31.0)
    D.text(xb + 9.0, 28.2 if s1 else 27.2, "Heat exch.", fs=5.4)
    rx = xb + 17.0
    D.line([(xb + 12.0, 34.0), (rx, 34.0)])
    S.bed(rx, 28.0, 7.0, 26.0 if not s1 else 26.0, "R-401")
    D.text(rx + 3.5, 56.3, ("Pd/C, 70 °C, 50 bar\nQ 0.25 MW" if s1 else "Pd/SBA-15, 350 °C,\n1.5 bar; Q 6.02 MW"), fs=5.6)
    # H2 package
    px0, pw = (xb + 8.0, 24.0) if s1 else (xb + 8.0, 28.0)
    D.rect(px0, 5.5, pw, 10.0, ec=NAVY, ls="--", r=1.0)
    D.text(px0 + pw / 2, 10.5, "A-300  H\u2082 production\nSMR | SOEC | PC (one per\nconfiguration; see sheet 3)", fs=4.6, color=NAVY)
    D.text(xb + 0.8, 14.8, "CH\u2084 + steam\n| water", ha="left", fs=4.6)
    D.line([(xb + 0.8, 10.5), (px0, 10.5)]); S.sn(xb + 4.4, 10.5, "14-15" if s1 else "12-13")
    D.line([(px0 + pw, 10.5), (xc - 0.6, 10.5)], color=GREY, ls="--"); S.sn((px0 + pw + xc) / 2, 10.5, "16-18" if s1 else "14-16")
    D.text(xc - 0.8, 17.0, "flue CO\u2082 (SMR)\nO\u2082 (SOEC, PC)", ha="right", fs=5.0, color=GREY)
    hx_ = rx + 3.5
    if s1:
        D.line([(hx_, 15.0), (hx_, 19.0)], color=NAVY); S.sn(hx_ - 3.4, 16.4, 8)
        S.compressor(hx_ - 3.5, 19.0, 7.0, 5.0)
        D.text(hx_ - 5.0, 21.5, "C-401\nH₂ compr.\n1→50 bar", ha="right", fs=5.2)
        D.line([(hx_, 24.0), (hx_, 28.0)])
    else:
        D.line([(hx_, 15.0), (hx_, 28.0)]); S.sn(hx_, 21.5, 9)
    if s1:
        # ---------------- distillation & blending ----------------
        xd = 178
        S.band(xc, xd, "Distillation & blending")
        S.outline(xc + 2.0, 7.5, xd - xc - 3.5, 56.5, "T-501 / M-502  EB column & blending")
        D.line([(rx + 7.0, 44.0), (xc + 7.0, 44.0)]); S.sn(xc - 4.0, 44.0, 9)
        cx = xc + 7.0
        S.column(cx, 20.0, 5.6, 38.0, 14)
        D.text(cx + 6.6, 57.9, "EB column\n~131-141 °C cut\nQ 1.55 MW", ha="left", fs=5.6)
        D.line([(cx + 5.6, 52.0), (cx + 13.0, 52.0), (cx + 13.0, 39.0), (cx + 18.5, 39.0)]); S.sn(cx + 9.5, 52.0, 11)
        D.text(cx + 14.0, 48.0, "EB additive\n(distillate)", ha="left", fs=5.2, italic=True)
        mx = cx + 18.5
        S.mixer(mx, 33.0)
        D.text(mx + 3.0, 30.0, "Blending\nvessel", fs=5.4, va="top")
        S.tank(mx - 0.5, 9.5, 7.0, 9.0)
        D.text(mx + 3.0, 13.4, "SPK\ntank", fs=4.6)
        D.line([(mx + 3.0, 18.5), (mx + 3.0, 33.0)]); S.sn(mx + 3.0, 22.3, 10)
        D.text(mx - 6.3, 14.0, "Purchased\nHEFA-SPK", fs=5.0)
        D.line([(mx - 1.9, 14.0), (mx - 0.5, 14.0)])
        D.line([(mx + 6.0, 36.0), (mx + 8.5, 36.0)])
        S.pump(mx + 8.5, 33.25)
        D.text(mx + 11.25, 30.6, "Pump", fs=5.4, va="top")
        D.line([(mx + 14.0, 36.0), (W_U - 16.0, 36.0)], color=GREEN, lw=1.3); S.sn(185.0, 36.0, 12)
        D.text(W_U - 15.5, 36.0, "Fuel blend\n21,134 kg/h\n(82 wt% SPK)", ha="left", fs=6.0)
        # side fractions to the fired heater
        D.line([(cx + 2.8, 20.0), (cx + 2.8, 4.5), (188.0, 4.5), (188.0, 60.0)], color=BROWN); S.sn(cx + 2.8, 12.0, 13)
        D.text(cx + 5.0, 5.9, "side fractions (fuel value)", ha="left", fs=5.2, italic=True, color=BROWN)
        xe = 198
    else:
        xd = xc
        D.line([(rx + 7.0, 44.0), (rx + 13.5, 44.0)])
        S.vessel(rx + 13.5, 36.0, 4.6, 16.0, "Separator", rot=True)
        D.text(rx + 15.8, 33.6, "H₂ separator", fs=5.4)
        D.line([(rx + 15.8, 36.0), (rx + 15.8, 32.0), (W_U - 18.0, 32.0)], color=GREEN, lw=1.3); S.sn(rx + 25.0, 32.0, 10)
        D.text(W_U - 17.5, 32.0, "Blendstock\n26,878 kg/h\n(33 wt% EB +\nn-alkanes)", ha="left", fs=6.0)
        D.line([(rx + 15.8, 52.0), (rx + 15.8, 70.0)], color=BROWN, head=False); S.sn(rx + 15.8, 61.0, 11)
        D.text(rx + 17.6, 56.0, "unreacted H₂", ha="left", fs=5.2, italic=True, color=BROWN)
        xe = 192
    # ---------------- energy recovery ----------------
    S.band(xd, xe, "Energy recovery")
    fx, fw = (xd + 2.5, xe - xd - 5.0) if s1 else (xd + 8.0, 28.0)
    D.rect(fx, 60.0, fw, 12.0)
    D.text(fx + fw / 2, 67.8, "F-601 Fuel-gas\nfired heater" if s1 else "F-601 Fuel-gas fired heater", fs=5.4)
    D.text(fx + fw / 2, 62.2, "heat credit;\nnot a costed unit" if s1 else "burns pyrolysis gas + unreacted H₂\n(heat credit; not a costed unit)",
           fs=4.8, color="#333333")
    D.line([(gx, 70.0), (fx, 70.0)], color=BROWN)
    D.text((gx + fx) / 2, 71.6, "fuel-gas header", fs=5.2, italic=True, color=BROWN)
    D.line([(fx, 66.5), ((fx - 14) if s1 else 136.0, 66.5)], color=ORANGE, ls="--")
    D.text((fx - 14.6) if s1 else 134.5, 66.5, "process heat to R-201, R-401, T-501, dryer" if s1 else "process heat to\nR-201, R-401, dryer",
           ha="right", fs=5.2, color=ORANGE)
    D.line([(fx + fw * 0.75, 72.0), (fx + fw * 0.75, 76.0)])
    D.text(fx + fw * 0.75 + 1.0, 75.0, "Flue gas", ha="left", fs=5.6)
    D.line([(fx + fw * 0.25, 76.0), (fx + fw * 0.25, 72.0)])
    D.text(fx + fw * 0.25 - 1.0, 75.0, "NG top-up", ha="right", fs=5.6)
    # footnote
    D.text(W_U - 1.0, 1.3, "Dashed outlines = equipment costed within one BioSTEAM unit. Stream numbers = model streams "
           "(PFD_stream_tables.xlsx). H₂ streams " + ("14-18" if s1 else "12-16") + " depend on the H₂ route.",
           ha="right", fs=5.0, color=GREY)


def hband(D, y0, y1, title):
    D.rect(4.0, y0, 146.0, y1 - y0, fc=BAND, ec=BANDE, lw=0.8, z=0)
    D.text(5.0, y1 - 2.0, title, ha="left", fs=7.4, bold=True, color="#333333")


def h2_sheet(D, word=False):
    S = Sym(D)
    if not word: D.text(1.0, 85.5, "Process flow diagram - Sheet 3: A-300 hydrogen production, three alternative trains "
           "(one installed per configuration; flows for Scenario 1 | Scenario 2)", ha="left", fs=8.2)
    # ---------------- SMR ----------------
    hband(D, 57.0, 81.0, "Option 1 - Steam methane reforming (SMR)")
    y = 66.0
    D.text(5.0, y + 3.6, "Natural gas", ha="left", fs=6.0)
    D.line([(5.0, y), (14.0, y)]); S.sn(9.5, y, "H1")
    S.mixer(14.0, y - 3.0)
    D.text(17.0, 58.6, "Steam", fs=6.0)
    D.line([(17.0, 59.8), (17.0, y - 3.0)]); S.sn(19.4, 61.2, "H2")
    D.line([(20.0, y), (24.0, y)])
    S.hx(24.0, y - 3.0); D.text(27.0, y + 4.6, "E-301\nfeed preheat", fs=5.2)
    D.line([(30.0, y), (34.0, y)])
    S.reformer(34.0, 59.5, 12.0, 14.0)
    D.text(38.6, 75.3, "R-301 reformer", fs=5.0, bold=True, color=NAVY)
    D.text(40.0, 61.6, "", fs=1)
    D.line([(46.0, y), (50.0, y)])
    S.hx(50.0, y - 3.0); D.text(53.0, y + 5.5, "E-302\ncooler", fs=5.2)
    D.line([(56.0, y), (60.0, y)])
    S.vessel(60.0, 60.0, 5.0, 12.0, "WGS", rot=True)
    D.text(62.5, 74.4, "R-302", fs=5.6, bold=True, color=NAVY)
    D.line([(65.0, y), (69.0, y)])
    S.hx(69.0, y - 3.0); D.text(72.0, y + 5.5, "E-303\ncooler", fs=5.2)
    D.line([(75.0, y), (79.0, y)])
    S.psa(79.0, 60.0)
    D.text(83.0, 74.4, "PSA", fs=5.6, bold=True, color=NAVY)
    D.line([(86.6, y), (150.0, y)], head=False)
    D.text(118.0, y + 6.5, "R-301: CH₄ + H₂O → CO + 3H₂ | R-302: CO + H₂O → CO₂ + H₂\n"
           "model: 78% H₂-yield efficiency, stoichiometric steam (S/C 2)\n"
           "typ. reformer 850 °C, 20-30 bar; HT-WGS 350-400 °C; PSA 99.9% H₂", fs=4.8)
    D.text(118.0, y - 4.4, "process CO₂ 7.0 kg/kg H₂ (model); LCA uses 9.0 kg CO₂e/kg H₂", fs=5.0, color=GREY)
    D.line([(84.6, 60.0), (84.6, 58.2), (40.0, 58.2), (40.0, 59.5)], color=BROWN, ls="--")
    D.text(62.0, 59.3, "PSA tail gas to burners", fs=5.0, italic=True, color=BROWN)
    D.line([(45.0, 73.5), (45.0, 81.6)]); S.sn(47.6, 77.4, "H3")
    D.text(46.0, 82.6, "Flue gas (CO₂)", ha="left", fs=5.6)
    # ---------------- SOEC ----------------
    hband(D, 31.0, 55.0, "Option 2 - Solid oxide electrolysis (SOEC)")
    y = 42.0
    D.text(5.0, y + 3.6, "Deionised water", ha="left", fs=6.0)
    D.line([(5.0, y), (12.0, y)]); S.sn(8.5, y, "H4")
    S.pump(12.0, y - 2.75); D.text(14.75, y - 5.0, "P-311*", fs=5.2)
    D.line([(17.5, y), (21.5, y)])
    S.hx(21.5, y - 3.0); D.text(24.5, y - 5.0, "E-311* steam\ngenerator", fs=5.2, va="top")
    D.line([(27.5, y), (34.0, y)])
    S.stack(34.0, 35.0, 14.0, 11.0)
    D.text(41.0, 41.0, "EL-301\nSOEC stack", fs=5.6, bold=True, color=NAVY)
    D.rect(34.0, 47.0, 14.0, 4.4)
    D.text(41.0, 49.2, "T-301 power\nelectronics", fs=4.6)
    D.line([(41.0, 47.0), (41.0, 46.0)], color=ORANGE, ls="--")
    D.text(5.0, 49.6, "Grid electricity\n(716 g CO₂e/kWh)", ha="left", fs=5.0)
    D.line([(21.0, 49.2), (34.0, 49.2)], color=ORANGE, ls="--"); S.sn(28.0, 49.2, "H5")
    D.line([(48.0, 44.0), (54.0, 44.0)])
    D.text(51.4, 45.4, "H₂+steam", fs=4.2, italic=True)
    S.hx(54.0, 41.0); D.text(57.0, 47.4, "E-313*\ncondenser", fs=5.2, va="bottom")
    D.line([(60.0, 44.0), (64.0, 44.0)])
    S.vessel(64.0, 38.0, 4.0, 12.0, "KO", rot=True); D.text(66.0, 51.2, "V-311*", fs=5.2)
    D.line([(66.0, 38.0), (66.0, 33.6)], color=GREY, ls="--"); D.text(67.0, 33.8, "condensate*", ha="left", fs=5.0, color=GREY)
    D.line([(68.0, 44.0), (74.0, 44.0)])
    S.compressor_h(74.0, 41.25, 7.0, 5.5); D.text(77.5, 48.6, "C-311", fs=5.6, bold=True, color=NAVY)
    D.line([(81.0, 44.0), (150.0, 44.0)], head=False)
    D.line([(48.0, 37.0), (90.0, 37.0)]); S.sn(78.0, 37.0, "H6")
    D.text(90.6, 37.0, "O₂ by-product (vent)", ha="left", fs=5.6)
    D.text(116.0, 50.0, "H₂O → H₂ + ½ O₂ at 85% HHV efficiency = 46.4 kWh/kg H₂\n"
           "power: S1 5.46 MW | S2 18.31 MW\ntyp. stack 750-850 °C", fs=5.2)
    # ---------------- photocatalysis ----------------
    hband(D, 5.0, 29.0, "Option 3 - Solar photocatalytic water splitting (PC)")
    y = 14.0
    D.text(5.0, y + 3.6, "Water", ha="left", fs=6.0)
    D.line([(5.0, y), (12.0, y)]); S.sn(8.5, y, "H7")
    D.rect(12.0, 10.0, 9.0, 8.0); D.text(16.5, 14.0, "WT-321\nwater\ntreatment", fs=5.0)
    D.line([(21.0, y), (26.0, y)])
    D.rect(26.0, 5.6, 34.0, 20.4, fc="none", ec=GREY, ls="--", r=1.0)
    S.sun(29.5, 22.8)
    D.text(46.0, 22.6, "PC-321 photocatalytic\npanel field", fs=5.6, bold=True, color=NAVY)
    S.panels(28.0, 11.0)
    D.text(43.0, 8.4, "STH 5%; sized at 1,000 W/m²\nS1 9.3 ha | S2 31.1 ha", fs=5.0)
    D.line([(60.0, y), (66.0, y)]); S.sn(63.0, y, "H8")
    S.screen(66.0, 10.5, 9.0, 7.0); D.text(70.5, 19.4, "S-321 H₂/O₂\nseparation", fs=5.2, va="bottom")
    D.line([(75.0, y), (150.0, y)], head=False)
    D.line([(70.5, 10.5), (70.5, 7.2), (90.0, 7.2)]); S.sn(80.0, 7.2, "H9")
    D.text(90.6, 7.2, "O₂ by-product (vent)", ha="left", fs=5.6)
    D.text(116.0, 22.0, "auxiliary power 5 kWh/kg H₂: S1 0.59 | S2 1.97 MW\n"
           "annual-mean irradiance (~250 W/m²) would need ~4× the area", fs=5.2)
    # ---------------- common H2 header ----------------
    D.line([(150.0, 14.0), (150.0, 83.0)], color=NAVY, lw=1.3); S.sn(150.0, 74.0, "H10")
    D.text(148.8 if word else 151.2, 84.0, "H₂ to R-401", ha="right" if word else "left", fs=6.2, bold=True)
    # ---------------- stream table ----------------
    if word:
        rows = [("H1", "Natural gas (CH₄)", "300", "1,006", "14 | 12"), ("H2", "Steam (S/C 2)", "674", "2,260", "15 | 13"),
                ("H3", "Flue gas (CO₂)", "823", "2,760", "16 | 14"), ("H4", "Deionised water", "1,051", "3,525", "15 | 13"),
                ("H5", "Electricity (MW)", "5.46", "18.31", "–"), ("H6", "O₂ (SOEC)", "933", "3,131", "17 | 15"),
                ("H7", "Water (PC)", "1,051", "3,525", "15 | 13"), ("H8", "H₂/O₂ mixture", "1,051", "3,525", "–"),
                ("H9", "O₂ (PC)", "933", "3,131", "18 | 16"), ("H10", "H₂ product", "118", "394", "8 | 9")]
        yt = 0.5
        for bx, block in ((4.0, rows[:5]), (51.0, rows[5:])):
            cols = [bx, bx + 5.5, bx + 22.0, bx + 29.5, bx + 37.0]
            for x, h in zip(cols, ["No.", "Stream", "S1 kg/h", "S2 kg/h", "Main no."]):
                D.text(x, yt, h, ha="left", fs=5.2, bold=True)
            D.line([(bx, yt - 1.6), (bx + 44.0, yt - 1.6)], lw=0.6, head=False)
            for i, r in enumerate(block):
                for x, v in zip(cols, r):
                    D.text(x, yt - 3.6 - i * 2.75, v, ha="left", fs=5.2)
            D.line([(bx, yt - 3.6 - 4 * 2.75 - 1.8), (bx + 44.0, yt - 3.6 - 4 * 2.75 - 1.8)], lw=0.6, head=False)
        D.text(99.0, yt + 0.9, "Main no. = stream number on sheet 1 (S1) | sheet 2 (S2).\n"
               "Costed in the model (CEPCI 2023): SMR reactor & PSA,\n"
               "heat exchangers, WGS; SOEC stack, power electronics,\n"
               "compression; PC panels ($250/m²), water treatment,\n"
               "H₂ separation. * not separately costed (implied equipment).\n"
               "typ. = typical design value, not a model parameter;\n"
               "H₂-unit process conditions are not modelled in detail.", va="top", ha="left", fs=4.8, color="#333333")
        return
    x0, yt = 154.0, 79.0
    cols = [x0, x0 + 5.5, x0 + 29.0, x0 + 37.5, x0 + 46.0]
    for x, h in zip(cols, ["No.", "Stream", "S1 kg/h", "S2 kg/h", "Main no."]):
        D.text(x, yt, h, ha="left", fs=5.4, bold=True)
    D.line([(x0, yt - 1.4), (213.0, yt - 1.4)], lw=0.6, head=False)
    rows = [("H1", "Natural gas (CH₄)", "300", "1,006", "14 | 12"),
            ("H2", "Steam (S/C 2)", "674", "2,260", "15 | 13"),
            ("H3", "Flue gas (CO₂)", "823", "2,760", "16 | 14"),
            ("H4", "Deionised water", "1,051", "3,525", "15 | 13"),
            ("H5", "Electricity (MW)", "5.46", "18.31", "–"),
            ("H6", "O₂ (SOEC)", "933", "3,131", "17 | 15"),
            ("H7", "Water (PC)", "1,051", "3,525", "15 | 13"),
            ("H8", "H₂/O₂ mixture", "1,051", "3,525", "–"),
            ("H9", "O₂ (PC)", "933", "3,131", "18 | 16"),
            ("H10", "H₂ product", "118", "394", "8 | 9")]
    for i, r in enumerate(rows):
        yy = yt - 3.4 - i * 2.6
        for x, v in zip(cols, r):
            D.text(x, yy, v, ha="left", fs=5.2)
    yb = yt - 3.4 - 9 * 2.6 - 1.6
    D.line([(x0, yb), (213.0, yb)], lw=0.6, head=False)
    D.text(x0, yb - 1.2, "Main no. = stream number on sheet 1 (S1) | sheet 2 (S2).\n"
           "Costed in the model (CEPCI 2023):\n"
           " SMR: reactor & PSA, heat exchangers, WGS\n"
           " SOEC: stack, power electronics, compression\n"
           " PC: panels ($250/m²), water treatment,\n   H₂ separation\n"
           "* not separately costed (implied equipment).\n"
           "typ. = typical design value, not a model\nparameter. Process conditions of the H₂\n"
           "units are not modelled in detail.", va="top", ha="left", fs=5.0, color="#333333")


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "."
    pages = []
    for sc, name in ((1, "PFD_Scenario1_PS_only_style"), (2, "PFD_Scenario2_cohydropyrolysis_style")):
        m = Mpl(); sheet(m, sc); m.save(os.path.join(out, name))
        d = Drawio(); sheet(d, sc)
        pages.append(d.page("Scenario 1 - PS-only" if sc == 1 else "Scenario 2 - co-hydropyrolysis", f"pfds{sc}"))
        print("saved", name)
    m = Mpl(); h2_sheet(m); m.save(os.path.join(out, "PFD_Sheet3_H2_production_style"))
    d = Drawio(); h2_sheet(d); pages.append(d.page("Sheet 3 - A-300 hydrogen production", "pfds3"))
    print("saved PFD_Sheet3_H2_production_style")
    with open(os.path.join(out, "PFD_simulation_model_style.drawio"), "w", encoding="utf-8") as f:
        f.write('<mxfile host="app.diagrams.net">' + "".join(pages) + "</mxfile>")
    print("saved PFD_simulation_model_style.drawio")
    # Word version of sheet 3: diagram only (stream table moved to a Word table), cropped to x <= 154
    m = Mpl(); h2_sheet(m, word=True)
    m.ax.set_xlim(0, 154.5); m.ax.set_ylim(-17.5, 86.0)
    m.fig.set_size_inches(13.4 * 154.5 / W_U, 5.5 * 103.5 / H_U)
    m.fig.savefig(os.path.join(out, "PFD_Sheet3_H2_word.png"), dpi=300); m.fig.savefig(os.path.join(out, "PFD_Sheet3_H2_word.pdf"))
    m.fig.savefig(os.path.join(out, "PFD_Sheet3_H2_word.svg")); m.plt.close(m.fig)
    print("saved PFD_Sheet3_H2_word")
