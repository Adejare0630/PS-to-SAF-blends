"""
run_R1_analysis.py - reviewer-driven reruns (R1.2, R1.4, R1.5, R1.14, R2.4)

  1. Equal-feed vs equal-product basis TEA (R1.4)
  2. Price sweeps + breakeven prices vs fossil-jet parity (R1.5)
  3. Monte Carlo with an explicit distribution table (R2.4) - reads R1_mc_distributions.csv
  4. Scenario relabelling for display (R1.14): new Sc1 = PS-only (reference), new Sc2 = co-hydropyrolysis

Run from the Module_R1 folder:      python run_R1_analysis.py
Env options:  SC2_BLEND_VOL_PCT=16 (12-25)  R1_MC_N=1000   R1_MC_CONV_N=5000   R1_MC_CONV_CONFIGS=SMR   SCENARIO_RELABEL=0
Outputs go to R1_outputs/<SC1_CASE>/ (CSV + PNG).  SC1_CASE=Li25 (default) or Extrap34 - see run_R1_cases.py.  CSV scenario names use the NEW labels; 'model_label' is the old ID.
NOTE: needs the same environment as main.py (BioSTEAM etc.).
"""
import os, sys
ROOT = os.path.dirname(os.path.abspath(__file__))
SCRIPTS = os.path.join(ROOT, "tea_20260605_1634", "scripts")
sys.path.insert(0, ROOT); sys.path.insert(0, SCRIPTS)

import numpy as np
import pandas as pd
import matplotlib
if "get_ipython" not in globals():
    matplotlib.use("Agg")
import scenario_relabel as rl            # display swap Sc1<->Sc2 in all figures
import matplotlib.pyplot as plt
from scipy import stats, optimize
from scipy.stats import qmc

CASE = os.environ.get("SC1_CASE", "Li25")           # Li25 = Li as measured (oil:PS 2.5); Extrap34 = extrapolation (3.4)
SC2C = "Prajapati"     # PS-only route = Prajapati et al. measured basis (the submitted 50:50 blend was removed); blend aromatics = sensitivity
OUT = os.path.join(ROOT, "R1_outputs", CASE)
os.makedirs(OUT, exist_ok=True)
LABEL_TAG = "" if CASE == "Li25" else "  [EXTRAPOLATED CASE: oil:PS = 3.4, beyond Li's measured 2.5]"


def to_csv_case(df, name):
    """Write a CSV with a leading 'case' column (Li25 = measured basis; Extrap34 = extrapolated sensitivity)."""
    df = df.copy()
    if "case" not in df.columns:
        df.insert(0, "case", CASE)
    df.to_csv(os.path.join(OUT, name), index=False)

CONFIGS = [(1, "SMR"), (1, "Photocatalysis"), (1, "SOEC"),
           (2, "SMR"), (2, "Photocatalysis"), (2, "SOEC")]
# plot order: reference route first (physical scenario 2 = new Sc1)
PLOT_ORDER = [(2, "SMR"), (2, "Photocatalysis"), (2, "SOEC"),
              (1, "SMR"), (1, "Photocatalysis"), (1, "SOEC")]
H2_SHORT = {"SMR": "SMR", "Photocatalysis": "Photo", "SOEC": "SOEC"}


def old_label(sc, h2):   # model ID
    return f"Sc{sc}_{h2}"


def new_label(sc, h2):   # label used in CSV outputs
    return rl.disp(old_label(sc, h2))


def plot_label(sc, h2):  # OLD-style text; the matplotlib patch swaps it on display
    return f"Sc{sc}+{H2_SHORT[h2]}"


def lhv(tm, sc):
    return tm.SAF_LHV_MJ_KG if sc == 1 else tm.BLEND_LHV_MJ_KG


# ----------------------------------------------------------------------------------------------
def simulate_all(tm, simulate, scale2=1.0):
    tm.SC2_FEED_SCALE = scale2
    cfgs, teas = {}, {}
    for sc, h2 in CONFIGS:
        cfg = simulate(sc, h2)
        cfgs[(sc, h2)] = cfg
        teas[(sc, h2)] = tm.run_tea(cfg)
    tm.SC2_FEED_SCALE = 1.0
    return cfgs, teas


def equal_basis(tm, simulate, parity):
    cfg_a, tea_a = simulate_all(tm, simulate, 1.0)
    ratio = cfg_a[(1, "SMR")]["saf_kg_hr"] / cfg_a[(2, "SMR")]["saf_kg_hr"]
    cfg_b, tea_b = simulate_all(tm, simulate, ratio)
    rows = []
    for basis, cfgs, teas in (("equal PS feed (as submitted)", cfg_a, tea_a),
                              ("equal product output", cfg_b, tea_b)):
        for sc, h2 in PLOT_ORDER:
            c, t = cfgs[(sc, h2)], teas[(sc, h2)]
            m = t["mfsp_per_kg"]
            rows.append(dict(scenario=new_label(sc, h2), model_label=old_label(sc, h2), basis=basis,
                             raw_PS_kg_hr=c["streams"]["ps_kg_hr"], product_kg_hr=c["saf_kg_hr"],
                             TPEC_MM=c["tpec"] / 1e6, FCI_MM=t["FCI"] / 1e6,
                             MFSP_usd_per_kg=m, MFSP_usd_per_GJ=m / lhv(tm, sc) * 1000,
                             MFSP_usd_per_GGE=t["mfsp_gge"], LHV_MJ_per_kg=lhv(tm, sc),
                             vs_parity_pct=(m / parity - 1) * 100))
    df = pd.DataFrame(rows)
    to_csv_case(df, "R1_equal_basis.csv")
    return df, cfg_a, tea_a, ratio


# ----------------------------------------------------------------------------------------------
def price_sweeps(tm, cfgs, teas, parity):
    nominal = dict(oil=tm.OIL_PRICE_KG, ps=tm.PS_PRICE_KG, spk=tm.SPK_PRICE_KG)
    grids = dict(oil=np.round(np.arange(0, 1.01, 0.1), 2), ps=np.round(np.arange(0, 0.81, 0.1), 2),
                 spk=np.round(np.arange(1.5, 3.01, 0.25), 2))
    key = dict(oil="oil_price_mult", ps="ps_price_mult", spk="spk_price_mult")
    applies = dict(oil=[1], ps=[1, 2], spk=[2])
    rows, be_rows = [], []
    for what in ("oil", "ps", "spk"):
        for sc, h2 in CONFIGS:
            if sc not in applies[what]:
                continue
            f = lambda p: tm.sensitivity_mfsp(sc, h2, cfgs[(sc, h2)], teas[(sc, h2)],
                                              **{key[what]: p / nominal[what]})
            for p in grids[what]:
                rows.append(dict(scenario=new_label(sc, h2), model_label=old_label(sc, h2), price_varied=what,
                                 price_usd_per_kg=p, MFSP_usd_per_kg=f(p)))
            try:
                be = optimize.brentq(lambda p: f(p) - parity, 0.0, 6.0)
            except ValueError:
                be = np.nan
            be_rows.append(dict(scenario=new_label(sc, h2), price_varied=what, nominal_price=nominal[what],
                                breakeven_price_to_parity=be))
    to_csv_case(pd.DataFrame(rows), "R1_price_sweeps.csv")
    to_csv_case(pd.DataFrame(be_rows), "R1_breakeven_prices.csv")
    return pd.DataFrame(rows), pd.DataFrame(be_rows)


# ----------------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------------
EB_MARKET_USD_PER_KG = dict(low=1.10, base=1.25, high=1.70)   # 2026 ethylbenzene quotes ~1,100-1,700 USD/t (IMARC, Expert Market Research, ChemAnalyst; indicative, regional)


def cp_blend_pct():
    import compounds as cp
    return cp.SC2_BLEND_VOL_PCT


def eb_additive_cost(tm, cfgs, teas):
    """PRIMARY Sc2-route metric (PS-only route, Prajapati16): implied cost of the EB additive.
    additive cost = (MFSP_blend x blend_kg - SPK_price x spk_kg) / additive_kg  (the blend MFSP already carries the 10% IRR).
    Compared with market ethylbenzene.  Blended-fuel MFSP/GWP are reported separately (R1_equal_basis.csv, LCA outputs)."""
    rows = []
    for h2 in ("SMR", "Photocatalysis", "SOEC"):
        c, t = cfgs[(2, h2)], teas[(2, h2)]
        add = c.get("additive_kg_hr", 0.0)
        if add <= 0:
            continue
        m = t["mfsp_per_kg"]
        cost = (m * c["saf_kg_hr"] - tm.SPK_PRICE_KG * c["spk_kg_hr"]) / add
        rows.append(dict(scenario=new_label(2, h2), model_label=old_label(2, h2), sc2_case=SC2C,
                         additive_kg_hr=add, other_ends_kg_hr=c.get("ends_kg_hr", 0.0), spk_kg_hr=c["spk_kg_hr"],
                         blend_kg_hr=c["saf_kg_hr"], blend_MFSP_usd_per_kg=m,
                         EB_additive_cost_usd_per_kg=cost,
                         EB_market_low=EB_MARKET_USD_PER_KG["low"], EB_market_base=EB_MARKET_USD_PER_KG["base"],
                         EB_market_high=EB_MARKET_USD_PER_KG["high"],
                         additive_vs_market_base_pct=(cost / EB_MARKET_USD_PER_KG["base"] - 1) * 100,
                         HEFA_SPK_price_usd_per_kg=tm.SPK_PRICE_KG))
    df = pd.DataFrame(rows)
    to_csv_case(df, "R1_EB_additive_cost.csv")
    return df


def blend_properties():
    """Ideal-mixing property table for additive/HEFA-SPK blends (no BioSTEAM needed). Writes R1_blend_properties.csv.
    ONLY density, LHV and aromatics are estimated. Distillation curve, freeze point, flash point, viscosity, thermal stability,
    lubricity and seal compatibility are UNTESTED (Prajapati reports 12 and 16 vol% only) - see column 'untested'.
    Jet A density window 775-840 kg/m3 at 15 C and ~25 vol% aromatics cap: verify against current ASTM D1655 / D7566."""
    import compounds as cp
    rows = []
    for vol in (8.0, 12.0, 15.0, 16.0, 17.5, 20.0, 22.5, 25.0):
        w, lhv_b = cp.sc2_blend_params(vol)
        rho = vol / 100 * cp.SC2_EB_RHO + (1 - vol / 100) * cp.SC2_SPK_RHO
        rows.append(dict(additive_vol_pct=vol, aromatics_vol_pct=vol, additive_mass_pct=w * 100, density_kg_m3_15C_ideal=rho,
                         density_in_775_840=(775 <= rho <= 840), aromatics_le_25_vol=(vol <= 25.0),
                         blend_LHV_MJ_kg=lhv_b, blend_LHV_MJ_L=lhv_b * rho / 1000,
                         status="tested by Prajapati" if vol in (12.0, 16.0) else "extrapolated",
                         untested="distillation curve; freeze point; flash point; viscosity; thermal stability; lubricity; seal swell; ASTM D4054 qualification",
                         assumptions=f"additive density {cp.SC2_EB_RHO} kg/m3 (EB-rich); HEFA-SPK density {cp.SC2_SPK_RHO} kg/m3 and LHV {cp.SC2_SPK_LHV} MJ/kg; ideal volume mixing"))
    df = pd.DataFrame(rows); to_csv_case(df, "R1_blend_properties.csv")
    return df


def blend_sweep(tm, simulate, parity):
    """Sensitivity: aromatic (EB-additive) content of the blend with HEFA-SPK, 15-25 vol% (PS-only route, physical Sc2).
    Prajapati et al. tested 12 and 16 vol%; 17.5-25 vol% are extrapolations (25 = finished-jet aromatics cap, verify ASTM D1655/D7566).
    The additive made per hour is fixed by the process; a higher blend share means LESS purchased SPK and LESS fuel, so
    cost per kg of blend shifts toward the additive cost.  Writes R1_blend_sweep.csv and R1_fig_blend_sweep.png."""
    import compounds as cp
    keep = (cp.SC2_ADDITIVE_MASS_FRAC, tm.BLEND_LHV_MJ_KG)
    factors = None
    try:
        import make_lca as ml
        factors = ml.load_all_impacts()
    except Exception as e:   # LCA files unavailable -> TEA only
        print("   (blend sweep: LCA skipped:", e, ")")
    rows = []
    try:
        for vol in (12.0, 15.0, 17.5, 20.0, 22.5, 25.0):
            w, lhv_b = cp.sc2_blend_params(vol)
            cp.SC2_ADDITIVE_MASS_FRAC = w; tm.BLEND_LHV_MJ_KG = lhv_b
            for h2 in ("SMR", "Photocatalysis", "SOEC"):
                cfg = simulate(2, h2); t = tm.run_tea(cfg); m = t["mfsp_per_kg"]
                add = cfg["additive_kg_hr"]
                cost = (m * cfg["saf_kg_hr"] - tm.SPK_PRICE_KG * cfg["spk_kg_hr"]) / add
                gwp = float("nan")
                if factors is not None:
                    inv = ml.compute_inventory(cfg); inv["lhv"] = lhv_b
                    res, _ = ml.compute_impacts_per_kg(inv, factors)
                    gwp = res["Global warming"] / lhv_b * 1000.0
                rows.append(dict(scenario=new_label(2, h2), model_label=old_label(2, h2), blend_aromatics_vol_pct=vol,
                                 status="tested by Prajapati" if vol in (12.0, 16.0) else "extrapolated blend share",
                                 additive_mass_frac=w, additive_kg_hr=add, spk_kg_hr=cfg["spk_kg_hr"], blend_kg_hr=cfg["saf_kg_hr"],
                                 blend_LHV_MJ_kg=lhv_b, blend_MFSP_usd_per_kg=m, vs_parity_pct=(m / parity - 1) * 100,
                                 EB_additive_cost_usd_per_kg=cost, EB_market_base=EB_MARKET_USD_PER_KG["base"],
                                 blend_GWP_g_per_MJ=gwp))
    finally:
        cp.SC2_ADDITIVE_MASS_FRAC, tm.BLEND_LHV_MJ_KG = keep
    df = pd.DataFrame(rows); to_csv_case(df, "R1_blend_sweep.csv")
    fig, ax = plt.subplots(1, 3, figsize=(15, 4.2))
    for h2 in ("SMR", "Photocatalysis", "SOEC"):
        d = df[df.model_label == old_label(2, h2)]
        ax[0].plot(d.blend_aromatics_vol_pct, d.blend_MFSP_usd_per_kg, "o-", label=plot_label(2, h2))
        ax[1].plot(d.blend_aromatics_vol_pct, d.EB_additive_cost_usd_per_kg, "o-", label=plot_label(2, h2))
        ax[2].plot(d.blend_aromatics_vol_pct, d.blend_GWP_g_per_MJ, "o-", label=plot_label(2, h2))
    ax[0].axhline(parity, color="r", ls="--", lw=1, label="fossil-jet parity"); ax[0].set_ylabel("Blend MFSP (USD/kg)")
    ax[1].axhspan(EB_MARKET_USD_PER_KG["low"], EB_MARKET_USD_PER_KG["high"], color="0.85", label="market EB range")
    ax[1].set_ylabel("Implied EB-additive cost (USD/kg)")
    ax[2].axhline(88.9, color="r", ls="--", lw=1, label="Jet-A 88.9"); ax[2].set_ylabel("GWP (g CO2-eq/MJ)")
    for a_ in ax:
        a_.set_xlabel("Aromatic additive in blend (vol%)"); a_.axvline(12, color="k", ls=":", lw=1); a_.axvline(16, color="k", ls=":", lw=1); a_.axvspan(16, 25, color="0.93", zorder=0); a_.legend(fontsize=8)
    fig.suptitle("Blend-share sensitivity (15-25 vol%); dotted = Prajapati's tested 12 and 16 vol%, shaded = extrapolated")
    fig.tight_layout(); fig.savefig(os.path.join(OUT, "R1_fig_blend_sweep.png"), dpi=200); plt.close(fig)
    return df


def _apply_sc1_ratio(tm, r):
    """Set ratio r, with composition/yields rescaled from Li's per-feed yields (compounds.sc1_composition_for_ratio).
    Updates tea_model AND pyrolyzer (which holds its own copies of the fraction constants)."""
    import compounds as cp, pyrolyzer as pz
    d = cp.sc1_composition_for_ratio(r)
    tm.OIL_TO_PS_RATIO = r
    tm.SCENARIO1_PYRO_YIELDS.clear(); tm.SCENARIO1_PYRO_YIELDS.update(d["yields"])
    tm.SCENARIO1_LIQUID_FRACTION = d["liq"]
    pz.SCENARIO1_LIQUID_FRACTION, pz.SCENARIO1_CHAR_FRACTION, pz.SCENARIO1_GAS_FRACTION = d["liq"], d["char"], d["gas"]
    return d


def ratio_sweep(tm, simulate, parity):
    """R2.1 / sensitivity: MFSP and product aromatics vs waste-oil : PS ratio, co-hydropyrolysis route (physical Sc1).
    Li et al. 2025 measured ONLY r = 2.5; every other ratio rescales Li's per-feed yields linearly (assumption).
    Writes R1_ratio_sweep.csv and R1_fig_ratio_sweep.png."""
    import compounds as cp, pyrolyzer as pz
    keep = dict(r=tm.OIL_TO_PS_RATIO, y=dict(tm.SCENARIO1_PYRO_YIELDS), liq=tm.SCENARIO1_LIQUID_FRACTION,
                pz=(pz.SCENARIO1_LIQUID_FRACTION, pz.SCENARIO1_CHAR_FRACTION, pz.SCENARIO1_GAS_FRACTION))
    rows = []
    try:
        for ratio in (2.5, 2.75, 3.0, 3.25, 3.4, 3.5, 3.75):
            d = _apply_sc1_ratio(tm, ratio)
            for h2 in ("SMR", "Photocatalysis", "SOEC"):
                cfg = simulate(1, h2); t = tm.run_tea(cfg)
                rows.append(dict(scenario=new_label(1, h2), model_label=old_label(1, h2), oil_to_PS_ratio=ratio,
                                 status="measured (Li 2025)" if ratio == 2.5 else "extrapolated",
                                 PS_mass_fraction=1 / (1 + ratio), oil_kg_hr=cfg["streams"]["oil_kg_hr"],
                                 oil_t_per_day=cfg["streams"]["oil_kg_hr"] * 24 / 1000, product_kg_hr=cfg["saf_kg_hr"],
                                 aromatics_wt_pct=d["aromatics_wt"] * 100, aromatics_vol_pct=d["aromatics_vol"] * 100,
                                 MFSP_usd_per_kg=t["mfsp_per_kg"], vs_parity_pct=(t["mfsp_per_kg"] / parity - 1) * 100))
    finally:   # restore the active case
        tm.OIL_TO_PS_RATIO = keep["r"]
        tm.SCENARIO1_PYRO_YIELDS.clear(); tm.SCENARIO1_PYRO_YIELDS.update(keep["y"])
        tm.SCENARIO1_LIQUID_FRACTION = keep["liq"]
        pz.SCENARIO1_LIQUID_FRACTION, pz.SCENARIO1_CHAR_FRACTION, pz.SCENARIO1_GAS_FRACTION = keep["pz"]
    df = pd.DataFrame(rows); to_csv_case(df, "R1_ratio_sweep.csv")
    ratio_figure(df, parity)
    return df


def ratio_figure(df, parity):
    fig, ax = plt.subplots(figsize=(8, 5.0))
    ax2 = ax.twinx()
    ax2.axhspan(23, 25, color="#9ecae1", alpha=0.35, lw=0, label="aromatics target 23-25 vol%")
    ax.axvspan(2.5, df.oil_to_PS_ratio.max() + 0.05, color="#f0f0f0", alpha=0.7, lw=0, zorder=0)
    for h2, col in (("SMR", "#1f4e79"), ("SOEC", "#2a9d8f"), ("Photocatalysis", "#d95f02")):
        g = df[df.model_label == old_label(1, h2)].sort_values("oil_to_PS_ratio")
        ax.plot(g.oil_to_PS_ratio, g.MFSP_usd_per_kg, marker="o", ms=4, color=col, label=plot_label(1, h2))
    g = df[df.model_label == old_label(1, "SMR")].sort_values("oil_to_PS_ratio")
    ax2.plot(g.oil_to_PS_ratio, g.aromatics_vol_pct, "k--", marker="s", ms=3, label="product aromatics (vol%)")
    ax.axhline(parity, color="#b71c1c", ls="--", lw=1.1, label=f"fossil-jet parity ${parity:.2f}/kg")
    ax.axvline(2.5, color="k", ls=":", lw=1)
    ax.set_xlabel("waste oil : PS mass ratio   (2.5 = measured by Li et al.; grey region > 2.5 = extrapolated, no data)", fontsize=8)
    ax.set_ylabel("MFSP ($/kg fuel)"); ax2.set_ylabel("product aromatics (vol%)")
    h1, l1 = ax.get_legend_handles_labels(); h2_, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2_, l1 + l2, fontsize=7, loc="upper center", bbox_to_anchor=(0.5, -0.17), ncol=3, frameon=False)
    ax.set_title("Co-hydropyrolysis route: MFSP and product aromatics vs oil:PS ratio")  # sweep is always labelled (grey = extrapolated)
    fig.tight_layout(); fig.savefig(os.path.join(OUT, "R1_fig_ratio_sweep.png"), dpi=200); plt.close(fig)


def load_distributions(tm):
    d = pd.read_csv(os.path.join(ROOT, "R1_mc_distributions.csv"))
    # co-hydropyrolysis liquid-yield range is absolute (0.65-0.90 wt%), so re-base the multipliers on the active case
    m = (d.key == "liq_yield_mult") & (d.applies_to == "sc1")
    d.loc[m, "low"] = 0.65 / tm.SCENARIO1_LIQUID_FRACTION
    d.loc[m, "high"] = 0.90 / tm.SCENARIO1_LIQUID_FRACTION
    # PS-only liquid-yield range is absolute too (0.76-0.987 wt%; literature + Prajapati), re-based on the active SC2 case
    m2 = (d.key == "liq_yield_mult") & (d.applies_to == "sc2")
    d.loc[m2, "low"] = 0.76 / tm.SCENARIO2_LIQUID_FRACTION
    d.loc[m2, "high"] = 0.987 / tm.SCENARIO2_LIQUID_FRACTION
    d["mean"] = (d.low + d["mode"] + d.high) / 3
    d["sd"] = np.sqrt((d.low**2 + d["mode"]**2 + d.high**2 - d.low * d["mode"] - d.low * d.high
                       - d["mode"] * d.high) / 18)
    to_csv_case(d, "R1_mc_distributions_used.csv")
    return d


def mc_one(tm, sc, h2, cfg, tea, dist, n, seed=42):
    d = dist[dist.applies_to.isin(["all", f"sc{sc}"])].reset_index(drop=True)
    u = qmc.LatinHypercube(d=len(d), seed=seed).random(n)          # Latin hypercube
    mult = np.empty_like(u)
    for j, r in d.iterrows():
        c = (r["mode"] - r.low) / (r.high - r.low)
        mult[:, j] = stats.triang(c, loc=r.low, scale=r.high - r.low).ppf(u[:, j])
    mf = np.array([tm.sensitivity_mfsp(sc, h2, cfg, tea, **{k: mult[i, j] for j, k in enumerate(d.key)})
                   for i in range(n)])
    samples = pd.DataFrame(mult, columns=d.key)
    samples["mfsp"] = mf
    rho = [dict(parameter=p, spearman_rho=stats.spearmanr(samples[k], mf)[0])
           for p, k in zip(d.parameter, d.key)]
    return samples, pd.DataFrame(rho)


def monte_carlo(tm, cfgs, teas, parity):
    dist = load_distributions(tm)
    n = int(os.environ.get("R1_MC_N", 1000))
    n_conv = int(os.environ.get("R1_MC_CONV_N", 5000))
    conv_cfgs = os.environ.get("R1_MC_CONV_CONFIGS", "SMR").split(",")
    summ, spear, conv, samples_all = [], [], [], {}
    for sc, h2 in PLOT_ORDER:
        print(f"  MC {old_label(sc, h2)}  N={n}")
        s, rho = mc_one(tm, sc, h2, cfgs[(sc, h2)], teas[(sc, h2)], dist, n)
        samples_all[(sc, h2)] = s
        to_csv_case(s, f"R1_mc_samples_{new_label(sc, h2)}.csv")
        q = s.mfsp
        base = teas[(sc, h2)]["mfsp_per_kg"]
        summ.append(dict(scenario=new_label(sc, h2), model_label=old_label(sc, h2), N=n, base=base,
                         mean=q.mean(), std=q.std(ddof=1), P5=q.quantile(.05), P25=q.quantile(.25),
                         P50=q.quantile(.5), P75=q.quantile(.75), P95=q.quantile(.95),
                         prob_below_parity=(q <= parity).mean()))
        rho.insert(0, "scenario", new_label(sc, h2))
        spear.append(rho)
        if h2 in conv_cfgs:
            print(f"  convergence run N={n_conv}")
            s2, _ = mc_one(tm, sc, h2, cfgs[(sc, h2)], teas[(sc, h2)], dist, n_conv, seed=7)
            for nn, ss in ((n, q), (n_conv, s2.mfsp)):
                conv.append(dict(scenario=new_label(sc, h2), N=nn, mean=ss.mean(), P5=ss.quantile(.05),
                                 P50=ss.quantile(.5), P95=ss.quantile(.95)))
    S = pd.DataFrame(summ); to_csv_case(S, "R1_mc_summary.csv")
    to_csv_case(pd.concat(spear), "R1_mc_spearman.csv")
    to_csv_case(pd.DataFrame(conv), "R1_mc_convergence.csv")
    return S, samples_all


# ----------------------------------------------------------------------------------------------
def figures(eq, sweeps, samples_all, parity):
    # F1 equal-basis bars
    fig, ax = plt.subplots(figsize=(9, 4.5))
    x = np.arange(len(PLOT_ORDER)); w = 0.38
    for k, (basis, col) in enumerate((("equal PS feed (as submitted)", "#7f9db9"), ("equal product output", "#1f4e79"))):
        v = [eq[(eq.model_label == old_label(*c)) & (eq.basis == basis)].MFSP_usd_per_kg.iloc[0] for c in PLOT_ORDER]
        ax.bar(x + (k - .5) * w, v, w, label=basis, color=col)
    ax.axhline(parity, color="#b71c1c", ls="--", lw=1.2, label=f"Fossil-jet parity ${parity:.2f}/kg")
    ax.set_xticks(x); ax.set_xticklabels([plot_label(*c) for c in PLOT_ORDER], fontsize=9)
    ax.set_ylabel("MFSP ($/kg fuel)"); ax.legend(fontsize=8); ax.set_title("MFSP on equal-feed and equal-product bases" + LABEL_TAG, fontsize=8 if LABEL_TAG else 12)
    fig.tight_layout(); fig.savefig(os.path.join(OUT, "R1_fig_mfsp_equal_basis.png"), dpi=200); plt.close(fig)

    # F2 MC box plot
    fig, ax = plt.subplots(figsize=(9, 4.5))
    ax.boxplot([samples_all[c].mfsp for c in PLOT_ORDER], whis=(5, 95), showfliers=False)
    ax.axhline(parity, color="#b71c1c", ls="--", lw=1.2, label=f"Fossil-jet parity ${parity:.2f}/kg")
    ax.set_xticklabels([plot_label(*c) for c in PLOT_ORDER], fontsize=9)
    ax.set_ylabel("MFSP ($/kg fuel)"); ax.legend(fontsize=8)
    ax.set_title("Monte Carlo MFSP (box = P25-P75, whiskers = P5-P95)" + LABEL_TAG, fontsize=8 if LABEL_TAG else 12)
    fig.tight_layout(); fig.savefig(os.path.join(OUT, "R1_fig_mc_boxplot.png"), dpi=200); plt.close(fig)

    # F3 price sweeps
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.2), sharey=True)
    for ax, (what, ttl) in zip(axes, (("oil", "Waste cooking oil price"), ("ps", "Waste PS price"), ("spk", "HEFA-SPK price"))):
        d = sweeps[sweeps.price_varied == what]
        for lab, g in d.groupby("model_label"):
            sc, h2 = int(lab[2]), lab[4:]
            ax.plot(g.price_usd_per_kg, g.MFSP_usd_per_kg, marker="o", ms=3, label=plot_label(sc, h2))
        ax.axhline(parity, color="#b71c1c", ls="--", lw=1)
        ax.set_xlabel(ttl + " ($/kg)"); ax.legend(fontsize=7)
    axes[0].set_ylabel("MFSP ($/kg fuel)")
    if LABEL_TAG:
        fig.suptitle(LABEL_TAG.strip(), fontsize=8)
    fig.tight_layout(); fig.savefig(os.path.join(OUT, "R1_fig_price_sweeps.png"), dpi=200); plt.close(fig)


def main(simulate=None):
    import tea_model as tm
    simulate = simulate or tm.simulate_config
    parity = 3.10 / tm.to_gge(1.0, 1)
    note = ("MEASURED BASIS: Li et al. 2025 oil:PS = 2.5" if CASE == "Li25" else "EXTRAPOLATED SENSITIVITY: oil:PS = 3.4 (beyond Li et al. measured 2.5; yields scaled linearly; aromatics 23-25 vol%)")
    note += f" | PS-only route: Prajapati measured basis (400 C pyrolysis, vinyl-only Pd/C, EB-cut distillation); base blend {cp_blend_pct():g} vol% additive in HEFA-SPK; sensitivity 12-25 vol%"
    open(os.path.join(OUT, "CASE_NOTE.txt"), "w").write(note + "\n")
    print(f"Case {CASE}: oil:PS = {tm.OIL_TO_PS_RATIO}, liquid fraction {tm.SCENARIO1_LIQUID_FRACTION}")
    print(f"Fossil-jet parity = ${parity:.3f}/kg")
    print("[1/3] equal-product basis ..."); eq, cfgs, teas, ratio = equal_basis(tm, simulate, parity)
    print(f"      Sc2 (PS-only) feed scale for equal product = {ratio:.4f}")
    print("[2/3] price sweeps ..."); sweeps, be = price_sweeps(tm, cfgs, teas, parity)
    print("[2a] EB additive cost vs market ethylbenzene ..."); eb = eb_additive_cost(tm, cfgs, teas)
    print("[2c] blend aromatics sweep 15-25 vol% ..."); bs = blend_sweep(tm, simulate, parity); bp = blend_properties()
    print("[2b] oil:PS ratio sweep ..."); rs = ratio_sweep(tm, simulate, parity)
    print("[3/3] Monte Carlo ..."); S, samples_all = monte_carlo(tm, cfgs, teas, parity)
    figures(eq, sweeps, samples_all, parity)
    pd.set_option("display.width", 220)
    print(eq.round(3).to_string()); print(eb.round(3).to_string()); print(bs.round(3).to_string()); print(bp.round(3).drop(columns=['untested','assumptions']).to_string()); print(be.round(3).to_string()); print(rs.round(3).to_string()); print(S.round(3).to_string())
    print(f"\nOutputs in {OUT}")


if __name__ == "__main__":
    main()
